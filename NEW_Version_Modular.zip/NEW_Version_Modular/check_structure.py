#!/usr/bin/env python3
"""
Проверка структуры проекта Secure Pass Pro
"""

import os
import sys

# Цвета для вывода
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def print_header(text):
    print(f"\n{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}{text:^60}{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*60}{Colors.RESET}\n")

def print_ok(text):
    print(f"{Colors.GREEN}✅ {text}{Colors.RESET}")

def print_error(text):
    print(f"{Colors.RED}❌ {text}{Colors.RESET}")

def print_warning(text):
    print(f"{Colors.YELLOW}⚠️  {text}{Colors.RESET}")

def print_info(text):
    print(f"{Colors.BLUE}ℹ️  {text}{Colors.RESET}")

# Структура проекта
REQUIRED_FOLDERS = [
    "core",
    "gui",
    "gui/mixins",
    "security",
    "storage",
    "utils",
    "data",
    "resources",
    "logs",
]

REQUIRED_FILES = [
    "core/__init__.py",
    "core/generator.py",
    "gui/__init__.py",
    "gui/main_window.py",
    "gui/mixins/__init__.py",
    "gui/mixins/hibp_mixin.py",
    "gui/mixins/rgb_mixin.py",
    "gui/mixins/auto_lock_mixin.py",
    "gui/mixins/password_ops_mixin.py",
    "gui/mixins/master_mixin.py",
    "gui/mixins/settings_mixin.py",
    "gui/mixins/settings_window_mixin.py",
    "gui/mixins/dialogs_mixin.py",
    "gui/mixins/ui_setup_mixin.py",
    "gui/mixins/updater_mixin.py",
    "gui/mixins/name_generator_mixin.py",
    "gui/dialogs.py",
    "gui/widgets.py",
    "security/__init__.py",
    "security/master.py",
    "security/encryption.py",
    "security/clipboard.py",
    "security/panic.py",
    "security/antidebug.py",
    "storage/__init__.py",
    "storage/database.py",
    "storage/config.py",
    "utils/__init__.py",
    "utils/helpers.py",
    "utils/logger.py",
    "utils/paths.py",
    "utils/secure_file_ops.py",
    "utils/secure_memory.py",
    "utils/integrity_check.py",
    "utils/radius_manager.py",
    "localization/__init__.py",
    "localization/lang.py",
]

OPTIONAL_FILES = [
    "main.py",
    "__main__.py",
    "SecurePassPro.py",
    "app.py",
    "test_all_fixes.py",
    "check_structure.py",
    "config.example.json",
    "Computer Mouse Click.mp3",
    "DejaVuSans.ttf",
    "icon.ico",
    "app_icon.ico",
    "requirements.txt",
]

DATA_FILES = [
    "data/config.json",
    "data/passwords.db",
    "data/master.key",
    "data/db.salt",
    "data/machine.id",
    "data/key.version",
    "data/sqlcipher.salt",
]

RESOURCE_FILES = [
    "resources/public_key.pem",
    "resources/public_key.example.pem",
    "resources/private_key.pem",
]


def check_structure():
    """Проверяет структуру проекта"""
    print_header("🔍 ПРОВЕРКА СТРУКТУРЫ ПРОЕКТА")

    current_dir = os.getcwd()
    print_info(f"Текущая директория: {current_dir}\n")

    # Проверка обязательных папок
    print_header("📁 ПРОВЕРКА ПАПОК")
    missing_folders = []
    for folder in REQUIRED_FOLDERS:
        folder_path = os.path.join(current_dir, folder)
        if os.path.exists(folder_path) and os.path.isdir(folder_path):
            print_ok(f"Папка: {folder}")
        else:
            print_error(f"Папка: {folder} - ОТСУТСТВУЕТ")
            missing_folders.append(folder)

    # Проверка обязательных файлов
    print_header("📄 ПРОВЕРКА ОБЯЗАТЕЛЬНЫХ ФАЙЛОВ")
    missing_files = []
    for file in REQUIRED_FILES:
        file_path = os.path.join(current_dir, file)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            print_ok(f"Файл: {file}")
        else:
            print_error(f"Файл: {file} - ОТСУТСТВУЕТ")
            missing_files.append(file)

    # Проверка опциональных файлов
    print_header("📄 ПРОВЕРКА ОПЦИОНАЛЬНЫХ ФАЙЛОВ")
    found_optional = []
    for file in OPTIONAL_FILES:
        file_path = os.path.join(current_dir, file)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            print_ok(f"Файл: {file}")
            found_optional.append(file)
        else:
            print_warning(f"Файл: {file} - НЕ НАЙДЕН (опционально)")

    # Проверка файлов данных (не должны быть в Git)
    print_header("🔒 ПРОВЕРКА ФАЙЛОВ ДАННЫХ")
    for file in DATA_FILES:
        file_path = os.path.join(current_dir, file)
        if os.path.exists(file_path):
            size = os.path.getsize(file_path)
            print_ok(f"Файл: {file} ({size} байт) - существует")
        else:
            print_info(f"Файл: {file} - НЕ СУЩЕСТВУЕТ (создастся при запуске)")

    # Проверка ключей
    print_header("🔑 ПРОВЕРКА КЛЮЧЕЙ ШИФРОВАНИЯ")
    for file in RESOURCE_FILES:
        file_path = os.path.join(current_dir, file)
        if os.path.exists(file_path):
            size = os.path.getsize(file_path)
            print_ok(f"Файл: {file} ({size} байт)")
        else:
            print_warning(f"Файл: {file} - НЕ СУЩЕСТВУЕТ (создастся при первом запуске)")

    # Поиск главного файла запуска
    print_header("🚀 ПОИСК ГЛАВНОГО ФАЙЛА ЗАПУСКА")
    main_files = ["main.py", "__main__.py", "SecurePassPro.py", "app.py", "run.py"]
    found_main = None
    for main_file in main_files:
        if os.path.exists(os.path.join(current_dir, main_file)):
            found_main = main_file
            print_ok(f"Найден: {main_file}")
            break

    if not found_main:
        print_error("Не найден главный файл запуска!")
        print_info("Создайте main.py со следующим содержимым:")
        print("""
#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    import customtkinter as ctk
    from gui.main_window import SecurePassPro
    ctk.set_appearance_mode("System")
    ctk.set_default_color_theme("blue")
    app = SecurePassPro()
    app.mainloop()
""")

    # Итоги
    print_header("📊 ИТОГИ ПРОВЕРКИ")

    total_errors = len(missing_folders) + len(missing_files)
    total_warnings = len([f for f in OPTIONAL_FILES if f not in found_optional])

    print_info(f"Обязательные папки: {len(REQUIRED_FOLDERS) - len(missing_folders)}/{len(REQUIRED_FOLDERS)}")
    print_info(f"Обязательные файлы: {len(REQUIRED_FILES) - len(missing_files)}/{len(REQUIRED_FILES)}")
    print_info(f"Опциональные файлы найдено: {len(found_optional)}/{len(OPTIONAL_FILES)}")

    if total_errors == 0:
        print_ok("\n🎉 ВСЕ ОБЯЗАТЕЛЬНЫЕ ФАЙЛЫ НА МЕСТЕ!")
        if found_main:
            print_ok(f"✅ Программа готова к запуску: python {found_main}")
        else:
            print_warning("⚠️ Создайте main.py для запуска")
    else:
        print_error(f"\n❌ Найдено {total_errors} критических ошибок")
        print_info("Устраните ошибки перед запуском")

    if missing_folders:
        print_error(f"\nОтсутствующие папки: {missing_folders}")
    if missing_files:
        print_error(f"Отсутствующие файлы: {missing_files}")

    print()
    print_info("Нажмите Enter для выхода...")
    input()


if __name__ == "__main__":
    check_structure()
