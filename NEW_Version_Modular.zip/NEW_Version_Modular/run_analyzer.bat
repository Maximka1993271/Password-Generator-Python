@echo off
cd /d "C:\Users\Maksi\OneDrive\Рабочий стол\Secure Pass Pro"
python find_issues.py
pause