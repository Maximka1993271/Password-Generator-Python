@echo off
chcp 65001 >nul
title Secure Pass Pro - Анализатор кода
color 0A

echo ============================================================
echo    Secure Pass Pro v4.0 - Анализатор кода
echo ============================================================
echo.

:: Переход в директорию проекта
cd /d "C:\Users\Maksi\OneDrive\Рабочий стол\Secure Pass Pro"

:: Проверка наличия Python
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ОШИБКА] Python не найден!
    echo Скачайте Python: https://python.org
    pause
    exit /b 1
)

:: Показываем версию Python
echo Версия Python:
python --version
echo.

:: МЕНЮ ВЫБОРА
echo ============================================================
echo    ВЫБЕРИТЕ ДЕЙСТВИЕ:
echo ============================================================
echo.
echo   1  - Найти ошибки в коде
echo   2  - Исправить ошибки (АВТОМАТИЧЕСКИ)
echo   3  - Полная информация о проекте
echo   4  - Проверить структуру папок
echo   5  - ВСЁ ВМЕСТЕ
echo   6  - Выйти
echo.
echo ============================================================
echo.

set /p choice="Введите номер (1-6) и нажмите Enter: "

if "%choice%"=="1" goto find
if "%choice%"=="2" goto fix
if "%choice%"=="3" goto info
if "%choice%"=="4" goto structure
if "%choice%"=="5" goto all
if "%choice%"=="6" goto exit

echo Неверный выбор!
pause
goto menu

:find
cls
echo ============================================================
echo    ПОИСК ОШИБОК В КОДЕ
echo ============================================================
echo.
python find_issues.py
goto end

:fix
cls
echo ============================================================
echo    АВТОМАТИЧЕСКОЕ ИСПРАВЛЕНИЕ
echo ============================================================
echo.
echo ВНИМАНИЕ! Будут изменены файлы проекта!
echo.
set /p confirm="Вы уверены? (д/н): "
if /i not "%confirm%"=="д" goto end
python fix_issues.py
goto end

:info
cls
echo ============================================================
echo    ИНФОРМАЦИЯ О ПРОЕКТЕ
echo ============================================================
echo.
python project_info.py
goto end

:structure
cls
echo ============================================================
echo    ПРОВЕРКА СТРУКТУРЫ
echo ============================================================
echo.
python check_structure.py
goto end

:all
cls
echo ============================================================
echo    ПОЛНАЯ ПРОВЕРКА
echo ============================================================
echo.
echo [1/4] Проверка структуры...
python check_structure.py
if %errorlevel% neq 0 (
    echo ОШИБКА! Структура проекта нарушена!
    pause
    goto end
)
echo.
echo [2/4] Поиск ошибок...
python find_issues.py
echo.
echo [3/4] Сбор информации...
python project_info.py
echo.
echo [4/4] ПРОВЕРКА ЗАВЕРШЕНА!
echo.
goto end

:end
echo.
echo ============================================================
echo    ГОТОВО!
echo ============================================================
echo.
echo Нажмите любую клавишу для выхода...
pause >nul
exit /b 0

:exit
exit /b 0