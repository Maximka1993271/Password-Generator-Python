"""
Localization module - language support

Модуль локализации - поддержка языков
Модуль локалізації - підтримка мов
"""
from localization.lang import LANGUAGES

__all__ = ['LANGUAGES']