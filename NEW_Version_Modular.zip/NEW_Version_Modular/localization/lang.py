"""
Language dictionaries (RU, EN, UA)
with fallback language and missing key recovery
"""
from typing import Dict, Any, Optional, List, Tuple
from utils.logger import get_logger

logger = get_logger("lang")

# ==================== ОСНОВНЫЕ СЛОВАРИ ====================

LANGUAGES: Dict[str, Dict[str, str]] = {
    "RU": {
        # ==================== ОСНОВНОЕ ОКНО ====================
        "win_title": "Secure Pass Pro v4.0",
        "menu_title": "Меню",
        "len": "Длина",
        "author": "Автор: Максим Мельников",
        "upper": "Заглавные буквы",
        "lower": "Строчные буквы",
        "digits": "Цифры",
        "symb": "Спецсимволы",
        "ambig": "Исключить похожие (i, l, 1...)",
        "unambig": "Исключить не однозначные",
        "at_least": "Минимум 1 из каждой категории",
        "hide": "Скрывать символы",
        "no_repeat": "Избегать повторов символов подряд",
        
        # ==================== КНОПКИ МЕНЮ СО ЗНАЧКАМИ ====================
        "btn_gen": "🎲 Сгенерировать",
        "btn_name_gen": "👤 Генератор имён",
        "btn_copy": "📋 Копировать пароль",
        "btn_save": "💾 Сохранить в файл",
        "btn_open": "📂 Открыть файл",
        "btn_qr": "📱 QR-код пароль",
        "btn_hist": "📜 История",
        "btn_db": "🗄️ База паролей",
        "btn_hibp": "🔍 Проверить утечки",
        "btn_upd": "🔄 Обновить программу",
        "btn_about": "ℹ️ О программе",
        "btn_settings": "⚙️ Настройки",
        
        # ==================== ПОДСКАЗКИ (TOOLTIPS) ====================
        "tt_gen": "Создать новый случайный пароль",
        "tt_name_gen": "Генерация имён для SAMP RP, email, игр и других целей",
        "tt_copy": "Копировать в буфер (очистка через {0} сек)",
        "tt_save": "Сохранить текущий пароль в файл",
        "tt_open": "Открыть пароль из файла",
        "tt_qr": "Создать QR-код для быстрого сканирования",
        "tt_hist": "Показать последние 50 паролей",
        "tt_db": "Открыть хранилище паролей (SQLite)",
        "tt_hibp": "Проверить пароль в базе утечек Have I Been Pwned (k-anonymity)",
        "tt_upd": "Проверить наличие новой версии на GitHub",
        "tt_about": "Информация о разработчике и программе",
        "tt_settings": "Язык, звук и тема оформления",
        "tt_eye": "Показать / скрыть пароль",
        "tt_no_repeat": "Не допускать одинаковых символов подряд",
        "tt_auto_lock": "Автоматическая блокировка при бездействии",
        "tt_clip_timeout": "Через сколько секунд буфер обмена будет очищен",
        
        # ==================== ГЕНЕРАТОР ИМЁН ====================
        "name_gen_title": "Генератор имён",
        "name_gen_type_label": "Тип генерации",
        "name_gen_samp": "SAMP RP",
        "name_gen_email": "Email адрес",
        "name_gen_game": "Игровой ник",
        "name_gen_cool": "Крутой ник",
        "name_gen_beauty": "Красивый ник",
        "name_gen_short": "Короткий (3-5)",
        "name_gen_long": "Длинный (8+)",
        "name_gen_random": "Случайный",
        "name_gen_settings_label": "Настройки",
        "name_gen_gender": "Пол:",
        "name_gen_male": "Мужской",
        "name_gen_female": "Женский",
        "name_gen_random_gender": "Случайный",
        "name_gen_lang": "Язык:",
        "name_gen_russian": "Русский",
        "name_gen_english": "English",
        "name_gen_separator": "Разделитель:",
        "name_gen_separator_yes": "ДА (_)",
        "name_gen_separator_no": "НЕТ",
        "name_gen_count": "Количество:",
        "name_gen_generate_btn": "🎲 Сгенерировать",
        "name_gen_clear_btn": "🗑️ Очистить",
        "name_gen_copy_btn": "📋 Копировать всё",
        "name_gen_result_label": "Результат",
        
        # ==================== СТОЙКОСТЬ ПАРОЛЯ ====================
        "strength": "Стойкость: ~{0} вариантов",
        "crack_time": "{0}",
        "time_sec": "Несколько секунд на взлом",
        "time_day": "Дни на взлом",
        "time_year": "Года на взлом",
        "time_cent": "Столетия на взлом",
        "st_low": "Слабый пароль",
        "st_mid": "Средний пароль",
        "st_high": "Надёжный пароль",
        
        # ==================== НАСТРОЙКИ ====================
        "settings_title": "Настройки",
        "settings_lang": "Язык интерфейса",
        "settings_sound": "Звук приложения",
        "settings_theme": "Тема оформления",
        "settings_radius": "Закругление углов",
        "font_size": "Размер шрифта",
        "theme_sys": "Системная",
        "theme_dark": "Тёмная",
        "theme_light": "Светлая",
        "sound_on": "Звук: вкл",
        "sound_off": "Звук: выкл",
        "close": "Закрыть",
        "ok": "Ok",
        "cancel": "Отмена",
        "yes": "Да",
        "no": "Нет",
        
        # ==================== НАСТРОЙКИ - ВКЛАДКИ ====================
        "tab_design": "Дизайн",
        "tab_security": "Безопасность",
        "tab_general": "Общие",
        
        # ==================== НАСТРОЙКИ - RGB ====================
        "rgb_label": "🌈 RGB-подсветка",
        "rgb_on": "Вкл",
        "rgb_off": "Выкл",
        "rgb_speed": "Скорость RGB",
        "rgb_speed_slow": "Медленная",
        "rgb_speed_normal": "Нормальная",
        "rgb_speed_fast": "Быстрая",
        "rgb_width": "Толщина RGB",
        "rgb_width_thin": "Тонкая",
        "rgb_width_normal": "Средняя",
        "rgb_width_thick": "Толстая",
        
        # ==================== НАСТРОЙКИ - АВТОСОХРАНЕНИЕ ====================
        "auto_save": "Автосохранение",
        "auto_save_on": "✅ Включено",
        "auto_save_off": "❌ Выключено",
        "auto_save_enabled": "✅ Автосохранение включено!\nПароли будут сохраняться автоматически.",
        "auto_save_disabled": "❌ Автосохранение выключено.",
        "auto_save_label": "📁 Автосохранение",
        
        # ==================== НАСТРОЙКИ - АВТОБЛОКИРОВКА ====================
        "auto_lock": "Автоблокировка",
        "auto_lock_timeout": "Таймаут блокировки: {0} мин",
        "auto_lock_title": "Программа заблокирована",
        "unlock": "Разблокировать",
        
        # ==================== НАСТРОЙКИ - БУФЕР ОБМЕНА ====================
        "clip_timeout": "Очистка буфера: {0} сек",
        "clipboard_cleared": "✅ Буфер обмена очищен!",
        "clipboard_auto_clear": "Автоочистка буфера через {0} сек",
        "clear_clipboard": "Очистить буфер обмена",
        
        # ==================== МАСТЕР-ПАРОЛЬ ====================
        "master_title": "Мастер-пароль",
        "master_prompt": "Введите мастер-пароль для доступа к программе:",
        "master_set_title": "Установить мастер-пароль",
        "master_set_prompt": "Придумайте мастер-пароль:",
        "master_confirm": "Подтвердите мастер-пароль:",
        "master_mismatch": "Пароли не совпадают!",
        "master_wrong": "Неверный мастер-пароль! Попытка {0} из {1}.",
        "master_blocked": "Превышено число попыток. Программа закрыта.",
        "master_set_ok": "Мастер-пароль установлен!",
        "master_removed": "Мастер-пароль удалён!",
        "master_btn_set": "🔐 Установить мастер-пароль",
        "master_btn_remove": "🗑️ Удалить мастер-пароль",
        "master_current": "Статус:",
        "master_status_set": "Установлен",
        "master_status_not_set": "Не установлен",
        "master_remove_confirm": "Вы уверены, что хотите удалить мастер-пароль?\n\nВсе сохранённые пароли останутся, но шифрование будет отключено.",
        "master_remove_prompt": "Введите текущий мастер-пароль для подтверждения:",
        "master_not_set": "Мастер-пароль не установлен.",
        "master_already_set": "Мастер-пароль уже установлен!\n\nИспользуйте кнопку 'Удалить' для его удаления.",
        "master_set_error": "Не удалось установить мастер-пароль.",
        "master_remove_error": "Не удалось удалить мастер-пароль.",
        "master_status_text": "🔐 Мастер-пароль: установлен (Argon2id)",
        "master_status_not_set_text": "⚠️ Мастер-пароль: не установлен",
        
        # ==================== БАЗА ПАРОЛЕЙ ====================
        "db_title": "База паролей",
        "db_label_prompt": "Метка:",
        "db_saved": "Пароль сохранён в базу!",
        "db_empty": "База пуста...",
        "db_copy": "📋 Копировать",
        "db_delete": "🗑️ Удалить",
        "db_edit": "✏️ Изменить",
        "db_save_current": "💾 Сохранить текущий пароль",
        "db_no_pass": "Сначала сгенерируйте пароль!",
        "db_count": "Записей: {0}",
        "db_search": "Поиск...",
        "db_del_confirm": "Удалить эту запись?",
        "db_edit_title": "Редактировать запись",
        "db_edit_label": "Метка:",
        "db_edit_pass": "Пароль:",
        "db_save_success": "Пароль сохранён",
        "db_save_error": "Ошибка сохранения",
        "db_delete_success": "Запись удалена",
        "db_delete_error": "Ошибка удаления",
        "db_search_no_results": "Ничего не найдено",
        
        # ==================== ИСТОРИЯ ====================
        "hist_empty": "История пуста...",
        "btn_clear_hist": "🗑️ Очистить историю",
        
        # ==================== PDF ====================
        "pdf_date": "Дата",
        "pdf_pass": "Пароль",
        "pdf_generate": "📄 Создать PDF",
        "cancel_generate": "❌ Отмена генерации",
        "export_pdf_success": "PDF экспортирован",
        "export_pdf_error": "Ошибка экспорта PDF",
        
        # ==================== QR-КОД ====================
        "qr_closes_in": "Окно закроется через",
        "seconds_short": "сек",
        
        # ==================== БЛОКИРОВКА ====================
        "lock_screen_title": "Введите мастер-пароль",
        "lock_screen_attempts": "Осталось попыток: {0}",
        "lock_screen_blocked": "Доступ заблокирован на {0} сек",
        "lock_wait": "Подождите",
        "lock_max_attempts": "Превышено число попыток. Приложение закрывается...",
        
        # ==================== HIBP (ПРОВЕРКА УТЕЧЕК) ====================
        "hibp_no_password": "Сначала сгенерируйте пароль.",
        "hibp_checking": "Проверка...",
        "hibp_safe": "✅ Пароль не найден в базах утечек.\n\nМожно использовать.",
        "hibp_found": "❌ Пароль найден {count} раз(а) в утечках!\n\nСгенерируйте новый пароль.",
        "hibp_error": "⚠️ Не удалось связаться с сервером.\nПроверьте интернет-соединение.",
        "hibp_error_title": "Ошибка проверки",
        "hibp_safe_title": "Пароль безопасен",
        "hibp_found_title": "ВНИМАНИЕ! Пароль скомпрометирован",
        "hibp_warning": "⚠️ Рекомендуется немедленно сменить пароль!",
        
        # ==================== ОБНОВЛЕНИЯ ====================
        "update_check": "Проверка обновлений",
        "update_available": "Доступна новая версия v{0}",
        "update_not_available": "Установлена последняя версия",
        "update_available_title": "Доступно обновление",
        "update_confirm_title": "Обновление",
        "update_confirm_message": "Установить обновление?\n\nПрограмма будет перезапущена.",
        "update_error": "Не удалось установить обновление.",
        
        # ==================== БЕЗОПАСНОСТЬ ====================
        "security": "Безопасность",
        "security_audit_pass": "Проверка безопасности пройдена",
        "security_audit_fail": "Обнаружены проблемы безопасности",
        "wiki_link": "Читать Security Logic Wiki",
        "rate_limit_warning": "⚠️ Внимание: Режим 'без повторов' снижает криптостойкость пароля",
        
        # ==================== SQLCIPHER ====================
        "sqlcipher_enabled": "✅ SQLCipher включён",
        "sqlcipher_disabled": "❌ SQLCipher отключён (используется стандартное шифрование)",
        
        # ==================== ОШИБКИ ====================
        "err_cat": "Выберите хотя бы одну категорию!",
        "err_pool_small": "Слишком мало доступных символов!",
        "err_save": "Ошибка сохранения: {0}",
        "err_open": "Не удалось прочитать файл: {0}",
        "err_unsupported": "Неподдерживаемый тип файла: {0}",
        "err_integrity": "Критическая ошибка: Файл поврежден!",
        "err_no_repeat": "Не удалось создать пароль без повторов.",
        "err_no_repeat_fallback": "\nИспользован пароль с повторами.",
        "err_title": "Ошибка",
        "err_encrypt": "Ошибка шифрования",
        "err_decrypt": "Ошибка дешифрования",
        "err_database": "Ошибка базы данных",
        "err_network": "Ошибка сети",
        "err_permission": "Ошибка доступа",
        
        # ==================== ЦЕЛОСТНОСТЬ ФАЙЛА ====================
        "integrity_warn": "⚠ Файл мог быть изменён. Продолжить?",
        "integrity_fail": "🚨 Файл повреждён! Открытие отменено.",
        "integrity_ok": "✅ Целостность файла подтверждена.",
        
        # ==================== О ПРОГРАММЕ ====================
        "about_text": "Профессиональный инструмент для генерации паролей.\nИспользует криптографически стойкие алгоритмы.\n\n✅ Argon2id\n✅ SQLite хранилище\n✅ Генератор имён (8 режимов)\n✅ RGB анимация\n✅ 50+ исправлений",
        
        # ==================== СТАТУСЫ ====================
        "status_ok": "✅ Готово",
        "status_error": "❌ Ошибка",
        "status_warning": "⚠️ Предупреждение",
        "please_wait": "Пожалуйста, подождите...",
        "copied": "Скопировано! ({0}с)",
        
        # ==================== DICEWARE ====================
        "diceware": "Diceware режим",
        "diceware_word_count": "Количество слов",
        "diceware_separator": "Разделитель",
        "diceware_words": "Слова",
        
        # ==================== ПАРОЛЬ ====================
        "password_strength_low": "Слабый пароль",
        "password_strength_medium": "Средний пароль",
        "password_strength_high": "Надёжный пароль",
        
        # ==================== ГЕНЕРАТОР ИМЁН - ДОПОЛНИТЕЛЬНЫЕ ====================
        "name_gen_copied": "✅ Скопировано {0} имён!",
        "name_gen_generating": "Генерация...",
        "name_gen_error": "Ошибка генерации имён",
    },
    
    "EN": {
        # ==================== MAIN WINDOW ====================
        "win_title": "Secure Pass Pro v4.0",
        "menu_title": "Menu",
        "len": "Length",
        "author": "Author: Maxim Melnikov",
        "upper": "Uppercase",
        "lower": "Lowercase",
        "digits": "Digits",
        "symb": "Special symbols",
        "ambig": "Exclude ambiguous (i, l, 1...)",
        "unambig": "Exclude non-obvious",
        "at_least": "Min 1 from each category",
        "hide": "Hide symbols",
        "no_repeat": "Avoid consecutive repeated characters",
        
        # ==================== MENU BUTTONS WITH ICONS ====================
        "btn_gen": "🎲 Generate",
        "btn_name_gen": "👤 Name Generator",
        "btn_copy": "📋 Copy password",
        "btn_save": "💾 Save to file",
        "btn_open": "📂 Open file",
        "btn_qr": "📱 Password QR-code",
        "btn_hist": "📜 History",
        "btn_db": "🗄️ Password vault",
        "btn_hibp": "🔍 Check leaks",
        "btn_upd": "🔄 Update program",
        "btn_about": "ℹ️ About",
        "btn_settings": "⚙️ Settings",
        
        # ==================== TOOLTIPS ====================
        "tt_gen": "Create a new random password",
        "tt_name_gen": "Generate names for SAMP RP, email, games and other purposes",
        "tt_copy": "Copy to clipboard (clears in {0} sec)",
        "tt_save": "Save current password to file",
        "tt_open": "Open password from file",
        "tt_qr": "Create a QR code for quick scanning",
        "tt_hist": "Show last 50 generated passwords",
        "tt_db": "Open password vault (SQLite)",
        "tt_hibp": "Check password against Have I Been Pwned leak database (k-anonymity)",
        "tt_upd": "Check for new version on GitHub",
        "tt_about": "Developer and program info",
        "tt_settings": "Language, sound and theme",
        "tt_eye": "Show / hide password",
        "tt_no_repeat": "Prevent the same character appearing consecutively",
        "tt_auto_lock": "Auto lock on inactivity",
        "tt_clip_timeout": "Seconds before clipboard is cleared",
        
        # ==================== NAME GENERATOR ====================
        "name_gen_title": "Name Generator",
        "name_gen_type_label": "Generation type",
        "name_gen_samp": "SAMP RP",
        "name_gen_email": "Email address",
        "name_gen_game": "Game nickname",
        "name_gen_cool": "Cool nickname",
        "name_gen_beauty": "Beautiful nickname",
        "name_gen_short": "Short (3-5)",
        "name_gen_long": "Long (8+)",
        "name_gen_random": "Random",
        "name_gen_settings_label": "Settings",
        "name_gen_gender": "Gender:",
        "name_gen_male": "Male",
        "name_gen_female": "Female",
        "name_gen_random_gender": "Random",
        "name_gen_lang": "Language:",
        "name_gen_russian": "Russian",
        "name_gen_english": "English",
        "name_gen_separator": "Separator:",
        "name_gen_separator_yes": "YES (_)",
        "name_gen_separator_no": "NO",
        "name_gen_count": "Count:",
        "name_gen_generate_btn": "🎲 Generate",
        "name_gen_clear_btn": "🗑️ Clear",
        "name_gen_copy_btn": "📋 Copy all",
        "name_gen_result_label": "Result",
        
        # ==================== PASSWORD STRENGTH ====================
        "strength": "Strength: ~{0} combos",
        "crack_time": "{0}",
        "time_sec": "A few seconds to crack",
        "time_day": "Days to crack",
        "time_year": "Years to crack",
        "time_cent": "Centuries to crack",
        "st_low": "Weak password",
        "st_mid": "Medium password",
        "st_high": "Strong password",
        
        # ==================== SETTINGS ====================
        "settings_title": "Settings",
        "settings_lang": "Interface language",
        "settings_sound": "App sound",
        "settings_theme": "Appearance theme",
        "settings_radius": "Corner radius",
        "font_size": "Font size",
        "theme_sys": "System",
        "theme_dark": "Dark",
        "theme_light": "Light",
        "sound_on": "Sound: on",
        "sound_off": "Sound: off",
        "close": "Close",
        "ok": "Ok",
        "cancel": "Cancel",
        "yes": "Yes",
        "no": "No",
        
        # ==================== SETTINGS - TABS ====================
        "tab_design": "Design",
        "tab_security": "Security",
        "tab_general": "General",
        
        # ==================== SETTINGS - RGB ====================
        "rgb_label": "🌈 RGB border",
        "rgb_on": "On",
        "rgb_off": "Off",
        "rgb_speed": "RGB Speed",
        "rgb_speed_slow": "Slow",
        "rgb_speed_normal": "Normal",
        "rgb_speed_fast": "Fast",
        "rgb_width": "RGB Width",
        "rgb_width_thin": "Thin",
        "rgb_width_normal": "Normal",
        "rgb_width_thick": "Thick",
        
        # ==================== SETTINGS - AUTO SAVE ====================
        "auto_save": "Auto save",
        "auto_save_on": "✅ On",
        "auto_save_off": "❌ Off",
        "auto_save_enabled": "✅ Auto save enabled!\nPasswords will be saved automatically.",
        "auto_save_disabled": "❌ Auto save disabled.",
        "auto_save_label": "📁 Auto save",
        
        # ==================== SETTINGS - AUTO LOCK ====================
        "auto_lock": "Auto lock",
        "auto_lock_timeout": "Lock timeout: {0} min",
        "auto_lock_title": "Program locked",
        "unlock": "Unlock",
        
        # ==================== SETTINGS - CLIPBOARD ====================
        "clip_timeout": "Clipboard clear: {0} sec",
        "clipboard_cleared": "✅ Clipboard cleared!",
        "clipboard_auto_clear": "Auto clear clipboard in {0} sec",
        "clear_clipboard": "Clear clipboard",
        
        # ==================== MASTER PASSWORD ====================
        "master_title": "Master password",
        "master_prompt": "Enter master password to access the program:",
        "master_set_title": "Set master password",
        "master_set_prompt": "Create a master password:",
        "master_confirm": "Confirm master password:",
        "master_mismatch": "Passwords do not match!",
        "master_wrong": "Wrong master password! Attempt {0} of {1}.",
        "master_blocked": "Too many failed attempts. Program closed.",
        "master_set_ok": "Master password has been set!",
        "master_removed": "Master password has been removed!",
        "master_btn_set": "🔐 Set master password",
        "master_btn_remove": "🗑️ Remove master password",
        "master_current": "Status:",
        "master_status_set": "Set",
        "master_status_not_set": "Not set",
        "master_remove_confirm": "Are you sure you want to remove the master password?\n\nAll saved passwords will remain, but encryption will be disabled.",
        "master_remove_prompt": "Enter current master password to confirm:",
        "master_not_set": "Master password is not set.",
        "master_already_set": "Master password is already set!\n\nUse 'Remove' button to delete it.",
        "master_set_error": "Could not set master password.",
        "master_remove_error": "Could not remove master password.",
        "master_status_text": "🔐 Master password: set (Argon2id)",
        "master_status_not_set_text": "⚠️ Master password: not set",
        
        # ==================== PASSWORD DATABASE ====================
        "db_title": "Password vault",
        "db_label_prompt": "Label:",
        "db_saved": "Password saved to vault!",
        "db_empty": "Vault is empty...",
        "db_copy": "📋 Copy",
        "db_delete": "🗑️ Delete",
        "db_edit": "✏️ Edit",
        "db_save_current": "💾 Save current password",
        "db_no_pass": "Generate a password first!",
        "db_count": "Records: {0}",
        "db_search": "Search...",
        "db_del_confirm": "Delete this record?",
        "db_edit_title": "Edit record",
        "db_edit_label": "Label:",
        "db_edit_pass": "Password:",
        "db_save_success": "Password saved",
        "db_save_error": "Save error",
        "db_delete_success": "Record deleted",
        "db_delete_error": "Delete error",
        "db_search_no_results": "No results found",
        
        # ==================== HISTORY ====================
        "hist_empty": "History is empty...",
        "btn_clear_hist": "🗑️ Clear history",
        
        # ==================== PDF ====================
        "pdf_date": "Date",
        "pdf_pass": "Password",
        "pdf_generate": "📄 Generate PDF",
        "cancel_generate": "❌ Cancel generation",
        "export_pdf_success": "PDF exported",
        "export_pdf_error": "PDF export error",
        
        # ==================== QR CODE ====================
        "qr_closes_in": "Window closes in",
        "seconds_short": "sec",
        
        # ==================== LOCK SCREEN ====================
        "lock_screen_title": "Enter master password",
        "lock_screen_attempts": "Attempts remaining: {0}",
        "lock_screen_blocked": "Access blocked for {0} sec",
        "lock_wait": "Please wait",
        "lock_max_attempts": "Too many failed attempts. Application will close...",
        
        # ==================== HIBP ====================
        "hibp_no_password": "Generate a password first.",
        "hibp_checking": "Checking...",
        "hibp_safe": "✅ Password not found in any breach databases.\n\nSafe to use.",
        "hibp_found": "❌ Password found {count} time(s) in breaches!\n\nGenerate a new password.",
        "hibp_error": "⚠️ Could not reach the server.\nCheck your internet connection.",
        "hibp_error_title": "Check error",
        "hibp_safe_title": "Password is safe",
        "hibp_found_title": "WARNING! Password compromised",
        "hibp_warning": "⚠️ It is recommended to change your password immediately!",
        
        # ==================== UPDATES ====================
        "update_check": "Check for updates",
        "update_available": "New version v{0} available",
        "update_not_available": "Latest version installed",
        "update_available_title": "Update available",
        "update_confirm_title": "Update",
        "update_confirm_message": "Install update?\n\nThe program will be restarted.",
        "update_error": "Failed to install update.",
        
        # ==================== SECURITY ====================
        "security": "Security",
        "security_audit_pass": "Security check passed",
        "security_audit_fail": "Security issues detected",
        "wiki_link": "Read Security Logic Wiki",
        "rate_limit_warning": "⚠️ Warning: 'No repeats' mode reduces password cryptographic strength",
        
        # ==================== SQLCIPHER ====================
        "sqlcipher_enabled": "✅ SQLCipher enabled",
        "sqlcipher_disabled": "❌ SQLCipher disabled (using standard encryption)",
        
        # ==================== ERRORS ====================
        "err_cat": "Select at least one category!",
        "err_pool_small": "Too few available characters!",
        "err_save": "Save failed: {0}",
        "err_open": "Could not read file: {0}",
        "err_unsupported": "Unsupported file type: {0}",
        "err_integrity": "Critical error: File corrupted!",
        "err_no_repeat": "Could not generate password without repeats.",
        "err_no_repeat_fallback": "\nPassword with repeats used.",
        "err_title": "Error",
        "err_encrypt": "Encryption error",
        "err_decrypt": "Decryption error",
        "err_database": "Database error",
        "err_network": "Network error",
        "err_permission": "Permission error",
        
        # ==================== FILE INTEGRITY ====================
        "integrity_warn": "⚠ File may have been modified. Continue?",
        "integrity_fail": "🚨 File corrupted! Opening cancelled.",
        "integrity_ok": "✅ File integrity verified.",
        
        # ==================== ABOUT ====================
        "about_text": "Professional password generation tool.\nUses cryptographically secure algorithms.\n\n✅ Argon2id\n✅ SQLite storage\n✅ Name generator (8 modes)\n✅ RGB animation\n✅ 50+ fixes",
        
        # ==================== STATUS ====================
        "status_ok": "✅ Done",
        "status_error": "❌ Error",
        "status_warning": "⚠️ Warning",
        "please_wait": "Please wait...",
        "copied": "Copied! ({0}s)",
        
        # ==================== DICEWARE ====================
        "diceware": "Diceware mode",
        "diceware_word_count": "Word count",
        "diceware_separator": "Separator",
        "diceware_words": "Words",
        
        # ==================== PASSWORD ====================
        "password_strength_low": "Weak password",
        "password_strength_medium": "Medium password",
        "password_strength_high": "Strong password",
        
        # ==================== NAME GENERATOR - EXTRA ====================
        "name_gen_copied": "✅ Copied {0} names!",
        "name_gen_generating": "Generating...",
        "name_gen_error": "Name generation error",
    },
    
    "UA": {
        # ==================== ГОЛОВНЕ ВІКНО ====================
        "win_title": "Secure Pass Pro v4.0",
        "menu_title": "Меню",
        "len": "Довжина",
        "author": "Автор: Максим Мельніков",
        "upper": "Великі літери",
        "lower": "Малі літери",
        "digits": "Цифри",
        "symb": "Спецсимволи",
        "ambig": "Виключити схожі (i, l, 1...)",
        "unambig": "Виключити неоднозначні",
        "at_least": "Мінімум 1 з кожної категорії",
        "hide": "Приховувати символи",
        "no_repeat": "Уникати повторів символів поспіль",
        
        # ==================== КНОПКИ МЕНЮ ЗІ ЗНАЧКАМИ ====================
        "btn_gen": "🎲 Згенерувати",
        "btn_name_gen": "👤 Генератор імен",
        "btn_copy": "📋 Копіювати пароль",
        "btn_save": "💾 Зберегти у файл",
        "btn_open": "📂 Відкрити файл",
        "btn_qr": "📱 QR-код пароля",
        "btn_hist": "📜 Історія",
        "btn_db": "🗄️ База паролів",
        "btn_hibp": "🔍 Перевірити витоки",
        "btn_upd": "🔄 Оновити програму",
        "btn_about": "ℹ️ Про програму",
        "btn_settings": "⚙️ Налаштування",
        
        # ==================== ПІДКАЗКИ (TOOLTIPS) ====================
        "tt_gen": "Створити новий випадковий пароль",
        "tt_name_gen": "Генерація імен для SAMP RP, email, ігор та інших цілей",
        "tt_copy": "Копіювати в буфер (очищення через {0} сек)",
        "tt_save": "Зберегти поточний пароль у файл",
        "tt_open": "Відкрити пароль з файлу",
        "tt_qr": "Створити QR-код для швидкого сканування",
        "tt_hist": "Показувати останні 50 паролів",
        "tt_db": "Відкрити сховище паролів (SQLite)",
        "tt_hibp": "Перевірити пароль у базі витоків Have I Been Pwned (k-anonymity)",
        "tt_upd": "Перевірити наявність нової версії на GitHub",
        "tt_about": "Інформація про розробника та програму",
        "tt_settings": "Мова, звук та тема оформлення",
        "tt_eye": "Показати / приховати пароль",
        "tt_no_repeat": "Не допускати однакових символів підряд",
        "tt_auto_lock": "Автоматичне блокування при бездіяльності",
        "tt_clip_timeout": "Через скільки секунд буфер обміну буде очищено",
        
        # ==================== ГЕНЕРАТОР ІМЕН ====================
        "name_gen_title": "Генератор імен",
        "name_gen_type_label": "Тип генерації",
        "name_gen_samp": "SAMP RP",
        "name_gen_email": "Email адреса",
        "name_gen_game": "Ігровий нік",
        "name_gen_cool": "Крутий нік",
        "name_gen_beauty": "Красивий нік",
        "name_gen_short": "Короткий (3-5)",
        "name_gen_long": "Довгий (8+)",
        "name_gen_random": "Випадковий",
        "name_gen_settings_label": "Налаштування",
        "name_gen_gender": "Стать:",
        "name_gen_male": "Чоловіча",
        "name_gen_female": "Жіноча",
        "name_gen_random_gender": "Випадкова",
        "name_gen_lang": "Мова:",
        "name_gen_russian": "Російська",
        "name_gen_english": "English",
        "name_gen_separator": "Розділювач:",
        "name_gen_separator_yes": "ТАК (_)",
        "name_gen_separator_no": "НІ",
        "name_gen_count": "Кількість:",
        "name_gen_generate_btn": "🎲 Згенерувати",
        "name_gen_clear_btn": "🗑️ Очистити",
        "name_gen_copy_btn": "📋 Копіювати всі",
        "name_gen_result_label": "Результат",
        
        # ==================== СТІЙКІСТЬ ПАРОЛЯ ====================
        "strength": "Стійкість: ~{0} варіантів",
        "crack_time": "{0}",
        "time_sec": "Кілька секунд на злам",
        "time_day": "Дні на злам",
        "time_year": "Роки на злам",
        "time_cent": "Століття на злам",
        "st_low": "Слабкий пароль",
        "st_mid": "Середній пароль",
        "st_high": "Надійний пароль",
        
        # ==================== НАЛАШТУВАННЯ ====================
        "settings_title": "Налаштування",
        "settings_lang": "Мова інтерфейсу",
        "settings_sound": "Звук програми",
        "settings_theme": "Тема оформлення",
        "settings_radius": "Закруглення кутів",
        "font_size": "Розмір шрифту",
        "theme_sys": "Системна",
        "theme_dark": "Темна",
        "theme_light": "Світла",
        "sound_on": "Звук: увімк",
        "sound_off": "Звук: вимк",
        "close": "Закрити",
        "ok": "Гаразд",
        "cancel": "Скасувати",
        "yes": "Так",
        "no": "Ні",
        
        # ==================== НАЛАШТУВАННЯ - ВКЛАДКИ ====================
        "tab_design": "Дизайн",
        "tab_security": "Безпека",
        "tab_general": "Загальні",
        
        # ==================== НАЛАШТУВАННЯ - RGB ====================
        "rgb_label": "🌈 RGB-підсвітка",
        "rgb_on": "Увімк",
        "rgb_off": "Вимк",
        "rgb_speed": "Швидкість RGB",
        "rgb_speed_slow": "Повільна",
        "rgb_speed_normal": "Нормальна",
        "rgb_speed_fast": "Швидка",
        "rgb_width": "Товщина RGB",
        "rgb_width_thin": "Тонка",
        "rgb_width_normal": "Середня",
        "rgb_width_thick": "Товста",
        
        # ==================== НАЛАШТУВАННЯ - АВТОЗБЕРЕЖЕННЯ ====================
        "auto_save": "Автозбереження",
        "auto_save_on": "✅ Увімкнено",
        "auto_save_off": "❌ Вимкнено",
        "auto_save_enabled": "✅ Автозбереження увімкнено!\nПаролі зберігатимуться автоматично.",
        "auto_save_disabled": "❌ Автозбереження вимкнено.",
        "auto_save_label": "📁 Автозбереження",
        
        # ==================== НАЛАШТУВАННЯ - АВТОБЛОКУВАННЯ ====================
        "auto_lock": "Автоблокування",
        "auto_lock_timeout": "Таймаут блокування: {0} хв",
        "auto_lock_title": "Програму заблоковано",
        "unlock": "Розблокувати",
        
        # ==================== НАЛАШТУВАННЯ - БУФЕР ОБМІНУ ====================
        "clip_timeout": "Очищення буфера: {0} сек",
        "clipboard_cleared": "✅ Буфер обміну очищено!",
        "clipboard_auto_clear": "Автоочищення буфера через {0} сек",
        "clear_clipboard": "Очистити буфер обміну",
        
        # ==================== МАЙСТЕР-ПАРОЛЬ ====================
        "master_title": "Майстер-пароль",
        "master_prompt": "Введіть майстер-пароль для доступу до програми:",
        "master_set_title": "Встановити майстер-пароль",
        "master_set_prompt": "Придумайте майстер-пароль:",
        "master_confirm": "Підтвердіть майстер-пароль:",
        "master_mismatch": "Паролі не збігаються!",
        "master_wrong": "Невірний майстер-пароль! Спроба {0} з {1}.",
        "master_blocked": "Перевищено кількість спроб. Програму закрито.",
        "master_set_ok": "Майстер-пароль встановлено!",
        "master_removed": "Майстер-пароль видалено!",
        "master_btn_set": "🔐 Встановити майстер-пароль",
        "master_btn_remove": "🗑️ Видалити майстер-пароль",
        "master_current": "Статус:",
        "master_status_set": "Встановлено",
        "master_status_not_set": "Не встановлено",
        "master_remove_confirm": "Ви впевнені, що хочете видалити майстер-пароль?\n\nВсі збережені паролі залишаться, але шифрування буде вимкнено.",
        "master_remove_prompt": "Введіть поточний майстер-пароль для підтвердження:",
        "master_not_set": "Майстер-пароль не встановлено.",
        "master_already_set": "Майстер-пароль вже встановлено!\n\nВикористовуйте кнопку 'Видалити' для його видалення.",
        "master_set_error": "Не вдалося встановити майстер-пароль.",
        "master_remove_error": "Не вдалося видалити майстер-пароль.",
        "master_status_text": "🔐 Майстер-пароль: встановлено (Argon2id)",
        "master_status_not_set_text": "⚠️ Майстер-пароль: не встановлено",
        
        # ==================== БАЗА ПАРОЛІВ ====================
        "db_title": "База паролів",
        "db_label_prompt": "Мітка:",
        "db_saved": "Пароль збережено до бази!",
        "db_empty": "База порожня...",
        "db_copy": "📋 Копіювати",
        "db_delete": "🗑️ Видалити",
        "db_edit": "✏️ Змінити",
        "db_save_current": "💾 Зберегти поточний пароль",
        "db_no_pass": "Спочатку згенеруйте пароль!",
        "db_count": "Записів: {0}",
        "db_search": "Пошук...",
        "db_del_confirm": "Видалити цей запис?",
        "db_edit_title": "Редагувати запис",
        "db_edit_label": "Мітка:",
        "db_edit_pass": "Пароль:",
        "db_save_success": "Пароль збережено",
        "db_save_error": "Помилка збереження",
        "db_delete_success": "Запис видалено",
        "db_delete_error": "Помилка видалення",
        "db_search_no_results": "Нічого не знайдено",
        
        # ==================== ІСТОРІЯ ====================
        "hist_empty": "Історія порожня...",
        "btn_clear_hist": "🗑️ Очистити історію",
        
        # ==================== PDF ====================
        "pdf_date": "Дата",
        "pdf_pass": "Пароль",
        "pdf_generate": "📄 Створити PDF",
        "cancel_generate": "❌ Скасувати генерацію",
        "export_pdf_success": "PDF експортовано",
        "export_pdf_error": "Помилка експорту PDF",
        
        # ==================== QR-КОД ====================
        "qr_closes_in": "Вікно закриється через",
        "seconds_short": "сек",
        
        # ==================== БЛОКУВАННЯ ====================
        "lock_screen_title": "Введіть майстер-пароль",
        "lock_screen_attempts": "Залишилось спроб: {0}",
        "lock_screen_blocked": "Доступ заблоковано на {0} сек",
        "lock_wait": "Зачекайте",
        "lock_max_attempts": "Перевищено кількість спроб. Додаток закривається...",
        
        # ==================== HIBP (ПЕРЕВІРКА ВИТОКІВ) ====================
        "hibp_no_password": "Спочатку згенеруйте пароль.",
        "hibp_checking": "Перевірка...",
        "hibp_safe": "✅ Пароль не знайдено в базах витоків.\n\nМожна використовувати.",
        "hibp_found": "❌ Пароль знайдено {count} раз(и) у витоках!\n\nЗгенеруйте новий пароль.",
        "hibp_error": "⚠️ Не вдалося зв'язатися з сервером.\nПеревірте інтернет-з'єднання.",
        "hibp_error_title": "Помилка перевірки",
        "hibp_safe_title": "Пароль безпечний",
        "hibp_found_title": "УВАГА! Пароль скомпрометовано",
        "hibp_warning": "⚠️ Рекомендується негайно змінити пароль!",
        
        # ==================== ОНОВЛЕННЯ ====================
        "update_check": "Перевірка оновлень",
        "update_available": "Доступна нова версія v{0}",
        "update_not_available": "Встановлено останню версію",
        "update_available_title": "Доступно оновлення",
        "update_confirm_title": "Оновлення",
        "update_confirm_message": "Встановити оновлення?\n\nПрограма буде перезапущена.",
        "update_error": "Не вдалося встановити оновлення.",
        
        # ==================== БЕЗПЕКА ====================
        "security": "Безпека",
        "security_audit_pass": "Перевірку безпеки пройдено",
        "security_audit_fail": "Виявлено проблеми безпеки",
        "wiki_link": "Читати Security Logic Wiki",
        "rate_limit_warning": "⚠️ Увага: Режим 'без повторів' знижує криптостійкість пароля",
        
        # ==================== SQLCIPHER ====================
        "sqlcipher_enabled": "✅ SQLCipher увімкнено",
        "sqlcipher_disabled": "❌ SQLCipher вимкнено (використовується стандартне шифрування)",
        
        # ==================== ПОМИЛКИ ====================
        "err_cat": "Виберіть хоча б одну категорію!",
        "err_pool_small": "Занадто мало доступних символів!",
        "err_save": "Помилка збереження: {0}",
        "err_open": "Не вдалося прочитати файл: {0}",
        "err_unsupported": "Непідтримуваний тип файлу: {0}",
        "err_integrity": "Критична помилка: Файл пошкоджено!",
        "err_no_repeat": "Не вдалося створити пароль без повторів.",
        "err_no_repeat_fallback": "\nВикористано пароль з повторами.",
        "err_title": "Помилка",
        "err_encrypt": "Помилка шифрування",
        "err_decrypt": "Помилка дешифрування",
        "err_database": "Помилка бази даних",
        "err_network": "Помилка мережі",
        "err_permission": "Помилка доступу",
        
        # ==================== ЦІЛІСНІСТЬ ФАЙЛУ ====================
        "integrity_warn": "⚠ Файл міг бути змінений. Продовжити?",
        "integrity_fail": "🚨 Файл пошкоджено! Відкриття скасовано.",
        "integrity_ok": "✅ Цілісність файлу підтверджено.",
        
        # ==================== ПРО ПРОГРАМУ ====================
        "about_text": "Професійний інструмент для генерації паролів.\nВикористовує криптографічно стійкі алгоритми.\n\n✅ Argon2id\n✅ SQLite сховище\n✅ Генератор імен (8 режимів)\n✅ RGB анімація\n✅ 50+ виправлень",
        
        # ==================== СТАТУСИ ====================
        "status_ok": "✅ Готово",
        "status_error": "❌ Помилка",
        "status_warning": "⚠️ Попередження",
        "please_wait": "Будь ласка, зачекайте...",
        "copied": "Скопійовано! ({0}с)",
        
        # ==================== DICEWARE ====================
        "diceware": "Diceware режим",
        "diceware_word_count": "Кількість слів",
        "diceware_separator": "Розділювач",
        "diceware_words": "Слова",
        
        # ==================== ПАРОЛЬ ====================
        "password_strength_low": "Слабкий пароль",
        "password_strength_medium": "Середній пароль",
        "password_strength_high": "Надійний пароль",
        
        # ==================== ГЕНЕРАТОР ІМЕН - ДОДАТКОВІ ====================
        "name_gen_copied": "✅ Скопійовано {0} імен!",
        "name_gen_generating": "Генерація...",
        "name_gen_error": "Помилка генерації імен",
    }
}


# ==================== FALLBACK И ВОССТАНОВЛЕНИЕ КЛЮЧЕЙ ====================

DEFAULT_LANGUAGE = "RU"
SUPPORTED_LANGUAGES = ["RU", "EN", "UA"]


class LanguageManager:
    """Менеджер языков с fallback и восстановлением отсутствующих ключей"""
    
    _instance = None
    _current_lang: str = DEFAULT_LANGUAGE
    _fallback_lang: str = DEFAULT_LANGUAGE
    _missing_keys_cache: Dict[str, List[str]] = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @classmethod
    def set_language(cls, lang_code: str) -> bool:
        if lang_code in SUPPORTED_LANGUAGES:
            cls._current_lang = lang_code
            logger.debug(f"Language set to: {lang_code}")
            return True
        logger.warning(f"Unsupported language: {lang_code}")
        return False
    
    @classmethod
    def set_fallback(cls, lang_code: str) -> bool:
        if lang_code in SUPPORTED_LANGUAGES:
            cls._fallback_lang = lang_code
            logger.debug(f"Fallback language set to: {lang_code}")
            return True
        return False
    
    @classmethod
    def get_current_lang(cls) -> str:
        return cls._current_lang
    
    @classmethod
    def get_fallback_lang(cls) -> str:
        return cls._fallback_lang
    
    @classmethod
    def get(cls, key: str, default: Optional[str] = None, log_missing: bool = True) -> str:
        current_dict = LANGUAGES.get(cls._current_lang, {})
        if key in current_dict:
            return current_dict[key]
        
        fallback_dict = LANGUAGES.get(cls._fallback_lang, {})
        if key in fallback_dict:
            if log_missing:
                logger.debug(f"Missing key '{key}' in {cls._current_lang}, using fallback {cls._fallback_lang}")
                cls._log_missing_key(key)
            return fallback_dict[key]
        
        if log_missing:
            logger.warning(f"Missing key '{key}' in all languages")
        if default is not None:
            return default
        return key
    
    @classmethod
    def _log_missing_key(cls, key: str) -> None:
        if cls._current_lang not in cls._missing_keys_cache:
            cls._missing_keys_cache[cls._current_lang] = []
        if key not in cls._missing_keys_cache[cls._current_lang]:
            cls._missing_keys_cache[cls._current_lang].append(key)
    
    @classmethod
    def get_all_keys(cls, lang_code: str) -> Dict[str, str]:
        return LANGUAGES.get(lang_code, {}).copy()
    
    @classmethod
    def has_key(cls, lang_code: str, key: str) -> bool:
        return key in LANGUAGES.get(lang_code, {})
    
    @classmethod
    def get_missing_keys(cls, lang_code: str) -> List[str]:
        current_dict = LANGUAGES.get(lang_code, {})
        fallback_dict = LANGUAGES.get(cls._fallback_lang, {})
        
        missing = []
        for key in fallback_dict:
            if key not in current_dict:
                missing.append(key)
        return missing
    
    @classmethod
    def get_all_missing_keys(cls) -> Dict[str, List[str]]:
        result = {}
        for lang in SUPPORTED_LANGUAGES:
            missing = cls.get_missing_keys(lang)
            if missing:
                result[lang] = missing
        return result
    
    @classmethod
    def repair_missing_keys(cls, lang_code: str) -> int:
        if lang_code not in LANGUAGES:
            logger.warning(f"Cannot repair: language {lang_code} not found")
            return 0
        
        current_dict = LANGUAGES[lang_code]
        fallback_dict = LANGUAGES.get(cls._fallback_lang, {})
        
        count = 0
        for key, value in fallback_dict.items():
            if key not in current_dict:
                current_dict[key] = value
                count += 1
                logger.debug(f"Repaired missing key '{key}' for language {lang_code}")
        
        if count > 0:
            logger.info(f"Repaired {count} missing keys for language {lang_code}")
        
        return count
    
    @classmethod
    def repair_all_languages(cls) -> Dict[str, int]:
        result = {}
        for lang in SUPPORTED_LANGUAGES:
            count = cls.repair_missing_keys(lang)
            if count > 0:
                result[lang] = count
        return result
    
    @classmethod
    def add_key(cls, lang_code: str, key: str, value: str) -> bool:
        if lang_code not in LANGUAGES:
            return False
        
        LANGUAGES[lang_code][key] = value
        logger.debug(f"Added key '{key}' to language {lang_code}")
        return True
    
    @classmethod
    def get_missing_keys_cache(cls) -> Dict[str, List[str]]:
        return cls._missing_keys_cache.copy()
    
    @classmethod
    def clear_missing_keys_cache(cls) -> None:
        cls._missing_keys_cache = {}
    
    @classmethod
    def validate_all(cls) -> Tuple[bool, Dict[str, List[str]]]:
        fallback_dict = LANGUAGES.get(cls._fallback_lang, {})
        issues = {}
        
        for lang in SUPPORTED_LANGUAGES:
            if lang == cls._fallback_lang:
                continue
            
            current_dict = LANGUAGES.get(lang, {})
            missing = []
            for key in fallback_dict:
                if key not in current_dict:
                    missing.append(key)
            
            if missing:
                issues[lang] = missing
        
        return len(issues) == 0, issues


# ==================== УДОБНЫЕ ФУНКЦИИ ====================

def get_text(key: str, default: Optional[str] = None) -> str:
    return LanguageManager.get(key, default)


def set_language(lang_code: str) -> bool:
    return LanguageManager.set_language(lang_code)


def set_fallback_language(lang_code: str) -> bool:
    return LanguageManager.set_fallback(lang_code)


def get_current_language() -> str:
    return LanguageManager.get_current_lang()


def get_fallback_language() -> str:
    return LanguageManager.get_fallback_lang()


def repair_language(lang_code: str) -> int:
    return LanguageManager.repair_missing_keys(lang_code)


def repair_all_languages() -> Dict[str, int]:
    return LanguageManager.repair_all_languages()


def validate_languages() -> Tuple[bool, Dict[str, List[str]]]:
    return LanguageManager.validate_all()


def get_missing_keys_report() -> Dict[str, List[str]]:
    return LanguageManager.get_all_missing_keys()


def get_missing_keys(lang_code: str) -> List[str]:
    return LanguageManager.get_missing_keys(lang_code)