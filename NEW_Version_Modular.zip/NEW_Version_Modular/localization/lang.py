"""
🌐 Language dictionaries (RU, EN, UA) with fallback language and missing key recovery
"""
from typing import Dict, Any, Optional, List, Tuple
from utils.logger import get_logger

logger = get_logger("lang")

# 📂 Словарь поддерживаемых языков и их строк
LANGUAGES: Dict[str, Dict[str, str]] = {
    "RU": {
        # 🖥️ Основное окно
        "win_title": "Secure Pass Pro v4.0",
        "menu_title": "Меню",
        "len": "Длина",
        "author": "Автор: Максим Мельников",
        "upper": "Заглавные буквы",
        "lower": "Строчные буквы",
        "digits": "Цифры",
        "symb": "Спецсимволы",
        "ambig": "Исключить похожие (i, l, 1...)",
        "unambig": "Исключить неоднозначные",
        "at_least": "Минимум 1 из каждой категории",
        "hide": "Скрывать символы",
        "no_repeat": "Избегать повторов символов подряд",
        
        # 🎛️ Кнопки меню
        "btn_gen": "🎲 Сгенерировать",
        "btn_name_gen": "👤 Генератор имён",
        "btn_copy": "📋 Копировать пароль",
        "btn_save": "💾 Сохранить в файл",
        "btn_open": "📂 Открыть файл",
        "btn_qr": "📱 QR-код",
        "btn_hist": "📜 История",
        "btn_db": "🗄️ База паролей",
        "btn_hibp": "🔍 Проверить утечки",
        "btn_upd": "🔄 Обновить",
        "btn_about": "ℹ️ О программе",
        "btn_settings": "⚙️ Настройки",
        
        # 👁 Кнопка глаза
        "btn_eye": "👁",
        "btn_eye_closed": "🙈",
        
        # 💡 Подсказки
        "tt_gen": "Создать новый случайный пароль",
        "tt_name_gen": "Генерация имён для любых целей",
        "tt_copy": "Копировать в буфер (очистка через {0} сек)",
        "tt_save": "Сохранить текущий пароль в файл",
        "tt_open": "Открыть пароль из файла",
        "tt_qr": "Создать QR-код для быстрого сканирования",
        "tt_hist": "Показать последние 50 паролей",
        "tt_db": "Открыть хранилище паролей",
        "tt_hibp": "Проверить пароль в базе утечек",
        "tt_upd": "Проверить наличие новой версии",
        "tt_about": "Информация о программе",
        "tt_settings": "Настройки приложения",
        "tt_eye": "👁 Показать / скрыть пароль",
        "tt_no_repeat": "Не допускать одинаковых символов подряд",
        "tt_auto_lock": "Автоматическая блокировка при бездействии",
        "tt_clip_timeout": "Через сколько секунд буфер обмена будет очищен",
        
        # 👤 Генератор имён
        "name_gen_title": "👤 Генератор имён",
        "name_gen_type_label": "Тип генерации",
        "name_gen_samp": "🎮 SAMP RP",
        "name_gen_email": "📧 Email адрес",
        "name_gen_game": "🎮 Игровой ник",
        "name_gen_cool": "😎 Крутой ник",
        "name_gen_beauty": "✨ Красивый ник",
        "name_gen_short": "📏 Короткий (3-5)",
        "name_gen_long": "📏 Длинный (8+)",
        "name_gen_random": "🎲 Случайный",
        "name_gen_settings_label": "⚙️ Настройки",
        "name_gen_gender": "👤 Пол:",
        "name_gen_male": "👨 Мужской",
        "name_gen_female": "👩 Женский",
        "name_gen_random_gender": "🎲 Случайный",
        "name_gen_lang": "🌐 Язык:",
        "name_gen_russian": "🇷🇺 Русский",
        "name_gen_english": "🇬🇧 English",
        "name_gen_separator": "🔗 Разделитель:",
        "name_gen_separator_yes": "✅ ДА (_)",
        "name_gen_separator_no": "❌ НЕТ",
        "name_gen_count": "🔢 Количество:",
        "name_gen_generate_btn": "🎲 Сгенерировать",
        "name_gen_clear_btn": "🗑️ Очистить",
        "name_gen_copy_btn": "📋 Копировать всё",
        "name_gen_result_label": "📝 Результат",
        "name_gen_copied": "✅ Скопировано {0} имён!",
        "name_gen_generating": "⏳ Генерация...",
        "name_gen_error": "❌ Ошибка генерации имён",
        
        # 💪 Стойкость пароля
        "strength": "🔒 Стойкость: ~{0} вариантов",
        "crack_time": "⏱️ {0}",
        "time_sec": "секунды на взлом",
        "time_day": "дни на взлом",
        "time_year": "годы на взлом",
        "time_cent": "столетия на взлом",
        "st_low": "🔴 Слабый пароль",
        "st_mid": "🟡 Средний пароль",
        "st_high": "🟢 Надёжный пароль",
        
        # ⚙️ Настройки
        "settings_title": "⚙️ Настройки",
        "settings_subtitle": "Настройте приложение под свои потребности",
        "settings_lang": "🌐 Язык интерфейса",
        "settings_lang_desc": "Выберите язык интерфейса",
        "settings_sound": "🔊 Звук приложения",
        "settings_theme": "🎨 Тема оформления",
        "settings_theme_desc": "Выберите оформление приложения",
        "settings_radius": "🔘 Закругление углов",
        "font_size": "🔤 Размер шрифта",
        "font_size_desc": "Размер текста в интерфейсе",
        "radius_desc": "Скругление углов элементов",
        "theme_sys": "💻 Системная",
        "theme_dark": "🌙 Тёмная",
        "theme_light": "☀️ Светлая",
        "sound_on": "🔊 Звук: вкл",
        "sound_off": "🔇 Звук: выкл",
        "sound_desc": "Звуковые эффекты при действиях",
        "close": "❌ Закрыть",
        "ok": "✅ OK",
        "cancel": "❌ Отмена",
        "yes": "✅ Да",
        "no": "❌ Нет",
        "save": "💾 Сохранить",
        "delete": "🗑️ Удалить",
        "edit": "✏️ Редактировать",
        "copy": "📋 Копировать",
        "clear": "🗑️ Очистить",
        "back": "🔙 Назад",
        "next": "➡️ Далее",
        "finish": "✅ Завершить",
        "apply": "✅ Применить",
        "reset": "🔄 Сбросить",
        "refresh": "🔄 Обновить",
        
        # 📑 Вкладки настроек
        "tab_design": "🎨 Дизайн",
        "tab_security": "🔒 Безопасность",
        "tab_general": "⚙️ Общие",
        
        # 🌈 RGB
        "rgb_label": "🌈 RGB-подсветка",
        "rgb_label_desc": "Цветная анимация границ",
        "rgb_on": "✅ Вкл",
        "rgb_off": "❌ Выкл",
        "rgb_speed": "⚡ Скорость RGB",
        "rgb_speed_desc": "Скорость анимации",
        "rgb_speed_slow": "🐢 Медленная",
        "rgb_speed_normal": "⚡ Нормальная",
        "rgb_speed_fast": "🚀 Быстрая",
        "rgb_width": "📏 Толщина RGB",
        "rgb_width_desc": "Толщина подсветки",
        "rgb_width_thin": "➖ Тонкая",
        "rgb_width_normal": "➖➖ Средняя",
        "rgb_width_thick": "🔲 Толстая",
        
        # 💾 Автосохранение
        "auto_save": "💾 Автосохранение",
        "auto_save_desc": "Автоматическое сохранение паролей",
        "auto_save_on": "✅ Включено",
        "auto_save_off": "❌ Выключено",
        "auto_save_enabled": "✅ Автосохранение включено",
        "auto_save_disabled": "❌ Автосохранение выключено",
        "auto_save_label": "💾 Автосохранение",
        
        # 🔒 Автоблокировка
        "auto_lock": "🔒 Автоблокировка",
        "auto_lock_desc": "Автоматическая блокировка при бездействии",
        "auto_lock_timeout": "⏰ Таймаут блокировки: {0} мин",
        "auto_lock_title": "🔒 Программа заблокирована",
        "unlock": "🔓 Разблокировать",
        
        # 📋 Буфер обмена
        "clip_timeout": "📋 Очистка буфера: {0} сек",
        "clip_timeout_desc": "Автоочистка буфера обмена",
        "clipboard_cleared": "✅ Буфер обмена очищен",
        "clipboard_auto_clear": "📋 Автоочистка буфера через {0} сек",
        "clear_clipboard": "🗑️ Очистить буфер обмена",
        "pwd_done": "✅ Пароль скопирован",
        
        # 🔐 Мастер-пароль
        "master_title": "🔐 Мастер-пароль",
        "master_desc": "Защита доступа к программе",
        "master_prompt": "🔑 Введите мастер-пароль для доступа:",
        "master_set_title": "🔐 Установить мастер-пароль",
        "master_set_prompt": "🔑 Придумайте мастер-пароль:",
        "master_confirm": "✅ Подтвердите мастер-пароль:",
        "master_mismatch": "❌ Пароли не совпадают",
        "master_wrong": "❌ Неверный пароль! Попытка {0} из {1}",
        "master_blocked": "🚫 Превышено число попыток. Программа закрыта",
        "master_set_ok": "✅ Мастер-пароль установлен",
        "master_removed": "✅ Мастер-пароль удалён",
        "master_btn_set": "🔐 Установить мастер-пароль",
        "master_btn_remove": "🗑️ Удалить мастер-пароль",
        "master_current": "📊 Статус:",
        "master_status_set": "✅ Установлен",
        "master_status_not_set": "❌ Не установлен",
        "master_remove_confirm": "⚠️ Удалить мастер-пароль?",
        "master_remove_prompt": "🔑 Введите текущий мастер-пароль:",
        "master_not_set": "❌ Мастер-пароль не установлен",
        "master_already_set": "✅ Мастер-пароль уже установлен",
        "master_set_error": "❌ Ошибка установки мастер-пароля",
        "master_remove_error": "❌ Ошибка удаления мастер-пароля",
        "master_status_text": "🔐 Мастер-пароль: установлен",
        "master_status_not_set_text": "⚠️ Мастер-пароль: не установлен",
        "master_too_short": "⚠️ Пароль слишком короткий. Минимум 8 символов",
        "master_weak": "⚠️ Пароль слишком простой. Добавьте цифру или спецсимвол",
        
        # 🗄️ База паролей
        "db_title": "🗄️ База паролей",
        "db_label_prompt": "🏷️ Метка:",
        "db_saved": "✅ Пароль сохранён",
        "db_empty": "📭 База пуста",
        "db_copy": "📋 Копировать",
        "db_delete": "🗑️ Удалить",
        "db_edit": "✏️ Изменить",
        "db_save_current": "💾 Сохранить текущий пароль",
        "db_no_pass": "⚠️ Сначала сгенерируйте пароль",
        "db_count": "📊 Записей: {0}",
        "db_search": "🔍 Поиск",
        "db_del_confirm": "🗑️ Удалить эту запись?",
        "db_edit_title": "✏️ Редактировать запись",
        "db_edit_label": "🏷️ Метка:",
        "db_edit_pass": "🔑 Пароль:",
        "db_save_success": "✅ Пароль сохранён",
        "db_save_error": "❌ Ошибка сохранения",
        "db_delete_success": "✅ Запись удалена",
        "db_delete_error": "❌ Ошибка удаления",
        "db_search_no_results": "🔍 Ничего не найдено",
        "db_no_label": "🏷️ Без метки",
        
        # 📜 История
        "hist_empty": "📭 История пуста",
        "btn_clear_hist": "🗑️ Очистить историю",
        
        # 📄 PDF
        "pdf_date": "📅 Дата",
        "pdf_pass": "🔑 Пароль",
        "pdf_theme": "📄 Тема PDF",
        "pdf_theme_desc": "Оформление экспорта в PDF",
        "pdf_theme_light": "☀️ Светлая",
        "pdf_theme_dark": "🌙 Тёмная",
        
        # 📱 QR-код
        "qr_closes_in": "⏰ Окно закроется через",
        "seconds_short": "сек",
        
        # 🔒 Блокировка
        "lock_screen_title": "🔒 Введите мастер-пароль",
        "lock_wait": "⏳ Подождите",
        
        # 🔍 HIBP
        "hibp_no_password": "⚠️ Сначала сгенерируйте пароль",
        "hibp_checking": "🔍 Проверка...",
        "hibp_safe": "✅ Пароль безопасен",
        "hibp_found": "❌ Пароль найден в {count} утечках",
        "hibp_error": "⚠️ Ошибка проверки",
        "hibp_error_title": "❌ Ошибка проверки",
        "hibp_safe_title": "✅ Пароль безопасен",
        "hibp_found_title": "🚨 ВНИМАНИЕ! Пароль скомпрометирован",
        "hibp_warning": "⚠️ Рекомендуется сменить пароль",
        
        # 🔄 Обновления
        "update_check": "🔄 Проверка обновлений",
        "update_available": "📦 Доступна версия {0}",
        "update_not_available": "✅ Установлена последняя версия",
        "update_available_title": "📦 Доступно обновление",
        "update_confirm_title": "🔄 Обновление",
        "update_confirm_message": "📥 Установить обновление?",
        "update_error": "❌ Ошибка обновления",
        "update_signature_error": "❌ Проверка подписи обновления не удалась!",
        "update_integrity_error": "❌ Проверка целостности обновления не удалась!",
        "update_restart": "✅ Обновление успешно загружено!\n\n🔄 Приложение перезапустится для применения изменений.",
        "download_start": "📥 Загрузка обновления...",
        "err_timeout": "⏰ Превышено время ожидания",
        "err_import": "❌ Ошибка импорта модуля",
        
        # 🔒 Безопасность
        "security": "🔒 Безопасность",
        "security_audit_pass": "✅ Проверка безопасности пройдена",
        "security_audit_fail": "⚠️ Обнаружены проблемы безопасности",
        "wiki_link": "📖 Wiki",
        "rate_limit_warning": "⚠️ Режим 'без повторов' снижает стойкость",
        "duplicate_warning": "⚠️ Такой пароль уже существует в базе.\n\n💾 Сохранить всё равно?",
        "skip_duplicates": "⏭️ Пропускать дубликаты паролей",
        
        # 🗄️ SQLCipher
        "sqlcipher_enabled": "✅ SQLCipher включён",
        "sqlcipher_disabled": "❌ SQLCipher отключён",
        
        # ⚠️ Ошибки
        "err_cat": "⚠️ Выберите хотя бы одну категорию",
        "err_pool_small": "⚠️ Слишком мало доступных символов",
        "err_save": "❌ Ошибка сохранения: {0}",
        "err_open": "❌ Не удалось прочитать файл: {0}",
        "err_unsupported": "❌ Неподдерживаемый тип файла: {0}",
        "err_integrity": "🚨 Критическая ошибка: Файл повреждён",
        "err_no_repeat": "⚠️ Не удалось создать пароль без повторов",
        "err_no_repeat_fallback": "\n⚠️ Использован пароль с повторами",
        "err_title": "❌ Ошибка",
        "err_encrypt": "🔒 Ошибка шифрования",
        "err_decrypt": "🔓 Ошибка дешифрования",
        "err_database": "🗄️ Ошибка базы данных",
        "err_network": "🌐 Ошибка сети",
        "err_permission": "🔐 Ошибка доступа",
        "err_copy": "📋 Ошибка копирования",
        "err_qr": "📱 Ошибка создания QR-кода",
        "no_pwd": "⚠️ Нет пароля для сохранения",
        "warn": "⚠️ Внимание",
        
        # 🚨 Целостность
        "integrity_warn": "⚠️ Файл мог быть изменён. Продолжить?",
        "integrity_fail": "🚨 Файл повреждён! Открытие отменено",
        "integrity_ok": "✅ Целостность файла подтверждена",
        
        # ℹ️ О программе
        "about_text": "🔐 Профессиональный генератор паролей\nс открытым исходным кодом",
        "about_text_simple": "🔐 Профессиональный генератор паролей\n\n© Максим Мельников\n📜 MIT License",
        
        # 📊 Статусы
        "status_ok": "✅ Готово",
        "status_error": "❌ Ошибка",
        "status_warning": "⚠️ Предупреждение",
        "please_wait": "⏳ Пожалуйста, подождите...",
        "copied": "✅ Скопировано! ({0}с)",
        
        # 🎲 Diceware
        "diceware": "🎲 Diceware режим",
        "diceware_word_count": "📊 Количество слов",
        "diceware_separator": "🔗 Разделитель",
        "diceware_words": "📝 Слова",
        
        # 🔑 Пароль
        "password_strength_low": "🔴 Слабый пароль",
        "password_strength_medium": "🟡 Средний пароль",
        "password_strength_high": "🟢 Надёжный пароль",
        
        # ⚙️ Дополнительные настройки
        "settings_autosave": "💾 Автосохранение",
        "settings_rgb": "🌈 RGB анимация",
        "settings_sound_effect": "🔊 Звуковые эффекты",
        "settings_auto_lock": "🔒 Автоблокировка",
        "settings_corner_radius": "🔘 Скругление углов",
        "settings_font_size": "🔤 Размер шрифта",
        "settings_clipboard_timeout": "📋 Таймаут буфера",
        
        # 📤 Экспорт
        "export_title": "📤 Экспорт данных",
        "export_json": "📄 JSON",
        "export_csv": "📊 CSV",
        "export_html": "🌐 HTML",
        "export_format": "📁 Формат экспорта:",
        "export_success": "✅ Данные экспортированы: {0}",
        "export_error": "❌ Ошибка экспорта",
        "export_no_data": "📭 Нет данных для экспорта",
        "export_passwords": "🔑 Пароли",
        "export_date": "📅 Дата экспорта",
        "export_app": "🔐 Secure Pass Pro v4.0",
        "export_fields": "📋 Выберите поля для экспорта",
        "export_encoding": "🔤 Кодировка",
        "export_encrypt": "🔒 Зашифровать экспорт",
        "export_encrypt_password": "🔑 Пароль для шифрования",
        "export_encrypted": "🔒 Файл зашифрован паролем",
        "export_sort_title": "📊 Сортировать по",
        
        # 📥 Импорт
        "import_title": "📥 Импорт паролей",
        "import_format": "📁 Формат импорта:",
        "import_warning": "⚠️ Импортируйте только из доверенных источников",
        "import_found": "🔍 Найдено паролей",
        "import_confirm": "📥 Импортировать?",
        "import_success": "✅ Импортировано: {0}",
        "import_error": "❌ Ошибка импорта: {0}",
        "import_no_passwords": "📭 Не найдено паролей в файле",
        
        # 🔐 2FA
        "2fa_title": "🔐 Двухфакторная аутентификация",
        "2fa_settings_title": "⚙️ Настройки 2FA",
        "2fa_setup_title": "🔧 Настройка 2FA",
        "2fa_verify_title": "✅ Подтверждение 2FA",
        "2fa_verify_disable": "🔑 Введите код 2FA для подтверждения отключения:",
        "2fa_verify_regenerate": "🔄 Введите код 2FA для генерации новых резервных кодов:",
        "2fa_enable": "🔒 Включить 2FA",
        "2fa_disable": "🔓 Отключить 2FA",
        "2fa_status_enabled": "✅ Включена",
        "2fa_status_disabled": "❌ Отключена",
        "2fa_description": "🔐 Двухфакторная аутентификация добавляет дополнительный уровень безопасности.\n\nПри каждом входе потребуется вводить 6-значный код из приложения-аутентификатора.",
        "2fa_scan_qr": "📱 Отсканируйте этот QR-код приложением-аутентификатором:",
        "2fa_or_enter_manually": "✏️ Или введите этот код вручную:",
        "2fa_enter_code": "🔢 Введите код подтверждения:",
        "2fa_enter_verification": "🔢 Введите код из приложения-аутентификатора:",
        "2fa_enter_backup": "🎫 Введите резервный код (формат: XXXXXXXX):",
        "2fa_invalid_code": "❌ Неверный код подтверждения",
        "2fa_incorrect": "❌ Неверный код. Попробуйте ещё раз",
        "2fa_enabled_success": "✅ Двухфакторная аутентификация успешно включена!\n\n💾 Сохраните резервные коды в надёжном месте",
        "2fa_disabled_success": "✅ Двухфакторная аутентификация отключена",
        "2fa_disable_confirm": "🔐 2FA уже включена.\n\n❓ Вы хотите отключить её?",
        "2fa_disable_warning": "⚠️ ВНИМАНИЕ: Отключение 2FA сделает ваш аккаунт менее защищённым!\n\n❓ Вы уверены, что хотите отключить 2FA?",
        "2fa_master_required": "🔐 Сначала установите мастер-пароль перед включением 2FA",
        "2fa_setup_cancelled": "❌ Настройка 2FA отменена",
        "2fa_backup_codes": "📋 Резервные коды",
        "2fa_backup_codes_info": "🎫 Резервные коды",
        "2fa_backup_title": "🎫 Резервный код",
        "2fa_backup_warning": "⚠️ Сохраните резервные коды! Они необходимы для восстановления доступа",
        "2fa_backup_warning_detailed": "⚠️ Сохраните эти коды в надёжном месте!\n🔑 Каждый код можно использовать только один раз",
        "2fa_backup_count": "📊 Осталось резервных кодов: {0}",
        "2fa_backup_used": "⚠️ Использован резервный код!\n🔄 Сгенерируйте новые резервные коды в настройках",
        "2fa_invalid_try_backup": "❌ Неверный код.\n\n🎫 Использовать резервный код?",
        "2fa_invalid_backup": "❌ Неверный резервный код",
        "2fa_regenerate_backup": "🔄 Сгенерировать новые резервные коды",
        "2fa_backup_regenerated": "✅ Новые резервные коды успешно сгенерированы",
        "2fa_regenerate_backup_confirm": "🔄 Генерация новых резервных кодов сделает старые недействительными.\n\n❓ Продолжить?",
        "qr_module_missing": "📱 Модуль qrcode не установлен.\n📦 Установите: pip install qrcode[pil]",
        "copy_all": "📋 Копировать все",
        "copy": "📋 Копировать",
    },
    
    "EN": {
        # 🖥️ Main window
        "win_title": "Secure Pass Pro v4.0",
        "menu_title": "Menu",
        "len": "Length",
        "author": "Author: Maxim Melnikov",
        "upper": "Uppercase",
        "lower": "Lowercase",
        "digits": "Digits",
        "symb": "Special symbols",
        "ambig": "Exclude ambiguous (i, l, 1...)",
        "unambig": "Exclude non-obvious",
        "at_least": "Min 1 from each category",
        "hide": "Hide symbols",
        "no_repeat": "Avoid consecutive repeated characters",
        
        # 🎛️ Menu buttons
        "btn_gen": "🎲 Generate",
        "btn_name_gen": "👤 Name Generator",
        "btn_copy": "📋 Copy password",
        "btn_save": "💾 Save to file",
        "btn_open": "📂 Open file",
        "btn_qr": "📱 QR Code",
        "btn_hist": "📜 History",
        "btn_db": "🗄️ Password vault",
        "btn_hibp": "🔍 Check leaks",
        "btn_upd": "🔄 Update",
        "btn_about": "ℹ️ About",
        "btn_settings": "⚙️ Settings",
        
        # 👁 Eye button
        "btn_eye": "👁",
        "btn_eye_closed": "🙈",
        
        # 💡 Tooltips
        "tt_gen": "Create a new random password",
        "tt_name_gen": "Generate names for any purpose",
        "tt_copy": "Copy to clipboard (clears in {0} sec)",
        "tt_save": "Save current password to file",
        "tt_open": "Open password from file",
        "tt_qr": "Create QR code for quick scanning",
        "tt_hist": "Show last 50 passwords",
        "tt_db": "Open password vault",
        "tt_hibp": "Check password against breach database",
        "tt_upd": "Check for new version",
        "tt_about": "Program information",
        "tt_settings": "Application settings",
        "tt_eye": "👁 Show / hide password",
        "tt_no_repeat": "Prevent consecutive repeated characters",
        "tt_auto_lock": "Auto lock on inactivity",
        "tt_clip_timeout": "Seconds before clipboard is cleared",
        
        # 👤 Name generator
        "name_gen_title": "👤 Name Generator",
        "name_gen_type_label": "Generation type",
        "name_gen_samp": "🎮 SAMP RP",
        "name_gen_email": "📧 Email address",
        "name_gen_game": "🎮 Game nickname",
        "name_gen_cool": "😎 Cool nickname",
        "name_gen_beauty": "✨ Beautiful nickname",
        "name_gen_short": "📏 Short (3-5)",
        "name_gen_long": "📏 Long (8+)",
        "name_gen_random": "🎲 Random",
        "name_gen_settings_label": "⚙️ Settings",
        "name_gen_gender": "👤 Gender:",
        "name_gen_male": "👨 Male",
        "name_gen_female": "👩 Female",
        "name_gen_random_gender": "🎲 Random",
        "name_gen_lang": "🌐 Language:",
        "name_gen_russian": "🇷🇺 Russian",
        "name_gen_english": "🇬🇧 English",
        "name_gen_separator": "🔗 Separator:",
        "name_gen_separator_yes": "✅ YES (_)",
        "name_gen_separator_no": "❌ NO",
        "name_gen_count": "🔢 Count:",
        "name_gen_generate_btn": "🎲 Generate",
        "name_gen_clear_btn": "🗑️ Clear",
        "name_gen_copy_btn": "📋 Copy all",
        "name_gen_result_label": "📝 Result",
        "name_gen_copied": "✅ Copied {0} names!",
        "name_gen_generating": "⏳ Generating...",
        "name_gen_error": "❌ Name generation error",
        
        # 💪 Password strength
        "strength": "🔒 Strength: ~{0} combos",
        "crack_time": "⏱️ {0}",
        "time_sec": "seconds to crack",
        "time_day": "days to crack",
        "time_year": "years to crack",
        "time_cent": "centuries to crack",
        "st_low": "🔴 Weak password",
        "st_mid": "🟡 Medium password",
        "st_high": "🟢 Strong password",
        
        # ⚙️ Settings
        "settings_title": "⚙️ Settings",
        "settings_subtitle": "Configure the app to your needs",
        "settings_lang": "🌐 Interface language",
        "settings_lang_desc": "Choose interface language",
        "settings_sound": "🔊 App sound",
        "settings_theme": "🎨 Appearance theme",
        "settings_theme_desc": "Choose application appearance",
        "settings_radius": "🔘 Corner radius",
        "font_size": "🔤 Font size",
        "font_size_desc": "Interface text size",
        "radius_desc": "Corner rounding of elements",
        "theme_sys": "💻 System",
        "theme_dark": "🌙 Dark",
        "theme_light": "☀️ Light",
        "sound_on": "🔊 Sound: on",
        "sound_off": "🔇 Sound: off",
        "sound_desc": "Sound effects for actions",
        "close": "❌ Close",
        "ok": "✅ OK",
        "cancel": "❌ Cancel",
        "yes": "✅ Yes",
        "no": "❌ No",
        "save": "💾 Save",
        "delete": "🗑️ Delete",
        "edit": "✏️ Edit",
        "copy": "📋 Copy",
        "clear": "🗑️ Clear",
        "back": "🔙 Back",
        "next": "➡️ Next",
        "finish": "✅ Finish",
        "apply": "✅ Apply",
        "reset": "🔄 Reset",
        "refresh": "🔄 Refresh",
        
        # 📑 Settings tabs
        "tab_design": "🎨 Design",
        "tab_security": "🔒 Security",
        "tab_general": "⚙️ General",
        
        # 🌈 RGB
        "rgb_label": "🌈 RGB border",
        "rgb_label_desc": "Colorful border animation",
        "rgb_on": "✅ On",
        "rgb_off": "❌ Off",
        "rgb_speed": "⚡ RGB Speed",
        "rgb_speed_desc": "Animation speed",
        "rgb_speed_slow": "🐢 Slow",
        "rgb_speed_normal": "⚡ Normal",
        "rgb_speed_fast": "🚀 Fast",
        "rgb_width": "📏 RGB Width",
        "rgb_width_desc": "Border thickness",
        "rgb_width_thin": "➖ Thin",
        "rgb_width_normal": "➖➖ Normal",
        "rgb_width_thick": "🔲 Thick",
        
        # 💾 Auto save
        "auto_save": "💾 Auto save",
        "auto_save_desc": "Automatically save passwords",
        "auto_save_on": "✅ On",
        "auto_save_off": "❌ Off",
        "auto_save_enabled": "✅ Auto save enabled",
        "auto_save_disabled": "❌ Auto save disabled",
        "auto_save_label": "💾 Auto save",
        
        # 🔒 Auto lock
        "auto_lock": "🔒 Auto lock",
        "auto_lock_desc": "Auto lock on inactivity",
        "auto_lock_timeout": "⏰ Lock timeout: {0} min",
        "auto_lock_title": "🔒 Program locked",
        "unlock": "🔓 Unlock",
        
        # 📋 Clipboard
        "clip_timeout": "📋 Clipboard clear: {0} sec",
        "clip_timeout_desc": "Auto clear clipboard",
        "clipboard_cleared": "✅ Clipboard cleared",
        "clipboard_auto_clear": "📋 Auto clear clipboard in {0} sec",
        "clear_clipboard": "🗑️ Clear clipboard",
        "pwd_done": "✅ Password copied",
        
        # 🔐 Master password
        "master_title": "🔐 Master password",
        "master_desc": "Program access protection",
        "master_prompt": "🔑 Enter master password:",
        "master_set_title": "🔐 Set master password",
        "master_set_prompt": "🔑 Create master password:",
        "master_confirm": "✅ Confirm master password:",
        "master_mismatch": "❌ Passwords do not match",
        "master_wrong": "❌ Wrong password! Attempt {0} of {1}",
        "master_blocked": "🚫 Too many attempts. Program closed",
        "master_set_ok": "✅ Master password set",
        "master_removed": "✅ Master password removed",
        "master_btn_set": "🔐 Set master password",
        "master_btn_remove": "🗑️ Remove master password",
        "master_current": "📊 Status:",
        "master_status_set": "✅ Set",
        "master_status_not_set": "❌ Not set",
        "master_remove_confirm": "⚠️ Remove master password?",
        "master_remove_prompt": "🔑 Enter current master password:",
        "master_not_set": "❌ Master password not set",
        "master_already_set": "✅ Master password already set",
        "master_set_error": "❌ Failed to set master password",
        "master_remove_error": "❌ Failed to remove master password",
        "master_status_text": "🔐 Master password: set",
        "master_status_not_set_text": "⚠️ Master password: not set",
        "master_too_short": "⚠️ Password too short. Minimum 8 characters",
        "master_weak": "⚠️ Password too weak. Add a digit or special character",
        
        # 🗄️ Password database
        "db_title": "🗄️ Password vault",
        "db_label_prompt": "🏷️ Label:",
        "db_saved": "✅ Password saved",
        "db_empty": "📭 Vault is empty",
        "db_copy": "📋 Copy",
        "db_delete": "🗑️ Delete",
        "db_edit": "✏️ Edit",
        "db_save_current": "💾 Save current password",
        "db_no_pass": "⚠️ Generate a password first",
        "db_count": "📊 Records: {0}",
        "db_search": "🔍 Search",
        "db_del_confirm": "🗑️ Delete this record?",
        "db_edit_title": "✏️ Edit record",
        "db_edit_label": "🏷️ Label:",
        "db_edit_pass": "🔑 Password:",
        "db_save_success": "✅ Password saved",
        "db_save_error": "❌ Save error",
        "db_delete_success": "✅ Record deleted",
        "db_delete_error": "❌ Delete error",
        "db_search_no_results": "🔍 No results found",
        "db_no_label": "🏷️ No label",
        
        # 📜 History
        "hist_empty": "📭 History is empty",
        "btn_clear_hist": "🗑️ Clear history",
        
        # 📄 PDF
        "pdf_date": "📅 Date",
        "pdf_pass": "🔑 Password",
        "pdf_theme": "📄 PDF Theme",
        "pdf_theme_desc": "PDF export appearance",
        "pdf_theme_light": "☀️ Light",
        "pdf_theme_dark": "🌙 Dark",
        
        # 📱 QR code
        "qr_closes_in": "⏰ Window closes in",
        "seconds_short": "sec",
        
        # 🔒 Lock screen
        "lock_screen_title": "🔒 Enter master password",
        "lock_wait": "⏳ Please wait",
        
        # 🔍 HIBP
        "hibp_no_password": "⚠️ Generate a password first",
        "hibp_checking": "🔍 Checking...",
        "hibp_safe": "✅ Password is safe",
        "hibp_found": "❌ Password found in {count} breaches",
        "hibp_error": "⚠️ Check error",
        "hibp_error_title": "❌ Check error",
        "hibp_safe_title": "✅ Password is safe",
        "hibp_found_title": "🚨 WARNING! Password compromised",
        "hibp_warning": "⚠️ Change your password immediately",
        
        # 🔄 Updates
        "update_check": "🔄 Check for updates",
        "update_available": "📦 Version {0} available",
        "update_not_available": "✅ Latest version installed",
        "update_available_title": "📦 Update available",
        "update_confirm_title": "🔄 Update",
        "update_confirm_message": "📥 Install update?",
        "update_error": "❌ Update error",
        "update_signature_error": "❌ Update signature verification failed!",
        "update_integrity_error": "❌ Update integrity check failed!",
        "update_restart": "✅ Update downloaded successfully!\n\n🔄 The application will restart to apply changes.",
        "download_start": "📥 Downloading update...",
        "err_timeout": "⏰ Connection timeout",
        "err_import": "❌ Module import error",
        
        # 🔒 Security
        "security": "🔒 Security",
        "security_audit_pass": "✅ Security check passed",
        "security_audit_fail": "⚠️ Security issues detected",
        "wiki_link": "📖 Wiki",
        "rate_limit_warning": "⚠️ 'No repeats' mode reduces strength",
        "duplicate_warning": "⚠️ This password already exists in the database.\n\n💾 Save anyway?",
        "skip_duplicates": "⏭️ Skip duplicate passwords",
        
        # 🗄️ SQLCipher
        "sqlcipher_enabled": "✅ SQLCipher enabled",
        "sqlcipher_disabled": "❌ SQLCipher disabled",
        
        # ⚠️ Errors
        "err_cat": "⚠️ Select at least one category",
        "err_pool_small": "⚠️ Too few available characters",
        "err_save": "❌ Save failed: {0}",
        "err_open": "❌ Could not read file: {0}",
        "err_unsupported": "❌ Unsupported file type: {0}",
        "err_integrity": "🚨 Critical error: File corrupted",
        "err_no_repeat": "⚠️ Could not generate password without repeats",
        "err_no_repeat_fallback": "\n⚠️ Password with repeats used",
        "err_title": "❌ Error",
        "err_encrypt": "🔒 Encryption error",
        "err_decrypt": "🔓 Decryption error",
        "err_database": "🗄️ Database error",
        "err_network": "🌐 Network error",
        "err_permission": "🔐 Permission error",
        "err_copy": "📋 Copy error",
        "err_qr": "📱 QR code error",
        "no_pwd": "⚠️ No password to save",
        "warn": "⚠️ Warning",
        
        # 🚨 Integrity
        "integrity_warn": "⚠️ File may have been modified. Continue?",
        "integrity_fail": "🚨 File corrupted! Opening cancelled",
        "integrity_ok": "✅ File integrity verified",
        
        # ℹ️ About
        "about_text": "🔐 Professional password generator\nwith open source code",
        "about_text_simple": "🔐 Professional password generator\n\n© Maxim Melnikov\n📜 MIT License",
        
        # 📊 Status
        "status_ok": "✅ Done",
        "status_error": "❌ Error",
        "status_warning": "⚠️ Warning",
        "please_wait": "⏳ Please wait...",
        "copied": "✅ Copied! ({0}s)",
        
        # 🎲 Diceware
        "diceware": "🎲 Diceware mode",
        "diceware_word_count": "📊 Word count",
        "diceware_separator": "🔗 Separator",
        "diceware_words": "📝 Words",
        
        # 🔑 Password
        "password_strength_low": "🔴 Weak password",
        "password_strength_medium": "🟡 Medium password",
        "password_strength_high": "🟢 Strong password",
        
        # ⚙️ Additional settings
        "settings_autosave": "💾 Auto save",
        "settings_rgb": "🌈 RGB animation",
        "settings_sound_effect": "🔊 Sound effects",
        "settings_auto_lock": "🔒 Auto lock",
        "settings_corner_radius": "🔘 Corner radius",
        "settings_font_size": "🔤 Font size",
        "settings_clipboard_timeout": "📋 Clipboard timeout",
        
        # 📤 Export
        "export_title": "📤 Export Data",
        "export_json": "📄 JSON",
        "export_csv": "📊 CSV",
        "export_html": "🌐 HTML",
        "export_format": "📁 Export format:",
        "export_success": "✅ Data exported: {0}",
        "export_error": "❌ Export error",
        "export_no_data": "📭 No data to export",
        "export_passwords": "🔑 Passwords",
        "export_date": "📅 Export date",
        "export_app": "🔐 Secure Pass Pro v4.0",
        "export_fields": "📋 Select fields to export",
        "export_encoding": "🔤 Encoding",
        "export_encrypt": "🔒 Encrypt export",
        "export_encrypt_password": "🔑 Encryption password",
        "export_encrypted": "🔒 File encrypted with password",
        "export_sort_title": "📊 Sort by",
        
        # 📥 Import
        "import_title": "📥 Import Passwords",
        "import_format": "📁 Import format:",
        "import_warning": "⚠️ Import only from trusted sources",
        "import_found": "🔍 Passwords found",
        "import_confirm": "📥 Import?",
        "import_success": "✅ Imported: {0}",
        "import_error": "❌ Import error: {0}",
        "import_no_passwords": "📭 No passwords found in file",
        
        # 🔐 2FA
        "2fa_title": "🔐 Two-Factor Authentication",
        "2fa_settings_title": "⚙️ 2FA Settings",
        "2fa_setup_title": "🔧 2FA Setup",
        "2fa_verify_title": "✅ 2FA Verification",
        "2fa_verify_disable": "🔑 Enter 2FA code to confirm disabling:",
        "2fa_verify_regenerate": "🔄 Enter 2FA code to generate new backup codes:",
        "2fa_enable": "🔒 Enable 2FA",
        "2fa_disable": "🔓 Disable 2FA",
        "2fa_status_enabled": "✅ Enabled",
        "2fa_status_disabled": "❌ Disabled",
        "2fa_description": "🔐 Two-Factor Authentication adds an extra layer of security.\n\nEach time you unlock the program, you will need to enter a 6-digit code from an authenticator app.",
        "2fa_scan_qr": "📱 Scan this QR code with your authenticator app:",
        "2fa_or_enter_manually": "✏️ Or enter this code manually:",
        "2fa_enter_code": "🔢 Enter verification code:",
        "2fa_enter_verification": "🔢 Enter code from authenticator app:",
        "2fa_enter_backup": "🎫 Enter backup code (format: XXXXXXXX):",
        "2fa_invalid_code": "❌ Invalid verification code",
        "2fa_incorrect": "❌ Incorrect code. Please try again",
        "2fa_enabled_success": "✅ Two-Factor Authentication has been enabled successfully!\n\n💾 Please save your backup codes in a safe place",
        "2fa_disabled_success": "✅ Two-Factor Authentication has been disabled",
        "2fa_disable_confirm": "🔐 2FA is already enabled.\n\n❓ Do you want to disable it?",
        "2fa_disable_warning": "⚠️ WARNING: Disabling 2FA will make your account less secure!\n\n❓ Are you sure you want to disable 2FA?",
        "2fa_master_required": "🔐 Please set a master password before enabling 2FA",
        "2fa_setup_cancelled": "❌ 2FA setup cancelled",
        "2fa_backup_codes": "📋 Backup Codes",
        "2fa_backup_codes_info": "🎫 Backup Codes",
        "2fa_backup_title": "🎫 Backup Code",
        "2fa_backup_warning": "⚠️ Save backup codes! They are required to recover access",
        "2fa_backup_warning_detailed": "⚠️ Store these codes in a safe place!\n🔑 Each code can be used only once",
        "2fa_backup_count": "📊 Remaining backup codes: {0}",
        "2fa_backup_used": "⚠️ Backup code used!\n🔄 Please generate new backup codes in settings",
        "2fa_invalid_try_backup": "❌ Invalid code.\n\n🎫 Do you want to use a backup code?",
        "2fa_invalid_backup": "❌ Invalid backup code",
        "2fa_regenerate_backup": "🔄 Generate New Backup Codes",
        "2fa_backup_regenerated": "✅ New backup codes generated successfully",
        "2fa_regenerate_backup_confirm": "🔄 Generating new backup codes will invalidate old ones.\n\n❓ Continue?",
        "qr_module_missing": "📱 QR code module not installed.\n📦 Install: pip install qrcode[pil]",
        "copy_all": "📋 Copy All",
        "copy": "📋 Copy",
    },
    
    "UA": {
        # 🖥️ Головне вікно
        "win_title": "Secure Pass Pro v4.0",
        "menu_title": "Меню",
        "len": "Довжина",
        "author": "Автор: Максим Мельніков",
        "upper": "Великі літери",
        "lower": "Малі літери",
        "digits": "Цифри",
        "symb": "Спецсимволи",
        "ambig": "Виключити схожі (i, l, 1...)",
        "unambig": "Виключити неоднозначні",
        "at_least": "Мінімум 1 з кожної категорії",
        "hide": "Приховувати символи",
        "no_repeat": "Уникати повторів символів поспіль",
        
        # 🎛️ Кнопки меню
        "btn_gen": "🎲 Згенерувати",
        "btn_name_gen": "👤 Генератор імен",
        "btn_copy": "📋 Копіювати пароль",
        "btn_save": "💾 Зберегти у файл",
        "btn_open": "📂 Відкрити файл",
        "btn_qr": "📱 QR-код",
        "btn_hist": "📜 Історія",
        "btn_db": "🗄️ База паролів",
        "btn_hibp": "🔍 Перевірити витоки",
        "btn_upd": "🔄 Оновити",
        "btn_about": "ℹ️ Про програму",
        "btn_settings": "⚙️ Налаштування",
        
        # 👁 Кнопка ока
        "btn_eye": "👁",
        "btn_eye_closed": "🙈",
        
        # 💡 Підказки
        "tt_gen": "Створити новий випадковий пароль",
        "tt_name_gen": "Генерація імен для будь-яких цілей",
        "tt_copy": "Копіювати в буфер (очищення через {0} сек)",
        "tt_save": "Зберегти поточний пароль у файл",
        "tt_open": "Відкрити пароль з файлу",
        "tt_qr": "Створити QR-код для швидкого сканування",
        "tt_hist": "Показати останні 50 паролів",
        "tt_db": "Відкрити сховище паролів",
        "tt_hibp": "Перевірити пароль у базі витоків",
        "tt_upd": "Перевірити наявність нової версії",
        "tt_about": "Інформація про програму",
        "tt_settings": "Налаштування програми",
        "tt_eye": "👁 Показати / приховати пароль",
        "tt_no_repeat": "Не допускати одинакових символів підряд",
        "tt_auto_lock": "Автоматичне блокування при бездіяльності",
        "tt_clip_timeout": "Через скільки секунд буфер обміну буде очищено",
        
        # 👤 Генератор імен
        "name_gen_title": "👤 Генератор імен",
        "name_gen_type_label": "Тип генерації",
        "name_gen_samp": "🎮 SAMP RP",
        "name_gen_email": "📧 Email адреса",
        "name_gen_game": "🎮 Ігровий нік",
        "name_gen_cool": "😎 Крутий нік",
        "name_gen_beauty": "✨ Красивий нік",
        "name_gen_short": "📏 Короткий (3-5)",
        "name_gen_long": "📏 Довгий (8+)",
        "name_gen_random": "🎲 Випадковий",
        "name_gen_settings_label": "⚙️ Налаштування",
        "name_gen_gender": "👤 Стать:",
        "name_gen_male": "👨 Чоловіча",
        "name_gen_female": "👩 Жіноча",
        "name_gen_random_gender": "🎲 Випадкова",
        "name_gen_lang": "🌐 Мова:",
        "name_gen_russian": "🇷🇺 Російська",
        "name_gen_english": "🇬🇧 English",
        "name_gen_separator": "🔗 Розділювач:",
        "name_gen_separator_yes": "✅ ТАК (_)",
        "name_gen_separator_no": "❌ НІ",
        "name_gen_count": "🔢 Кількість:",
        "name_gen_generate_btn": "🎲 Згенерувати",
        "name_gen_clear_btn": "🗑️ Очистити",
        "name_gen_copy_btn": "📋 Копіювати всі",
        "name_gen_result_label": "📝 Результат",
        "name_gen_copied": "✅ Скопійовано {0} імен!",
        "name_gen_generating": "⏳ Генерація...",
        "name_gen_error": "❌ Помилка генерації імен",
        
        # 💪 Стійкість пароля
        "strength": "🔒 Стійкість: ~{0} варіантів",
        "crack_time": "⏱️ {0}",
        "time_sec": "секунди на злам",
        "time_day": "дні на злам",
        "time_year": "роки на злам",
        "time_cent": "століття на злам",
        "st_low": "🔴 Слабкий пароль",
        "st_mid": "🟡 Середній пароль",
        "st_high": "🟢 Надійний пароль",
        
        # ⚙️ Налаштування
        "settings_title": "⚙️ Налаштування",
        "settings_subtitle": "Налаштуйте додаток під свої потреби",
        "settings_lang": "🌐 Мова інтерфейсу",
        "settings_lang_desc": "Виберіть мову інтерфейсу",
        "settings_sound": "🔊 Звук програми",
        "settings_theme": "🎨 Тема оформлення",
        "settings_theme_desc": "Виберіть оформлення додатку",
        "settings_radius": "🔘 Закруглення кутів",
        "font_size": "🔤 Розмір шрифту",
        "font_size_desc": "Розмір тексту в інтерфейсі",
        "radius_desc": "Закруглення кутів елементів",
        "theme_sys": "💻 Системна",
        "theme_dark": "🌙 Темна",
        "theme_light": "☀️ Світла",
        "sound_on": "🔊 Звук: увімк",
        "sound_off": "🔇 Звук: вимк",
        "sound_desc": "Звукові ефекти при діях",
        "close": "❌ Закрити",
        "ok": "✅ Гаразд",
        "cancel": "❌ Скасувати",
        "yes": "✅ Так",
        "no": "❌ Ні",
        "save": "💾 Зберегти",
        "delete": "🗑️ Видалити",
        "edit": "✏️ Редагувати",
        "copy": "📋 Копіювати",
        "clear": "🗑️ Очистити",
        "back": "🔙 Назад",
        "next": "➡️ Далі",
        "finish": "✅ Завершити",
        "apply": "✅ Застосувати",
        "reset": "🔄 Скинути",
        "refresh": "🔄 Оновити",
        
        # 📑 Вкладки налаштувань
        "tab_design": "🎨 Дизайн",
        "tab_security": "🔒 Безпека",
        "tab_general": "⚙️ Загальні",
        
        # 🌈 RGB
        "rgb_label": "🌈 RGB-підсвітка",
        "rgb_label_desc": "Кольорова анімація границь",
        "rgb_on": "✅ Увімк",
        "rgb_off": "❌ Вимк",
        "rgb_speed": "⚡ Швидкість RGB",
        "rgb_speed_desc": "Швидкість анімації",
        "rgb_speed_slow": "🐢 Повільна",
        "rgb_speed_normal": "⚡ Нормальна",
        "rgb_speed_fast": "🚀 Швидка",
        "rgb_width": "📏 Товщина RGB",
        "rgb_width_desc": "Товщина підсвітки",
        "rgb_width_thin": "➖ Тонка",
        "rgb_width_normal": "➖➖ Середня",
        "rgb_width_thick": "🔲 Товста",
        
        # 💾 Автозбереження
        "auto_save": "💾 Автозбереження",
        "auto_save_desc": "Автоматичне збереження паролів",
        "auto_save_on": "✅ Увімкнено",
        "auto_save_off": "❌ Вимкнено",
        "auto_save_enabled": "✅ Автозбереження увімкнено",
        "auto_save_disabled": "❌ Автозбереження вимкнено",
        "auto_save_label": "💾 Автозбереження",
        
        # 🔒 Автоблокування
        "auto_lock": "🔒 Автоблокування",
        "auto_lock_desc": "Автоматичне блокування при бездіяльності",
        "auto_lock_timeout": "⏰ Таймаут блокування: {0} хв",
        "auto_lock_title": "🔒 Програму заблоковано",
        "unlock": "🔓 Розблокувати",
        
        # 📋 Буфер обміну
        "clip_timeout": "📋 Очищення буфера: {0} сек",
        "clip_timeout_desc": "Автоочищення буфера обміну",
        "clipboard_cleared": "✅ Буфер обміну очищено",
        "clipboard_auto_clear": "📋 Автоочищення буфера через {0} сек",
        "clear_clipboard": "🗑️ Очистити буфер обміну",
        "pwd_done": "✅ Пароль скопійовано",
        
        # 🔐 Майстер-пароль
        "master_title": "🔐 Майстер-пароль",
        "master_desc": "Захист доступу до програми",
        "master_prompt": "🔑 Введіть майстер-пароль:",
        "master_set_title": "🔐 Встановити майстер-пароль",
        "master_set_prompt": "🔑 Придумайте майстер-пароль:",
        "master_confirm": "✅ Підтвердіть майстер-пароль:",
        "master_mismatch": "❌ Паролі не збігаються",
        "master_wrong": "❌ Невірний пароль! Спроба {0} з {1}",
        "master_blocked": "🚫 Перевищено кількість спроб. Програму закрито",
        "master_set_ok": "✅ Майстер-пароль встановлено",
        "master_removed": "✅ Майстер-пароль видалено",
        "master_btn_set": "🔐 Встановити майстер-пароль",
        "master_btn_remove": "🗑️ Видалити майстер-пароль",
        "master_current": "📊 Статус:",
        "master_status_set": "✅ Встановлено",
        "master_status_not_set": "❌ Не встановлено",
        "master_remove_confirm": "⚠️ Видалити майстер-пароль?",
        "master_remove_prompt": "🔑 Введіть поточний майстер-пароль:",
        "master_not_set": "❌ Майстер-пароль не встановлено",
        "master_already_set": "✅ Майстер-пароль вже встановлено",
        "master_set_error": "❌ Помилка встановлення майстер-пароля",
        "master_remove_error": "❌ Помилка видалення майстер-пароля",
        "master_status_text": "🔐 Майстер-пароль: встановлено",
        "master_status_not_set_text": "⚠️ Майстер-пароль: не встановлено",
        "master_too_short": "⚠️ Пароль занадто короткий. Мінімум 8 символів",
        "master_weak": "⚠️ Пароль занадто простий. Додайте цифру або спецсимвол",
        
        # 🗄️ База паролів
        "db_title": "🗄️ База паролів",
        "db_label_prompt": "🏷️ Мітка:",
        "db_saved": "✅ Пароль збережено",
        "db_empty": "📭 База порожня",
        "db_copy": "📋 Копіювати",
        "db_delete": "🗑️ Видалити",
        "db_edit": "✏️ Змінити",
        "db_save_current": "💾 Зберегти поточний пароль",
        "db_no_pass": "⚠️ Спочатку згенеруйте пароль",
        "db_count": "📊 Записів: {0}",
        "db_search": "🔍 Пошук",
        "db_del_confirm": "🗑️ Видалити цей запис?",
        "db_edit_title": "✏️ Редагувати запис",
        "db_edit_label": "🏷️ Мітка:",
        "db_edit_pass": "🔑 Пароль:",
        "db_save_success": "✅ Пароль збережено",
        "db_save_error": "❌ Помилка збереження",
        "db_delete_success": "✅ Запис видалено",
        "db_delete_error": "❌ Помилка видалення",
        "db_search_no_results": "🔍 Нічого не знайдено",
        "db_no_label": "🏷️ Без мітки",
        
        # 📜 Історія
        "hist_empty": "📭 Історія порожня",
        "btn_clear_hist": "🗑️ Очистити історію",
        
        # 📄 PDF
        "pdf_date": "📅 Дата",
        "pdf_pass": "🔑 Пароль",
        "pdf_theme": "📄 Тема PDF",
        "pdf_theme_desc": "Оформлення експорту в PDF",
        "pdf_theme_light": "☀️ Світла",
        "pdf_theme_dark": "🌙 Темна",
        
        # 📱 QR-код
        "qr_closes_in": "⏰ Вікно закриється через",
        "seconds_short": "сек",
        
        # 🔒 Блокування
        "lock_screen_title": "🔒 Введіть майстер-пароль",
        "lock_wait": "⏳ Зачекайте",
        
        # 🔍 HIBP
        "hibp_no_password": "⚠️ Спочатку згенеруйте пароль",
        "hibp_checking": "🔍 Перевірка...",
        "hibp_safe": "✅ Пароль безпечний",
        "hibp_found": "❌ Пароль знайдено в {count} витоках",
        "hibp_error": "⚠️ Помилка перевірки",
        "hibp_error_title": "❌ Помилка перевірки",
        "hibp_safe_title": "✅ Пароль безпечний",
        "hibp_found_title": "🚨 УВАГА! Пароль скомпрометовано",
        "hibp_warning": "⚠️ Рекомендується негайно змінити пароль",
        
        # 🔄 Оновлення
        "update_check": "🔄 Перевірка оновлень",
        "update_available": "📦 Доступна версія {0}",
        "update_not_available": "✅ Встановлено останню версію",
        "update_available_title": "📦 Доступно оновлення",
        "update_confirm_title": "🔄 Оновлення",
        "update_confirm_message": "📥 Встановити оновлення?",
        "update_error": "❌ Помилка оновлення",
        "update_signature_error": "❌ Перевірка підпису оновлення не вдалася!",
        "update_integrity_error": "❌ Перевірка цілісності оновлення не вдалася!",
        "update_restart": "✅ Оновлення успішно завантажено!\n\n🔄 Додаток перезапуститься для застосування змін.",
        "download_start": "📥 Завантаження оновлення...",
        "err_timeout": "⏰ Перевищено час очікування",
        "err_import": "❌ Помилка імпорту модуля",
        
        # 🔒 Безпека
        "security": "🔒 Безпека",
        "security_audit_pass": "✅ Перевірку безпеки пройдено",
        "security_audit_fail": "⚠️ Виявлено проблеми безпеки",
        "wiki_link": "📖 Wiki",
        "rate_limit_warning": "⚠️ Режим 'без повторів' знижує стійкість",
        "duplicate_warning": "⚠️ Такий пароль вже існує в базі.\n\n💾 Зберегти все одно?",
        "skip_duplicates": "⏭️ Пропускати дублікати паролів",
        
        # 🗄️ SQLCipher
        "sqlcipher_enabled": "✅ SQLCipher увімкнено",
        "sqlcipher_disabled": "❌ SQLCipher вимкнено",
        
        # ⚠️ Помилки
        "err_cat": "⚠️ Виберіть хоча б одну категорію",
        "err_pool_small": "⚠️ Занадто мало доступних символів",
        "err_save": "❌ Помилка збереження: {0}",
        "err_open": "❌ Не вдалося прочитати файл: {0}",
        "err_unsupported": "❌ Непідтримуваний тип файлу: {0}",
        "err_integrity": "🚨 Критична помилка: Файл пошкоджено",
        "err_no_repeat": "⚠️ Не вдалося створити пароль без повторів",
        "err_no_repeat_fallback": "\n⚠️ Використано пароль з повторами",
        "err_title": "❌ Помилка",
        "err_encrypt": "🔒 Помилка шифрування",
        "err_decrypt": "🔓 Помилка дешифрування",
        "err_database": "🗄️ Помилка бази даних",
        "err_network": "🌐 Помилка мережі",
        "err_permission": "🔐 Помилка доступу",
        "err_copy": "📋 Помилка копіювання",
        "err_qr": "📱 Помилка створення QR-коду",
        "no_pwd": "⚠️ Немає пароля для збереження",
        "warn": "⚠️ Увага",
        
        # 🚨 Цілісність
        "integrity_warn": "⚠️ Файл міг бути змінений. Продовжити?",
        "integrity_fail": "🚨 Файл пошкоджено! Відкриття скасовано",
        "integrity_ok": "✅ Цілісність файлу підтверджено",
        
        # ℹ️ Про програму
        "about_text": "🔐 Професійний генератор паролей\nз відкритим вихідним кодом",
        "about_text_simple": "🔐 Професійний генератор паролів\n\n© Максим Мельников\n📜 MIT License",
        
        # 📊 Статуси
        "status_ok": "✅ Готово",
        "status_error": "❌ Помилка",
        "status_warning": "⚠️ Попередження",
        "please_wait": "⏳ Будь ласка, зачекайте...",
        "copied": "✅ Скопійовано! ({0}с)",
        
        # 🎲 Diceware
        "diceware": "🎲 Diceware режим",
        "diceware_word_count": "📊 Кількість слів",
        "diceware_separator": "🔗 Розділювач",
        "diceware_words": "📝 Слова",
        
        # 🔑 Пароль
        "password_strength_low": "🔴 Слабкий пароль",
        "password_strength_medium": "🟡 Середній пароль",
        "password_strength_high": "🟢 Надійний пароль",
        
        # ⚙️ Додаткові налаштування
        "settings_autosave": "💾 Автозбереження",
        "settings_rgb": "🌈 RGB анімація",
        "settings_sound_effect": "🔊 Звукові ефекти",
        "settings_auto_lock": "🔒 Автоблокування",
        "settings_corner_radius": "🔘 Закруглення кутів",
        "settings_font_size": "🔤 Розмір шрифту",
        "settings_clipboard_timeout": "📋 Таймаут буфера",
        
        # 📤 Експорт
        "export_title": "📤 Експорт даних",
        "export_json": "📄 JSON",
        "export_csv": "📊 CSV",
        "export_html": "🌐 HTML",
        "export_format": "📁 Формат експорту:",
        "export_success": "✅ Дані експортовано: {0}",
        "export_error": "❌ Помилка експорту",
        "export_no_data": "📭 Немає даних для експорту",
        "export_passwords": "🔑 Паролі",
        "export_date": "📅 Дата експорту",
        "export_app": "🔐 Secure Pass Pro v4.0",
        "export_fields": "📋 Виберіть поля для експорту",
        "export_encoding": "🔤 Кодування",
        "export_encrypt": "🔒 Зашифрувати експорт",
        "export_encrypt_password": "🔑 Пароль для шифрування",
        "export_encrypted": "🔒 Файл зашифровано паролем",
        "export_sort_title": "📊 Сортувати за",
        
        # 📥 Імпорт
        "import_title": "📥 Імпорт паролів",
        "import_format": "📁 Формат імпорту:",
        "import_warning": "⚠️ Імпортуйте тільки з перевірених джерел",
        "import_found": "🔍 Знайдено паролів",
        "import_confirm": "📥 Імпортувати?",
        "import_success": "✅ Імпортовано: {0}",
        "import_error": "❌ Помилка імпорту: {0}",
        "import_no_passwords": "📭 Не знайдено паролів у файлі",
        
        # 🔐 2FA
        "2fa_title": "🔐 Двофакторна аутентифікація",
        "2fa_settings_title": "⚙️ Налаштування 2FA",
        "2fa_setup_title": "🔧 Налаштування 2FA",
        "2fa_verify_title": "✅ Підтвердження 2FA",
        "2fa_verify_disable": "🔑 Введіть код 2FA для підтвердження вимкнення:",
        "2fa_verify_regenerate": "🔄 Введіть код 2FA для генерації нових резервних кодів:",
        "2fa_enable": "🔒 Увімкнути 2FA",
        "2fa_disable": "🔓 Вимкнути 2FA",
        "2fa_status_enabled": "✅ Увімкнено",
        "2fa_status_disabled": "❌ Вимкнено",
        "2fa_description": "🔐 Двофакторна аутентифікація додає додатковий рівень безпеки.\n\nПри кожному вході в програму потрібно буде вводити 6-значний код із застосунку-аутентифікатора.",
        "2fa_scan_qr": "📱 Відскануйте цей QR-код застосунком-аутентифікатором:",
        "2fa_or_enter_manually": "✏️ Або введіть цей код вручну:",
        "2fa_enter_code": "🔢 Введіть код підтвердження:",
        "2fa_enter_verification": "🔢 Введіть код із застосунку-аутентифікатора:",
        "2fa_enter_backup": "🎫 Введіть резервний код (формат: XXXXXXXX):",
        "2fa_invalid_code": "❌ Невірний код підтвердження",
        "2fa_incorrect": "❌ Невірний код. Спробуйте ще раз",
        "2fa_enabled_success": "✅ Двофакторну аутентифікацію успішно увімкнено!\n\n💾 Збережіть резервні коди в надійному місці",
        "2fa_disabled_success": "✅ Двофакторну аутентифікацію вимкнено",
        "2fa_disable_confirm": "🔐 2FA вже увімкнена.\n\n❓ Ви хочете вимкнути її?",
        "2fa_disable_warning": "⚠️ УВАГА: Вимкнення 2FA зробить ваш акаунт менш захищеним!\n\n❓ Ви впевнені, що хочете вимкнути 2FA?",
        "2fa_master_required": "🔐 Спочатку встановіть майстер-пароль перед увімкненням 2FA",
        "2fa_setup_cancelled": "❌ Налаштування 2FA скасовано",
        "2fa_backup_codes": "📋 Резервні коди",
        "2fa_backup_codes_info": "🎫 Резервні коди",
        "2fa_backup_title": "🎫 Резервний код",
        "2fa_backup_warning": "⚠️ Збережіть резервні коди! Вони необхідні для відновлення доступу",
        "2fa_backup_warning_detailed": "⚠️ Збережіть ці коди в надійному місці!\n🔑 Кожен код можна використати лише один раз",
        "2fa_backup_count": "📊 Залишилось резервних кодів: {0}",
        "2fa_backup_used": "⚠️ Використано резервний код!\n🔄 Будь ласка, згенеруйте нові резервні коди в налаштуваннях",
        "2fa_invalid_try_backup": "❌ Невірний код.\n\n🎫 Використати резервний код?",
        "2fa_invalid_backup": "❌ Невірний резервний код",
        "2fa_regenerate_backup": "🔄 Згенерувати нові резервні коди",
        "2fa_backup_regenerated": "✅ Нові резервні коди успішно згенеровано",
        "2fa_regenerate_backup_confirm": "🔄 Генерація нових резервних кодів зробить старі недійсними.\n\n❓ Продовжити?",
        "qr_module_missing": "📱 Модуль qrcode не встановлено.\n📦 Встановіть: pip install qrcode[pil]",
        "copy_all": "📋 Копіювати всі",
        "copy": "📋 Копіювати",
    },
}


DEFAULT_LANGUAGE = "RU"
SUPPORTED_LANGUAGES = ["RU", "EN", "UA"]


class LanguageManager:
    """🌐 Менеджер языков с fallback и восстановлением отсутствующих ключей"""
    
    _instance = None
    _current_lang: str = DEFAULT_LANGUAGE
    _fallback_lang: str = DEFAULT_LANGUAGE
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @classmethod
    def set_language(cls, lang_code: str) -> bool:
        """🌐 Установить текущий язык интерфейса"""
        if lang_code in SUPPORTED_LANGUAGES:
            cls._current_lang = lang_code
            logger.debug(f"🌐 Language set to: {lang_code}")
            return True
        logger.warning(f"⚠️ Unsupported language: {lang_code}")
        return False
    
    @classmethod
    def set_fallback(cls, lang_code: str) -> bool:
        """🔄 Установить резервный язык (fallback)"""
        if lang_code in SUPPORTED_LANGUAGES:
            cls._fallback_lang = lang_code
            return True
        return False
    
    @classmethod
    def get_current_lang(cls) -> str:
        """🌐 Получить код текущего языка"""
        return cls._current_lang
    
    @classmethod
    def get_fallback_lang(cls) -> str:
        """🔄 Получить код резервного языка"""
        return cls._fallback_lang
    
    @classmethod
    def get(cls, key: str, default: Optional[str] = None, log_missing: bool = True) -> str:
        """🔍 Получить строку перевода по ключу с умным поиском"""
        # 1️⃣ Пробуем основной язык
        current_dict = LANGUAGES.get(cls._current_lang, {})
        if key in current_dict and current_dict[key]:
            return current_dict[key]
        
        # 2️⃣ Пробуем резервный язык (fallback)
        fallback_dict = LANGUAGES.get(cls._fallback_lang, {})
        if key in fallback_dict and fallback_dict[key]:
            return fallback_dict[key]
        
        # 3️⃣ Пробуем английский как мировой стандарт
        en_dict = LANGUAGES.get("EN", {})
        if key in en_dict and en_dict[key]:
            return en_dict[key]
        
        # 4️⃣ Возвращаем дефолт или сам ключ
        if default is not None:
            return default
        return key


def get_text(key: str, default: Optional[str] = None) -> str:
    """🔍 Получить текст по ключу"""
    return LanguageManager.get(key, default)


def set_language(lang_code: str) -> bool:
    """🌐 Сменить язык приложения"""
    return LanguageManager.set_language(lang_code)


def set_fallback_language(lang_code: str) -> bool:
    """🔄 Сменить резервный язык приложения"""
    return LanguageManager.set_fallback(lang_code)


def get_current_language() -> str:
    """🌐 Получить текущий язык"""
    return LanguageManager.get_current_lang()


def get_fallback_language() -> str:
    """🔄 Получить резервный язык"""
    return LanguageManager.get_fallback_lang()


__all__ = [
    'LANGUAGES',
    'DEFAULT_LANGUAGE',
    'SUPPORTED_LANGUAGES',
    'LanguageManager',
    'get_text',
    'set_language',
    'set_fallback_language',
    'get_current_language',
    'get_fallback_language',
]