# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['Secure_Pass_Pro.pyw'],
    pathex=[],
    binaries=[],
    datas=[('icon.ico', '.'), ('app_icon.ico', '.'), ('Computer Mouse Click.mp3', '.'), ('DejaVuSans.ttf', '.'), ('core', 'core'), ('gui', 'gui'), ('security', 'security'), ('storage', 'storage'), ('localization', 'localization'), ('utils', 'utils')],
    hiddenimports=['customtkinter', 'tkinter', 'PIL._tkinter_finder', 'argon2', 'argon2._ffi', 'argon2._legacy', 'fpdf', 'qrcode', 'cryptography', 'hashlib', 'hmac', 'sqlite3', 'ctypes', 'queue', 'threading', 'webbrowser', 'json'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='SecurePassPro',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['icon.ico'],
)
