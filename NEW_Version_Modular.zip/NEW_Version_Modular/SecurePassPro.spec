# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

datas = [('icon.ico', '.'), ('app_icon.ico', '.'), ('Computer Mouse Click.mp3', '.'), ('DejaVuSans.ttf', '.'), ('core', 'core'), ('gui', 'gui'), ('security', 'security'), ('storage', 'storage'), ('localization', 'localization'), ('utils', 'utils')]
binaries = []
hiddenimports = ['customtkinter', 'tkinter', 'PIL._tkinter_finder', 'argon2', 'argon2._ffi', 'argon2._legacy', 'fpdf', 'qrcode', 'cryptography', 'cryptography.hazmat.primitives.ciphers.aead', 'cryptography.hazmat.primitives.kdf.pbkdf2', 'cryptography.hazmat.backends', 'hashlib', 'hmac', 'sqlite3', 'ctypes', 'queue', 'threading', 'webbrowser', 'json', 'math', 'time', 'datetime', 'tempfile', 'subprocess', 'urllib', 'urllib.request', 'socket', 'logging', 'logging.handlers']
tmp_ret = collect_all('customtkinter')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('qrcode')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('PIL')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('argon2')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
tmp_ret = collect_all('cryptography')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]


a = Analysis(
    ['Secure_Pass_Pro.pyw'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='SecurePassPro',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['icon.ico'],
)
