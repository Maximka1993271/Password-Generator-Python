#!/usr/bin/env python3
"""
Скрипт для поиска ошибок и проблем в коде Secure Pass Pro
БЕЗ создания файлов БД и мастер-пароля
Запуск: python find_issues.py
"""

import os
import re
import sys
import subprocess
from pathlib import Path
from typing import List, Dict, Set, Tuple, Any

# Отключаем создание файлов БД
os.environ['SECUREPASSPRO_TEST_MODE'] = '1'
os.environ['SECUREPASSPRO_SKIP_DB_INIT'] = '1'

# Цвета для вывода
class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    MAGENTA = '\033[95m'
    RESET = '\033[0m'
    BOLD = '\033[1m'


def print_header(text):
    print(f"\n{Colors.CYAN}{'='*70}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}{text:^70}{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*70}{Colors.RESET}\n")


def print_error(text):
    print(f"{Colors.RED}❌ {text}{Colors.RESET}")


def print_warning(text):
    print(f"{Colors.YELLOW}⚠️  {text}{Colors.RESET}")


def print_info(text):
    print(f"{Colors.BLUE}ℹ️  {text}{Colors.RESET}")


def print_success(text):
    print(f"{Colors.GREEN}✅ {text}{Colors.RESET}")


class CodeAnalyzer:
    """Анализатор кода на поиск проблем (без создания файлов)"""

    def __init__(self, root_dir: str):
        self.root_dir = Path(root_dir)
        self.issues: List[Dict] = []
        self.stats = {
            "files": 0,
            "lines": 0,
            "errors": 0,
            "warnings": 0,
            "infos": 0
        }

        # Паттерны для поиска проблем
        self.patterns = {
            "hardcoded_password": re.compile(r'(password|passwd|pwd)\s*=\s*["\'][^"\']+["\']', re.IGNORECASE),
            "hardcoded_key": re.compile(r'(key|secret|token|api_key)\s*=\s*["\'][^"\']{10,}["\']', re.IGNORECASE),
            "eval_usage": re.compile(r'\beval\s*\('),
            "exec_usage": re.compile(r'\bexec\s*\('),
            "pickle_usage": re.compile(r'(pickle\.loads|pickle\.dumps|cPickle)'),
            "insecure_hash": re.compile(r'(md5|sha1)\s*\('),
            "bare_except": re.compile(r'except\s*:'),
            "pass_except": re.compile(r'except.*:\s*pass'),
            "too_broad_except": re.compile(r'except\s+Exception\s*:'),
            "todo_comment": re.compile(r'#\s*TODO|#\s*FIXME|#\s*HACK|#\s*XXX', re.IGNORECASE),
            "star_import": re.compile(r'from\s+\S+\s+import\s+\*'),
            "long_line": re.compile(r'^.{150,}$'),
            "trailing_whitespace": re.compile(r'[ \t]+$'),
            "subprocess_call": re.compile(r'subprocess\.(call|Popen|run)\s*\('),
            "os_system": re.compile(r'os\.system\s*\('),
            "debug_print": re.compile(r'print\s*\(.*[dbg|debug|DEBUG]', re.IGNORECASE),
            "commented_code": re.compile(r'^[ \t]*#.*(def |class |if |for |while |import )'),
        }

    def analyze_file(self, file_path: Path) -> None:
        """Анализирует один Python файл (без выполнения кода)"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.split('\n')

            self.stats["files"] += 1
            self.stats["lines"] += len(lines)

            # Только синтаксическая проверка (без импорта)
            try:
                compile(content, str(file_path), 'exec')
            except SyntaxError as e:
                self.add_issue(file_path, e.lineno or 0, f"Syntax error: {e.msg}", "ERROR")

            # Анализ строк
            for i, line in enumerate(lines, 1):
                self.analyze_line(file_path, line, i)

        except UnicodeDecodeError:
            self.add_issue(file_path, 0, "Unicode decode error (possibly binary file)", "WARNING")
        except Exception as e:
            self.add_issue(file_path, 0, f"Cannot read file: {e}", "ERROR")

    def add_issue(self, file_path: Path, line: int, msg: str, severity: str = "WARNING"):
        """Добавляет проблему в список"""
        self.issues.append({
            "file": str(file_path),
            "line": line,
            "msg": msg,
            "severity": severity
        })
        if severity == "ERROR":
            self.stats["errors"] += 1
        elif severity == "WARNING":
            self.stats["warnings"] += 1
        else:
            self.stats["infos"] += 1

    def analyze_line(self, file_path: Path, line: str, line_num: int) -> None:
        """Анализирует отдельную строку"""

        if len(line.strip()) < 3:
            return

        # Проверка паттернов
        for name, pattern in self.patterns.items():
            if pattern.search(line):
                if name in ["hardcoded_password", "hardcoded_key"]:
                    severity = "ERROR"
                elif name in ["eval_usage", "exec_usage", "pickle_usage", "subprocess_call", "os_system"]:
                    severity = "WARNING"
                else:
                    severity = "INFO"

                short_line = line.strip()[:60]
                self.add_issue(file_path, line_num, f"{name.replace('_', ' ').title()}: {short_line}", severity)

        # Проверка open() без with
        if 'open(' in line and 'with' not in line:
            if 'close()' in line or 'read(' in line or 'write(' in line:
                if 'try:' not in line:
                    self.add_issue(file_path, line_num, "File opened without 'with' context manager", "WARNING")

        # Проверка на слишком широкие except (уже исправлено, но проверяем)
        if re.search(r'except\s+Exception\s*:', line):
            self.add_issue(file_path, line_num, "Too broad except Exception (should use specific exceptions)", "WARNING")

        # Проверка на bare except
        if re.search(r'except\s*:', line) and 'pass' not in line.lower():
            self.add_issue(file_path, line_num, "Bare except: (should specify exception type)", "WARNING")

    def scan_project(self) -> None:
        """Сканирует весь проект (без импорта модулей)"""
        print_header("🔍 СКАНИРОВАНИЕ ПРОЕКТА")

        # Расширения для сканирования
        extensions = ['*.py', '*.pyw']

        python_files = []
        for ext in extensions:
            python_files.extend(list(self.root_dir.rglob(ext)))

        # Исключаем виртуальное окружение и кэш
        excluded_dirs = {'venv', 'env', '__pycache__', '.venv', '.git', 'build', 'dist', '.pytest_cache', '.mypy_cache', '.tox'}
        python_files = [f for f in python_files if not any(ex in f.parts for ex in excluded_dirs)]

        # Исключаем сторонние модули
        python_files = [f for f in python_files if 'site-packages' not in str(f)]

        print_info(f"Найдено файлов для анализа: {len(python_files)}")

        for i, file_path in enumerate(python_files):
            try:
                rel_path = file_path.relative_to(self.root_dir)
                print(f"  [{i+1}/{len(python_files)}] Анализ: {rel_path}")
                self.analyze_file(file_path)
            except Exception as e:
                print_warning(f"  Ошибка анализа {file_path.name}: {e}")

    def print_report(self) -> None:
        """Выводит отчёт о найденных проблемах"""
        print_header("📊 ОТЧЁТ О ПРОВЕРКЕ")

        print_info(f"Проанализировано файлов: {self.stats['files']}")
        print_info(f"Всего строк кода: {self.stats['lines']}")
        print_info(f"Найдено ошибок: {self.stats['errors']}")
        print_info(f"Найдено предупреждений: {self.stats['warnings']}")
        print_info(f"Найдено замечаний: {self.stats['infos']}")

        if self.issues:
            print_header("⚠️  НАЙДЕННЫЕ ПРОБЛЕМЫ")

            errors = [i for i in self.issues if i["severity"] == "ERROR"]
            warnings = [i for i in self.issues if i["severity"] == "WARNING"]
            infos = [i for i in self.issues if i["severity"] == "INFO"]

            if errors:
                print(f"\n{Colors.RED}🔴 ОШИБКИ ({len(errors)}):{Colors.RESET}")
                for issue in errors[:20]:
                    line_info = f":{issue['line']}" if issue['line'] > 0 else ""
                    file_name = Path(issue['file']).name
                    print(f"  {file_name}{line_info} - {issue['msg']}")
                if len(errors) > 20:
                    print_warning(f"  ... и ещё {len(errors)-20} ошибок")

            if warnings:
                print(f"\n{Colors.YELLOW}🟡 ПРЕДУПРЕЖДЕНИЯ ({len(warnings)}):{Colors.RESET}")
                for issue in warnings[:30]:
                    line_info = f":{issue['line']}" if issue['line'] > 0 else ""
                    file_name = Path(issue['file']).name
                    print(f"  {file_name}{line_info} - {issue['msg']}")
                if len(warnings) > 30:
                    print_warning(f"  ... и ещё {len(warnings)-30} предупреждений")

            if infos:
                print(f"\n{Colors.BLUE}🔵 ЗАМЕЧАНИЯ ({len(infos)}):{Colors.RESET}")
                for issue in infos[:20]:
                    line_info = f":{issue['line']}" if issue['line'] > 0 else ""
                    file_name = Path(issue['file']).name
                    print(f"  {file_name}{line_info} - {issue['msg']}")
                if len(infos) > 20:
                    print_warning(f"  ... и ещё {len(infos)-20} замечаний")
        else:
            print_success("🎉 Проблем не найдено!")

    def print_summary(self) -> None:
        """Выводит итоговую сводку"""
        print_header("📈 ИТОГОВАЯ СВОДКА")

        if self.stats["errors"] > 0:
            print_error(f"❌ Найдено {self.stats['errors']} ошибок")
            print_info("Рекомендуется исправить ошибки перед запуском")
        else:
            print_success("✨ Ошибок не найдено!")

        if self.stats["warnings"] > 0:
            print_warning(f"⚠️ Найдено {self.stats['warnings']} предупреждений")
            print_info("Предупреждения не критичны, но желательно их устранить")

        # Вывод общего вердикта
        print_header("🎯 ВЕРДИКТ")
        if self.stats["errors"] == 0 and self.stats["warnings"] == 0:
            print_success("Программа готова к запуску! 🚀")
        elif self.stats["errors"] == 0:
            print_warning("Программа может работать, но есть предупреждения")
        else:
            print_error("Программа содержит ошибки, требуется исправление")


def cleanup_data_folder(root_dir: Path) -> None:
    """Очищает временные файлы, созданные при анализе"""
    data_dir = root_dir / "data"
    if data_dir.exists():
        files_to_remove = ['db.salt', 'master.key', 'passwords.db', 'sqlcipher.salt', 'key.version', 'machine.id']
        removed = []
        for file in files_to_remove:
            file_path = data_dir / file
            if file_path.exists():
                try:
                    file_path.unlink()
                    removed.append(file)
                except Exception:
                    pass
        if removed:
            print_info(f"Очищены временные файлы: {', '.join(removed)}")


def check_python_version() -> bool:
    """Проверяет версию Python"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print_error(f"Требуется Python 3.8+, у вас {version.major}.{version.minor}")
        return False
    print_success(f"Python {version.major}.{version.minor}.{version.micro} - OK")
    return True


def check_imports() -> List[str]:
    """Проверяет наличие необходимых импортов (без выполнения кода)"""
    missing = []
    required_imports = [
        'customtkinter', 'tkinter', 'sqlite3', 'cryptography', 'argon2',
        'qrcode', 'PIL', 'fpdf', 'requests'
    ]

    for module in required_imports:
        try:
            __import__(module)
            print_success(f"{module} - OK")
        except ImportError:
            print_warning(f"{module} - НЕ УСТАНОВЛЕН (опционально)")
            missing.append(module)

    return missing


def main():
    """Главная функция"""
    print_header("🛠️  АНАЛИЗАТОР КОДА SECURE PASS PRO")

    root_dir = Path.cwd()
    print_info(f"Директория проекта: {root_dir}")
    print_info("Сканирование ТОЛЬКО статического кода (без выполнения)")
    print_info("Файлы БД НЕ создаются\n")

    # Проверка Python версии
    if not check_python_version():
        return

    # Проверка импортов
    print_header("📦 ПРОВЕРКА ЗАВИСИМОСТЕЙ")
    missing_imports = check_imports()

    # Анализ кода
    analyzer = CodeAnalyzer(str(root_dir))
    analyzer.scan_project()
    analyzer.print_report()
    analyzer.print_summary()

    # Очистка временных файлов
    cleanup_data_folder(root_dir)

    # Финальное сообщение
    print("\n" + "="*70)
    if missing_imports:
        print_warning(f"Отсутствуют модули: {', '.join(missing_imports)}")
        print_info("Установите: pip install " + " ".join(missing_imports))

    print_info("Нажмите ENTER для выхода...")
    try:
        input()
    except KeyboardInterrupt:
        pass
    except EOFError:
        pass


if __name__ == "__main__":
    # Отключаем создание файлов БД через переменную окружения
    os.environ['SECUREPASSPRO_SKIP_DB_INIT'] = '1'
    main()
