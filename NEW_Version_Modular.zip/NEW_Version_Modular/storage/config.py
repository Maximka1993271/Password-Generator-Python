"""
Configuration manager
"""
import os
import sys
import json
import tempfile
from typing import Dict, Any
from utils.paths import get_config_file, get_config_dir, hide_dir


def _atomic_write_json(path: str, data: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    hide_dir(os.path.dirname(path))
    fd, tmp_path = tempfile.mkstemp(prefix=".tmp-", dir=os.path.dirname(path), text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.remove(tmp_path)
        except Exception:
            pass
        raise


class Config:
    """Application settings manager"""

    _instance = None
    _data: Dict[str, Any] = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._load()
        return cls._instance

    def _load(self) -> None:
        """Load config from file"""
        config_file = get_config_file()
        if not os.path.exists(config_file):
            self._data = {}
            return

        try:
            with open(config_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                self._data = data if isinstance(data, dict) else {}
        except (json.JSONDecodeError, ValueError):
            self._data = {}

    def save(self) -> None:
        """Save config to file"""
        _atomic_write_json(get_config_file(), self._data)

    def get(self, key: str, default=None):
        """Get config value"""
        return self._data.get(key, default)

    def set(self, key: str, value) -> None:
        """Set config value"""
        self._data[key] = value
        self.save()

    def update(self, updates: Dict[str, Any]) -> None:
        """Update multiple config values"""
        self._data.update(updates)
        self.save()