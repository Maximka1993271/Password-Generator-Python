"""
Configuration manager with schema validation, corruption recovery, and backup
"""
import os
import sys
import json
import shutil
import re
import time
import threading
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
from utils.paths import get_config_file, get_config_dir, hide_dir
from utils.logger import get_logger
from utils.secure_file_ops import secure_write, secure_read

logger = get_logger("config")

# ==================== СХЕМА КОНФИГУРАЦИИ ====================

CONFIG_SCHEMA: Dict[str, Dict[str, Any]] = {
    # Тема и язык
    "THEME": {"type": str, "default": "Dark", "allowed": ["System", "Light", "Dark"]},
    "LANG": {"type": str, "default": "RU", "allowed": ["RU", "EN", "UA"]},
    
    # Звук и RGB
    "SOUND": {"type": bool, "default": True},
    "RGB": {"type": bool, "default": True},
    "RGB_SPEED": {"type": str, "default": "normal", "allowed": ["slow", "normal", "fast"]},
    "RGB_WIDTH": {"type": str, "default": "normal", "allowed": ["thin", "normal", "thick"]},
    
    # Интерфейс
    "RADIUS": {"type": int, "default": 25, "min": 0, "max": 50},
    "font_size": {"type": int, "default": 14, "min": 8, "max": 24},
    
    # Безопасность и таймауты
    "CLIP_TIMEOUT": {"type": int, "default": 60, "min": 5, "max": 300},
    "AUTO_LOCK": {"type": bool, "default": False},
    "AUTO_LOCK_TIMEOUT": {"type": int, "default": 5, "min": 1, "max": 60},
    
    # Автосохранение
    "auto_save": {"type": bool, "default": False},
    
    # PDF тема
    "PDF_THEME": {"type": str, "default": "light", "allowed": ["light", "dark"]},
    
    # ==================== 2FA НАСТРОЙКИ (ДОБАВЛЕНО) ====================
    "2fa_enabled": {"type": bool, "default": False},
    "2fa_secret": {"type": str, "default": ""},
    "2fa_backup_hashes": {"type": list, "default": []},
    "2fa_account_name": {"type": str, "default": ""},
    "2fa_setup_completed": {"type": bool, "default": False},
    "2fa_last_verified": {"type": str, "default": ""},  # ISO timestamp
}

# Версия схемы для миграции
SCHEMA_VERSION = 4  # Обновляем версию для 2FA
SCHEMA_MIGRATIONS: Dict[int, Callable[[Dict[str, Any]], Dict[str, Any]]] = {}


class ConfigError(Exception):
    """Исключение для ошибок конфигурации"""
    pass


class ConfigCorruptionError(ConfigError):
    """Исключение для повреждения конфигурации"""
    pass


class ConfigMigrationError(ConfigError):
    """Исключение для ошибок миграции"""
    pass


def _atomic_write_json(path: str, data: Dict[str, Any]) -> bool:
    """Атомарная запись JSON с проверкой целостности"""
    directory = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(directory, exist_ok=True)
    hide_dir(directory)
    
    try:
        content = json.dumps(data, indent=2, ensure_ascii=False).encode('utf-8')
        
        if not secure_write(path, content, make_hidden=True):
            return False
        
        # Проверяем целостность записанного файла
        read_content = secure_read(path)
        if read_content:
            test_data = json.loads(read_content.decode('utf-8'))
            if test_data != data:
                logger.error("JSON integrity check failed - data mismatch")
                return False
        
        return True
    except (OSError, IOError, TypeError) as e:
        logger.error(f"Atomic write failed: {e}")
        return False


def _create_backup(config_path: str) -> Optional[str]:
    """Создаёт резервную копию конфига"""
    if not os.path.exists(config_path):
        return None
    
    backup_dir = os.path.join(get_config_dir(), "config_backups")
    os.makedirs(backup_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(backup_dir, f"config_backup_{timestamp}.json")
    
    try:
        shutil.copy2(config_path, backup_path)
        logger.debug(f"Config backup created: {backup_path}")
        return backup_path
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Failed to create config backup: {e}")
        return None


def _cleanup_old_backups(backup_dir: str, max_backups: int = 5) -> None:
    """Очищает старые резервные копии"""
    try:
        if not os.path.exists(backup_dir):
            return
        
        backups = []
        for f in os.listdir(backup_dir):
            if f.startswith("config_backup_") and f.endswith(".json"):
                f_path = os.path.join(backup_dir, f)
                backups.append((f_path, os.path.getmtime(f_path)))
        
        # Сортируем по времени (старые первые)
        backups.sort(key=lambda x: x[1])
        
        # Удаляем лишние
        while len(backups) > max_backups:
            old_file = backups.pop(0)[0]
            try:
                os.remove(old_file)
                logger.debug(f"Removed old backup: {old_file}")
            except (OSError, IOError, PermissionError) as e:
                logger.warning(f"Failed to remove old backup: {e}")
    except (OSError, IOError) as e:
        logger.debug(f"Backup cleanup error: {e}")


def _validate_config(config: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    """
    Валидация конфигурации по схеме.
    Возвращает (валидированный_словарь, список_ошибок)
    """
    validated = {}
    errors = []
    
    for key, schema in CONFIG_SCHEMA.items():
        value = config.get(key, schema["default"])
        
        # Проверка типа
        if not isinstance(value, schema["type"]):
            errors.append(f"Config key '{key}' has wrong type {type(value).__name__}, expected {schema['type'].__name__}")
            logger.warning(f"Config key '{key}' has wrong type, using default: {schema['default']}")
            value = schema["default"]
        
        # Проверка допустимых значений (если есть)
        if "allowed" in schema and value not in schema["allowed"]:
            errors.append(f"Config key '{key}' value '{value}' not allowed. Allowed: {schema['allowed']}")
            logger.warning(f"Config key '{key}' value '{value}' not allowed, using default: {schema['default']}")
            value = schema["default"]
        
        # Проверка диапазона (для чисел)
        if "min" in schema and isinstance(value, (int, float)) and value < schema["min"]:
            errors.append(f"Config key '{key}' value {value} below minimum {schema['min']}")
            logger.warning(f"Config key '{key}' value {value} below min {schema['min']}, using default: {schema['default']}")
            value = schema["default"]
        if "max" in schema and isinstance(value, (int, float)) and value > schema["max"]:
            errors.append(f"Config key '{key}' value {value} above maximum {schema['max']}")
            logger.warning(f"Config key '{key}' value {value} above max {schema['max']}, using default: {schema['default']}")
            value = schema["default"]
        
        validated[key] = value
    
    # Добавляем неизвестные ключи как есть (для обратной совместимости)
    for key, value in config.items():
        if key not in validated and not key.startswith("_"):
            validated[key] = value
    
    return validated, errors


def _migrate_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Миграция конфигурации из старых версий.
    Поддерживает версии 1, 2, 3, 4.
    """
    version = config.get("_schema_version", 1)
    
    if version >= SCHEMA_VERSION:
        return config
    
    logger.info(f"Migrating config from version {version} to {SCHEMA_VERSION}")
    
    # Создаём резервную копию перед миграцией
    _create_backup(get_config_file())
    
    # Миграция с версии 1 на 2
    if version == 1:
        # Добавляем новые поля
        for key, schema in CONFIG_SCHEMA.items():
            if key not in config:
                config[key] = schema["default"]
        
        # Добавляем PDF_THEME
        if "PDF_THEME" not in config:
            config["PDF_THEME"] = "light"
        
        config["_schema_version"] = 2
    
    # Миграция с версии 2 на 3
    if version <= 2:
        # Валидация существующих значений
        for key, schema in CONFIG_SCHEMA.items():
            if key in config:
                value = config[key]
                # Проверяем допустимость
                if "allowed" in schema and value not in schema["allowed"]:
                    config[key] = schema["default"]
                    logger.warning(f"Migrated invalid value for {key} to default: {schema['default']}")
        
        config["_schema_version"] = 3
    
    # ==================== МИГРАЦИЯ НА ВЕРСИЮ 4 (ДЛЯ 2FA) ====================
    if version <= 3:
        # Добавляем 2FA поля
        for key in ["2fa_enabled", "2fa_secret", "2fa_backup_hashes", 
                    "2fa_account_name", "2fa_setup_completed", "2fa_last_verified"]:
            if key not in config:
                config[key] = CONFIG_SCHEMA.get(key, {"default": None})["default"]
        
        config["_schema_version"] = 4
        logger.info("Added 2FA configuration fields during migration")
    
    logger.info(f"Config migrated to version {SCHEMA_VERSION}")
    return config


def _repair_config(file_path: str) -> Optional[Dict[str, Any]]:
    """Попытка восстановить повреждённый конфиг"""
    logger.warning(f"Attempting to repair config: {file_path}")
    
    # Создаём бэкап повреждённого файла
    backup_path = file_path + ".corrupted"
    try:
        shutil.copy2(file_path, backup_path)
        logger.info(f"Backup of corrupted config saved to: {backup_path}")
    except (OSError, IOError, PermissionError) as e:
        logger.warning(f"Failed to backup corrupted config: {e}")
    
    # Пробуем прочитать файл построчно, игнорируя ошибки
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Удаляем невалидные управляющие символы
        clean_content = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', content)
        
        # Пробуем найти JSON объект
        json_match = re.search(r'\{.*\}', clean_content, re.DOTALL)
        if json_match:
            clean_content = json_match.group()
        
        # Пробуем спарсить очищенный контент
        try:
            repaired = json.loads(clean_content)
            logger.info("Config successfully repaired")
            return repaired
        except json.JSONDecodeError:
            # Пробуем более агрессивное восстановление
            clean_content = clean_content.replace("'", '"')
            clean_content = re.sub(r'//.*?$', '', clean_content, flags=re.MULTILINE)
            clean_content = re.sub(r'/\*.*?\*/', '', clean_content, flags=re.DOTALL)
            
            try:
                repaired = json.loads(clean_content)
                logger.info("Config successfully repaired (aggressive mode)")
                return repaired
            except json.JSONDecodeError:
                # Пробуем восстановить из бэкапа
                return _restore_from_backup()
    except (OSError, IOError) as e:
        logger.error(f"Config repair failed: {e}")
    
    # Если не удалось восстановить, пробуем из бэкапа
    return _restore_from_backup()


def _restore_from_backup() -> Optional[Dict[str, Any]]:
    """Восстанавливает конфиг из последнего бэкапа"""
    backup_dir = os.path.join(get_config_dir(), "config_backups")
    if not os.path.exists(backup_dir):
        return None
    
    backups = []
    for f in os.listdir(backup_dir):
        if f.startswith("config_backup_") and f.endswith(".json"):
            f_path = os.path.join(backup_dir, f)
            backups.append((f_path, os.path.getmtime(f_path)))
    
    if not backups:
        logger.warning("No backups found for recovery")
        return None
    
    # Сортируем по времени (новые первые)
    backups.sort(key=lambda x: x[1], reverse=True)
    latest_backup = backups[0][0]
    
    try:
        with open(latest_backup, 'r', encoding='utf-8') as f:
            restored = json.load(f)
        logger.info(f"Config restored from backup: {latest_backup}")
        return restored
    except (OSError, IOError, json.JSONDecodeError) as e:
        logger.error(f"Backup restore failed: {e}")
        return None


class Config:
    """Application settings manager with schema validation, recovery, and backup"""

    _instance = None
    _lock = threading.Lock()
    _data: Dict[str, Any] = {}
    _backup_path: Optional[str] = None
    _config_file: Optional[str] = None
    _last_save_time: float = 0
    _save_cooldown: float = 1.0  # Секунд между сохранениями

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._config_file = get_config_file()
                    cls._instance._backup_path = cls._instance._config_file + ".backup"
                    cls._instance._load()
        return cls._instance

    def _load(self) -> None:
        """Load config from file with validation, recovery, and migration"""
        config_file = self._config_file
        
        if not os.path.exists(config_file):
            logger.info("Config file not found, creating default")
            self._data = self._get_default_config()
            self._data["_schema_version"] = SCHEMA_VERSION
            self.save()
            return

        try:
            content = secure_read(config_file)
            if content:
                raw_data = json.loads(content.decode('utf-8'))
            else:
                raise ConfigCorruptionError("Empty config file")
            
            # Миграция старых версий
            if raw_data.get("_schema_version", 1) < SCHEMA_VERSION:
                raw_data = _migrate_config(raw_data)
            
            # Валидация и нормализация
            validated_data, errors = _validate_config(raw_data)
            
            if errors:
                logger.warning(f"Config validation had {len(errors)} errors: {errors[:3]}...")
            
            self._data = validated_data
            self._data["_schema_version"] = SCHEMA_VERSION
            
            # Если данные изменились (были невалидные ключи), сохраняем
            if validated_data != raw_data:
                logger.info("Config normalized, saving changes")
                self.save()
                
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            repaired = _repair_config(config_file)
            if repaired:
                validated_data, errors = _validate_config(repaired)
                self._data = validated_data
                self._data["_schema_version"] = SCHEMA_VERSION
                self.save()
                logger.info("Config restored after corruption")
            else:
                logger.warning("Using default config")
                self._data = self._get_default_config()
                self._data["_schema_version"] = SCHEMA_VERSION
        except ConfigCorruptionError as e:
            logger.error(f"Config corruption: {e}")
            self._data = self._get_default_config()
            self._data["_schema_version"] = SCHEMA_VERSION
        except (PermissionError, OSError, ValueError) as e:
            logger.error(f"Error reading config: {e}")
            self._data = self._get_default_config()
            self._data["_schema_version"] = SCHEMA_VERSION
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {key: schema["default"] for key, schema in CONFIG_SCHEMA.items()}

    def save(self) -> bool:
        """Save config to file with atomic write, backup, and cooldown"""
        config_file = self._config_file
        
        # Проверяем cooldown
        current_time = time.time()
        if current_time - self._last_save_time < self._save_cooldown:
            logger.debug("Save skipped due to cooldown")
            return True
        
        # Создаём бэкап перед сохранением
        if os.path.exists(config_file):
            _create_backup(config_file)
        
        # Сохраняем с версией схемы
        save_data = self._data.copy()
        save_data["_schema_version"] = SCHEMA_VERSION
        
        success = _atomic_write_json(config_file, save_data)
        if success:
            self._last_save_time = current_time
            # Очищаем старые бэкапы
            backup_dir = os.path.join(get_config_dir(), "config_backups")
            _cleanup_old_backups(backup_dir)
        else:
            logger.error("Failed to save config")
            # Пробуем восстановить из бэкапа
            restored = _restore_from_backup()
            if restored:
                self._data = restored
                return self.save()
        
        return success

    def get(self, key: str, default=None):
        """Get config value with type validation"""
        value = self._data.get(key, default)
        
        if key in CONFIG_SCHEMA and value is not None:
            expected_type = CONFIG_SCHEMA[key]["type"]
            if not isinstance(value, expected_type):
                logger.warning(f"Config key '{key}' has wrong type, returning default")
                return CONFIG_SCHEMA[key]["default"]
        
        return value

    def set(self, key: str, value) -> bool:
        """Set config value with validation. Returns success status."""
        with self._lock:
            if key in CONFIG_SCHEMA:
                schema = CONFIG_SCHEMA[key]
                
                if not isinstance(value, schema["type"]):
                    logger.error(f"Config key '{key}' expects type {schema['type'].__name__}, got {type(value).__name__}")
                    return False
                
                if "allowed" in schema and value not in schema["allowed"]:
                    logger.error(f"Config key '{key}' value '{value}' not allowed. Allowed: {schema['allowed']}")
                    return False
                
                if "min" in schema and isinstance(value, (int, float)) and value < schema["min"]:
                    logger.error(f"Config key '{key}' value {value} below minimum {schema['min']}")
                    return False
                if "max" in schema and isinstance(value, (int, float)) and value > schema["max"]:
                    logger.error(f"Config key '{key}' value {value} above maximum {schema['max']}")
                    return False
            
            self._data[key] = value
            return self.save()

    def update(self, updates: Dict[str, Any]) -> int:
        """Update multiple config values. Returns number of successful updates."""
        success_count = 0
        for key, value in updates.items():
            if self.set(key, value):
                success_count += 1
            else:
                logger.error(f"Failed to update config key '{key}'")
        
        if success_count > 0:
            self.save()
        
        return success_count
    
    def reset_to_defaults(self) -> bool:
        """Reset all settings to defaults"""
        with self._lock:
            self._data = self._get_default_config()
            self._data["_schema_version"] = SCHEMA_VERSION
            return self.save()
    
    def export(self, file_path: str) -> bool:
        """Export config to another file"""
        try:
            content = json.dumps(self._data, indent=2, ensure_ascii=False).encode('utf-8')
            return secure_write(file_path, content, make_hidden=False)
        except (OSError, IOError) as e:
            logger.error(f"Config export failed: {e}")
            return False
    
    def import_from(self, file_path: str) -> bool:
        """Import config from another file with validation"""
        try:
            content = secure_read(file_path)
            if not content:
                return False
            
            raw_data = json.loads(content.decode('utf-8'))
            validated_data, errors = _validate_config(raw_data)
            if errors:
                logger.warning(f"Import config has {len(errors)} errors, but imported anyway")
            
            self._data = validated_data
            self._data["_schema_version"] = SCHEMA_VERSION
            return self.save()
        except (OSError, IOError, json.JSONDecodeError) as e:
            logger.error(f"Config import failed: {e}")
            return False
    
    def get_backup_available(self) -> bool:
        """Check if backup config is available"""
        return os.path.exists(self._backup_path)
    
    def restore_from_backup(self) -> bool:
        """Restore config from backup"""
        if not self.get_backup_available():
            logger.warning("No backup available")
            return False
        
        try:
            content = secure_read(self._backup_path)
            if not content:
                return False
            
            backup_data = json.loads(content.decode('utf-8'))
            validated_data, errors = _validate_config(backup_data)
            self._data = validated_data
            self._data["_schema_version"] = SCHEMA_VERSION
            return self.save()
        except Exception as e:
            logger.error(f"Backup restore failed: {e}")
            return False
    
    def validate_all(self) -> Tuple[bool, List[str]]:
        """Validate entire config. Returns (is_valid, list_of_errors)"""
        _, errors = _validate_config(self._data)
        return len(errors) == 0, errors
    
    def get_schema_info(self) -> Dict[str, Any]:
        """Get schema information for UI"""
        info = {}
        for key, schema in CONFIG_SCHEMA.items():
            info[key] = {
                "type": schema["type"].__name__,
                "default": schema["default"],
                "current": self._data.get(key, schema["default"])
            }
            if "allowed" in schema:
                info[key]["allowed"] = schema["allowed"]
            if "min" in schema:
                info[key]["min"] = schema["min"]
            if "max" in schema:
                info[key]["max"] = schema["max"]
        return info
    
    def get_version(self) -> int:
        """Get current config schema version"""
        return self._data.get("_schema_version", 1)
    
    def has_key(self, key: str) -> bool:
        """Check if key exists in config"""
        return key in self._data
    
    def get_all(self) -> Dict[str, Any]:
        """Get a copy of all config data"""
        return self._data.copy()
    
    # ==================== 2FA МЕТОДЫ (ДОБАВЛЕНО) ====================
    
    def is_2fa_enabled(self) -> bool:
        """Проверяет, включена ли 2FA"""
        return self.get("2fa_enabled", False)
    
    def get_2fa_secret(self) -> str:
        """Возвращает секрет 2FA"""
        return self.get("2fa_secret", "")
    
    def get_2fa_backup_hashes(self) -> List[str]:
        """Возвращает хеши резервных кодов"""
        return self.get("2fa_backup_hashes", [])
    
    def get_2fa_account_name(self) -> str:
        """Возвращает имя аккаунта для 2FA"""
        return self.get("2fa_account_name", "")
    
    def is_2fa_setup_completed(self) -> bool:
        """Проверяет, завершена ли настройка 2FA"""
        return self.get("2fa_setup_completed", False)
    
    def set_2fa_enabled(self, enabled: bool) -> bool:
        """Включает/выключает 2FA"""
        return self.set("2fa_enabled", enabled)
    
    def set_2fa_secret(self, secret: str) -> bool:
        """Устанавливает секрет 2FA"""
        return self.set("2fa_secret", secret)
    
    def set_2fa_backup_hashes(self, hashes: List[str]) -> bool:
        """Устанавливает хеши резервных кодов"""
        return self.set("2fa_backup_hashes", hashes)
    
    def set_2fa_account_name(self, name: str) -> bool:
        """Устанавливает имя аккаунта для 2FA"""
        return self.set("2fa_account_name", name)
    
    def set_2fa_setup_completed(self, completed: bool) -> bool:
        """Отмечает завершение настройки 2FA"""
        return self.set("2fa_setup_completed", completed)
    
    def set_2fa_last_verified(self, timestamp: str = None) -> bool:
        """Устанавливает время последней верификации 2FA"""
        if timestamp is None:
            from datetime import datetime
            timestamp = datetime.now().isoformat()
        return self.set("2fa_last_verified", timestamp)
    
    def clear_2fa(self) -> bool:
        """Очищает все 2FA настройки"""
        success = True
        success &= self.set("2fa_enabled", False)
        success &= self.set("2fa_secret", "")
        success &= self.set("2fa_backup_hashes", [])
        success &= self.set("2fa_setup_completed", False)
        success &= self.set("2fa_last_verified", "")
        # Не очищаем account_name, он может понадобиться при повторной настройке
        return success


# Экспорт
__all__ = [
    'Config',
    'ConfigError',
    'ConfigCorruptionError',
    'ConfigMigrationError',
]