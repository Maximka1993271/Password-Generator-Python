"""
Configuration manager with schema validation, corruption recovery, and backup
"""
import os
import sys
import json
import tempfile
import shutil
import re
from typing import Dict, Any, Optional, List, Tuple
from utils.paths import get_config_file, get_config_dir, hide_dir
from utils.logger import get_logger

logger = get_logger("config")

# ==================== СХЕМА КОНФИГУРАЦИИ ====================

CONFIG_SCHEMA: Dict[str, Dict[str, Any]] = {
    # Тема и язык
    "THEME": {"type": str, "default": "Dark", "allowed": ["System", "Light", "Dark"]},
    "LANG": {"type": str, "default": "RU", "allowed": ["RU", "EN", "UA"]},
    
    # Звук и RGB
    "SOUND": {"type": bool, "default": True},
    "RGB": {"type": bool, "default": True},
    "RGB_SPEED": {"type": str, "default": "normal", "allowed": ["slow", "normal", "fast"]},
    "RGB_WIDTH": {"type": str, "default": "normal", "allowed": ["thin", "normal", "thick"]},
    
    # Интерфейс
    "RADIUS": {"type": int, "default": 25, "min": 0, "max": 50},
    "font_size": {"type": int, "default": 14, "min": 8, "max": 24},
    
    # Безопасность и таймауты
    "CLIP_TIMEOUT": {"type": int, "default": 60, "min": 5, "max": 300},
    "AUTO_LOCK": {"type": bool, "default": False},
    "AUTO_LOCK_TIMEOUT": {"type": int, "default": 5, "min": 1, "max": 60},
    
    # Автосохранение
    "auto_save": {"type": bool, "default": False},
}

# Версия схемы для миграции
SCHEMA_VERSION = 2


def _atomic_write_json(path: str, data: Dict[str, Any]) -> bool:
    """Атомарная запись JSON с проверкой целостности"""
    directory = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(directory, exist_ok=True)
    hide_dir(directory)
    
    fd, tmp_path = tempfile.mkstemp(prefix=".tmp-", dir=directory, text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        
        # Проверяем целостность записанного файла
        with open(tmp_path, 'r', encoding='utf-8') as f:
            test_data = json.load(f)
            if test_data != data:
                raise ValueError("JSON integrity check failed - data mismatch")
        
        os.replace(tmp_path, path)
        return True
    except (json.JSONDecodeError, ValueError, OSError, IOError) as e:
        logger.error(f"Atomic write failed: {e}")
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        return False
    except Exception as e:
        logger.error(f"Unexpected error in atomic write: {e}")
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        return False


def _validate_config(config: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    """
    Валидация конфигурации по схеме.
    Возвращает (валидированный_словарь, список_ошибок)
    """
    validated = {}
    errors = []
    
    for key, schema in CONFIG_SCHEMA.items():
        value = config.get(key, schema["default"])
        
        # Проверка типа
        if not isinstance(value, schema["type"]):
            errors.append(f"Config key '{key}' has wrong type {type(value).__name__}, expected {schema['type'].__name__}")
            logger.warning(f"Config key '{key}' has wrong type, using default: {schema['default']}")
            value = schema["default"]
        
        # Проверка допустимых значений (если есть)
        if "allowed" in schema and value not in schema["allowed"]:
            errors.append(f"Config key '{key}' value '{value}' not allowed. Allowed: {schema['allowed']}")
            logger.warning(f"Config key '{key}' value '{value}' not allowed, using default: {schema['default']}")
            value = schema["default"]
        
        # Проверка диапазона (для чисел)
        if "min" in schema and isinstance(value, (int, float)) and value < schema["min"]:
            errors.append(f"Config key '{key}' value {value} below minimum {schema['min']}")
            logger.warning(f"Config key '{key}' value {value} below min {schema['min']}, using default: {schema['default']}")
            value = schema["default"]
        if "max" in schema and isinstance(value, (int, float)) and value > schema["max"]:
            errors.append(f"Config key '{key}' value {value} above maximum {schema['max']}")
            logger.warning(f"Config key '{key}' value {value} above max {schema['max']}, using default: {schema['default']}")
            value = schema["default"]
        
        validated[key] = value
    
    # Добавляем неизвестные ключи как есть (для обратной совместимости)
    for key, value in config.items():
        if key not in validated and not key.startswith("_"):
            validated[key] = value
    
    return validated, errors


def _repair_config(file_path: str) -> Optional[Dict[str, Any]]:
    """Попытка восстановить повреждённый конфиг"""
    logger.warning(f"Attempting to repair config: {file_path}")
    
    try:
        # Создаём бэкап повреждённого файла
        backup_path = file_path + ".corrupted"
        shutil.copy2(file_path, backup_path)
        logger.info(f"Backup of corrupted config saved to: {backup_path}")
        
        # Пробуем прочитать файл построчно, игнорируя ошибки
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Пробуем восстановить JSON
        # Удаляем невалидные управляющие символы
        clean_content = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', content)
        
        # Пробуем найти JSON объект
        json_match = re.search(r'\{.*\}', clean_content, re.DOTALL)
        if json_match:
            clean_content = json_match.group()
        
        # Пробуем спарсить очищенный контент
        try:
            repaired = json.loads(clean_content)
            logger.info("Config successfully repaired")
            return repaired
        except json.JSONDecodeError:
            # Пробуем более агрессивное восстановление
            clean_content = clean_content.replace("'", '"')
            clean_content = re.sub(r'//.*?$', '', clean_content, flags=re.MULTILINE)
            clean_content = re.sub(r'/\*.*?\*/', '', clean_content, flags=re.DOTALL)
            
            try:
                repaired = json.loads(clean_content)
                logger.info("Config successfully repaired (aggressive mode)")
                return repaired
            except json.JSONDecodeError:
                logger.warning("Could not repair config, using defaults")
                return None
    except Exception as e:
        logger.error(f"Config repair failed: {e}")
        return None


def _migrate_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Миграция конфигурации из старых версий"""
    version = config.get("_schema_version", 1)
    
    if version >= SCHEMA_VERSION:
        return config
    
    logger.info(f"Migrating config from version {version} to {SCHEMA_VERSION}")
    
    # Миграция с версии 1 на 2
    if version == 1:
        for key, schema in CONFIG_SCHEMA.items():
            if key not in config:
                config[key] = schema["default"]
        
        config["_schema_version"] = 2
    
    return config


class Config:
    """Application settings manager with schema validation, recovery, and backup"""

    _instance = None
    _data: Dict[str, Any] = {}
    _backup_path: Optional[str] = None
    _config_file: Optional[str] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._config_file = get_config_file()
            cls._instance._backup_path = cls._instance._config_file + ".backup"
            cls._instance._load()
        return cls._instance

    def _load(self) -> None:
        """Load config from file with validation, recovery, and migration"""
        config_file = self._config_file
        
        if not os.path.exists(config_file):
            logger.info("Config file not found, creating default")
            self._data = self._get_default_config()
            self._data["_schema_version"] = SCHEMA_VERSION
            self.save()
            return

        try:
            with open(config_file, "r", encoding="utf-8") as f:
                raw_data = json.load(f)
            
            # Миграция старых версий
            if raw_data.get("_schema_version", 1) < SCHEMA_VERSION:
                raw_data = _migrate_config(raw_data)
            
            # Валидация и нормализация
            validated_data, errors = _validate_config(raw_data)
            
            if errors:
                logger.warning(f"Config validation had {len(errors)} errors: {errors[:3]}...")
            
            self._data = validated_data
            self._data["_schema_version"] = SCHEMA_VERSION
            
            # Если данные изменились (были невалидные ключи), сохраняем
            if validated_data != raw_data:
                logger.info("Config normalized, saving changes")
                self.save()
                
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            repaired = _repair_config(config_file)
            if repaired:
                validated_data, errors = _validate_config(repaired)
                self._data = validated_data
                self._data["_schema_version"] = SCHEMA_VERSION
                self.save()
                logger.info("Config restored after corruption")
            else:
                logger.warning("Using default config")
                self._data = self._get_default_config()
                self._data["_schema_version"] = SCHEMA_VERSION
                
        except (PermissionError, OSError) as e:
            logger.error(f"Error reading config: {e}")
            self._data = self._get_default_config()
            self._data["_schema_version"] = SCHEMA_VERSION
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {key: schema["default"] for key, schema in CONFIG_SCHEMA.items()}

    def save(self) -> bool:
        """Save config to file with atomic write and backup"""
        config_file = self._config_file
        
        # Создаём бэкап перед сохранением
        if os.path.exists(config_file):
            try:
                shutil.copy2(config_file, self._backup_path)
                logger.debug(f"Backup created: {self._backup_path}")
            except (OSError, IOError) as e:
                logger.debug(f"Backup creation failed: {e}")
        
        # Сохраняем с версией схемы
        save_data = self._data.copy()
        save_data["_schema_version"] = SCHEMA_VERSION
        
        success = _atomic_write_json(config_file, save_data)
        if not success:
            logger.error("Failed to save config")
            if os.path.exists(self._backup_path):
                try:
                    shutil.copy2(self._backup_path, config_file)
                    logger.info("Config restored from backup")
                    return True
                except Exception as e:
                    logger.error(f"Backup restore failed: {e}")
        
        return success

    def get(self, key: str, default=None):
        """Get config value with type validation"""
        value = self._data.get(key, default)
        
        if key in CONFIG_SCHEMA and value is not None:
            expected_type = CONFIG_SCHEMA[key]["type"]
            if not isinstance(value, expected_type):
                logger.warning(f"Config key '{key}' has wrong type, returning default")
                return CONFIG_SCHEMA[key]["default"]
        
        return value

    def set(self, key: str, value) -> bool:
        """Set config value with validation. Returns success status."""
        if key in CONFIG_SCHEMA:
            schema = CONFIG_SCHEMA[key]
            
            if not isinstance(value, schema["type"]):
                logger.error(f"Config key '{key}' expects type {schema['type'].__name__}, got {type(value).__name__}")
                return False
            
            if "allowed" in schema and value not in schema["allowed"]:
                logger.error(f"Config key '{key}' value '{value}' not allowed. Allowed: {schema['allowed']}")
                return False
            
            if "min" in schema and isinstance(value, (int, float)) and value < schema["min"]:
                logger.error(f"Config key '{key}' value {value} below minimum {schema['min']}")
                return False
            if "max" in schema and isinstance(value, (int, float)) and value > schema["max"]:
                logger.error(f"Config key '{key}' value {value} above maximum {schema['max']}")
                return False
        
        self._data[key] = value
        return self.save()

    def update(self, updates: Dict[str, Any]) -> int:
        """Update multiple config values. Returns number of successful updates."""
        success_count = 0
        for key, value in updates.items():
            if self.set(key, value):
                success_count += 1
            else:
                logger.error(f"Failed to update config key '{key}'")
        
        if success_count > 0:
            self.save()
        
        return success_count
    
    def reset_to_defaults(self) -> bool:
        """Reset all settings to defaults"""
        self._data = self._get_default_config()
        self._data["_schema_version"] = SCHEMA_VERSION
        return self.save()
    
    def export(self, file_path: str) -> bool:
        """Export config to another file"""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(self._data, f, indent=2, ensure_ascii=False)
            return True
        except (OSError, IOError) as e:
            logger.error(f"Config export failed: {e}")
            return False
    
    def import_from(self, file_path: str) -> bool:
        """Import config from another file with validation"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                raw_data = json.load(f)
            
            validated_data, errors = _validate_config(raw_data)
            if errors:
                logger.warning(f"Import config has {len(errors)} errors, but imported anyway")
            
            self._data = validated_data
            self._data["_schema_version"] = SCHEMA_VERSION
            return self.save()
        except (OSError, IOError, json.JSONDecodeError) as e:
            logger.error(f"Config import failed: {e}")
            return False
    
    def get_backup_available(self) -> bool:
        """Check if backup config is available"""
        return os.path.exists(self._backup_path)
    
    def restore_from_backup(self) -> bool:
        """Restore config from backup"""
        if not self.get_backup_available():
            logger.warning("No backup available")
            return False
        
        try:
            with open(self._backup_path, 'r', encoding='utf-8') as f:
                backup_data = json.load(f)
            
            validated_data, errors = _validate_config(backup_data)
            self._data = validated_data
            self._data["_schema_version"] = SCHEMA_VERSION
            return self.save()
        except Exception as e:
            logger.error(f"Backup restore failed: {e}")
            return False
    
    def validate_all(self) -> Tuple[bool, List[str]]:
        """Validate entire config. Returns (is_valid, list_of_errors)"""
        _, errors = _validate_config(self._data)
        return len(errors) == 0, errors
    
    def get_schema_info(self) -> Dict[str, Any]:
        """Get schema information for UI"""
        info = {}
        for key, schema in CONFIG_SCHEMA.items():
            info[key] = {
                "type": schema["type"].__name__,
                "default": schema["default"],
                "current": self._data.get(key, schema["default"])
            }
            if "allowed" in schema:
                info[key]["allowed"] = schema["allowed"]
            if "min" in schema:
                info[key]["min"] = schema["min"]
            if "max" in schema:
                info[key]["max"] = schema["max"]
        return info