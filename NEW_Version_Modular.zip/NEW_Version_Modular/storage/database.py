"""
SQLite/SQLCipher database for saved passwords (with full field encryption, connection pooling, and metadata minimization)
FIXED VERSION - исправлены все проблемы с подключением и обработкой исключений
"""
import os
import sys
import sqlite3
import ctypes
import datetime
import threading
import hashlib
import secrets
import shutil
import time
from contextlib import contextmanager
from typing import List, Dict, Any, Optional, Tuple
from utils.paths import get_db_file, get_config_dir, hide_dir
from utils.logger import get_logger
from utils.secure_file_ops import secure_write, secure_read

logger = get_logger("database")

# Проверка на тестовый режим (для find_issues.py)
SKIP_DB_INIT = os.environ.get('SECUREPASSPRO_SKIP_DB_INIT', '0') == '1'

if SKIP_DB_INIT:
    logger.info("Database initialization skipped (test mode)")

# ==================== SQLCipher DETECTION ====================
SQLCIPHER_AVAILABLE = False
sqlcipher = None

try:
    from sqlcipher3 import dbapi2 as _sqlcipher
    SQLCIPHER_AVAILABLE = True
    sqlcipher = _sqlcipher
    logger.info("SQLCipher available - using full database encryption")
except ImportError as e:
    try:
        import sqlite3
        sqlcipher = sqlite3
        logger.info(f"SQLCipher not available - using standard SQLite: {e}")
    except ImportError as e2:
        logger.error(f"SQLite import error: {e2}")
        sqlcipher = None

# ==================== DB_FILE EXPORT ====================
DB_FILE = get_db_file()
CONFIG_DIR = get_config_dir()
BACKUP_DIR = os.path.join(CONFIG_DIR, "backups")
MAX_BACKUPS = 5
BACKUP_INTERVAL_DAYS = 7
# ========================================================

# Connection pool
_connection_pool = {}
_pool_lock = threading.Lock()
_pool_size = 0
_MAX_POOL_SIZE = 5

# Encryption key for SQLCipher (derived from master password)
_sqlcipher_key: Optional[bytes] = None
_sqlcipher_key_hex: Optional[str] = None

# Флаг, что БД работает в режиме SQLite (без шифрования)
_using_fallback_sqlite = False


class DatabaseError(Exception):
    """Исключение для ошибок базы данных"""
    pass


class DatabaseCorruptionError(DatabaseError):
    """Исключение для повреждения базы данных"""
    pass


class DatabaseLockError(DatabaseError):
    """Исключение для блокировок базы данных"""
    pass


def set_sqlcipher_key(master_password: str) -> None:
    """
    Set SQLCipher encryption key derived from master password.
    """
    global _sqlcipher_key, _sqlcipher_key_hex, _using_fallback_sqlite
    if not master_password:
        _clear_sqlcipher_key()
        return
    
    try:
        salt = _get_sqlcipher_salt()
        key = hashlib.pbkdf2_hmac('sha256', master_password.encode('utf-8'), salt, 64000, dklen=32)
        _sqlcipher_key = key
        _sqlcipher_key_hex = key.hex()
        _using_fallback_sqlite = False
        logger.debug("SQLCipher key set (memory secured)")
    except (ValueError, TypeError, OSError, IOError) as e:
        logger.error(f"Failed to set SQLCipher key: {e}")
        _using_fallback_sqlite = True


def _get_sqlcipher_salt() -> bytes:
    """Get or create SQLCipher salt"""
    salt_file = os.path.join(CONFIG_DIR, "sqlcipher.salt")
    
    if os.path.exists(salt_file):
        try:
            with open(salt_file, 'rb') as f:
                salt = f.read()
                if len(salt) == 32:
                    return salt
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to read SQLCipher salt: {e}")
    
    salt = secrets.token_bytes(32)
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(salt_file, 'wb') as f:
            f.write(salt)
        hide_dir(CONFIG_DIR)
        logger.info("SQLCipher salt generated")
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Failed to save SQLCipher salt: {e}")
    
    return salt


def _clear_sqlcipher_key() -> None:
    """Clear SQLCipher encryption key from memory"""
    global _sqlcipher_key, _sqlcipher_key_hex, _using_fallback_sqlite
    _using_fallback_sqlite = True
    
    if _sqlcipher_key:
        _secure_zero_bytes(_sqlcipher_key)
        _sqlcipher_key = None
    
    if _sqlcipher_key_hex:
        _clear_string(_sqlcipher_key_hex)
        _sqlcipher_key_hex = None


def clear_sqlcipher_key() -> None:
    """Public function to clear SQLCipher key"""
    _clear_sqlcipher_key()


def _secure_zero(data: bytearray) -> None:
    """Обнуляет bytearray через ctypes.memset"""
    if data is None:
        return
    try:
        length = len(data)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(data)), 0, length)
    except (TypeError, AttributeError, OSError) as e:
        logger.debug(f"Memory zeroing failed: {e}")
        for i in range(len(data)):
            data[i] = 0


def _secure_zero_bytes(data: bytes) -> None:
    """Обнуляет bytes"""
    if data is None:
        return
    try:
        ba = bytearray(data)
        _secure_zero(ba)
    except (TypeError, MemoryError, OSError) as e:
        logger.debug(f"Bytes zeroing failed: {e}")


def _clear_string(s: str) -> None:
    """Пытается очистить строку"""
    try:
        if s and not s.startswith(('[decryption', '[encrypted', 'enc1:', 'enc2:', 'enc3:')):
            ba = bytearray(s.encode('utf-8'))
            _secure_zero(ba)
    except (UnicodeEncodeError, TypeError, MemoryError, OSError) as e:
        logger.debug(f"String clearing failed: {e}")


def _enc(text: str) -> str:
    """Encrypt any text field (field-level encryption as fallback)."""
    try:
        from security.encryption import encrypt
        return encrypt(text)
    except ImportError as e:
        logger.error(f"Encryption module not available: {e}")
        return text
    except (ValueError, TypeError, RuntimeError) as e:
        logger.error(f"Encryption error: {e}")
        return "[encryption_failed]"


def _dec(text: str) -> str:
    """Decrypt any text field."""
    try:
        from security.encryption import decrypt
        return decrypt(text)
    except ImportError as e:
        logger.error(f"Encryption module not available: {e}")
        return text
    except (ValueError, TypeError, RuntimeError) as e:
        logger.error(f"Decryption error: {e}")
        return "[decryption_failed]"


def _get_secure_pragmas() -> List[str]:
    """Get secure PRAGMA settings"""
    return [
        "PRAGMA encoding = 'UTF-8';",
        "PRAGMA secure_delete = ON;",
        "PRAGMA foreign_keys = ON;",
        "PRAGMA journal_mode = WAL;",
        "PRAGMA synchronous = NORMAL;",
        "PRAGMA temp_store = MEMORY;",
        "PRAGMA cache_size = -2000;",
        "PRAGMA auto_vacuum = INCREMENTAL;",
        "PRAGMA mmap_size = 268435456;",
    ]


def _create_backup() -> Optional[str]:
    """Создаёт резервную копию базы данных"""
    if not os.path.exists(DB_FILE):
        return None
    
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(BACKUP_DIR, f"passwords_backup_{timestamp}.db")
        
        shutil.copy2(DB_FILE, backup_path)
        logger.info(f"Database backup created: {backup_path}")
        
        # Очистка старых бэкапов
        _cleanup_old_backups()
        
        return backup_path
    except (OSError, IOError, PermissionError, shutil.Error) as e:
        logger.error(f"Failed to create backup: {e}")
        return None


def _cleanup_old_backups() -> None:
    """Очищает старые резервные копии"""
    try:
        if not os.path.exists(BACKUP_DIR):
            return
        
        backups = []
        for f in os.listdir(BACKUP_DIR):
            if f.startswith("passwords_backup_") and f.endswith(".db"):
                f_path = os.path.join(BACKUP_DIR, f)
                backups.append((f_path, os.path.getmtime(f_path)))
        
        # Сортируем по времени модификации (старые первые)
        backups.sort(key=lambda x: x[1])
        
        # Удаляем лишние
        while len(backups) > MAX_BACKUPS:
            old_file = backups.pop(0)[0]
            try:
                os.remove(old_file)
                logger.debug(f"Removed old backup: {old_file}")
            except (OSError, IOError, PermissionError) as e:
                logger.warning(f"Failed to remove old backup {old_file}: {e}")
                
    except (OSError, IOError, PermissionError) as e:
        logger.warning(f"Backup cleanup error: {e}")


def _attempt_corruption_recovery() -> bool:
    """Пытается восстановить повреждённую базу данных"""
    try:
        # Проверяем наличие бэкапа
        if not os.path.exists(BACKUP_DIR):
            return False
        
        # Ищем последний бэкап
        backups = []
        for f in os.listdir(BACKUP_DIR):
            if f.startswith("passwords_backup_") and f.endswith(".db"):
                f_path = os.path.join(BACKUP_DIR, f)
                backups.append((f_path, os.path.getmtime(f_path)))
        
        if not backups:
            logger.warning("No backups found for recovery")
            return False
        
        # Берём самый свежий бэкап
        backups.sort(key=lambda x: x[1], reverse=True)
        latest_backup = backups[0][0]
        
        # Восстанавливаем
        shutil.copy2(latest_backup, DB_FILE)
        logger.info(f"Database recovered from backup: {latest_backup}")
        return True
        
    except (OSError, IOError, PermissionError, shutil.Error) as e:
        logger.error(f"Recovery failed: {e}")
        return False


class PasswordDB:
    """Password vault database handler"""
    
    _initialized = False
    _use_field_encryption = not SQLCIPHER_AVAILABLE
    _corruption_attempted = False
    _deadlock_retries = 3
    _deadlock_delay = 0.1
    
    @classmethod
    def _init_db(cls):
        """Initialize database schema"""
        if cls._initialized:
            return
        
        if SKIP_DB_INIT:
            cls._initialized = True
            return
        
        try:
            os.makedirs(CONFIG_DIR, exist_ok=True)
            hide_dir(CONFIG_DIR)
            os.makedirs(BACKUP_DIR, exist_ok=True)
        except (PermissionError, OSError, IOError) as e:
            logger.error(f"Cannot create config dir: {e}")
            raise DatabaseError(f"Failed to create config directory: {e}")
        
        try:
            conn = cls._create_secure_connection()
            if conn is None:
                # Пробуем создать новую БД без шифрования
                logger.warning("Creating new database without encryption")
                conn = cls._create_sqlite_fallback()
                
            if conn is None:
                raise DatabaseError("Failed to create database connection")
            
            conn.text_factory = str
            
            for pragma in _get_secure_pragmas():
                try:
                    conn.execute(pragma)
                except sqlite3.OperationalError as e:
                    logger.debug(f"Pragma failed: {e}")
            
            # Создаём таблицу
            conn.execute("""
                CREATE TABLE IF NOT EXISTS p (
                    i INTEGER PRIMARY KEY AUTOINCREMENT,
                    l TEXT NOT NULL,
                    p TEXT NOT NULL,
                    c TEXT NOT NULL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_c ON p(c)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_l ON p(l)")
            
            # Проверка целостности
            cursor = conn.execute("PRAGMA integrity_check")
            integrity_result = cursor.fetchone()
            if integrity_result and integrity_result[0] != "ok":
                logger.warning(f"Database integrity check failed: {integrity_result}")
                conn.close()
                raise DatabaseCorruptionError(f"Database corruption detected: {integrity_result}")
            
            conn.commit()
            conn.close()
            cls._initialized = True
            
            # Периодический бэкап
            cls._create_auto_backup()
            
        except sqlite3.DatabaseError as e:
            logger.error(f"Database initialization error: {e}")
            if not cls._corruption_attempted:
                cls._corruption_attempted = True
                if _attempt_corruption_recovery():
                    cls._initialized = False
                    cls._init_db()
                    return
            raise DatabaseError(f"Failed to initialize database: {e}")
        except sqlite3.OperationalError as e:
            logger.error(f"Database operational error: {e}")
            raise DatabaseError(f"Database operational error: {e}")
        except sqlite3.Error as e:
            logger.error(f"Database error: {e}")
            raise DatabaseError(f"Database error: {e}")
    
    @classmethod
    def _create_auto_backup(cls) -> None:
        """Создаёт автоматический бэкап при необходимости"""
        try:
            if not os.path.exists(DB_FILE):
                return
            
            # Проверяем, когда был последний бэкап
            backups = []
            if os.path.exists(BACKUP_DIR):
                for f in os.listdir(BACKUP_DIR):
                    if f.startswith("passwords_backup_") and f.endswith(".db"):
                        f_path = os.path.join(BACKUP_DIR, f)
                        backups.append(os.path.getmtime(f_path))
            
            if backups:
                latest_backup_time = max(backups)
                days_since = (time.time() - latest_backup_time) / (24 * 3600)
                if days_since < BACKUP_INTERVAL_DAYS:
                    return
            
            _create_backup()
            
        except (OSError, IOError, PermissionError, ValueError) as e:
            logger.debug(f"Auto-backup check failed: {e}")
    
    @classmethod
    def _create_sqlite_fallback(cls) -> Optional[sqlite3.Connection]:
        """Создаёт соединение с SQLite (без шифрования) как fallback"""
        global _using_fallback_sqlite
        _using_fallback_sqlite = True
        
        try:
            db_file = DB_FILE
            db_dir = os.path.dirname(db_file)
            if db_dir:
                os.makedirs(db_dir, exist_ok=True)
            
            conn = sqlite3.connect(db_file, timeout=10)
            logger.info("Using SQLite fallback (no encryption)")
            return conn
        except sqlite3.Error as e:
            logger.error(f"SQLite fallback connection failed: {e}")
            return None
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"SQLite fallback directory error: {e}")
            return None
    
    @classmethod
    def _create_secure_connection(cls) -> Optional[sqlite3.Connection]:
        """Create secure connection with SQLCipher"""
        if sqlcipher is None:
            return cls._create_sqlite_fallback()
            
        db_file = DB_FILE
        
        # Проверяем существование директории
        db_dir = os.path.dirname(db_file)
        if db_dir:
            try:
                os.makedirs(db_dir, exist_ok=True)
            except (OSError, IOError, PermissionError) as e:
                logger.error(f"Failed to create DB directory: {e}")
                return None
        
        # Если уже используем fallback SQLite, сразу идём туда
        if _using_fallback_sqlite:
            return cls._create_sqlite_fallback()
        
        # Пробуем SQLCipher с ключом
        if SQLCIPHER_AVAILABLE and _sqlcipher_key_hex:
            try:
                conn = sqlcipher.connect(db_file, timeout=10)
                conn.execute(f"PRAGMA key = x'{_sqlcipher_key_hex}'")
                # Проверяем, что ключ правильный
                conn.execute("SELECT count(*) FROM sqlite_master").fetchone()
                logger.debug("SQLCipher connection successful")
                return conn
            except sqlite3.DatabaseError as e:
                logger.error(f"SQLCipher key error: {e}")
                # Пробуем подключиться без шифрования (старая БД)
                try:
                    conn = sqlcipher.connect(db_file, timeout=10)
                    conn.execute("SELECT count(*) FROM sqlite_master").fetchone()
                    logger.warning("Connected to unencrypted database")
                    return conn
                except sqlite3.Error:
                    pass
            except sqlite3.Error as e:
                logger.error(f"SQLCipher connection error: {e}")
        
        # Пробуем SQLCipher без ключа
        try:
            conn = sqlcipher.connect(db_file, timeout=10)
            conn.execute("SELECT count(*) FROM sqlite_master").fetchone()
            logger.warning("Connected to SQLCipher without key (unencrypted DB)")
            return conn
        except sqlite3.Error:
            pass
        
        # Если ничего не работает, используем SQLite fallback
        return cls._create_sqlite_fallback()
    
    @classmethod
    def _get_pool_connection(cls) -> Optional[sqlite3.Connection]:
        """Get connection from pool"""
        global _pool_size
        thread_id = threading.get_ident()
        
        with _pool_lock:
            if thread_id in _connection_pool:
                conn = _connection_pool[thread_id]
                try:
                    conn.execute("SELECT 1").fetchone()
                    return conn
                except sqlite3.OperationalError as e:
                    logger.debug(f"Connection died: {e}")
                    try:
                        conn.close()
                    except sqlite3.Error:
                        pass
                    del _connection_pool[thread_id]
                    _pool_size -= 1
            
            conn = cls._create_secure_connection()
            if conn is None:
                return None
            conn.text_factory = str
            
            for pragma in _get_secure_pragmas():
                try:
                    conn.execute(pragma)
                except sqlite3.OperationalError as e:
                    logger.debug(f"Pragma failed: {e}")
            
            _pool_size += 1
            if _pool_size > _MAX_POOL_SIZE:
                to_remove = []
                for tid, old_conn in _connection_pool.items():
                    if tid != thread_id:
                        try:
                            old_conn.close()
                        except sqlite3.Error:
                            pass
                        to_remove.append(tid)
                for tid in to_remove:
                    del _connection_pool[tid]
                _pool_size = len(_connection_pool) + 1
            
            _connection_pool[thread_id] = conn
            return conn
    
    @classmethod
    @contextmanager
    def _get_connection(cls):
        """Get connection from pool with retry on deadlock"""
        conn = None
        last_error = None
        
        for attempt in range(cls._deadlock_retries):
            try:
                conn = cls._get_pool_connection()
                if conn is None:
                    raise DatabaseError("No database connection available")
                yield conn
                return
            except sqlite3.OperationalError as e:
                last_error = e
                error_msg = str(e).lower()
                if "database is locked" in error_msg or "busy" in error_msg:
                    logger.debug(f"Database locked, retry {attempt + 1}/{cls._deadlock_retries}")
                    time.sleep(cls._deadlock_delay * (attempt + 1))
                    continue
                raise DatabaseError(f"Database operational error: {e}")
            except sqlite3.Error as e:
                last_error = e
                if conn:
                    try:
                        conn.rollback()
                    except sqlite3.Error:
                        pass
                raise DatabaseError(f"Database transaction failed: {e}")
            except DatabaseError:
                raise
            except (OSError, IOError, RuntimeError) as e:
                last_error = e
                raise DatabaseError(f"Unexpected error: {e}")
        
        if last_error:
            raise DatabaseError(f"Database deadlock after {cls._deadlock_retries} attempts: {last_error}")
        raise DatabaseError("Failed to acquire database connection")
    
    @classmethod
    def close_all_connections(cls):
        """Close all connections in pool"""
        global _pool_size
        with _pool_lock:
            for thread_id, conn in list(_connection_pool.items()):
                try:
                    conn.close()
                except sqlite3.Error as e:
                    logger.debug(f"Error closing connection {thread_id}: {e}")
                except (OSError, AttributeError) as e:
                    logger.debug(f"Error closing connection {thread_id}: {e}")
            _connection_pool.clear()
            _pool_size = 0
    
    @classmethod
    def save(cls, label: str, password: str) -> int:
        """Save a password to the vault"""
        cls._init_db()
        label_to_save = label[:100] if label else "Без метки"
        
        if cls._use_field_encryption:
            try:
                label_to_save = _enc(label_to_save)
                password_to_save = _enc(password)
            except (ValueError, TypeError, RuntimeError) as e:
                logger.error(f"Encryption failed during save: {e}")
                raise DatabaseError(f"Encryption failed: {e}")
        else:
            password_to_save = password
        
        try:
            with cls._get_connection() as conn:
                conn.execute("BEGIN TRANSACTION")
                cursor = conn.execute(
                    "INSERT INTO p (l, p, c) VALUES (?, ?, ?)",
                    (label_to_save, password_to_save,
                     datetime.datetime.now().strftime("%Y%m%d%H%M%S"))
                )
                conn.commit()
                return cursor.lastrowid
        except sqlite3.IntegrityError as e:
            logger.error(f"Database integrity error saving password: {e}")
            raise DatabaseError(f"Integrity error: {e}")
        except sqlite3.OperationalError as e:
            logger.error(f"Database operational error saving password: {e}")
            raise DatabaseError(f"Database operational error: {e}")
        except sqlite3.Error as e:
            logger.error(f"Database error saving password: {e}")
            raise DatabaseError(f"Database error: {e}")
        finally:
            if cls._use_field_encryption:
                _clear_string(label_to_save)
                _clear_string(password_to_save)
    
    @classmethod
    def get_all(cls) -> List[Dict[str, Any]]:
        """Get all saved passwords"""
        cls._init_db()
        records = []
        
        try:
            with cls._get_connection() as conn:
                rows = conn.execute("SELECT i, l, p, c FROM p ORDER BY i DESC").fetchall()
                
                for r in rows:
                    try:
                        if cls._use_field_encryption:
                            decrypted_label = _dec(r[1])
                            decrypted_password = _dec(r[2])
                        else:
                            decrypted_label = r[1]
                            decrypted_password = r[2]
                        
                        created_str = r[3]
                        if len(created_str) == 14:
                            created = f"{created_str[:4]}-{created_str[4:6]}-{created_str[6:8]} {created_str[8:10]}:{created_str[10:12]}:{created_str[12:14]}"
                        else:
                            created = r[3]
                    except (ValueError, UnicodeDecodeError, TypeError) as e:
                        logger.error(f"Decoding error for id {r[0]}: {e}")
                        decrypted_label = "[decoding failed]"
                        decrypted_password = "[decoding failed]"
                        created = r[3]
                    
                    records.append({
                        "id": r[0],
                        "label": decrypted_label,
                        "password": decrypted_password,
                        "created": created
                    })
                    
                    if cls._use_field_encryption:
                        _clear_string(decrypted_label)
                        _clear_string(decrypted_password)
                
                return records
        except sqlite3.OperationalError as e:
            logger.error(f"Database operational error getting all: {e}")
            raise DatabaseError(f"Failed to get records: {e}")
        except sqlite3.Error as e:
            logger.error(f"Database error getting all: {e}")
            raise DatabaseError(f"Failed to get records: {e}")
    
    @classmethod
    def get_by_id(cls, row_id: int) -> Optional[Dict[str, Any]]:
        """Get a single password by ID"""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                row = conn.execute("SELECT i, l, p, c FROM p WHERE i = ?", (row_id,)).fetchone()
                if not row:
                    return None
                
                try:
                    if cls._use_field_encryption:
                        decrypted_label = _dec(row[1])
                        decrypted_password = _dec(row[2])
                    else:
                        decrypted_label = row[1]
                        decrypted_password = row[2]
                    
                    created_str = row[3]
                    if len(created_str) == 14:
                        created = f"{created_str[:4]}-{created_str[4:6]}-{created_str[6:8]} {created_str[8:10]}:{created_str[10:12]}:{created_str[12:14]}"
                    else:
                        created = row[3]
                except (ValueError, UnicodeDecodeError, TypeError) as e:
                    logger.error(f"Decoding error for id {row[0]}: {e}")
                    decrypted_label = "[decoding failed]"
                    decrypted_password = "[decoding failed]"
                    created = row[3]
                
                return {
                    "id": row[0],
                    "label": decrypted_label,
                    "password": decrypted_password,
                    "created": created
                }
        except sqlite3.OperationalError as e:
            logger.error(f"Database operational error getting by id: {e}")
            raise DatabaseError(f"Failed to get record {row_id}: {e}")
        except sqlite3.Error as e:
            logger.error(f"Database error getting by id: {e}")
            raise DatabaseError(f"Failed to get record {row_id}: {e}")
    
    @classmethod
    def update(cls, row_id: int, label: str, password: str = None) -> None:
        """Update a password entry"""
        cls._init_db()
        
        label_to_save = label[:100] if label else "Без метки"
        if cls._use_field_encryption:
            try:
                label_to_save = _enc(label_to_save)
            except (ValueError, TypeError, RuntimeError) as e:
                logger.error(f"Encryption failed during update: {e}")
                raise DatabaseError(f"Encryption failed: {e}")
        
        try:
            with cls._get_connection() as conn:
                conn.execute("BEGIN TRANSACTION")
                if password is not None and password.strip():
                    password_to_save = password
                    if cls._use_field_encryption:
                        try:
                            password_to_save = _enc(password)
                        except (ValueError, TypeError, RuntimeError) as e:
                            logger.error(f"Password encryption failed: {e}")
                            raise DatabaseError(f"Password encryption failed: {e}")
                    conn.execute(
                        "UPDATE p SET l=?, p=? WHERE i=?",
                        (label_to_save, password_to_save, row_id)
                    )
                    if cls._use_field_encryption:
                        _clear_string(password_to_save)
                else:
                    conn.execute("UPDATE p SET l=? WHERE i=?", (label_to_save, row_id))
                conn.commit()
        except sqlite3.IntegrityError as e:
            logger.error(f"Database integrity error updating password {row_id}: {e}")
            raise DatabaseError(f"Integrity error: {e}")
        except sqlite3.OperationalError as e:
            logger.error(f"Database operational error updating password {row_id}: {e}")
            raise DatabaseError(f"Database operational error: {e}")
        except sqlite3.Error as e:
            logger.error(f"Database error updating password {row_id}: {e}")
            raise DatabaseError(f"Database error: {e}")
        finally:
            if cls._use_field_encryption:
                _clear_string(label_to_save)
    
    @classmethod
    def delete(cls, row_id: int) -> None:
        """Delete a password entry"""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                conn.execute("BEGIN TRANSACTION")
                conn.execute("DELETE FROM p WHERE i=?", (row_id,))
                conn.commit()
        except sqlite3.OperationalError as e:
            logger.error(f"Database operational error deleting password {row_id}: {e}")
            raise DatabaseError(f"Failed to delete record {row_id}: {e}")
        except sqlite3.Error as e:
            logger.error(f"Database error deleting password {row_id}: {e}")
            raise DatabaseError(f"Failed to delete record {row_id}: {e}")
    
    @classmethod
    def count(cls) -> int:
        """Get total number of saved passwords"""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                result = conn.execute("SELECT COUNT(*) FROM p").fetchone()
                return result[0] if result else 0
        except sqlite3.OperationalError as e:
            logger.error(f"Database operational error counting passwords: {e}")
            return 0
        except sqlite3.Error as e:
            logger.error(f"Database error counting passwords: {e}")
            return 0
    
    @classmethod
    def search(cls, query: str) -> List[Dict[str, Any]]:
        """Поиск паролей по метке, паролю или дате"""
        cls._init_db()
        
        if not query or query.strip() == "":
            return cls.get_all()
        
        query_lower = query.strip().lower()
        records = []
        
        try:
            all_records = cls.get_all()
            
            for rec in all_records:
                label_match = False
                pwd_match = False
                date_match = False
                
                if rec.get("label"):
                    label_match = query_lower in rec["label"].lower()
                if rec.get("password"):
                    pwd_match = query_lower in rec["password"].lower()
                if rec.get("created"):
                    date_match = query_lower in rec["created"].lower()
                
                if label_match or pwd_match or date_match:
                    records.append(rec)
            
            logger.debug(f"Search for '{query}' returned {len(records)} results")
            return records
            
        except (OSError, ValueError, TypeError) as e:
            logger.error(f"Search error: {e}")
            return cls.get_all()
    
    @classmethod
    def vacuum(cls) -> None:
        """Optimize database"""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                conn.execute("PRAGMA incremental_vacuum")
        except sqlite3.OperationalError as e:
            logger.error(f"Vacuum error: {e}")
        except sqlite3.Error as e:
            logger.error(f"Vacuum error: {e}")
    
    @classmethod
    def backup(cls, backup_path: str) -> bool:
        """Create a backup of the database"""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                if SQLCIPHER_AVAILABLE and _sqlcipher_key_hex and not _using_fallback_sqlite:
                    backup_conn = sqlcipher.connect(backup_path)
                    backup_conn.execute(f"PRAGMA key = x'{_sqlcipher_key_hex}'")
                    for pragma in _get_secure_pragmas():
                        try:
                            backup_conn.execute(pragma)
                        except sqlite3.OperationalError as e:
                            logger.debug(f"Pragma failed during backup: {e}")
                else:
                    backup_conn = sqlite3.connect(backup_path)
                conn.backup(backup_conn)
                backup_conn.close()
            return True
        except sqlite3.OperationalError as e:
            logger.error(f"Backup error: {e}")
            return False
        except sqlite3.Error as e:
            logger.error(f"Backup error: {e}")
            return False
        except (OSError, IOError) as e:
            logger.error(f"Backup file error: {e}")
            return False
    
    @classmethod
    def rekey(cls, new_master_password: str) -> bool:
        """Change SQLCipher encryption key"""
        if not SQLCIPHER_AVAILABLE:
            logger.warning("SQLCipher not available, cannot rekey")
            return False
        
        if not new_master_password:
            logger.warning("Cannot rekey with empty password")
            return False
        
        try:
            salt = _get_sqlcipher_salt()
            new_key = hashlib.pbkdf2_hmac('sha256', new_master_password.encode('utf-8'), salt, 64000, dklen=32)
            new_key_hex = new_key.hex()
            
            with cls._get_connection() as conn:
                conn.execute(f"PRAGMA rekey = x'{new_key_hex}'")
            
            global _sqlcipher_key, _sqlcipher_key_hex, _using_fallback_sqlite
            _secure_zero_bytes(_sqlcipher_key) if _sqlcipher_key else None
            _sqlcipher_key = new_key
            _sqlcipher_key_hex = new_key_hex
            _using_fallback_sqlite = False
            
            logger.info("Database rekey completed")
            return True
        except sqlite3.OperationalError as e:
            logger.error(f"Rekey error: {e}")
            return False
        except sqlite3.Error as e:
            logger.error(f"Rekey error: {e}")
            return False
        except (ValueError, TypeError, OSError) as e:
            logger.error(f"Rekey error: {e}")
            return False
    
    @classmethod
    def is_sqlcipher_available(cls) -> bool:
        """Check if SQLCipher is available"""
        return SQLCIPHER_AVAILABLE and _sqlcipher_key_hex is not None and not _using_fallback_sqlite
    
    @classmethod
    def has_key(cls) -> bool:
        """Check if encryption key is set"""
        return _sqlcipher_key_hex is not None
    
    @classmethod
    def is_using_fallback(cls) -> bool:
        """Check if using SQLite fallback (no encryption)"""
        return _using_fallback_sqlite
    
    @classmethod
    def check_integrity(cls) -> Tuple[bool, str]:
        """Проверяет целостность базы данных"""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                cursor = conn.execute("PRAGMA integrity_check")
                result = cursor.fetchone()
                if result and result[0] == "ok":
                    return True, "ok"
                else:
                    return False, result[0] if result else "unknown error"
        except sqlite3.OperationalError as e:
            logger.error(f"Integrity check error: {e}")
            return False, str(e)
        except sqlite3.Error as e:
            logger.error(f"Integrity check error: {e}")
            return False, str(e)
    
    @classmethod
    def create_backup(cls) -> Optional[str]:
        """Создаёт ручную резервную копию"""
        return _create_backup()
    
    @classmethod
    def get_db_size(cls) -> int:
        """Возвращает размер базы данных в байтах"""
        try:
            if os.path.exists(DB_FILE):
                return os.path.getsize(DB_FILE)
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"Failed to get DB size: {e}")
        return 0


# Для обратной совместимости
DB_FILE = DB_FILE
CONFIG_DIR = CONFIG_DIR