"""
SQLite database for saved passwords (with full field encryption)
"""
import sqlite3
import os
import sys
import ctypes
import datetime
import threading
from contextlib import contextmanager
from typing import List, Dict, Any
from utils.paths import get_db_file, get_config_dir, hide_dir
from utils.logger import get_logger

logger = get_logger("database")

# Connection pool
_connection_pool = {}
_pool_lock = threading.Lock()


def _secure_zero(data: bytearray) -> None:
    """Обнуляет bytearray через ctypes.memset"""
    if data is None:
        return
    try:
        length = len(data)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(data)), 0, length)
    except (TypeError, AttributeError, OSError) as e:
        logger.debug(f"Memory zeroing failed: {e}")
        for i in range(len(data)):
            data[i] = 0


def _clear_string(s: str) -> None:
    """Пытается очистить строку (через обнуление bytearray)"""
    try:
        if s and not s.startswith("[encrypted"):
            ba = bytearray(s.encode('utf-8'))
            _secure_zero(ba)
    except (UnicodeEncodeError, TypeError, MemoryError) as e:
        logger.debug(f"String clearing failed: {e}")


def _enc(text: str) -> str:
    """Encrypt any text field."""
    from security.encryption import encrypt
    return encrypt(text)


def _dec(text: str) -> str:
    """Decrypt any text field."""
    try:
        from security.encryption import decrypt
        return decrypt(text)
    except (ValueError, TypeError) as e:
        logger.error(f"Decryption error in database: {e}")
        return "[encrypted - unlock with master password]"


class PasswordDB:
    """Password vault database handler with connection pooling"""

    _initialized = False

    @classmethod
    def _init_db(cls):
        """Initialize database schema (called once)"""
        if cls._initialized:
            return
        
        db_file = get_db_file()
        config_dir = get_config_dir()
        try:
            os.makedirs(config_dir, exist_ok=True)
            hide_dir(config_dir)
        except (PermissionError, OSError) as e:
            logger.error(f"Cannot create config dir: {e}")
            raise
        
        try:
            conn = sqlite3.connect(db_file)
            conn.text_factory = str
            conn.execute("PRAGMA encoding = 'UTF-8';")
            conn.execute("PRAGMA secure_delete = ON;")
            conn.execute("PRAGMA foreign_keys = ON;")
            conn.execute("PRAGMA journal_mode = WAL;")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS passwords (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    label TEXT NOT NULL,
                    password TEXT NOT NULL,
                    created TEXT NOT NULL
                )
            """)
            conn.commit()
            conn.close()
        except sqlite3.Error as e:
            logger.error(f"Database initialization error: {e}")
            raise
        
        cls._initialized = True

    @classmethod
    @contextmanager
    def _get_connection(cls):
        """Get connection from pool or create new one"""
        thread_id = threading.get_ident()
        
        with _pool_lock:
            if thread_id in _connection_pool:
                conn = _connection_pool[thread_id]
                try:
                    # Check if connection is still alive
                    conn.execute("SELECT 1").fetchone()
                except sqlite3.OperationalError:
                    # Connection dead, create new one
                    db_file = get_db_file()
                    conn = sqlite3.connect(db_file)
                    conn.text_factory = str
                    conn.execute("PRAGMA secure_delete = ON;")
                    conn.execute("PRAGMA foreign_keys = ON;")
                    _connection_pool[thread_id] = conn
            else:
                db_file = get_db_file()
                conn = sqlite3.connect(db_file)
                conn.text_factory = str
                conn.execute("PRAGMA secure_delete = ON;")
                conn.execute("PRAGMA foreign_keys = ON;")
                _connection_pool[thread_id] = conn
        
        try:
            yield conn
        except sqlite3.Error as e:
            conn.rollback()
            logger.error(f"Database error in transaction: {e}")
            raise
        finally:
            # Don't close, keep in pool
            pass

    @classmethod
    def close_all_connections(cls):
        """Close all connections in pool (call on app exit)"""
        with _pool_lock:
            for thread_id, conn in _connection_pool.items():
                try:
                    conn.close()
                except sqlite3.Error as e:
                    logger.debug(f"Error closing connection {thread_id}: {e}")
            _connection_pool.clear()

    @classmethod
    def save(cls, label: str, password: str) -> int:
        """Save an encrypted password to the vault."""
        cls._init_db()
        
        encrypted_label = _enc(label[:200])
        encrypted_password = _enc(password)
        
        try:
            with cls._get_connection() as conn:
                with conn:
                    cursor = conn.execute(
                        "INSERT INTO passwords (label, password, created) VALUES (?, ?, ?)",
                        (encrypted_label, encrypted_password,
                         datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                    )
                    return cursor.lastrowid
        except sqlite3.IntegrityError as e:
            logger.error(f"Integrity error saving password: {e}")
            raise ValueError("Duplicate or invalid data") from e
        except sqlite3.OperationalError as e:
            logger.error(f"Database locked or corrupted: {e}")
            raise ConnectionError("Database unavailable") from e
        except sqlite3.Error as e:
            logger.error(f"Database error saving password: {e}")
            raise
        finally:
            _clear_string(encrypted_label)
            _clear_string(encrypted_password)

    @classmethod
    def get_all(cls) -> List[Dict[str, Any]]:
        """Get all saved passwords (fully decrypted)."""
        cls._init_db()
        
        records = []
        try:
            with cls._get_connection() as conn:
                rows = conn.execute(
                    "SELECT id, label, password, created FROM passwords ORDER BY id DESC"
                ).fetchall()
                
                for r in rows:
                    try:
                        decrypted_label = _dec(r[1])
                        decrypted_password = _dec(r[2])
                    except (ValueError, TypeError) as e:
                        logger.error(f"Decryption error for id {r[0]}: {e}")
                        decrypted_label = "[decryption failed]"
                        decrypted_password = "[decryption failed]"
                    
                    records.append({
                        "id": r[0],
                        "label": decrypted_label,
                        "password": decrypted_password,
                        "created": r[3]
                    })
                    
                    _clear_string(decrypted_label)
                    _clear_string(decrypted_password)
                
                return records
        except sqlite3.OperationalError as e:
            logger.error(f"Database locked or corrupted: {e}")
            return []
        except sqlite3.Error as e:
            logger.error(f"Database error: {e}")
            return []

    @classmethod
    def update(cls, row_id: int, label: str, password: str = None) -> None:
        """Update a password entry (re-encrypts with current key)."""
        cls._init_db()
        
        if password is not None:
            encrypted_label = _enc(label[:200])
            encrypted_password = _enc(password)
            try:
                with cls._get_connection() as conn:
                    with conn:
                        conn.execute(
                            "UPDATE passwords SET label=?, password=? WHERE id=?",
                            (encrypted_label, encrypted_password, row_id))
            except sqlite3.Error as e:
                logger.error(f"Database error updating password {row_id}: {e}")
                raise
            finally:
                _clear_string(encrypted_label)
                _clear_string(encrypted_password)
        else:
            encrypted_label = _enc(label[:200])
            try:
                with cls._get_connection() as conn:
                    with conn:
                        conn.execute("UPDATE passwords SET label=? WHERE id=?",
                                     (encrypted_label, row_id))
            except sqlite3.Error as e:
                logger.error(f"Database error updating label {row_id}: {e}")
                raise
            finally:
                _clear_string(encrypted_label)

    @classmethod
    def delete(cls, row_id: int) -> None:
        """Delete a password entry."""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                with conn:
                    conn.execute("DELETE FROM passwords WHERE id=?", (row_id,))
        except sqlite3.Error as e:
            logger.error(f"Database error deleting password {row_id}: {e}")
            raise

    @classmethod
    def count(cls) -> int:
        """Get total number of saved passwords."""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                result = conn.execute("SELECT COUNT(*) FROM passwords").fetchone()
                return result[0] if result else 0
        except sqlite3.Error as e:
            logger.error(f"Database error counting passwords: {e}")
            return 0

    @classmethod
    def search(cls, query: str) -> List[Dict[str, Any]]:
        """Search passwords by label (decrypts all for secure search)."""
        cls._init_db()
        
        query = query[:200].lower()
        records = []
        
        try:
            all_records = cls.get_all()
            for rec in all_records:
                if query in rec["label"].lower():
                    records.append(rec)
            return records
        except (ValueError, TypeError) as e:
            logger.error(f"Search error: {e}")
            return []