"""
SQLite/SQLCipher database for saved passwords (with full field encryption, connection pooling, and metadata minimization)
"""
import sqlite3
import os
import sys
import ctypes
import datetime
import threading
import hashlib
from contextlib import contextmanager
from typing import List, Dict, Any, Optional
from utils.paths import get_db_file, get_config_dir, hide_dir
from utils.logger import get_logger

logger = get_logger("database")

# ==================== SQLCipher DETECTION ====================
SQLCIPHER_AVAILABLE = False
try:
    from sqlcipher3 import dbapi2 as sqlcipher
    SQLCIPHER_AVAILABLE = True
    logger.info("SQLCipher available - using full database encryption")
except ImportError:
    try:
        import sqlite3
        sqlcipher = sqlite3
        logger.info("SQLCipher not available - using standard SQLite")
    except ImportError:
        pass

# ==================== DB_FILE EXPORT ====================
DB_FILE = get_db_file()
CONFIG_DIR = get_config_dir()
# ========================================================

# Connection pool
_connection_pool = {}
_pool_lock = threading.Lock()
_pool_size = 0
_MAX_POOL_SIZE = 5

# Encryption key for SQLCipher (derived from master password)
_sqlcipher_key: Optional[str] = None


def set_sqlcipher_key(master_password: str) -> None:
    """Set SQLCipher encryption key derived from master password"""
    global _sqlcipher_key
    if not master_password:
        _sqlcipher_key = None
        return
    # PBKDF2 key derivation for SQLCipher
    key = hashlib.pbkdf2_hmac('sha256', master_password.encode('utf-8'), b'salt_sqlcipher', 64000, dklen=32)
    _sqlcipher_key = key.hex()
    logger.debug("SQLCipher key set")


def clear_sqlcipher_key() -> None:
    """Clear SQLCipher encryption key from memory"""
    global _sqlcipher_key
    _sqlcipher_key = None


def _secure_zero(data: bytearray) -> None:
    """Обнуляет bytearray через ctypes.memset"""
    if data is None:
        return
    try:
        length = len(data)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(data)), 0, length)
    except Exception:
        for i in range(len(data)):
            data[i] = 0


def _clear_string(s: str) -> None:
    """Пытается очистить строку (через обнуление bytearray)"""
    try:
        if s and not s.startswith("[encrypted"):
            ba = bytearray(s.encode('utf-8'))
            _secure_zero(ba)
    except Exception:
        pass


def _enc(text: str) -> str:
    """Encrypt any text field (field-level encryption as fallback)."""
    from security.encryption import encrypt
    return encrypt(text)


def _dec(text: str) -> str:
    """Decrypt any text field."""
    try:
        from security.encryption import decrypt
        return decrypt(text)
    except Exception as e:
        logger.error(f"Decryption error: {e}")
        return "[encrypted - unlock with master password]"


class PasswordDB:
    """Password vault database handler with SQLCipher support, connection pooling and metadata minimization"""
    
    _initialized = False
    _pragma_cache = None
    
    @classmethod
    def _get_secure_pragmas(cls) -> List[str]:
        """Get secure PRAGMA settings for SQLite/SQLCipher"""
        if cls._pragma_cache is not None:
            return cls._pragma_cache
        
        pragmas = [
            "PRAGMA encoding = 'UTF-8';",
            "PRAGMA secure_delete = ON;",
            "PRAGMA foreign_keys = ON;",
            "PRAGMA journal_mode = WAL;",
            "PRAGMA synchronous = NORMAL;",
            "PRAGMA temp_store = MEMORY;",
            "PRAGMA cache_size = -2000;",
            "PRAGMA auto_vacuum = INCREMENTAL;",
            "PRAGMA mmap_size = 268435456;",
        ]
        
        # Add SQLCipher pragmas if available
        if SQLCIPHER_AVAILABLE and _sqlcipher_key:
            pragmas.insert(0, f"PRAGMA key = \"{_sqlcipher_key}\";")
            pragmas.insert(1, "PRAGMA cipher_page_size = 4096;")
            pragmas.insert(2, "PRAGMA kdf_iter = 64000;")
            pragmas.insert(3, "PRAGMA cipher_hmac_algorithm = HMAC_SHA512;")
            pragmas.insert(4, "PRAGMA cipher_kdf_algorithm = PBKDF2_HMAC_SHA512;")
        
        cls._pragma_cache = pragmas
        return pragmas
    
    @classmethod
    def _init_db(cls):
        """Initialize database schema (called once)"""
        if cls._initialized:
            return
        
        db_file = DB_FILE
        config_dir = CONFIG_DIR
        try:
            os.makedirs(config_dir, exist_ok=True)
            hide_dir(config_dir)
        except (PermissionError, OSError) as e:
            logger.error(f"Cannot create config dir: {e}")
            raise
        
        try:
            # Create connection with SQLCipher if available
            if SQLCIPHER_AVAILABLE and _sqlcipher_key:
                conn = sqlcipher.connect(db_file)
            else:
                conn = sqlcipher.connect(db_file)
            
            conn.text_factory = str
            
            # Apply secure pragmas
            for pragma in cls._get_secure_pragmas():
                try:
                    conn.execute(pragma)
                except Exception as e:
                    logger.debug(f"Pragma failed (may be normal for SQLCipher): {e}")
            
            # ========== METADATA MINIMIZATION ==========
            # Используем абстрактные имена таблиц и полей
            # Таблица: p (passwords)
            # Поля: i (id), l (label), p (password), c (created)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS p (
                    i INTEGER PRIMARY KEY AUTOINCREMENT,
                    l TEXT NOT NULL,
                    p TEXT NOT NULL,
                    c TEXT NOT NULL
                )
            """)
            
            # Минимизируем индексы (только необходимые)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_c ON p(c)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_l ON p(l)")
            
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"Database initialization error: {e}")
            raise
        
        cls._initialized = True
    
    @classmethod
    def _get_pool_connection(cls) -> sqlite3.Connection:
        """Get connection from pool with size management"""
        global _pool_size
        thread_id = threading.get_ident()
        
        with _pool_lock:
            if thread_id in _connection_pool:
                conn = _connection_pool[thread_id]
                try:
                    conn.execute("SELECT 1").fetchone()
                    return conn
                except Exception:
                    pass
            
            # Create new connection
            if SQLCIPHER_AVAILABLE and _sqlcipher_key:
                conn = sqlcipher.connect(DB_FILE)
            else:
                conn = sqlcipher.connect(DB_FILE)
            
            conn.text_factory = str
            
            # Apply secure pragmas
            for pragma in cls._get_secure_pragmas():
                try:
                    conn.execute(pragma)
                except Exception:
                    pass
            
            # Pool size management
            _pool_size += 1
            if _pool_size > _MAX_POOL_SIZE:
                to_remove = []
                for tid, old_conn in _connection_pool.items():
                    if tid != thread_id:
                        try:
                            old_conn.close()
                        except Exception:
                            pass
                        to_remove.append(tid)
                for tid in to_remove:
                    del _connection_pool[tid]
                _pool_size = len(_connection_pool) + 1
            
            _connection_pool[thread_id] = conn
            return conn
    
    @classmethod
    @contextmanager
    def _get_connection(cls):
        """Get connection from pool"""
        conn = None
        try:
            conn = cls._get_pool_connection()
            yield conn
        except Exception as e:
            if conn:
                conn.rollback()
            logger.error(f"Database error in transaction: {e}")
            raise
        finally:
            pass
    
    @classmethod
    def close_all_connections(cls):
        """Close all connections in pool (call on app exit)"""
        global _pool_size
        with _pool_lock:
            for thread_id, conn in _connection_pool.items():
                try:
                    conn.close()
                except Exception as e:
                    logger.debug(f"Error closing connection {thread_id}: {e}")
            _connection_pool.clear()
            _pool_size = 0
    
    @classmethod
    def save(cls, label: str, password: str) -> int:
        """Save an encrypted password to the vault."""
        cls._init_db()
        
        # Ограничиваем длину метки для metadata minimization
        encrypted_label = _enc(label[:100])
        encrypted_password = _enc(password)
        
        try:
            with cls._get_connection() as conn:
                with conn:
                    # Используем компактный формат даты: YYYYMMDDHHMMSS
                    cursor = conn.execute(
                        "INSERT INTO p (l, p, c) VALUES (?, ?, ?)",
                        (encrypted_label, encrypted_password,
                         datetime.datetime.now().strftime("%Y%m%d%H%M%S"))
                    )
                    return cursor.lastrowid
        except Exception as e:
            logger.error(f"Database error saving password: {e}")
            raise
        finally:
            _clear_string(encrypted_label)
            _clear_string(encrypted_password)
    
    @classmethod
    def get_all(cls) -> List[Dict[str, Any]]:
        """Get all saved passwords (fully decrypted)."""
        cls._init_db()
        
        records = []
        try:
            with cls._get_connection() as conn:
                rows = conn.execute(
                    "SELECT i, l, p, c FROM p ORDER BY i DESC"
                ).fetchall()
                
                for r in rows:
                    try:
                        decrypted_label = _dec(r[1])
                        decrypted_password = _dec(r[2])
                        created_str = r[3]
                        # Конвертируем компактную дату обратно в читаемый формат
                        if len(created_str) == 14:
                            created = f"{created_str[:4]}-{created_str[4:6]}-{created_str[6:8]} {created_str[8:10]}:{created_str[10:12]}:{created_str[12:14]}"
                        else:
                            created = r[3]
                    except Exception as e:
                        logger.error(f"Decryption error for id {r[0]}: {e}")
                        decrypted_label = "[decryption failed]"
                        decrypted_password = "[decryption failed]"
                        created = r[3]
                    
                    records.append({
                        "id": r[0],
                        "label": decrypted_label,
                        "password": decrypted_password,
                        "created": created
                    })
                    
                    _clear_string(decrypted_label)
                    _clear_string(decrypted_password)
                
                return records
        except Exception as e:
            logger.error(f"Database error getting all: {e}")
            return []
    
    @classmethod
    def get_by_id(cls, row_id: int) -> Optional[Dict[str, Any]]:
        """Get a single password by ID"""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                row = conn.execute(
                    "SELECT i, l, p, c FROM p WHERE i = ?",
                    (row_id,)
                ).fetchone()
                
                if not row:
                    return None
                
                try:
                    decrypted_label = _dec(row[1])
                    decrypted_password = _dec(row[2])
                    created_str = row[3]
                    if len(created_str) == 14:
                        created = f"{created_str[:4]}-{created_str[4:6]}-{created_str[6:8]} {created_str[8:10]}:{created_str[10:12]}:{created_str[12:14]}"
                    else:
                        created = row[3]
                except Exception as e:
                    logger.error(f"Decryption error for id {row[0]}: {e}")
                    decrypted_label = "[decryption failed]"
                    decrypted_password = "[decryption failed]"
                    created = row[3]
                
                return {
                    "id": row[0],
                    "label": decrypted_label,
                    "password": decrypted_password,
                    "created": created
                }
        except Exception as e:
            logger.error(f"Database error getting by id: {e}")
            return None
    
    @classmethod
    def update(cls, row_id: int, label: str, password: str = None) -> None:
        """Update a password entry (re-encrypts with current key)."""
        cls._init_db()
        
        if password is not None:
            encrypted_label = _enc(label[:100])
            encrypted_password = _enc(password)
            try:
                with cls._get_connection() as conn:
                    with conn:
                        conn.execute(
                            "UPDATE p SET l=?, p=? WHERE i=?",
                            (encrypted_label, encrypted_password, row_id))
            except Exception as e:
                logger.error(f"Database error updating password {row_id}: {e}")
                raise
            finally:
                _clear_string(encrypted_label)
                _clear_string(encrypted_password)
        else:
            encrypted_label = _enc(label[:100])
            try:
                with cls._get_connection() as conn:
                    with conn:
                        conn.execute("UPDATE p SET l=? WHERE i=?",
                                     (encrypted_label, row_id))
            except Exception as e:
                logger.error(f"Database error updating label {row_id}: {e}")
                raise
            finally:
                _clear_string(encrypted_label)
    
    @classmethod
    def delete(cls, row_id: int) -> None:
        """Delete a password entry."""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                with conn:
                    conn.execute("DELETE FROM p WHERE i=?", (row_id,))
        except Exception as e:
            logger.error(f"Database error deleting password {row_id}: {e}")
            raise
    
    @classmethod
    def count(cls) -> int:
        """Get total number of saved passwords."""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                result = conn.execute("SELECT COUNT(*) FROM p").fetchone()
                return result[0] if result else 0
        except Exception as e:
            logger.error(f"Database error counting passwords: {e}")
            return 0
    
    @classmethod
    def search(cls, query: str) -> List[Dict[str, Any]]:
        """Search passwords by label (decrypts all for secure search)."""
        cls._init_db()
        
        query = query[:100].lower()
        records = []
        
        try:
            all_records = cls.get_all()
            for rec in all_records:
                if query in rec["label"].lower():
                    records.append(rec)
            return records
        except Exception as e:
            logger.error(f"Search error: {e}")
            return []
    
    @classmethod
    def vacuum(cls) -> None:
        """Optimize database (remove deleted data)"""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                conn.execute("PRAGMA incremental_vacuum")
        except Exception as e:
            logger.error(f"Vacuum error: {e}")
    
    @classmethod
    def backup(cls, backup_path: str) -> bool:
        """Create a backup of the database"""
        cls._init_db()
        
        try:
            with cls._get_connection() as conn:
                if SQLCIPHER_AVAILABLE and _sqlcipher_key:
                    backup_conn = sqlcipher.connect(backup_path)
                    for pragma in cls._get_secure_pragmas():
                        try:
                            backup_conn.execute(pragma)
                        except Exception:
                            pass
                else:
                    backup_conn = sqlite3.connect(backup_path)
                conn.backup(backup_conn)
                backup_conn.close()
            return True
        except Exception as e:
            logger.error(f"Backup error: {e}")
            return False
    
    @classmethod
    def rekey(cls, new_master_password: str) -> bool:
        """Change SQLCipher encryption key (requires SQLCipher)"""
        if not SQLCIPHER_AVAILABLE:
            logger.warning("SQLCipher not available, cannot rekey")
            return False
        
        try:
            new_key = hashlib.pbkdf2_hmac('sha256', new_master_password.encode('utf-8'), b'salt_sqlcipher', 64000, dklen=32)
            new_key_hex = new_key.hex()
            
            with cls._get_connection() as conn:
                conn.execute(f"PRAGMA rekey = \"{new_key_hex}\"")
            
            global _sqlcipher_key
            _sqlcipher_key = new_key_hex
            return True
        except Exception as e:
            logger.error(f"Rekey error: {e}")
            return False