"""
Password database storage with SQLite
PORTABLE VERSION - database is stored in the program's folder
Works from any location: USB flash drive, C:\, D:\, desktop
3 LANGUAGE SUPPORT: RU, EN, UA

Хранилище паролей с SQLite
ПОРТАТИВНАЯ ВЕРСИЯ - база данных хранится в папке с программой
Работает с любого места: флешка, диск C:\, D:\, рабочий стол
ПОДДЕРЖКА 3 ЯЗЫКОВ: RU, EN, UA

Сховище паролів з SQLite
ПОРТАТИВНА ВЕРСІЯ - база даних зберігається в папці з програмою
Працює з будь-якого місця: флешка, диск C:\, D:\, робочий стіл
ПІДТРИМКА 3 МОВ: RU, EN, UA
"""
import os
import sys
import sqlite3
import datetime
import threading
import shutil
import json
import time
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, asdict

# ==================== LOGGER WITHOUT DEPENDENCIES / ЛОГГЕР БЕЗ ЗАВИСИМОСТЕЙ / ЛОГЕР БЕЗ ЗАЛЕЖНОСТЕЙ ====================
def _get_logger(name):
    import logging
    logger = logging.getLogger(name)
    logger.setLevel(logging.WARNING)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger

logger = _get_logger("database")

# ==================== PORTABLE PATHS LOGIC / ПОРТАТИВНАЯ ЛОГИКА ПУТЕЙ / ПОРТАТИВНА ЛОГІКА ШЛЯХІВ ====================
def _get_base_dir() -> str:
    """
    Get the directory where the application is running
    
    Получить папку, где запущено приложение
    
    Отримати папку, де запущено додаток
    """
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def _get_db_path() -> str:
    """
    Get database file path inside application directory
    
    Получить путь к файлу БД в папке приложения
    
    Отримати шлях до файлу БД в папці додатку
    """
    base_dir = _get_base_dir()
    
    # Check for master_mixin / config locations to keep alignment
    data_dir = os.path.join(base_dir, "data")
    if os.path.exists(data_dir):
        return os.path.join(data_dir, "passwords.db")
        
    return os.path.join(base_dir, "passwords.db")

DB_PATH = _get_db_path()
DB_FILE = DB_PATH  # Alias for compatibility with encryption.py

# Lock for thread-safe operations
_db_lock = threading.RLock()

# ==================== DATABASE INITIALIZATION ====================

def _get_connection() -> sqlite3.Connection:
    """
    Open a standalone SQLite connection with proper timeout configuration
    
    Открывает соединение SQLite с правильной настройкой таймаута
    
    Відкриває з'єднання SQLite з правильним налаштуванням таймауту
    """
    db_dir = os.path.dirname(DB_PATH)
    try:
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir, exist_ok=True)
    except (OSError, IOError, PermissionError) as e:
        logger.debug(f"Directory creation skipped or failed: {e}")
        
    conn = sqlite3.connect(DB_PATH, timeout=20.0)
    conn.row_factory = sqlite3.Row
    return conn

def _init_db() -> None:
    """
    Initialize database and create table if it doesn't exist
    
    Инициализирует базу данных и создает таблицу, если она не существует
    
    Ініціалізує базу даних та створює таблицю, якщо вона не існує
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            
            # Create table with correct schema for the application
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS passwords (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    label TEXT NOT NULL,
                    password TEXT NOT NULL,
                    created TEXT NOT NULL,
                    updated TEXT,
                    notes TEXT
                )
            """)
            
            # Create indexes for better performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_label ON passwords(label)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_created ON passwords(created)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_updated ON passwords(updated)")
            
            conn.commit()
            logger.info(f"Database initialized at: {DB_PATH}")
        except sqlite3.Error as e:
            logger.error(f"Database initialization error: {e}")
            raise
        finally:
            conn.close()


# ==================== CORE DATABASE OPERATIONS ====================

def _save_password(label: str, password: str, notes: str = "") -> int:
    """
    Save password to database
    
    Сохраняет пароль в базу
    
    Зберігає пароль у базу
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # Validate and sanitize inputs
            if not label or label.strip() == "":
                label = "Без метки"
            label = label[:200]
            
            if notes and len(notes) > 500:
                notes = notes[:500]
            
            cursor.execute(
                "INSERT INTO passwords (label, password, created, updated, notes) VALUES (?, ?, ?, ?, ?)",
                (label, password, now, now, notes)
            )
            conn.commit()
            record_id = cursor.lastrowid
            logger.info(f"Password saved with ID: {record_id}, label: {label}")
            return record_id
        except sqlite3.Error as e:
            conn.rollback()
            logger.error(f"Failed to save password: {e}")
            raise Exception(f"Error saving password: {e}")
        finally:
            conn.close()

def _get_all_passwords() -> List[Dict[str, Any]]:
    """
    Get all passwords from database
    
    Возвращает все пароли
    
    Повертає всі паролі
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id, label, password, created, updated, notes FROM passwords ORDER BY id DESC")
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
        except sqlite3.Error as e:
            logger.error(f"Failed to get passwords: {e}")
            return []
        finally:
            conn.close()

def _search_passwords(query: str) -> List[Dict[str, Any]]:
    """
    Search passwords by label, password or date
    
    Ищет пароли
    
    Шукає паролі
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            search_term = f'%{query}%'
            cursor.execute(
                "SELECT id, label, password, created, updated, notes FROM passwords "
                "WHERE label LIKE ? OR password LIKE ? OR created LIKE ? OR notes LIKE ? "
                "ORDER BY id DESC",
                (search_term, search_term, search_term, search_term)
            )
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
        except sqlite3.Error as e:
            logger.error(f"Failed to search passwords: {e}")
            return []
        finally:
            conn.close()

def _get_password_by_id(record_id: int) -> Optional[Dict[str, Any]]:
    """
    Get password by ID
    
    Возвращает пароль по ID
    
    Повертає пароль за ID
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, label, password, created, updated, notes FROM passwords WHERE id = ?",
                (record_id,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
        except sqlite3.Error as e:
            logger.error(f"Failed to get password by ID: {e}")
            return None
        finally:
            conn.close()

def _update_password(record_id: int, label: str, password: Optional[str] = None, notes: Optional[str] = None) -> bool:
    """
    Update password record
    
    Обновляет запись
    
    Оновлює запис
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # Validate and sanitize inputs
            if not label or label.strip() == "":
                label = "Без метки"
            label = label[:200]
            
            if notes and len(notes) > 500:
                notes = notes[:500]
            
            if password is not None and notes is not None:
                cursor.execute(
                    "UPDATE passwords SET label = ?, password = ?, updated = ?, notes = ? WHERE id = ?",
                    (label, password, now, notes, record_id)
                )
            elif password is not None:
                cursor.execute(
                    "UPDATE passwords SET label = ?, password = ?, updated = ? WHERE id = ?",
                    (label, password, now, record_id)
                )
            elif notes is not None:
                cursor.execute(
                    "UPDATE passwords SET label = ?, updated = ?, notes = ? WHERE id = ?",
                    (label, now, notes, record_id)
                )
            else:
                cursor.execute(
                    "UPDATE passwords SET label = ?, updated = ? WHERE id = ?",
                    (label, now, record_id)
                )
            conn.commit()
            logger.info(f"Password updated with ID: {record_id}")
            return cursor.rowcount > 0
        except sqlite3.Error as e:
            conn.rollback()
            logger.error(f"Failed to update password: {e}")
            return False
        finally:
            conn.close()

def _delete_password(record_id: int) -> bool:
    """
    Delete password record
    
    Удаляет запись
    
    Видаляє запис
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM passwords WHERE id = ?", (record_id,))
            conn.commit()
            logger.info(f"Password deleted with ID: {record_id}")
            return cursor.rowcount > 0
        except sqlite3.Error as e:
            conn.rollback()
            logger.error(f"Failed to delete password: {e}")
            return False
        finally:
            conn.close()

def _count_passwords() -> int:
    """
    Count passwords in database
    
    Считает количество записей
    
    Рахує кількість записів
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM passwords")
            return cursor.fetchone()[0]
        except sqlite3.Error as e:
            logger.error(f"Failed to count passwords: {e}")
            return 0
        finally:
            conn.close()

def _clear_all_passwords() -> bool:
    """
    Delete all passwords
    
    Удаляет все пароли
    
    Видаляє всі паролі
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM passwords")
            cursor.execute("DELETE FROM sqlite_sequence WHERE name='passwords'")
            conn.commit()
            logger.info("All passwords cleared")
            return True
        except sqlite3.Error as e:
            conn.rollback()
            logger.error(f"Failed to clear passwords: {e}")
            return False
        finally:
            conn.close()

def _create_backup() -> Optional[str]:
    """
    Create database backup
    
    Создает резервную копию
    
    Створює резервну копію
    """
    try:
        if not os.path.exists(DB_PATH):
            return None
            
        base_dir = _get_base_dir()
        backup_dir = os.path.join(base_dir, "backups")
        os.makedirs(backup_dir, exist_ok=True)
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"passwords_backup_{timestamp}.db"
        backup_path = os.path.join(backup_dir, backup_filename)
        
        with _db_lock:
            shutil.copy2(DB_PATH, backup_path)
            
        logger.info(f"Database backed up successfully to: {backup_path}")
        return backup_path
    except (OSError, IOError, sqlite3.Error, shutil.Error) as e:
        logger.error(f"Failed to generate database backup: {e}")
        return None

def _vacuum_database() -> None:
    """
    Optimize database
    
    Оптимизирует базу данных
    
    Оптимізує базу даних
    """
    with _db_lock:
        conn = _get_connection()
        try:
            conn.execute("VACUUM")
            logger.info("Database vacuum completed")
        except sqlite3.Error as e:
            logger.error(f"Vacuum error: {e}")
        finally:
            conn.close()


# ==================== PASSWORDDB CLASS (COMPATIBLE WITH GUI) ====================

class PasswordDB:
    """
    Password database class with CRUD operations for GUI compatibility
    
    Класс для работы с базой паролей (совместимый с GUI)
    
    Клас для роботи з базою паролів (сумісний з GUI)
    """
    
    _initialized = False
    
    @classmethod
    def _ensure_initialized(cls) -> None:
        """
        Ensure database is initialized
        
        Инициализирует БД если нужно
        
        Ініціалізує БД якщо потрібно
        """
        if not cls._initialized:
            _init_db()
            cls._initialized = True
    
    @classmethod
    def save(cls, label: str, password: str, notes: str = "") -> int:
        """
        Save password to database
        
        Сохраняет пароль в базу данных
        
        Зберігає пароль у базу даних
        """
        cls._ensure_initialized()
        return _save_password(label, password, notes)
    
    @classmethod
    def get_all(cls) -> List[Dict[str, Any]]:
        """
        Get all passwords
        
        Возвращает все пароли
        
        Повертає всі паролі
        """
        cls._ensure_initialized()
        return _get_all_passwords()
    
    @classmethod
    def search(cls, query: str) -> List[Dict[str, Any]]:
        """
        Search passwords
        
        Ищет пароли
        
        Шукає паролі
        """
        cls._ensure_initialized()
        return _search_passwords(query)
    
    @classmethod
    def get_by_id(cls, record_id: int) -> Optional[Dict[str, Any]]:
        """
        Get password by ID
        
        Возвращает пароль по ID
        
        Повертає пароль за ID
        """
        cls._ensure_initialized()
        return _get_password_by_id(record_id)
    
    @classmethod
    def update(cls, record_id: int, label: str, password: Optional[str] = None, notes: Optional[str] = None) -> bool:
        """
        Update password record
        
        Обновляет запись
        
        Оновлює запис
        """
        cls._ensure_initialized()
        return _update_password(record_id, label, password, notes)
    
    @classmethod
    def delete(cls, record_id: int) -> bool:
        """
        Delete password record
        
        Удаляет запись
        
        Видаляє запис
        """
        cls._ensure_initialized()
        return _delete_password(record_id)
    
    @classmethod
    def count(cls) -> int:
        """
        Count passwords
        
        Считает количество записей
        
        Рахує кількість записів
        """
        cls._ensure_initialized()
        return _count_passwords()
    
    @classmethod
    def clear_all(cls) -> bool:
        """
        Delete all passwords
        
        Удаляет все пароли
        
        Видаляє всі паролі
        """
        cls._ensure_initialized()
        return _clear_all_passwords()
    
    @classmethod
    def create_backup(cls) -> Optional[str]:
        """
        Create database backup
        
        Создает резервную копию
        
        Створює резервну копію
        """
        cls._ensure_initialized()
        return _create_backup()
    
    @classmethod
    def vacuum(cls) -> None:
        """
        Optimize database
        
        Оптимизирует базу данных
        
        Оптимізує базу даних
        """
        cls._ensure_initialized()
        _vacuum_database()
    
    @classmethod
    def get_db_path(cls) -> str:
        """
        Get database file path
        
        Возвращает путь к БД
        
        Повертає шлях до БД
        """
        return DB_PATH
    
    @classmethod
    def get_db_size(cls) -> int:
        """
        Get database file size in bytes
        
        Размер файла БД в байтах
        
        Розмір файлу БД у байтах
        """
        try:
            if os.path.exists(DB_PATH):
                return os.path.getsize(DB_PATH)
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"Failed to get DB size: {e}")
        return 0
    
    @classmethod
    def close_connection(cls) -> None:
        """
        Close database connection (no-op for SQLite, connections are closed per operation)
        
        Закрывает соединение с БД (для SQLite не требуется, соединения закрываются после каждой операции)
        
        Закриває з'єднання з БД (для SQLite не потрібно, з'єднання закриваються після кожної операції)
        """
        logger.debug("Database connection closed (no-op for SQLite)")
    
    @classmethod
    def close_all_connections(cls) -> None:
        """
        Close all database connections
        
        Закрыть все соединения с БД
        
        Закрити всі з'єднання з БД
        """
        logger.debug("All database connections closed")


# ==================== ALIAS FOR BACKWARD COMPATIBILITY ====================
Database = PasswordDB

# Export
__all__ = ['PasswordDB', 'Database', 'DB_FILE', 'DB_PATH']