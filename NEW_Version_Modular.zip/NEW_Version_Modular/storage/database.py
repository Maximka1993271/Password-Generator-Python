"""
Password database storage with SQLite
PORTABLE VERSION - database is stored in the program's folder
Works from any location: USB flash drive, C:\, D:\, desktop
3 LANGUAGE SUPPORT: RU, EN, UA

Хранилище паролей с SQLite
ПОРТАТИВНАЯ ВЕРСИЯ - база данных хранится в папке с программой
Работает с любого места: флешка, диск C:\, D:\, рабочий стол
ПОДДЕРЖКА 3 ЯЗЫКОВ: RU, EN, UA

Сховище паролів з SQLite
ПОРТАТИВНА ВЕРСІЯ - база даних зберігається в папці з програмою
Працює з будь-якого місця: флешка, диск C:\, D:\, робочий стіл
ПІДТРИМКА 3 МОВ: RU, EN, UA
"""
import os
import sys
import sqlite3
import datetime
import threading
from typing import List, Dict, Any, Optional

# ==================== LOGGER WITHOUT DEPENDENCIES / ЛОГГЕР БЕЗ ЗАВИСИМОСТЕЙ / ЛОГЕР БЕЗ ЗАЛЕЖНОСТЕЙ ====================
def _get_logger(name):
    import logging
    logger = logging.getLogger(name)
    logger.setLevel(logging.WARNING)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        logger.addHandler(handler)
    return logger

logger = _get_logger("database")

# ==================== PORTABLE PATH / ПОРТАТИВНЫЙ ПУТЬ / ПОРТАТИВНИЙ ШЛЯХ ====================

def get_program_dir() -> str:
    """Return the directory where the EXE or script is located
    Возвращает директорию, где находится EXE или скрипт
    Повертає директорію, де знаходиться EXE або скрипт"""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def get_db_path() -> str:
    """Return the path to the database file (in the .securepass folder next to the program)
    Возвращает путь к файлу базы данных (в папке .securepass рядом с программой)
    Повертає шлях до файлу бази даних (у папці .securepass поруч з програмою)"""
    program_dir = get_program_dir()
    db_dir = os.path.join(program_dir, '.securepass')
    os.makedirs(db_dir, exist_ok=True)
    
    if sys.platform == 'win32':
        try:
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(db_dir, 2)
        except Exception:
            pass
    
    return os.path.join(db_dir, 'passwords.db')

_DB_PATH = get_db_path()


def _get_connection() -> sqlite3.Connection:
    """Create a database connection / Создаёт соединение с базой данных / Створює з'єднання з базою даних"""
    conn = sqlite3.connect(_DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def _init_db() -> None:
    """Initialize the database (create table if it doesn't exist)
    Инициализирует базу данных (создаёт таблицу если её нет)
    Ініціалізує базу даних (створює таблицю якщо її немає)"""
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS passwords (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    label TEXT NOT NULL,
                    password TEXT NOT NULL,
                    created TEXT NOT NULL
                )
            ''')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_label ON passwords(label)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_created ON passwords(created)')
            conn.commit()
            logger.info(f"Database initialized at: {_DB_PATH}")
    except sqlite3.Error as e:
        logger.error(f"Database initialization error: {e}")
        raise


class PasswordDB:
    """Password database class (PORTABLE VERSION)
    Класс для работы с базой паролей (ПОРТАТИВНАЯ ВЕРСИЯ)
    Клас для роботи з базою паролів (ПОРТАТИВНА ВЕРСІЯ)"""
    
    _initialized = False
    _lock = threading.Lock()
    
    @classmethod
    def _ensure_initialized(cls) -> None:
        """Ensure the database is initialized / Гарантирует, что база данных инициализирована / Гарантує, що база даних ініціалізована"""
        if not cls._initialized:
            with cls._lock:
                if not cls._initialized:
                    _init_db()
                    cls._initialized = True
    
    @classmethod
    def save(cls, label: str, password: str) -> int:
        """Save password to database / Сохраняет пароль в базу данных / Зберігає пароль у базу даних"""
        cls._ensure_initialized()
        created = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        if not label or label.strip() == "":
            label = "Без метки"  # Will be replaced by translation in UI / Будет заменено переводом в UI / Буде замінено перекладом в UI
        label = label[:100]
        
        try:
            with _get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT INTO passwords (label, password, created) VALUES (?, ?, ?)",
                    (label, password, created)
                )
                conn.commit()
                record_id = cursor.lastrowid
                logger.info(f"Password saved with ID: {record_id}, label: {label}")
                return record_id
        except sqlite3.Error as e:
            logger.error(f"Failed to save password: {e}")
            raise Exception(f"Error saving password: {e}")
    
    @classmethod
    def get_all(cls) -> List[Dict[str, Any]]:
        """Return all passwords from database / Возвращает все пароли из базы данных / Повертає всі паролі з бази даних"""
        cls._ensure_initialized()
        
        try:
            with _get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT id, label, password, created FROM passwords ORDER BY id DESC")
                rows = cursor.fetchall()
                result = [dict(row) for row in rows]
                logger.debug(f"Retrieved {len(result)} passwords")
                return result
        except sqlite3.Error as e:
            logger.error(f"Failed to get passwords: {e}")
            return []
    
    @classmethod
    def search(cls, query: str) -> List[Dict[str, Any]]:
        """Search passwords by label, password or date / Ищет пароли по метке, паролю или дате / Шукає паролі за міткою, паролем або датою"""
        cls._ensure_initialized()
        
        if not query or query.strip() == "":
            return cls.get_all()
        
        try:
            with _get_connection() as conn:
                cursor = conn.cursor()
                search_term = f'%{query}%'
                cursor.execute(
                    "SELECT id, label, password, created FROM passwords "
                    "WHERE label LIKE ? OR password LIKE ? OR created LIKE ? "
                    "ORDER BY id DESC",
                    (search_term, search_term, search_term)
                )
                rows = cursor.fetchall()
                result = [dict(row) for row in rows]
                logger.debug(f"Search '{query}' found {len(result)} results")
                return result
        except sqlite3.Error as e:
            logger.error(f"Failed to search passwords: {e}")
            return []
    
    @classmethod
    def get_by_id(cls, record_id: int) -> Optional[Dict[str, Any]]:
        """Return password by ID / Возвращает пароль по ID / Повертає пароль за ID"""
        cls._ensure_initialized()
        
        try:
            with _get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT id, label, password, created FROM passwords WHERE id = ?",
                    (record_id,)
                )
                row = cursor.fetchone()
                return dict(row) if row else None
        except sqlite3.Error as e:
            logger.error(f"Failed to get password by ID: {e}")
            return None
    
    @classmethod
    def update(cls, record_id: int, label: str, password: Optional[str] = None) -> bool:
        """Update a record in the database / Обновляет запись в базе данных / Оновлює запис у базі даних"""
        cls._ensure_initialized()
        
        if not label or label.strip() == "":
            label = "Без метки"  # Will be replaced by translation in UI / Будет заменено переводом в UI / Буде замінено перекладом в UI
        label = label[:100]
        
        try:
            with _get_connection() as conn:
                cursor = conn.cursor()
                if password:
                    cursor.execute(
                        "UPDATE passwords SET label = ?, password = ? WHERE id = ?",
                        (label, password, record_id)
                    )
                else:
                    cursor.execute(
                        "UPDATE passwords SET label = ? WHERE id = ?",
                        (label, record_id)
                    )
                conn.commit()
                logger.info(f"Password updated with ID: {record_id}")
                return True
        except sqlite3.Error as e:
            logger.error(f"Failed to update password: {e}")
            return False
    
    @classmethod
    def delete(cls, record_id: int) -> bool:
        """Delete a record from the database / Удаляет запись из базы данных / Видаляє запис із бази даних"""
        cls._ensure_initialized()
        
        try:
            with _get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM passwords WHERE id = ?", (record_id,))
                conn.commit()
                logger.info(f"Password deleted with ID: {record_id}")
                return True
        except sqlite3.Error as e:
            logger.error(f"Failed to delete password: {e}")
            return False
    
    @classmethod
    def count(cls) -> int:
        """Return the number of records in the database / Возвращает количество записей в базе данных / Повертає кількість записів у базі даних"""
        cls._ensure_initialized()
        
        try:
            with _get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM passwords")
                count = cursor.fetchone()[0]
                return count
        except sqlite3.Error as e:
            logger.error(f"Failed to count passwords: {e}")
            return 0
    
    @classmethod
    def clear_all(cls) -> bool:
        """Delete all records from the database / Удаляет все записи из базы данных / Видаляє всі записи з бази даних"""
        cls._ensure_initialized()
        
        try:
            with _get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM passwords")
                cursor.execute("DELETE FROM sqlite_sequence WHERE name='passwords'")
                conn.commit()
                logger.info("All passwords cleared")
                return True
        except sqlite3.Error as e:
            logger.error(f"Failed to clear passwords: {e}")
            return False
    
    @classmethod
    def get_db_path(cls) -> str:
        """Return the path to the database file / Возвращает путь к файлу базы данных / Повертає шлях до файлу бази даних"""
        return _DB_PATH
    
    @classmethod
    def get_db_size(cls) -> int:
        """Return the size of the database file in bytes / Возвращает размер файла базы данных в байтах / Повертає розмір файлу бази даних у байтах"""
        try:
            if os.path.exists(_DB_PATH):
                return os.path.getsize(_DB_PATH)
        except Exception:
            pass
        return 0
    
    @classmethod
    def vacuum(cls) -> None:
        """Optimize the database / Оптимизирует базу данных / Оптимізує базу даних"""
        cls._ensure_initialized()
        try:
            with _get_connection() as conn:
                conn.execute("VACUUM")
                logger.info("Database vacuum completed")
        except sqlite3.Error as e:
            logger.error(f"Vacuum error: {e}")


__all__ = [
    'PasswordDB',
    'get_db_path',
]