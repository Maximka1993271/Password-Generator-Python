"""
SQLite database for saved passwords (with AES-256-GCM field encryption)
"""
import sqlite3
import os
import sys
import ctypes
import datetime
from contextlib import closing
from typing import List, Dict, Any
from utils.paths import get_db_file, get_config_dir, hide_dir


def _secure_zero(data: bytearray) -> None:
    """Обнуляет bytearray через ctypes.memset"""
    if data is None:
        return
    try:
        length = len(data)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(data)), 0, length)
    except Exception:
        for i in range(len(data)):
            data[i] = 0


def _clear_string(s: str) -> None:
    """Пытается очистить строку (через обнуление bytearray)"""
    try:
        if s:
            ba = bytearray(s.encode('utf-8'))
            _secure_zero(ba)
    except Exception:
        pass


def _enc(text: str) -> str:
    """Encrypt password field. Fail closed instead of storing plaintext."""
    from security.encryption import encrypt
    return encrypt(text)


def _dec(text: str) -> str:
    """Decrypt password field for display."""
    try:
        from security.encryption import decrypt
        return decrypt(text)
    except Exception:
        return "[encrypted - unlock with master password]"


class PasswordDB:
    """Password vault database handler"""

    @classmethod
    def _get_connection(cls):
        db_file = get_db_file()
        config_dir = get_config_dir()
        os.makedirs(config_dir, exist_ok=True)
        hide_dir(config_dir)
        conn = sqlite3.connect(db_file)
        conn.text_factory = str
        conn.execute("PRAGMA encoding = 'UTF-8';")
        conn.execute("PRAGMA secure_delete = ON;")
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS passwords (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                label TEXT NOT NULL,
                password TEXT NOT NULL,
                created TEXT NOT NULL
            )
        """)
        conn.commit()
        return conn

    @classmethod
    def save(cls, label: str, password: str) -> int:
        """Save an encrypted password to the vault."""
        encrypted = _enc(password)
        try:
            with closing(cls._get_connection()) as conn:
                with conn:
                    cursor = conn.execute(
                        "INSERT INTO passwords (label, password, created) VALUES (?, ?, ?)",
                        (label[:200], encrypted,
                         datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                    )
                    return cursor.lastrowid
        finally:
            _clear_string(encrypted)

    @classmethod
    def get_all(cls) -> List[Dict[str, Any]]:
        """Get all saved passwords (decrypted)."""
        records = []
        try:
            with closing(cls._get_connection()) as conn:
                rows = conn.execute(
                    "SELECT id, label, password, created FROM passwords ORDER BY id DESC"
                ).fetchall()
                
                for r in rows:
                    decrypted = _dec(r[2])
                    records.append({
                        "id": r[0],
                        "label": r[1],
                        "password": decrypted,
                        "created": r[3]
                    })
                    _clear_string(decrypted)
                
                return records
        except Exception:
            return []

    @classmethod
    def update(cls, row_id: int, label: str, password: str = None) -> None:
        """Update a password entry (re-encrypts with current key)."""
        if password is not None:
            encrypted = _enc(password)
            try:
                with closing(cls._get_connection()) as conn:
                    with conn:
                        conn.execute(
                            "UPDATE passwords SET label=?, password=? WHERE id=?",
                            (label[:200], encrypted, row_id))
            finally:
                _clear_string(encrypted)
        else:
            with closing(cls._get_connection()) as conn:
                with conn:
                    conn.execute("UPDATE passwords SET label=? WHERE id=?",
                                 (label[:200], row_id))

    @classmethod
    def delete(cls, row_id: int) -> None:
        """Delete a password entry."""
        with closing(cls._get_connection()) as conn:
            with conn:
                conn.execute("DELETE FROM passwords WHERE id=?", (row_id,))

    @classmethod
    def count(cls) -> int:
        """Get total number of saved passwords."""
        with closing(cls._get_connection()) as conn:
            return conn.execute(
                "SELECT COUNT(*) FROM passwords").fetchone()[0]

    @classmethod
    def search(cls, query: str) -> List[Dict[str, Any]]:
        """Search passwords by label (decrypted passwords not searchable by design)."""
        query = query[:200]
        records = []
        try:
            with closing(cls._get_connection()) as conn:
                rows = conn.execute(
                    "SELECT id, label, password, created FROM passwords "
                    "WHERE label LIKE ? ESCAPE '\\' ORDER BY id DESC",
                    (f"%{query.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')}%",)
                ).fetchall()
                
                for r in rows:
                    decrypted = _dec(r[2])
                    records.append({
                        "id": r[0],
                        "label": r[1],
                        "password": decrypted,
                        "created": r[3]
                    })
                    _clear_string(decrypted)
                
                return records
        except Exception:
            return []