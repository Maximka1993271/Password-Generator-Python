"""
Storage module - database and configuration

Модуль хранения - база данных и конфигурация
Модуль зберігання - база даних та конфігурація
"""
from storage.database import PasswordDB
from storage.config import Config

__all__ = ['PasswordDB', 'Config']