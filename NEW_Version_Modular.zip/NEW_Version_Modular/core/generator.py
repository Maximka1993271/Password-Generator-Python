"""
Password generator and strength calculator
"""
import secrets
import math
import string
import random
from typing import List, Optional, Tuple, Dict, Any


class PasswordGenerator:
    """Cryptographically secure password generator with Diceware support"""
    
    DEFAULT_SPECIAL = "!@#$%^&*()_+-=[]{}|;:,.<>?/~"
    AMBIGUOUS_CHARS = "il1Lo0O"
    UNAMBIGUOUS_CHARS = "{}[]()/\\'\"`~,;:.<>"
    
    # Diceware word list (базовый набор из 7776 слов, здесь сокращённая версия)
    DICEWARE_WORDS = [
        "apple", "banana", "cherry", "dog", "elephant", "flower", "green", "happy",
        "ice", "jungle", "kite", "lemon", "moon", "night", "orange", "purple",
        "queen", "river", "sun", "tree", "umbrella", "volcano", "water", "xray",
        "yellow", "zebra", "cloud", "dream", "energy", "forest", "gold", "heart",
        "idea", "joy", "kind", "light", "magic", "nature", "ocean", "peace",
        "quiet", "rain", "star", "time", "unity", "voice", "wind", "xenon", "youth", "zen",
        "alpha", "beta", "gamma", "delta", "echo", "foxtrot", "golf", "hotel",
        "india", "juliett", "kilo", "lima", "mike", "november", "oscar", "papa",
        "quebec", "romeo", "sierra", "tango", "uniform", "victor", "whiskey", "xray",
        "yankee", "zulu"
    ]
    
    def __init__(self):
        # Основные настройки
        self.use_upper = True
        self.use_lower = True
        self.use_digits = True
        self.use_special = False
        self.exclude_ambiguous = False
        self.exclude_unambiguous = False
        self.min_each = False
        self.no_repeat = False
        self.length = 20
        
        # Diceware настройки
        self.use_diceware = False
        self.diceware_word_count = 4
        self.diceware_separator = "-"
        self.diceware_capitalize = False
        self.diceware_add_number = False
    
    def _get_pool(self) -> str:
        """Get character pool based on current settings"""
        pool = ""
        if self.use_lower:
            pool += string.ascii_lowercase
        if self.use_upper:
            pool += string.ascii_uppercase
        if self.use_digits:
            pool += string.digits
        if self.use_special:
            pool += self.DEFAULT_SPECIAL
        
        if self.exclude_ambiguous:
            for ch in self.AMBIGUOUS_CHARS:
                pool = pool.replace(ch, '')
        
        if self.exclude_unambiguous:
            for ch in self.UNAMBIGUOUS_CHARS:
                pool = pool.replace(ch, '')
        
        return pool
    
    def _get_categories(self) -> List[str]:
        """Get list of character categories for 'min each' mode"""
        categories = []
        if self.use_lower:
            categories.append(string.ascii_lowercase)
        if self.use_upper:
            categories.append(string.ascii_uppercase)
        if self.use_digits:
            categories.append(string.digits)
        if self.use_special:
            categories.append(self.DEFAULT_SPECIAL)
        
        if self.exclude_ambiguous:
            categories = [''.join(c for c in cat if c not in self.AMBIGUOUS_CHARS) for cat in categories]
        if self.exclude_unambiguous:
            categories = [''.join(c for c in cat if c not in self.UNAMBIGUOUS_CHARS) for cat in categories]
        
        return [cat for cat in categories if cat]
    
    def _fix_no_repeats(self, chars: List[str], pool: str) -> Optional[str]:
        """Ensure no consecutive repeated characters"""
        result = list(chars)
        unique_pool = list(set(pool))
        max_attempts = 500
        
        def _secure_shuffle(lst: list) -> None:
            for i in range(len(lst) - 1, 0, -1):
                j = secrets.randbelow(i + 1)
                lst[i], lst[j] = lst[j], lst[i]
        
        for _ in range(max_attempts):
            _secure_shuffle(result)
            has_repeat = any(result[i] == result[i + 1] for i in range(len(result) - 1))
            if not has_repeat:
                return "".join(result)
        
        result = list(chars)
        _secure_shuffle(result)
        for attempt in range(max_attempts):
            fixed = False
            for i in range(len(result) - 1):
                if result[i] == result[i + 1]:
                    candidates = [c for c in unique_pool if c != result[i] and (i == 0 or c != result[i - 1])]
                    if candidates:
                        result[i + 1] = secrets.choice(candidates)
                        fixed = True
            if not fixed:
                break
            if not any(result[i] == result[i + 1] for i in range(len(result) - 1)):
                return "".join(result)
        return None
    
    def _generate_diceware(self) -> str:
        """Generate Diceware passphrase"""
        words = []
        for _ in range(self.diceware_word_count):
            word = secrets.choice(self.DICEWARE_WORDS)
            if self.diceware_capitalize:
                word = word.capitalize()
            words.append(word)
        
        passphrase = self.diceware_separator.join(words)
        
        if self.diceware_add_number:
            import random
            number = str(secrets.randbelow(100))
            passphrase += self.diceware_separator + number
        
        return passphrase
    
    def _get_min_required_length(self) -> int:
        """Calculate minimum required length based on active categories"""
        count = 0
        if self.use_upper:
            count += 1
        if self.use_lower:
            count += 1
        if self.use_digits:
            count += 1
        if self.use_special:
            count += 1
        
        if self.min_each and count > 0:
            return max(1, count)
        return 1
    
    def generate(self) -> Optional[str]:
        """Generate a password based on current settings"""
        
        # Diceware режим
        if self.use_diceware:
            return self._generate_diceware()
        
        # Обычная генерация
        try:
            length = int(self.length)
        except (TypeError, ValueError):
            return None
        if length <= 0:
            return None

        pool = self._get_pool()
        if not pool:
            return None
        
        min_length = self._get_min_required_length()
        if length < min_length:
            return None
        
        if self.min_each:
            categories = self._get_categories()
            if not categories or len(categories) < 1:
                categories = [pool]
            if length < len(categories):
                return None

            password_chars = []
            for cat in categories:
                if cat:
                    password_chars.append(secrets.choice(cat))
            
            remaining = length - len(password_chars)
            if remaining > 0 and pool:
                for _ in range(remaining):
                    password_chars.append(secrets.choice(pool))
            
            for i in range(len(password_chars) - 1, 0, -1):
                j = secrets.randbelow(i + 1)
                password_chars[i], password_chars[j] = password_chars[j], password_chars[i]
            
            result = "".join(password_chars)
        else:
            if not pool:
                return None
            result = ''.join(secrets.choice(pool) for _ in range(length))
        
        if self.no_repeat:
            fixed = self._fix_no_repeats(list(result), pool)
            if not fixed:
                return None
            result = fixed
        
        return result
    
    def filter_ambiguous_chars(self, password: str) -> str:
        """
        Filter out ambiguous characters (0, O, 1, l, I)
        """
        replacements = {
            '0': 'O',
            'O': 'Q',
            '1': '!',
            'l': 'L',
            'I': '!'
        }
        
        result = password
        for old, new in replacements.items():
            result = result.replace(old, new)
        
        return result
    
    def get_entropy_bits(self, password: str) -> float:
        """
        Calculate entropy bits of a password
        """
        if not password:
            return 0.0
        
        pool_size = 0
        if any(c.islower() for c in password):
            pool_size += 26
        if any(c.isupper() for c in password):
            pool_size += 26
        if any(c.isdigit() for c in password):
            pool_size += 10
        if any(c in string.punctuation for c in password):
            pool_size += 32
        
        if pool_size == 0:
            return 0.0
        
        return len(password) * math.log2(pool_size)


class StrengthCalculator:
    """Calculate password strength metrics"""
    
    @staticmethod
    def calculate(password: str) -> Dict[str, Any]:
        """
        Calculate password strength
        Returns dict with: pool_size, combinations, entropy_bits, strength_level, crack_time_label
        """
        if not password:
            return {
                'pool_size': 0,
                'combinations': 0,
                'entropy_bits': 0,
                'strength_level': 'empty',
                'crack_time_label': ''
            }
        
        pool_size = 0
        if any(c.islower() for c in password):
            pool_size += 26
        if any(c.isupper() for c in password):
            pool_size += 26
        if any(c.isdigit() for c in password):
            pool_size += 10
        if any(c in string.punctuation for c in password):
            pool_size += 32
        
        if pool_size == 0:
            pool_size = 1
        
        # Энтропия по формуле Шеннона
        entropy_bits = len(password) * math.log2(pool_size) if pool_size > 0 else 0
        combinations = pool_size ** len(password) if pool_size > 0 else 0
        
        # Определяем уровень сложности
        if entropy_bits < 40:
            strength_level = 'weak'
            crack_time_label = 'time_sec'
        elif entropy_bits < 60:
            strength_level = 'medium'
            crack_time_label = 'time_day'
        elif entropy_bits < 80:
            strength_level = 'medium'
            crack_time_label = 'time_year'
        else:
            strength_level = 'strong'
            crack_time_label = 'time_cent'
        
        return {
            'pool_size': pool_size,
            'combinations': f"{combinations:.1e}" if combinations > 0 else "0",
            'entropy_bits': entropy_bits,
            'strength_level': strength_level,
            'crack_time_label': crack_time_label
        }
    
    @staticmethod
    def calculate_entropy_bits(password: str) -> float:
        """Calculate entropy bits only"""
        if not password:
            return 0.0
        
        pool_size = 0
        if any(c.islower() for c in password):
            pool_size += 26
        if any(c.isupper() for c in password):
            pool_size += 26
        if any(c.isdigit() for c in password):
            pool_size += 10
        if any(c in string.punctuation for c in password):
            pool_size += 32
        
        if pool_size == 0:
            return 0.0
        
        return len(password) * math.log2(pool_size)