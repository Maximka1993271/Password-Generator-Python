"""
Password generator and strength calculator with secure memory handling

Генератор паролей и калькулятор стойкости с безопасной работой с памятью
Генератор паролів та калькулятор стійкості з безпечною роботою з пам'яттю
"""
import secrets
import math
import string
import random
import ctypes
from typing import List, Optional, Tuple, Dict, Any, Union
from array import array

from utils.logger import get_logger
from utils.secure_memory import SecureBytes, SecurePassword, MemoryGuard, secure_zero_memory, secure_zero_string

logger = get_logger("generator")


# ==================== HELPER FUNCTIONS / ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ / ДОПОМІЖНІ ФУНКЦІЇ ====================

def _secure_zero_bytearray(data: bytearray) -> None:
    """Safely zeroes a bytearray
    Безопасно обнуляет bytearray
    Безпечно обнуляє bytearray"""
    if data is None:
        return
    try:
        length = len(data)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(data)), 0, length)
    except (TypeError, AttributeError, OSError) as e:
        logger.debug(f"Memory zeroing failed: {e}")
        for i in range(len(data)):
            data[i] = 0


def _clear_string(s: str) -> None:
    """Attempts to clear string from memory
    Пытается очистить строку из памяти
    Намагається очистити рядок з пам'яті"""
    if not s:
        return
    # Do not try to clear encrypted data / Не пытаемся очистить зашифрованные данные / Не намагаємося очистити зашифровані дані
    if s.startswith(('[encrypted', 'enc1:', 'enc2:', 'enc3:')):
        return
    try:
        ba = bytearray(s.encode('utf-8'))
        _secure_zero_bytearray(ba)
    except (UnicodeEncodeError, TypeError, MemoryError) as e:
        logger.debug(f"String clearing failed: {e}")


def secure_compare(a: str, b: str) -> bool:
    """
    Secure string comparison resistant to timing attacks.
    Uses secrets.compare_digest.
    
    Безопасное сравнение строк, устойчивое к timing attacks.
    Безпечне порівняння рядків, стійке до timing attacks.
    """
    return secrets.compare_digest(a.encode('utf-8'), b.encode('utf-8'))


# ==================== SECURE STRING / БЕЗОПАСНАЯ СТРОКА / БЕЗПЕЧНИЙ РЯДОК ====================

class SecureString(SecurePassword):
    """
    Secure string that is automatically cleared from memory.
    Uses SecurePassword from secure_memory for guaranteed clearing.
    
    Безопасная строка, которая автоматически очищается из памяти.
    Безпечний рядок, який автоматично очищується з пам'яті.
    """

    def __init__(self, value: Union[str, bytes, bytearray] = None):
        super().__init__(value)

    def get(self) -> str:
        """Get the string (clear after use!)
        Получить строку (после использования очистить!)
        Отримати рядок (після використання очистити!)"""
        if self._data is None:
            return ""
        return self._data.decode('utf-8')

    def get_string(self) -> str:
        """Alias for get()
        Алиас для get()
        Аліас для get()"""
        return self.get()

    def __str__(self) -> str:
        return self.get()

    def __repr__(self) -> str:
        return "<SecureString length={}>".format(len(self))


class SecurePasswordContext:
    """
    Context manager for secure password handling.
    
    Usage / Использование / Використання:
        with SecurePasswordContext() as ctx:
            pwd = generator.generate_secure()
            ctx.set_password(pwd)
            # work with password / работа с паролем / робота з паролем
            result = ctx.get()
        # password is automatically cleared here / здесь пароль автоматически очищен / тут пароль автоматично очищено
    """

    def __init__(self):
        self._password: Optional[SecurePassword] = None

    def set_password(self, password: Union[str, SecurePassword]) -> None:
        """Set the password
        Установить пароль
        Встановити пароль"""
        if self._password:
            self._password.clear()
        if isinstance(password, SecurePassword):
            self._password = password
        else:
            self._password = SecurePassword(password)
            _clear_string(password)

    def get(self) -> Optional[str]:
        """Get the password as string (clear after use!)
        Получить пароль как строку (после использования очистить!)
        Отримати пароль як рядок (після використання очистити!)"""
        if self._password is None:
            return None
        return self._password.get_string()

    def get_secure(self) -> Optional[SecurePassword]:
        """Get SecurePassword object
        Получить SecurePassword
        Отримати SecurePassword"""
        return self._password

    def clear(self) -> None:
        """Clear the password
        Очистить пароль
        Очистити пароль"""
        if self._password:
            self._password.clear()
            self._password = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.clear()


# ==================== PASSWORD GENERATOR / ГЕНЕРАТОР ПАРОЛЕЙ / ГЕНЕРАТОР ПАРОЛІВ ====================

class PasswordGenerator:
    """Cryptographically secure password generator with Diceware support
    Криптографически безопасный генератор паролей с поддержкой Diceware
    Криптографічно безпечний генератор паролів з підтримкою Diceware"""

    DEFAULT_SPECIAL = "!@#$%^&*()_+-=[]{}|;:,.<>?/~"
    AMBIGUOUS_CHARS = "il1Lo0O"
    UNAMBIGUOUS_CHARS = "{}[]()/\\'\"`~,;:.<>"

    # Diceware word list (base set of 7776 words, shortened version here)
    # Список слов Diceware (базовый набор из 7776 слов, здесь сокращённая версия)
    # Список слів Diceware (базовий набір з 7776 слів, тут скорочена версія)
    DICEWARE_WORDS = [
        "apple", "banana", "cherry", "dog", "elephant", "flower", "green", "happy",
        "ice", "jungle", "kite", "lemon", "moon", "night", "orange", "purple",
        "queen", "river", "sun", "tree", "umbrella", "volcano", "water", "xray",
        "yellow", "zebra", "cloud", "dream", "energy", "forest", "gold", "heart",
        "idea", "joy", "kind", "light", "magic", "nature", "ocean", "peace",
        "quiet", "rain", "star", "time", "unity", "voice", "wind", "xenon", "youth", "zen",
        "alpha", "beta", "gamma", "delta", "echo", "foxtrot", "golf", "hotel",
        "india", "juliett", "kilo", "lima", "mike", "november", "oscar", "papa",
        "quebec", "romeo", "sierra", "tango", "uniform", "victor", "whiskey", "xray",
        "yankee", "zulu"
    ]

    def __init__(self):
        # Main settings / Основные настройки / Основні налаштування
        self.use_upper = True
        self.use_lower = True
        self.use_digits = True
        self.use_special = False
        self.exclude_ambiguous = False
        self.exclude_unambiguous = False
        self.min_each = False
        self.no_repeat = False
        self.length = 20

        # Diceware settings / Настройки Diceware / Налаштування Diceware
        self.use_diceware = False
        self.diceware_word_count = 4
        self.diceware_separator = "-"
        self.diceware_capitalize = False
        self.diceware_add_number = False

        # Buffer for secure password storage / Буфер для безопасного хранения пароля / Буфер для безпечного зберігання пароля
        self._secure_buffer: Optional[SecurePassword] = None

    def _get_pool(self) -> str:
        """Get character pool based on current settings
        Получить набор символов на основе текущих настроек
        Отримати набір символів на основі поточних налаштувань"""
        pool = ""
        if self.use_lower:
            pool += string.ascii_lowercase
        if self.use_upper:
            pool += string.ascii_uppercase
        if self.use_digits:
            pool += string.digits
        if self.use_special:
            pool += self.DEFAULT_SPECIAL

        if self.exclude_ambiguous:
            for ch in self.AMBIGUOUS_CHARS:
                pool = pool.replace(ch, '')

        if self.exclude_unambiguous:
            for ch in self.UNAMBIGUOUS_CHARS:
                pool = pool.replace(ch, '')

        return pool

    def _get_categories(self) -> List[str]:
        """Get list of character categories for 'min each' mode
        Получить список категорий символов для режима 'минимум 1 из каждой'
        Отримати список категорій символів для режиму 'мінімум 1 з кожної'"""
        categories = []
        if self.use_lower:
            categories.append(string.ascii_lowercase)
        if self.use_upper:
            categories.append(string.ascii_uppercase)
        if self.use_digits:
            categories.append(string.digits)
        if self.use_special:
            categories.append(self.DEFAULT_SPECIAL)

        if self.exclude_ambiguous:
            categories = [''.join(c for c in cat if c not in self.AMBIGUOUS_CHARS) for cat in categories]
        if self.exclude_unambiguous:
            categories = [''.join(c for c in cat if c not in self.UNAMBIGUOUS_CHARS) for cat in categories]

        return [cat for cat in categories if cat]

    def _fix_no_repeats(self, chars: List[str], pool: str) -> Optional[bytearray]:
        """Ensure no consecutive repeated characters, returns bytearray
        Обеспечить отсутствие повторяющихся символов подряд, возвращает bytearray
        Забезпечити відсутність символів, що повторюються підряд, повертає bytearray"""
        result = list(chars)
        unique_pool = list(set(pool))
        max_attempts = 500

        def _secure_shuffle(lst: list) -> None:
            for i in range(len(lst) - 1, 0, -1):
                j = secrets.randbelow(i + 1)
                lst[i], lst[j] = lst[j], lst[i]

        for _ in range(max_attempts):
            _secure_shuffle(result)
            has_repeat = any(result[i] == result[i + 1] for i in range(len(result) - 1))
            if not has_repeat:
                return bytearray("".join(result), 'utf-8')

        result = list(chars)
        _secure_shuffle(result)
        for attempt in range(max_attempts):
            fixed = False
            for i in range(len(result) - 1):
                if result[i] == result[i + 1]:
                    candidates = [c for c in unique_pool if c != result[i] and (i == 0 or c != result[i - 1])]
                    if candidates:
                        result[i + 1] = secrets.choice(candidates)
                        fixed = True
            if not fixed:
                break
            if not any(result[i] == result[i + 1] for i in range(len(result) - 1)):
                return bytearray("".join(result), 'utf-8')
        return None

    def _generate_diceware_secure(self) -> SecurePassword:
        """Generate Diceware passphrase as SecurePassword
        Генерирует Diceware парольную фразу как SecurePassword
        Генерує Diceware парольну фразу як SecurePassword"""
        words = []
        for _ in range(self.diceware_word_count):
            word = secrets.choice(self.DICEWARE_WORDS)
            if self.diceware_capitalize:
                word = word.capitalize()
            words.append(word)

        passphrase = self.diceware_separator.join(words)

        if self.diceware_add_number:
            number = str(secrets.randbelow(100))
            passphrase += self.diceware_separator + number
            _clear_string(number)

        result = SecurePassword(passphrase)

        # Clear temporary strings from memory / Очищаем временные строки из памяти / Очищуємо тимчасові рядки з пам'яті
        _clear_string(passphrase)
        for word in words:
            _clear_string(word)

        return result

    def _get_min_required_length(self) -> int:
        """Calculate minimum required length based on active categories
        Вычисляет минимальную длину на основе активных категорий
        Обчислює мінімальну довжину на основі активних категорій"""
        count = 0
        if self.use_upper:
            count += 1
        if self.use_lower:
            count += 1
        if self.use_digits:
            count += 1
        if self.use_special:
            count += 1

        if self.min_each and count > 0:
            return max(1, count)
        return 1

    def _generate_secure(self) -> Optional[SecurePassword]:
        """
        Generate a password as SecurePassword based on current settings.
        Returns a SecurePassword that will be automatically cleared when deleted.
        
        Генерирует пароль как SecurePassword на основе текущих настроек.
        Возвращает SecurePassword, который автоматически очистится при удалении.
        
        Генерує пароль як SecurePassword на основі поточних налаштувань.
        Повертає SecurePassword, який автоматично очиститься при видаленні.
        """

        # Diceware mode / Режим Diceware / Режим Diceware
        if self.use_diceware:
            return self._generate_diceware_secure()

        # Regular generation / Обычная генерация / Звичайна генерація
        try:
            length = int(self.length)
        except (TypeError, ValueError):
            return None
        if length <= 0:
            return None

        pool = self._get_pool()
        if not pool:
            return None

        min_length = self._get_min_required_length()
        if length < min_length:
            return None

        if self.min_each:
            categories = self._get_categories()
            if not categories or len(categories) < 1:
                categories = [pool]
            if length < len(categories):
                return None

            password_chars = []
            for cat in categories:
                if cat:
                    password_chars.append(secrets.choice(cat))

            remaining = length - len(password_chars)
            if remaining > 0 and pool:
                for _ in range(remaining):
                    password_chars.append(secrets.choice(pool))

            for i in range(len(password_chars) - 1, 0, -1):
                j = secrets.randbelow(i + 1)
                password_chars[i], password_chars[j] = password_chars[j], password_chars[i]

            result_str = "".join(password_chars)
            result = SecurePassword(result_str)
            _clear_string(result_str)
        else:
            if not pool:
                return None
            result_str = ''.join(secrets.choice(pool) for _ in range(length))
            result = SecurePassword(result_str)
            _clear_string(result_str)

        if self.no_repeat:
            fixed = self._fix_no_repeats(list(result.get_string()), pool)
            if not fixed:
                return None
            # Clear old result / Очищаем старый результат / Очищуємо старий результат
            result.clear()
            result = SecurePassword(fixed.decode('utf-8'))
            _secure_zero_bytearray(fixed)

        return result

    def generate(self) -> Optional[str]:
        """
        Generate a password based on current settings.
        CAUTION: Returns a regular Python string.
        After use, call _clear_string() to clear it.
        
        Генерирует пароль на основе текущих настроек.
        ВНИМАНИЕ: Возвращает обычную строку Python.
        После использования вызовите _clear_string() для очистки.
        
        Генерує пароль на основі поточних налаштувань.
        УВАГА: Повертає звичайний рядок Python.
        Після використання викличте _clear_string() для очищення.
        """
        secure_pwd = self._generate_secure()
        if secure_pwd is None:
            return None

        result = secure_pwd.get_string()
        secure_pwd.clear()
        return result

    def generate_secure(self) -> Optional[SecurePassword]:
        """
        Generate a password as SecurePassword.
        Recommended method - use with SecurePasswordContext().
        
        Example / Пример / Приклад:
            with SecurePasswordContext() as ctx:
                pwd = generator.generate_secure()
                ctx.set_password(pwd)
                use_password(ctx.get())
        """
        return self._generate_secure()

    def filter_ambiguous_chars(self, password: str) -> str:
        """
        Filter out ambiguous characters (0, O, 1, l, I)
        Отфильтровать неоднозначные символы
        Відфільтрувати неоднозначні символи
        """
        replacements = {
            '0': 'O',
            'O': 'Q',
            '1': '!',
            'l': 'L',
            'I': '!'
        }

        result = password
        for old, new in replacements.items():
            result = result.replace(old, new)

        return result

    def get_entropy_bits(self, password: str) -> float:
        """
        Calculate entropy bits of a password
        Вычислить энтропию пароля в битах
        Обчислити ентропію пароля в бітах
        """
        if not password:
            return 0.0

        pool_size = 0
        if any(c.islower() for c in password):
            pool_size += 26
        if any(c.isupper() for c in password):
            pool_size += 26
        if any(c.isdigit() for c in password):
            pool_size += 10
        if any(c in string.punctuation for c in password):
            pool_size += 32

        if pool_size == 0:
            return 0.0

        return len(password) * math.log2(pool_size)

    def clear_sensitive_data(self) -> None:
        """Clear all sensitive data from buffers
        Очистить все чувствительные данные из буферов
        Очистити всі чутливі дані з буферів"""
        if self._secure_buffer:
            self._secure_buffer.clear()
            self._secure_buffer = None


class StrengthCalculator:
    """Calculate password strength metrics
    Вычисляет метрики стойкости пароля
    Обчислює метрики стійкості пароля"""

    @staticmethod
    def calculate(password: str) -> Dict[str, Any]:
        """
        Calculate password strength
        Returns dict with: pool_size, combinations, entropy_bits, strength_level, crack_time_label
        
        Вычисляет стойкость пароля
        Возвращает словарь с: pool_size, combinations, entropy_bits, strength_level, crack_time_label
        
        Обчислює стійкість пароля
        Повертає словник з: pool_size, combinations, entropy_bits, strength_level, crack_time_label
        """
        if not password:
            return {
                'pool_size': 0,
                'combinations': 0,
                'entropy_bits': 0,
                'strength_level': 'empty',
                'crack_time_label': ''
            }

        pool_size = 0
        if any(c.islower() for c in password):
            pool_size += 26
        if any(c.isupper() for c in password):
            pool_size += 26
        if any(c.isdigit() for c in password):
            pool_size += 10
        if any(c in string.punctuation for c in password):
            pool_size += 32

        if pool_size == 0:
            pool_size = 1

        # Shannon entropy formula / Формула энтропии Шеннона / Формула ентропії Шеннона
        entropy_bits = len(password) * math.log2(pool_size) if pool_size > 0 else 0
        combinations = pool_size ** len(password) if pool_size > 0 else 0

        # Determine strength level / Определяем уровень сложности / Визначаємо рівень складності
        # NOTE: The actual display strings (Weak, Medium, Strong) are taken from lang.py in the GUI layer
        # ПРИМЕЧАНИЕ: Фактические строки (Слабый, Средний, Надёжный) берутся из lang.py в слое GUI
        # ПРИМІТКА: Фактичні рядки (Слабкий, Середній, Надійний) беруться з lang.py в шарі GUI
        if entropy_bits < 40:
            strength_level = 'weak'
            crack_time_label = 'time_sec'
        elif entropy_bits < 60:
            strength_level = 'medium'
            crack_time_label = 'time_day'
        elif entropy_bits < 80:
            strength_level = 'medium'
            crack_time_label = 'time_year'
        else:
            strength_level = 'strong'
            crack_time_label = 'time_cent'

        return {
            'pool_size': pool_size,
            'combinations': f"{combinations:.1e}" if combinations > 0 else "0",
            'entropy_bits': entropy_bits,
            'strength_level': strength_level,
            'crack_time_label': crack_time_label
        }

    @staticmethod
    def calculate_entropy_bits(password: str) -> float:
        """Calculate entropy bits only
        Вычислить только энтропию в битах
        Обчислити тільки ентропію в бітах"""
        if not password:
            return 0.0

        pool_size = 0
        if any(c.islower() for c in password):
            pool_size += 26
        if any(c.isupper() for c in password):
            pool_size += 26
        if any(c.isdigit() for c in password):
            pool_size += 10
        if any(c in string.punctuation for c in password):
            pool_size += 32

        if pool_size == 0:
            return 0.0

        return len(password) * math.log2(pool_size)