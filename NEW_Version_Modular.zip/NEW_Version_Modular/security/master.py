"""
Master password management with Argon2id and rate limiting

Управление мастер-паролем с Argon2id и ограничением частоты попыток
Керування майстер-паролем з Argon2id та обмеженням частоти спроб
"""
import os
import sys
import ctypes
import hashlib
import hmac
import secrets
import time
import tempfile
import json
import platform
import socket
import uuid
from typing import Optional, Tuple, Dict, Any, List
from datetime import datetime
from dataclasses import dataclass, asdict

# ==================== PORTABLE PATH LOGIC / ПОРТАТИВНАЯ ЛОГИКА ПУТЕЙ / ПОРТАТИВНА ЛОГІКА ШЛЯХІВ ====================
if getattr(sys, 'frozen', False):
    _BASE_DIR = os.path.dirname(sys.executable)
else:
    _BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CONFIG_DIR = os.path.join(_BASE_DIR, "data")
MASTER_FILE = os.path.join(CONFIG_DIR, "master.key")
LOCKOUT_FILE = os.path.join(CONFIG_DIR, "lockout.json")
AUDIT_LOG_FILE = os.path.join(CONFIG_DIR, "auth_audit.json")
PASSWORD_HISTORY_FILE = os.path.join(CONFIG_DIR, "password_history.json")
TRUSTED_DEVICES_FILE = os.path.join(CONFIG_DIR, "trusted_devices.json")
RECOVERY_CODES_FILE = os.path.join(CONFIG_DIR, "recovery_codes.json")
SESSIONS_FILE = os.path.join(CONFIG_DIR, "sessions.json")
# =============================================================

# ==================== LOGGER / ЛОГГЕР / ЛОГЕР ====================
def _get_logger():
    try:
        from utils.logger import get_logger
        return get_logger("master")
    except ImportError:
        import logging
        logger = logging.getLogger("master")
        logger.setLevel(logging.WARNING)
        if not logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
            logger.addHandler(handler)
        return logger

logger = _get_logger()

# ==================== ARGON2 ====================
try:
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError, VerificationError, InvalidHashError
    _ARGON2_OK = True
except ImportError as e:
    PasswordHasher = None
    VerifyMismatchError = VerificationError = InvalidHashError = Exception
    _ARGON2_OK = False
    logger.debug(f"Argon2 not available: {e}")

_ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=4, hash_len=32) if _ARGON2_OK else None

# ==================== CONSTANTS / КОНСТАНТЫ / КОНСТАНТИ ====================
MAX_ATTEMPTS = 5
LOCKOUT_TIMES = {
    1: 0,
    2: 0,
    3: 5,
    4: 10,
    5: 30,
}
PERMANENT_LOCKOUT_AFTER = MAX_ATTEMPTS
AUDIT_LOG_MAX_ENTRIES = 100
AUDIT_LOG_RETENTION_DAYS = 90
PASSWORD_HISTORY_MAX = 5
SESSION_TIMEOUT_HOURS = 24
MAX_TRUSTED_DEVICES = 5
RECOVERY_CODES_COUNT = 10
RECOVERY_CODE_LENGTH = 8


@dataclass
class AuditEvent:
    """Audit event structure / Структура события аудита / Структура події аудиту"""
    event: str
    timestamp: str
    details: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class TrustedDevice:
    """Trusted device structure / Структура доверенного устройства / Структура довіреного пристрою"""
    device_id: str
    device_name: str
    fingerprint: str
    added_at: str
    last_used: str
    ip_address: str
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Session:
    """Session structure / Структура сессии / Структура сесії"""
    session_id: str
    created_at: str
    expires_at: str
    device_id: str
    ip_address: str
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RecoveryCode:
    """Recovery code structure / Структура кода восстановления / Структура коду відновлення"""
    code_hash: str
    created_at: str
    used: bool = False
    used_at: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class MasterPasswordError(Exception):
    pass


class LockoutError(MasterPasswordError):
    pass


class AuditError(MasterPasswordError):
    pass


class SessionError(MasterPasswordError):
    pass


class TrustedDeviceError(MasterPasswordError):
    pass


class RecoveryCodeError(MasterPasswordError):
    pass


def _hide_dir(path: str) -> None:
    """Hide directory on Windows / Скрывает папку на Windows / Ховає папку на Windows"""
    if sys.platform == "win32":
        try:
            ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
        except (AttributeError, OSError, TypeError) as e:
            logger.debug(f"Hide dir failed: {e}")


def _secure_write(path: str, data: bytes) -> None:
    """Secure atomic write / Безопасная атомарная запись / Безпечний атомарний запис"""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(prefix=".tmp-", dir=os.path.dirname(path))
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, path)
            if sys.platform == "win32":
                try:
                    ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
                except (AttributeError, OSError, TypeError):
                    pass
            else:
                try:
                    os.chmod(path, 0o600)
                except (PermissionError, OSError):
                    pass
        except (PermissionError, OSError, IOError) as e:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise IOError(f"Cannot write to {path}: {e}")
    except (OSError, IOError, PermissionError) as e:
        raise IOError(f"Cannot create directory for {path}: {e}")


def _secure_read(path: str) -> Optional[bytes]:
    """Secure read / Безопасное чтение / Безпечне читання"""
    try:
        if not os.path.exists(path):
            return None
        with open(path, 'rb') as f:
            return f.read()
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Failed to read {path}: {e}")
        return None


def _get_device_fingerprint() -> str:
    """Get unique device fingerprint for trusted device tracking
    Получить уникальный отпечаток устройства для отслеживания доверенных устройств
    Отримати унікальний відбиток пристрою для відстеження довірених пристроїв"""
    try:
        # Combine multiple identifiers for unique fingerprint
        # Комбинируем несколько идентификаторов для уникального отпечатка
        # Комбінуємо кілька ідентифікаторів для унікального відбитка
        identifiers = [
            platform.node(),  # Hostname / Имя хоста / Ім'я хоста
            platform.machine(),  # Machine type / Тип машини / Тип машини
            platform.processor(),  # Processor / Процессор / Процесор
            str(uuid.getnode()),  # MAC address / MAC-адрес / MAC-адреса
            sys.platform,  # Platform / Платформа / Платформа
        ]
        
        # Filter None values / Фильтруем None значения / Фільтруємо None значення
        identifiers = [str(i) for i in identifiers if i]
        
        fingerprint_string = "|".join(identifiers)
        return hashlib.sha256(fingerprint_string.encode('utf-8')).hexdigest()[:32]
    except (OSError, ValueError, TypeError, AttributeError) as e:
        logger.debug(f"Device fingerprint error: {e}")
        # Fallback to random UUID / Fallback к случайному UUID / Fallback до випадкового UUID
        return hashlib.sha256(str(uuid.uuid4()).encode('utf-8')).hexdigest()[:32]


def _get_ip_address() -> str:
    """Get local IP address / Получить локальный IP-адрес / Отримати локальну IP-адресу"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except (socket.error, OSError, AttributeError) as e:
        logger.debug(f"IP address detection error: {e}")
        return "unknown"


def _save_lockout_state() -> None:
    """Save lockout state / Сохраняет состояние блокировки / Зберігає стан блокування"""
    try:
        state = {
            "attempt_count": MasterPassword._attempt_count,
            "last_attempt_time": MasterPassword._last_attempt_time,
            "lockout_until": MasterPassword._lockout_until,
            "is_permanently_locked": MasterPassword._is_permanently_locked,
            "last_update": datetime.now().isoformat()
        }
        _secure_write(LOCKOUT_FILE, json.dumps(state, indent=2).encode('utf-8'))
    except (OSError, IOError, PermissionError, TypeError) as e:
        logger.debug(f"Failed to save lockout state: {e}")


def _load_lockout_state() -> None:
    """Load lockout state / Загружает состояние блокировки / Завантажує стан блокування"""
    if not os.path.exists(LOCKOUT_FILE):
        return
    
    try:
        content = _secure_read(LOCKOUT_FILE)
        if content:
            state = json.loads(content.decode('utf-8'))
        
            MasterPassword._attempt_count = state.get("attempt_count", 0)
            MasterPassword._last_attempt_time = state.get("last_attempt_time", 0)
            MasterPassword._lockout_until = state.get("lockout_until", 0)
            MasterPassword._is_permanently_locked = state.get("is_permanently_locked", False)
            
            if MasterPassword._lockout_until > 0 and MasterPassword._lockout_until <= time.time():
                MasterPassword._reset_attempts()
            
            logger.debug("Lockout state loaded")
    except (json.JSONDecodeError, OSError, IOError, KeyError, UnicodeDecodeError) as e:
        logger.debug(f"Failed to load lockout state: {e}")


def _save_audit_log() -> None:
    """Save audit log / Сохраняет журнал аудита / Зберігає журнал аудиту"""
    try:
        MasterPassword._cleanup_audit_log()
        
        audit_data = {
            "entries": [e.to_dict() if hasattr(e, 'to_dict') else e for e in MasterPassword._audit_log],
            "last_update": datetime.now().isoformat(),
            "version": 3
        }
        _secure_write(AUDIT_LOG_FILE, json.dumps(audit_data, indent=2).encode('utf-8'))
    except (OSError, IOError, PermissionError, TypeError) as e:
        logger.debug(f"Failed to save audit log: {e}")


def _load_audit_log() -> None:
    """Load audit log / Загружает журнал аудита / Завантажує журнал аудиту"""
    if not os.path.exists(AUDIT_LOG_FILE):
        return
    
    try:
        content = _secure_read(AUDIT_LOG_FILE)
        if content:
            audit_data = json.loads(content.decode('utf-8'))
            entries = audit_data.get("entries", [])
            if isinstance(entries, list):
                MasterPassword._audit_log = entries[-AUDIT_LOG_MAX_ENTRIES:]
            logger.debug(f"Loaded {len(MasterPassword._audit_log)} audit entries")
    except (json.JSONDecodeError, OSError, IOError, UnicodeDecodeError, KeyError) as e:
        logger.debug(f"Failed to load audit log: {e}")


def _save_password_history() -> None:
    """Save password history / Сохраняет историю паролей / Зберігає історію паролів"""
    try:
        history_data = {
            "entries": MasterPassword._password_history,
            "last_update": datetime.now().isoformat(),
            "max_entries": PASSWORD_HISTORY_MAX
        }
        _secure_write(PASSWORD_HISTORY_FILE, json.dumps(history_data, indent=2).encode('utf-8'))
    except (OSError, IOError, PermissionError, TypeError) as e:
        logger.debug(f"Failed to save password history: {e}")


def _load_password_history() -> None:
    """Load password history / Загружает историю паролей / Завантажує історію паролів"""
    if not os.path.exists(PASSWORD_HISTORY_FILE):
        return
    
    try:
        content = _secure_read(PASSWORD_HISTORY_FILE)
        if content:
            history_data = json.loads(content.decode('utf-8'))
            entries = history_data.get("entries", [])
            if isinstance(entries, list):
                MasterPassword._password_history = entries[-PASSWORD_HISTORY_MAX:]
            logger.debug(f"Loaded {len(MasterPassword._password_history)} password history entries")
    except (json.JSONDecodeError, OSError, IOError, UnicodeDecodeError, KeyError) as e:
        logger.debug(f"Failed to load password history: {e}")


def _save_trusted_devices() -> None:
    """Save trusted devices / Сохраняет доверенные устройства / Зберігає довірені пристрої"""
    try:
        devices_data = {
            "devices": [d.to_dict() if hasattr(d, 'to_dict') else d for d in MasterPassword._trusted_devices],
            "last_update": datetime.now().isoformat()
        }
        _secure_write(TRUSTED_DEVICES_FILE, json.dumps(devices_data, indent=2).encode('utf-8'))
    except (OSError, IOError, PermissionError, TypeError) as e:
        logger.debug(f"Failed to save trusted devices: {e}")


def _load_trusted_devices() -> None:
    """Load trusted devices / Загружает доверенные устройства / Завантажує довірені пристрої"""
    if not os.path.exists(TRUSTED_DEVICES_FILE):
        return
    
    try:
        content = _secure_read(TRUSTED_DEVICES_FILE)
        if content:
            devices_data = json.loads(content.decode('utf-8'))
            devices = devices_data.get("devices", [])
            if isinstance(devices, list):
                MasterPassword._trusted_devices = devices
            logger.debug(f"Loaded {len(MasterPassword._trusted_devices)} trusted devices")
    except (json.JSONDecodeError, OSError, IOError, UnicodeDecodeError, KeyError) as e:
        logger.debug(f"Failed to load trusted devices: {e}")


def _save_recovery_codes() -> None:
    """Save recovery codes / Сохраняет коды восстановления / Зберігає коди відновлення"""
    try:
        codes_data = {
            "codes": [c.to_dict() if hasattr(c, 'to_dict') else c for c in MasterPassword._recovery_codes],
            "last_update": datetime.now().isoformat()
        }
        _secure_write(RECOVERY_CODES_FILE, json.dumps(codes_data, indent=2).encode('utf-8'))
    except (OSError, IOError, PermissionError, TypeError) as e:
        logger.debug(f"Failed to save recovery codes: {e}")


def _load_recovery_codes() -> None:
    """Load recovery codes / Загружает коды восстановления / Завантажує коди відновлення"""
    if not os.path.exists(RECOVERY_CODES_FILE):
        return
    
    try:
        content = _secure_read(RECOVERY_CODES_FILE)
        if content:
            codes_data = json.loads(content.decode('utf-8'))
            codes = codes_data.get("codes", [])
            if isinstance(codes, list):
                MasterPassword._recovery_codes = codes
            logger.debug(f"Loaded {len(MasterPassword._recovery_codes)} recovery codes")
    except (json.JSONDecodeError, OSError, IOError, UnicodeDecodeError, KeyError) as e:
        logger.debug(f"Failed to load recovery codes: {e}")


def _save_sessions() -> None:
    """Save active sessions / Сохраняет активные сессии / Зберігає активні сесії"""
    try:
        sessions_data = {
            "sessions": [s.to_dict() if hasattr(s, 'to_dict') else s for s in MasterPassword._sessions],
            "last_update": datetime.now().isoformat()
        }
        _secure_write(SESSIONS_FILE, json.dumps(sessions_data, indent=2).encode('utf-8'))
    except (OSError, IOError, PermissionError, TypeError) as e:
        logger.debug(f"Failed to save sessions: {e}")


def _load_sessions() -> None:
    """Load active sessions / Загружает активные сессии / Завантажує активні сесії"""
    if not os.path.exists(SESSIONS_FILE):
        return
    
    try:
        content = _secure_read(SESSIONS_FILE)
        if content:
            sessions_data = json.loads(content.decode('utf-8'))
            sessions = sessions_data.get("sessions", [])
            if isinstance(sessions, list):
                MasterPassword._sessions = sessions
                # Clean expired sessions / Очищаем просроченные сессии / Очищуємо прострочені сесії
                MasterPassword._cleanup_expired_sessions()
            logger.debug(f"Loaded {len(MasterPassword._sessions)} sessions")
    except (json.JSONDecodeError, OSError, IOError, UnicodeDecodeError, KeyError) as e:
        logger.debug(f"Failed to load sessions: {e}")


class MasterPassword:
    MAX_ATTEMPTS = MAX_ATTEMPTS
    SALT_SIZE = 32
    PBKDF2_ITERATIONS = 600000
    USE_ARGON2 = _ARGON2_OK
    
    _attempt_count = 0
    _last_attempt_time = 0
    _lockout_until = 0
    _is_permanently_locked = False
    _audit_log: List[Dict[str, Any]] = []
    
    _cached_config = None
    _skip_2fa_once = False
    _trusted_devices: List[Dict[str, Any]] = []
    _recovery_codes: List[Dict[str, Any]] = []
    _sessions: List[Dict[str, Any]] = []
    _current_session_id: Optional[str] = None
    
    # Password history / История паролей / Історія паролів
    _password_history: List[str] = []
    _password_history_max = PASSWORD_HISTORY_MAX

    @classmethod
    def _get_lockout_delay(cls, attempts: int) -> int:
        return LOCKOUT_TIMES.get(attempts, LOCKOUT_TIMES[MAX_ATTEMPTS])
    
    @classmethod
    def _apply_rate_limit(cls) -> Tuple[bool, int]:
        current_time = time.time()
        
        if cls._is_permanently_locked:
            return False, -1
        
        if cls._lockout_until > current_time:
            return False, int(cls._lockout_until - current_time)
        
        if current_time - cls._last_attempt_time > 1800:
            cls._attempt_count = 0
            cls._lockout_until = 0
            _save_lockout_state()
        
        return True, 0
    
    @classmethod
    def _record_failed_attempt(cls, source: str = "unknown") -> int:
        cls._attempt_count += 1
        cls._last_attempt_time = time.time()
        
        cls._log_audit_event("failed_attempt", {
            "attempts": cls._attempt_count,
            "source": source,
            "timestamp": datetime.now().isoformat(),
            "device_fingerprint": _get_device_fingerprint(),
            "ip_address": _get_ip_address()
        })
        
        if cls._attempt_count >= PERMANENT_LOCKOUT_AFTER:
            cls._is_permanently_locked = True
            _save_lockout_state()
            logger.warning(f"Permanent lockout triggered after {cls._attempt_count} attempts")
            return -1
        
        delay = cls._get_lockout_delay(cls._attempt_count)
        if delay > 0:
            cls._lockout_until = cls._last_attempt_time + delay
            logger.warning(f"Lockout for {delay} seconds after {cls._attempt_count} attempts")
        
        _save_lockout_state()
        return delay
    
    @classmethod
    def _reset_attempts(cls) -> None:
        cls._attempt_count = 0
        cls._lockout_until = 0
        cls._is_permanently_locked = False
        cls._last_attempt_time = 0
        _save_lockout_state()
        logger.debug("Attempts reset")
    
    @classmethod
    def _cleanup_audit_log(cls) -> None:
        try:
            current_time = datetime.now()
            cutoff_time = current_time.timestamp() - (AUDIT_LOG_RETENTION_DAYS * 24 * 3600)
            
            filtered_log = []
            for entry in cls._audit_log:
                try:
                    entry_time = datetime.fromisoformat(entry.get("timestamp", "2000-01-01T00:00:00")).timestamp()
                    if entry_time > cutoff_time:
                        filtered_log.append(entry)
                except (ValueError, TypeError):
                    filtered_log.append(entry)
            
            if len(filtered_log) > AUDIT_LOG_MAX_ENTRIES:
                filtered_log = filtered_log[-AUDIT_LOG_MAX_ENTRIES:]
            
            cls._audit_log = filtered_log
        except (ValueError, TypeError, OSError) as e:
            logger.debug(f"Audit log cleanup error: {e}")
    
    @classmethod
    def _cleanup_expired_sessions(cls) -> None:
        """Clean up expired sessions / Очищает просроченные сессии / Очищує прострочені сесії"""
        try:
            current_time = datetime.now().timestamp()
            active_sessions = []
            
            for session in cls._sessions:
                try:
                    expires_at = datetime.fromisoformat(session.get("expires_at", "2000-01-01T00:00:00")).timestamp()
                    if expires_at > current_time:
                        active_sessions.append(session)
                except (ValueError, TypeError):
                    active_sessions.append(session)
            
            if len(active_sessions) != len(cls._sessions):
                cls._sessions = active_sessions
                _save_sessions()
                logger.debug(f"Cleaned up {len(cls._sessions) - len(active_sessions)} expired sessions")
        except (ValueError, TypeError, OSError) as e:
            logger.debug(f"Session cleanup error: {e}")
    
    @classmethod
    def _log_audit_event(cls, event_type: str, details: Dict[str, Any]) -> None:
        try:
            event = {
                "event": event_type,
                "timestamp": datetime.now().isoformat(),
                "details": details.copy() if details else {}
            }
            cls._audit_log.append(event)
            
            if len(cls._audit_log) > AUDIT_LOG_MAX_ENTRIES:
                cls._audit_log = cls._audit_log[-AUDIT_LOG_MAX_ENTRIES:]
            
            try:
                _save_audit_log()
            except (OSError, IOError, PermissionError) as e:
                logger.debug(f"Audit log save error: {e}")
        except (TypeError, ValueError, KeyError) as e:
            logger.debug(f"Audit logging error: {e}")
    
    @classmethod
    def get_remaining_lockout_time(cls) -> int:
        if cls._is_permanently_locked:
            return -1
        if cls._lockout_until <= time.time():
            return 0
        return int(cls._lockout_until - time.time())
    
    @classmethod
    def get_attempts_remaining(cls) -> int:
        if cls._is_permanently_locked:
            return 0
        if cls._attempt_count >= MAX_ATTEMPTS:
            return 0
        return MAX_ATTEMPTS - cls._attempt_count
    
    @classmethod
    def is_permanently_locked(cls) -> bool:
        return cls._is_permanently_locked
    
    @classmethod
    def get_lockout_info(cls) -> dict:
        remaining = cls.get_remaining_lockout_time()
        return {
            'attempts': cls._attempt_count,
            'max_attempts': MAX_ATTEMPTS,
            'remaining_attempts': cls.get_attempts_remaining(),
            'lockout_seconds': remaining if remaining > 0 else 0,
            'is_locked': remaining > 0,
            'is_permanently_locked': cls._is_permanently_locked
        }
    
    @classmethod
    def get_audit_log(cls) -> List[Dict[str, Any]]:
        return cls._audit_log.copy()
    
    @classmethod
    def clear_audit_log(cls) -> bool:
        try:
            cls._audit_log = []
            _save_audit_log()
            logger.info("Audit log cleared")
            return True
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to clear audit log: {e}")
            return False
    
    @classmethod
    def reset_lockout(cls) -> bool:
        if not cls.is_permanently_locked() and cls.get_remaining_lockout_time() == 0:
            return True
        
        cls._reset_attempts()
        cls._log_audit_event("lockout_reset", {"source": "admin"})
        logger.info("Lockout state reset")
        return True

    @classmethod
    def _derive_key_pbkdf2(cls, password: bytes, salt: bytes) -> bytes:
        return hashlib.pbkdf2_hmac('sha256', password, salt, cls.PBKDF2_ITERATIONS, dklen=32)

    @classmethod
    def _hash_argon2(cls, password: str) -> str:
        if not _ARGON2_OK or _ph is None:
            raise RuntimeError("Argon2 is not available")
        try:
            return _ph.hash(password)
        except (ValueError, TypeError, RuntimeError) as e:
            logger.error(f"Argon2 hash error: {e}")
            raise RuntimeError(f"Failed to hash password: {e}")

    @classmethod
    def _verify_argon2(cls, password: str, stored_hash: str) -> bool:
        try:
            if not _ARGON2_OK or _ph is None:
                return False
            _ph.verify(stored_hash, password)
            if _ph.check_needs_rehash(stored_hash):
                logger.debug("Password hash needs rehash")
            return True
        except (VerifyMismatchError, VerificationError, InvalidHashError, TypeError, ValueError) as e:
            logger.debug(f"Argon2 verification failed: {type(e).__name__}")
            return False

    @classmethod
    def is_set(cls) -> bool:
        return os.path.exists(MASTER_FILE)

    @classmethod
    def verify(cls, password: str, record_attempt: bool = True, source: str = "unknown") -> bool:
        is_allowed, remaining = cls._apply_rate_limit()
        if not is_allowed:
            logger.warning(f"Rate limit applied, locked for {remaining} seconds")
            return False
        
        if not cls.is_set():
            if record_attempt:
                cls._reset_attempts()
            return True
        
        try:
            content = _secure_read(MASTER_FILE)
            if content is None:
                logger.error("Failed to read master file")
                if record_attempt:
                    cls._record_failed_attempt(source)
                return False
            
            version = content[:1]
            rest = content[1:]
            
            if version == b'\x02':
                stored_hash = rest.decode('utf-8')
                result = cls._verify_argon2(password, stored_hash)
            elif version == b'\x01':
                if len(rest) < cls.SALT_SIZE + 32:
                    logger.error("Invalid master file format")
                    if record_attempt:
                        cls._record_failed_attempt(source)
                    return False
                salt = rest[:cls.SALT_SIZE]
                stored_hash = rest[cls.SALT_SIZE:]
                if len(salt) != cls.SALT_SIZE or len(stored_hash) != 32:
                    logger.error("Invalid salt or hash length")
                    if record_attempt:
                        cls._record_failed_attempt(source)
                    return False
                derived = cls._derive_key_pbkdf2(password.encode('utf-8'), salt)
                result = hmac.compare_digest(derived, stored_hash)
            else:
                logger.error(f"Unknown master file version: {version}")
                if record_attempt:
                    cls._record_failed_attempt(source)
                return False
        except (OSError, IOError, PermissionError, UnicodeDecodeError, ValueError, TypeError) as e:
            logger.error(f"Error reading master file: {e}")
            if record_attempt:
                cls._record_failed_attempt(source)
            return False
        
        if result:
            if record_attempt:
                cls._reset_attempts()
                cls._log_audit_event("successful_auth", {
                    "source": source,
                    "device_fingerprint": _get_device_fingerprint(),
                    "ip_address": _get_ip_address()
                })
                # Create session on successful auth / Создаём сессию при успешной аутентификации / Створюємо сесію при успішній аутентифікації
                cls._create_session(source)
        else:
            if record_attempt:
                cls._record_failed_attempt(source)
        
        return result
    
    @classmethod
    def _create_session(cls, source: str) -> Optional[str]:
        """Create new session for successful authentication
        Создать новую сессию для успешной аутентификации
        Створити нову сесію для успішної аутентифікації"""
        try:
            session_id = secrets.token_hex(32)
            now = datetime.now()
            expires_at = now.timestamp() + (SESSION_TIMEOUT_HOURS * 3600)
            
            session = Session(
                session_id=session_id,
                created_at=now.isoformat(),
                expires_at=datetime.fromtimestamp(expires_at).isoformat(),
                device_id=_get_device_fingerprint(),
                ip_address=_get_ip_address()
            )
            
            cls._sessions.append(session.to_dict())
            cls._current_session_id = session_id
            _save_sessions()
            
            logger.debug(f"Session created: {session_id[:16]}...")
            return session_id
        except (ValueError, TypeError, OSError) as e:
            logger.debug(f"Session creation error: {e}")
            return None
    
    @classmethod
    def validate_session(cls, session_id: str) -> bool:
        """Validate if session is still active
        Проверить, активна ли сессия
        Перевірити, чи активна сесія"""
        try:
            cls._cleanup_expired_sessions()
            for session in cls._sessions:
                if session.get("session_id") == session_id:
                    expires_at = datetime.fromisoformat(session.get("expires_at", "2000-01-01T00:00:00")).timestamp()
                    if expires_at > time.time():
                        return True
            return False
        except (ValueError, TypeError, KeyError) as e:
            logger.debug(f"Session validation error: {e}")
            return False
    
    @classmethod
    def end_session(cls, session_id: Optional[str] = None) -> bool:
        """End a session / Завершить сессию / Завершити сесію"""
        try:
            if session_id is None:
                session_id = cls._current_session_id
            
            cls._sessions = [s for s in cls._sessions if s.get("session_id") != session_id]
            if session_id == cls._current_session_id:
                cls._current_session_id = None
            _save_sessions()
            logger.debug(f"Session ended: {session_id[:16] if session_id else 'None'}...")
            return True
        except (ValueError, TypeError, OSError) as e:
            logger.debug(f"Session end error: {e}")
            return False
    
    @classmethod
    def end_all_sessions(cls) -> int:
        """End all active sessions / Завершить все активные сессии / Завершити всі активні сесії"""
        count = len(cls._sessions)
        cls._sessions = []
        cls._current_session_id = None
        _save_sessions()
        logger.info(f"Ended {count} sessions")
        return count

    @classmethod
    def set_password(cls, password: str) -> None:
        if not password:
            raise MasterPasswordError("Master password must not be empty")
        
        if len(password) < 8:
            raise MasterPasswordError("Password too short. Minimum 8 characters.")
        
        import re
        if not re.search(r"[0-9!@#$%^&*()_+=\[\]{};:,.<>/?@%-]", password):
            raise MasterPasswordError("Password too weak. Add a digit or special character.")

        try:
            os.makedirs(CONFIG_DIR, exist_ok=True)
            _hide_dir(CONFIG_DIR)
        except (PermissionError, OSError, IOError) as e:
            raise MasterPasswordError(f"Cannot create config directory: {e}")

        # Check password reuse / Проверка повторного использования пароля / Перевірка повторного використання пароля
        password_hash = cls._hash_password_for_history(password)
        if cls.is_password_reused(password_hash):
            raise MasterPasswordError("Password was used before. Please choose a different password.")

        try:
            if cls.USE_ARGON2:
                hashed = cls._hash_argon2(password)
                _secure_write(MASTER_FILE, b'\x02' + hashed.encode('utf-8'))
            else:
                salt = secrets.token_bytes(cls.SALT_SIZE)
                derived = cls._derive_key_pbkdf2(password.encode('utf-8'), salt)
                _secure_write(MASTER_FILE, b'\x01' + salt + derived)
        except (ValueError, TypeError, RuntimeError, OSError, IOError) as e:
            raise MasterPasswordError(f"Failed to set password: {e}")
        
        cls._reset_attempts()
        cls._log_audit_event("password_set", {"method": "Argon2id" if cls.USE_ARGON2 else "PBKDF2"})
        
        # Add to password history / Добавляем в историю паролей / Додаємо в історію паролів
        cls.add_to_history(password_hash)
    
    @classmethod
    def _hash_password_for_history(cls, password: str) -> str:
        """Hash password for history storage (not for verification!)
        Хеширует пароль для хранения в истории (не для верификации!)
        Хешує пароль для зберігання в історії (не для верифікації!)"""
        salt = b"securepasspro_history_salt"
        return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 10000, dklen=32).hex()

    @classmethod
    def add_to_history(cls, password_hash: str) -> None:
        """Add password hash to history / Добавляет хеш пароля в историю / Додає хеш пароля в історію"""
        try:
            cls._password_history.append(password_hash)
            if len(cls._password_history) > cls._password_history_max:
                cls._password_history = cls._password_history[-cls._password_history_max:]
            _save_password_history()
        except (TypeError, ValueError, OSError) as e:
            logger.debug(f"Failed to add to history: {e}")
    
    @classmethod
    def is_password_reused(cls, password_hash: str) -> bool:
        """Check if password was used before / Проверяет, использовался ли пароль ранее / Перевіряє, чи використовувався пароль раніше"""
        return password_hash in cls._password_history
    
    @classmethod
    def clear_history(cls) -> None:
        """Clear password history / Очищает историю паролей / Очищує історію паролів"""
        cls._password_history = []
        _save_password_history()
        logger.debug("Password history cleared")

    @classmethod
    def get_trusted_devices(cls) -> List[Dict[str, Any]]:
        """Get list of trusted devices / Получить список доверенных устройств / Отримати список довірених пристроїв"""
        return cls._trusted_devices.copy()
    
    @classmethod
    def add_trusted_device(cls, device_name: str) -> bool:
        """Add current device as trusted / Добавить текущее устройство как доверенное / Додати поточний пристрій як довірений"""
        try:
            if len(cls._trusted_devices) >= MAX_TRUSTED_DEVICES:
                logger.warning(f"Maximum trusted devices reached ({MAX_TRUSTED_DEVICES})")
                return False
            
            device = TrustedDevice(
                device_id=_get_device_fingerprint(),
                device_name=device_name,
                fingerprint=_get_device_fingerprint(),
                added_at=datetime.now().isoformat(),
                last_used=datetime.now().isoformat(),
                ip_address=_get_ip_address()
            )
            
            cls._trusted_devices.append(device.to_dict())
            _save_trusted_devices()
            logger.info(f"Trusted device added: {device_name}")
            return True
        except (ValueError, TypeError, OSError) as e:
            logger.error(f"Failed to add trusted device: {e}")
            return False
    
    @classmethod
    def remove_trusted_device(cls, device_id: str) -> bool:
        """Remove trusted device / Удалить доверенное устройство / Видалити довірений пристрій"""
        try:
            original_count = len(cls._trusted_devices)
            cls._trusted_devices = [d for d in cls._trusted_devices if d.get("device_id") != device_id]
            if len(cls._trusted_devices) < original_count:
                _save_trusted_devices()
                logger.info(f"Trusted device removed: {device_id[:16]}...")
                return True
            return False
        except (ValueError, TypeError, OSError) as e:
            logger.error(f"Failed to remove trusted device: {e}")
            return False
    
    @classmethod
    def is_device_trusted(cls) -> bool:
        """Check if current device is trusted / Проверить, доверено ли текущее устройство / Перевірити, чи довірено поточний пристрій"""
        current_fingerprint = _get_device_fingerprint()
        for device in cls._trusted_devices:
            if device.get("fingerprint") == current_fingerprint:
                # Update last used / Обновляем время последнего использования / Оновлюємо час останнього використання
                device["last_used"] = datetime.now().isoformat()
                _save_trusted_devices()
                return True
        return False

    @classmethod
    def generate_recovery_codes(cls, count: int = RECOVERY_CODES_COUNT) -> List[str]:
        """Generate new recovery codes / Генерирует новые коды восстановления / Генерує нові коди відновлення"""
        try:
            codes = []
            for _ in range(count):
                code = ''.join(str(secrets.randbelow(10)) for _ in range(RECOVERY_CODE_LENGTH))
                code_formatted = f"{code[:4]}-{code[4:]}" if RECOVERY_CODE_LENGTH == 8 else code
                
                recovery_code = RecoveryCode(
                    code_hash=hashlib.sha256(code.encode('utf-8')).hexdigest(),
                    created_at=datetime.now().isoformat(),
                    used=False
                )
                codes.append(code_formatted)
                cls._recovery_codes.append(recovery_code.to_dict())
            
            _save_recovery_codes()
            logger.info(f"Generated {count} recovery codes")
            return codes
        except (ValueError, TypeError, OSError) as e:
            logger.error(f"Failed to generate recovery codes: {e}")
            return []
    
    @classmethod
    def verify_recovery_code(cls, code: str) -> bool:
        """Verify and consume a recovery code / Проверить и использовать код восстановления / Перевірити та використати код відновлення"""
        try:
            code_clean = code.replace("-", "").replace(" ", "")
            code_hash = hashlib.sha256(code_clean.encode('utf-8')).hexdigest()
            
            for i, rc in enumerate(cls._recovery_codes):
                if rc.get("code_hash") == code_hash and not rc.get("used", False):
                    rc["used"] = True
                    rc["used_at"] = datetime.now().isoformat()
                    _save_recovery_codes()
                    logger.info("Recovery code used successfully")
                    return True
            
            logger.warning("Invalid or already used recovery code")
            return False
        except (ValueError, TypeError, OSError) as e:
            logger.error(f"Recovery code verification error: {e}")
            return False
    
    @classmethod
    def get_recovery_codes_status(cls) -> Dict[str, Any]:
        """Get recovery codes status / Получить статус кодов восстановления / Отримати статус кодів відновлення"""
        total = len(cls._recovery_codes)
        used = sum(1 for rc in cls._recovery_codes if rc.get("used", False))
        return {
            "total": total,
            "used": used,
            "available": total - used,
            "max_codes": RECOVERY_CODES_COUNT
        }
    
    @classmethod
    def get_sessions(cls) -> List[Dict[str, Any]]:
        """Get active sessions / Получить активные сессии / Отримати активні сесії"""
        cls._cleanup_expired_sessions()
        return cls._sessions.copy()
    
    @classmethod
    def get_current_session_id(cls) -> Optional[str]:
        """Get current session ID / Получить ID текущей сессии / Отримати ID поточної сесії"""
        return cls._current_session_id

    @classmethod
    def remove(cls) -> None:
        """Remove master password and all related data
        Удаляет мастер-пароль и все связанные данные
        Видаляє майстер-пароль та всі пов'язані дані"""
        
        # 1. Delete master password file / Удаляем файл мастер-пароля / Видаляємо файл майстер-пароля
        try:
            if os.path.exists(MASTER_FILE):
                os.remove(MASTER_FILE)
                logger.info("Master password file removed")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to remove master file: {e}")
        
        # 2. Delete lockout file / Удаляем файл блокировки / Видаляємо файл блокування
        try:
            if os.path.exists(LOCKOUT_FILE):
                os.remove(LOCKOUT_FILE)
                logger.info("Lockout file removed")
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"Failed to remove lockout file: {e}")
        
        # 3. Delete audit file / Удаляем файл аудита / Видаляємо файл аудиту
        try:
            if os.path.exists(AUDIT_LOG_FILE):
                os.remove(AUDIT_LOG_FILE)
                logger.info("Audit log file removed")
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"Failed to remove audit log file: {e}")
        
        # 4. Delete password history / Удаляем историю паролей / Видаляємо історію паролів
        try:
            if os.path.exists(PASSWORD_HISTORY_FILE):
                os.remove(PASSWORD_HISTORY_FILE)
                logger.info("Password history file removed")
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"Failed to remove password history: {e}")
        
        # 5. Delete trusted devices / Удаляем доверенные устройства / Видаляємо довірені пристрої
        try:
            if os.path.exists(TRUSTED_DEVICES_FILE):
                os.remove(TRUSTED_DEVICES_FILE)
                logger.info("Trusted devices file removed")
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"Failed to remove trusted devices: {e}")
        
        # 6. Delete recovery codes / Удаляем коды восстановления / Видаляємо коди відновлення
        try:
            if os.path.exists(RECOVERY_CODES_FILE):
                os.remove(RECOVERY_CODES_FILE)
                logger.info("Recovery codes file removed")
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"Failed to remove recovery codes: {e}")
        
        # 7. Delete sessions / Удаляем сессии / Видаляємо сесії
        try:
            if os.path.exists(SESSIONS_FILE):
                os.remove(SESSIONS_FILE)
                logger.info("Sessions file removed")
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"Failed to remove sessions: {e}")
        
        # 8. Reset state in memory / Сбрасываем состояние в памяти / Скидаємо стан у пам'яті
        cls._attempt_count = 0
        cls._lockout_until = 0
        cls._is_permanently_locked = False
        cls._last_attempt_time = 0
        cls._audit_log = []
        cls._password_history = []
        cls._trusted_devices = []
        cls._recovery_codes = []
        cls._sessions = []
        cls._current_session_id = None
        
        # 9. Log the event / Логируем событие / Логуємо подію
        cls._log_audit_event("password_removed", {})
        
        # 10. Disable 2FA / Отключаем 2FA / Вимкаємо 2FA
        try:
            if cls._cached_config:
                cls._cached_config.set_2fa_enabled(False)
                cls._cached_config.set_2fa_secret("")
                cls._cached_config.set_2fa_backup_hashes([])
                cls._cached_config.set_2fa_setup_completed(False)
                cls._cached_config.save()
                logger.info("2FA disabled in config")
        except (AttributeError, OSError, TypeError) as e:
            logger.debug(f"Error disabling 2FA: {e}")
        
        # 11. Disable 2FA via TOTP manager / Отключаем 2FA через TOTP менеджер / Вимкаємо 2FA через TOTP менеджер
        try:
            from security.totp import get_totp_manager
            manager = get_totp_manager()
            manager.disable_2fa()
            logger.info("2FA disabled via TOTP")
        except (ImportError, AttributeError, RuntimeError) as e:
            logger.debug(f"TOTP disable error: {e}")
        
        logger.info("Master password removed successfully")

    @classmethod
    def change_password(cls, old_password: str, new_password: str) -> bool:
        if not cls.verify(old_password, source="password_change"):
            logger.warning("Password change failed: invalid old password")
            cls._log_audit_event("failed_attempt", {"source": "password_change", "reason": "invalid_old"})
            return False
        
        if len(new_password) < 8:
            logger.warning("Password change failed: new password too short")
            return False
        
        # Check password reuse / Проверка повторного использования / Перевірка повторного використання
        new_hash = cls._hash_password_for_history(new_password)
        if cls.is_password_reused(new_hash):
            logger.warning("Password change failed: password reuse detected")
            cls._log_audit_event("failed_attempt", {"source": "password_change", "reason": "password_reuse"})
            return False
        
        try:
            cls.set_password(new_password)
            logger.info("Password changed successfully")
            cls._log_audit_event("password_changed", {})
            return True
        except MasterPasswordError as e:
            logger.error(f"Password change error: {e}")
            return False

    # ==================== 2FA METHODS / МЕТОДЫ 2FA / МЕТОДИ 2FA ====================
    
    @classmethod
    def set_config(cls, config) -> None:
        cls._cached_config = config
        # Load additional data from files / Загружаем дополнительные данные из файлов / Завантажуємо додаткові дані з файлів
        _load_password_history()
        _load_trusted_devices()
        _load_recovery_codes()
        _load_sessions()
    
    @classmethod
    def is_2fa_required(cls) -> bool:
        if cls._cached_config is None:
            return False
        try:
            return cls._cached_config.is_2fa_enabled()
        except AttributeError:
            return False
    
    @classmethod
    def set_skip_2fa_once(cls, skip: bool) -> None:
        cls._skip_2fa_once = skip
    
    @classmethod
    def should_skip_2fa(cls) -> bool:
        if cls._skip_2fa_once:
            cls._skip_2fa_once = False
            return True
        return False

    @classmethod
    def verify_with_2fa(cls, password: str, source: str = "startup") -> Tuple[bool, Optional[str]]:
        if not cls.verify(password, source=source):
            return False, "master_password_incorrect"
        
        if not cls.is_2fa_required() or cls.should_skip_2fa():
            return True, None
        
        try:
            from security.totp import TOTP, get_totp_manager
            
            secret = cls._cached_config.get_2fa_secret()
            if not secret:
                logger.error("2FA enabled but no secret found")
                cls._log_audit_event("2fa_verification_failed", {"reason": "no_secret", "source": source})
                return False, "2fa_missing_secret"
            
            totp = TOTP(secret)
            
            from gui.dialogs import CTkInputDialog
            from localization.lang import LANGUAGES
            import customtkinter as ctk
            
            lang = cls._cached_config.get("LANG", "RU")
            L = LANGUAGES.get(lang, LANGUAGES["RU"])
            
            code = CTkInputDialog.ask(
                None,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_enter_code", "Enter verification code:"),
                show="",
                theme="dark",
                lang=lang
            )
            
            if code is None:
                cls._log_audit_event("2fa_verification_failed", {"reason": "cancelled", "source": source})
                return False, "2fa_cancelled"
            
            code_clean = ''.join(filter(str.isdigit, str(code)))
            
            if totp.verify(code_clean)[0]:
                cls._log_audit_event("2fa_verification_success", {"source": source})
                return True, None
            
            manager = get_totp_manager()
            if manager.verify_backup_code(code_clean):
                cls._log_audit_event("2fa_backup_used", {"source": source})
                if cls._cached_config:
                    cls._cached_config.set_2fa_backup_hashes(manager.get_backup_codes_hashes())
                    cls._cached_config.save()
                return True, None
            
            cls._log_audit_event("2fa_verification_failed", {"reason": "invalid_code", "source": source})
            return False, "2fa_invalid_code"
            
        except ImportError as e:
            logger.error(f"Failed to import 2FA modules: {e}")
            return False, "2fa_module_error"
        except (ValueError, TypeError, AttributeError) as e:
            logger.error(f"2FA verification error: {e}")
            return False, "2fa_error"

    @classmethod
    def prompt_on_startup(cls, lang: str = "RU", theme: str = "dark") -> bool:
        _load_lockout_state()
        _load_audit_log()
        _load_password_history()
        _load_trusted_devices()
        _load_recovery_codes()
        _load_sessions()
        
        if not cls.is_set():
            return True

        try:
            import customtkinter as ctk
            import tkinter as tk
            from localization.lang import LANGUAGES
            from security.encryption import set_key_from_master
            from utils.helpers import center_screen
        except ImportError as e:
            logger.error(f"Failed to import GUI modules: {e}")
            return True

        L = LANGUAGES.get(lang, LANGUAGES.get("RU", {}))
        
        if theme == "light":
            bg_color = "#F3F3F3"
            fg_color = "#000000"
            entry_bg = "#FFFFFF"
            btn_fg = "#2d6a4f"
            btn_hover = "#40916c"
        else:
            bg_color = "#1d1e1e"
            fg_color = "#FFFFFF"
            entry_bg = "#2b2b2b"
            btn_fg = "#2d6a4f"
            btn_hover = "#40916c"

        root = ctk.CTk()
        root.title(L.get("master_title", "Master password"))
        root.resizable(False, False)
        root.configure(fg_color=bg_color)
        center_screen(root, 380, 280)

        result = {"ok": False}
        max_attempts = cls.MAX_ATTEMPTS
        is_closing = False

        main_frame = ctk.CTkFrame(root, fg_color="transparent")
        main_frame.pack(expand=True, fill="both", padx=25, pady=20)

        ctk.CTkLabel(
            main_frame,
            text="",
            font=("Segoe UI", 32),
            text_color="#4EC9B0"
        ).pack(pady=(0, 8))

        ctk.CTkLabel(
            main_frame,
            text=L.get("master_prompt", "Enter master password to access the program:"),
            font=("Segoe UI", 13),
            text_color=fg_color,
        ).pack(pady=(0, 12))

        entry = ctk.CTkEntry(
            main_frame,
            width=280,
            height=38,
            show="*",
            fg_color=entry_bg,
            text_color=fg_color,
            corner_radius=12,
        )
        entry.pack(pady=(0, 12))
        entry.focus_set()

        status = ctk.CTkLabel(
            main_frame, 
            text="", 
            font=("Segoe UI", 11), 
            text_color="#E24B4A",
            wraplength=300
        )
        status.pack(pady=(0, 8))

        btn_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        btn_frame.pack(pady=(10, 0))

        def update_status():
            if is_closing:
                return
            try:
                info = cls.get_lockout_info()
                if info['is_locked']:
                    status.configure(text=f"{L.get('lock_wait', 'Please wait')} {info['lockout_seconds']} {L.get('seconds_short', 'sec')}...")
                    entry.configure(state="disabled")
                    submit_btn.configure(state="disabled")
                    cancel_btn.configure(state="disabled")
                    root.after(1000, update_status)
                elif info['is_permanently_locked']:
                    status.configure(text=L.get("master_blocked", "Too many attempts. Program closed."))
                    entry.configure(state="disabled")
                    submit_btn.configure(state="disabled")
                    cancel_btn.configure(state="disabled")
                    root.after(2000, _safe_exit)
                else:
                    entry.configure(state="normal")
                    submit_btn.configure(state="normal")
                    cancel_btn.configure(state="normal")
                    if info['attempts'] > 0:
                        status.configure(text=L["master_wrong"].format(info['attempts'], max_attempts))
                    else:
                        status.configure(text="")
            except (KeyError, AttributeError, tk.TclError) as e:
                logger.debug(f"Update status error: {e}")
        
        def _safe_exit():
            nonlocal is_closing
            is_closing = True
            try:
                root.destroy()
            except tk.TclError:
                pass
            sys.exit(0)
        
        def finish_ok() -> None:
            if is_closing:
                return
            result["ok"] = True
            try:
                root.destroy()
            except tk.TclError:
                pass

        def cancel() -> None:
            nonlocal is_closing
            is_closing = True
            result["ok"] = False
            try:
                root.destroy()
            except tk.TclError:
                pass

        def submit() -> None:
            if is_closing:
                return
            
            if cls.get_remaining_lockout_time() > 0:
                update_status()
                return
            
            pwd = entry.get()
            if pwd:
                success, error_code = cls.verify_with_2fa(pwd, source="startup")
                
                if success:
                    try:
                        set_key_from_master(pwd)
                    except (ValueError, TypeError, RuntimeError) as e:
                        logger.error(f"Failed to set key from master: {e}")
                        return
                    finish_ok()
                    return
                elif error_code == "2fa_missing_secret":
                    logger.warning("2FA secret missing, disabling 2FA as fallback")
                    if cls._cached_config:
                        try:
                            cls._cached_config.set_2fa_enabled(False)
                            cls._cached_config.save()
                        except (AttributeError, OSError) as e:
                            logger.debug(f"Failed to disable 2FA: {e}")
                    if cls.verify(pwd, source="startup"):
                        try:
                            set_key_from_master(pwd)
                        except (ValueError, TypeError, RuntimeError) as e:
                            logger.error(f"Failed to set key from master: {e}")
                            return
                        finish_ok()
                        return
                elif error_code == "2fa_cancelled":
                    cancel()
                    return
                elif error_code == "2fa_invalid_code":
                    status.configure(text=L.get("2fa_invalid_code", "Invalid verification code"))
                    entry.delete(0, "end")
                    entry.focus_set()
                    return

            info = cls.get_lockout_info()
            if info['is_permanently_locked']:
                status.configure(text=L.get("master_blocked", "Too many attempts. Program closed."))
                entry.configure(state="disabled")
                submit_btn.configure(state="disabled")
                cancel_btn.configure(state="disabled")
                root.after(2000, _safe_exit)
            elif info['is_locked']:
                status.configure(text=f"{L.get('lock_wait', 'Please wait')} {info['lockout_seconds']} {L.get('seconds_short', 'sec')}...")
                entry.delete(0, "end")
                entry.configure(state="disabled")
                submit_btn.configure(state="disabled")
                cancel_btn.configure(state="disabled")
                root.after(1000, update_status)
            else:
                status.configure(text=L["master_wrong"].format(info['attempts'], max_attempts))
                entry.delete(0, "end")
                entry.focus_set()

        submit_btn = ctk.CTkButton(
            btn_frame,
            text=L.get("unlock", "Unlock"),
            width=100,
            height=34,
            corner_radius=17,
            fg_color=btn_fg,
            hover_color=btn_hover,
            font=("Segoe UI", 12, "bold"),
            command=submit,
        )
        submit_btn.pack(side="left", padx=6)
        
        cancel_btn = ctk.CTkButton(
            btn_frame,
            text=L.get("close", "Close"),
            width=100,
            height=34,
            corner_radius=17,
            fg_color="#8b0000",
            hover_color="#cc0000",
            font=("Segoe UI", 12, "bold"),
            command=cancel,
        )
        cancel_btn.pack(side="left", padx=6)

        entry.bind("<Return>", lambda _e: submit())
        entry.bind("<Escape>", lambda _e: cancel())
        root.protocol("WM_DELETE_WINDOW", cancel)
        
        update_status()
        
        try:
            root.mainloop()
        except (KeyboardInterrupt, SystemExit) as e:
            logger.debug(f"Startup prompt interrupted: {e}")
            return False
        
        return result["ok"]