"""
Master password management with Argon2id and rate limiting
"""
import os
import sys
import ctypes
import hashlib
import hmac
import secrets
import time
import tempfile
import json
from typing import Optional, Tuple, Dict, Any
from datetime import datetime

# Логгер будет инициализирован позже
def _get_logger():
    try:
        from utils.logger import get_logger
        return get_logger("master")
    except ImportError:
        import logging
        return logging.getLogger("master")

logger = _get_logger()

try:
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError, VerificationError, InvalidHashError
    _ARGON2_OK = True
except ImportError:
    PasswordHasher = None
    VerifyMismatchError = VerificationError = InvalidHashError = Exception
    _ARGON2_OK = False

# ==================== PORTABLE PATH LOGIC ====================
if getattr(sys, 'frozen', False):
    _BASE_DIR = os.path.dirname(sys.executable)
else:
    _BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CONFIG_DIR = os.path.join(_BASE_DIR, "data")
MASTER_FILE = os.path.join(CONFIG_DIR, "master.key")
LOCKOUT_FILE = os.path.join(CONFIG_DIR, "lockout.json")
# =============================================================

_ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=4, hash_len=32) if _ARGON2_OK else None

MAX_ATTEMPTS = 5
LOCKOUT_TIMES = {
    1: 0,
    2: 0,
    3: 5,
    4: 10,
    5: 30,
}
PERMANENT_LOCKOUT_AFTER = MAX_ATTEMPTS


class MasterPasswordError(Exception):
    """Исключение для ошибок мастер-пароля"""
    pass


class LockoutError(MasterPasswordError):
    """Исключение при блокировке"""
    pass


def _hide_dir(path: str) -> None:
    if sys.platform == "win32":
        try:
            ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
        except (AttributeError, OSError) as e:
            pass


def _secure_write(path: str, data: bytes) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".tmp-", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
        if sys.platform == "win32":
            try:
                ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
            except (AttributeError, OSError):
                pass
        else:
            try:
                os.chmod(path, 0o600)
            except (PermissionError, OSError):
                pass
    except (PermissionError, OSError, IOError) as e:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        raise IOError(f"Cannot write to {path}: {e}")


def _save_lockout_state() -> None:
    """Сохраняет состояние блокировки в файл"""
    try:
        state = {
            "attempt_count": MasterPassword._attempt_count,
            "last_attempt_time": MasterPassword._last_attempt_time,
            "lockout_until": MasterPassword._lockout_until,
            "is_permanently_locked": MasterPassword._is_permanently_locked,
            "last_update": datetime.now().isoformat()
        }
        _secure_write(LOCKOUT_FILE, json.dumps(state, indent=2).encode('utf-8'))
    except Exception as e:
        logger.debug(f"Failed to save lockout state: {e}")


def _load_lockout_state() -> None:
    """Загружает состояние блокировки из файла"""
    if not os.path.exists(LOCKOUT_FILE):
        return
    
    try:
        with open(LOCKOUT_FILE, 'r', encoding='utf-8') as f:
            state = json.load(f)
        
        MasterPassword._attempt_count = state.get("attempt_count", 0)
        MasterPassword._last_attempt_time = state.get("last_attempt_time", 0)
        MasterPassword._lockout_until = state.get("lockout_until", 0)
        MasterPassword._is_permanently_locked = state.get("is_permanently_locked", False)
        
        # Проверяем, не истекла ли блокировка
        if MasterPassword._lockout_until > 0 and MasterPassword._lockout_until <= time.time():
            MasterPassword._reset_attempts()
        
        logger.debug("Lockout state loaded")
    except (json.JSONDecodeError, OSError, IOError, KeyError) as e:
        logger.debug(f"Failed to load lockout state: {e}")


class MasterPassword:
    """Master password handler with Argon2id hashing and rate limiting"""

    MAX_ATTEMPTS = MAX_ATTEMPTS
    SALT_SIZE = 32
    PBKDF2_ITERATIONS = 600000
    USE_ARGON2 = _ARGON2_OK
    
    _attempt_count = 0
    _last_attempt_time = 0
    _lockout_until = 0
    _is_permanently_locked = False
    _audit_log: List[Dict[str, Any]] = []

    @classmethod
    def _get_lockout_delay(cls, attempts: int) -> int:
        return LOCKOUT_TIMES.get(attempts, LOCKOUT_TIMES[MAX_ATTEMPTS])
    
    @classmethod
    def _apply_rate_limit(cls) -> Tuple[bool, int]:
        current_time = time.time()
        
        if cls._is_permanently_locked:
            return False, -1
        
        if cls._lockout_until > current_time:
            return False, int(cls._lockout_until - current_time)
        
        if current_time - cls._last_attempt_time > 1800:
            cls._attempt_count = 0
            cls._lockout_until = 0
            _save_lockout_state()
        
        return True, 0
    
    @classmethod
    def _record_failed_attempt(cls, source: str = "unknown") -> int:
        cls._attempt_count += 1
        cls._last_attempt_time = time.time()
        
        # Логируем попытку
        cls._log_audit_event("failed_attempt", {
            "attempts": cls._attempt_count,
            "source": source,
            "timestamp": datetime.now().isoformat()
        })
        
        if cls._attempt_count >= PERMANENT_LOCKOUT_AFTER:
            cls._is_permanently_locked = True
            _save_lockout_state()
            logger.warning(f"Permanent lockout triggered after {cls._attempt_count} attempts")
            return -1
        
        delay = cls._get_lockout_delay(cls._attempt_count)
        if delay > 0:
            cls._lockout_until = cls._last_attempt_time + delay
            logger.warning(f"Lockout for {delay} seconds after {cls._attempt_count} attempts")
        
        _save_lockout_state()
        return delay
    
    @classmethod
    def _reset_attempts(cls) -> None:
        cls._attempt_count = 0
        cls._lockout_until = 0
        cls._is_permanently_locked = False
        cls._last_attempt_time = 0
        _save_lockout_state()
        logger.debug("Attempts reset")
    
    @classmethod
    def _log_audit_event(cls, event_type: str, details: Dict[str, Any]) -> None:
        """Логирует событие аудита"""
        event = {
            "event": event_type,
            "timestamp": datetime.now().isoformat(),
            "details": details
        }
        cls._audit_log.append(event)
        
        # Ограничиваем размер лога
        if len(cls._audit_log) > 100:
            cls._audit_log = cls._audit_log[-100:]
        
        # Логируем в основной лог
        if event_type == "failed_attempt":
            logger.warning(f"Auth failed: {details.get('attempts', 0)} attempts")
        elif event_type == "successful_auth":
            logger.info("Successful authentication")
        elif event_type == "password_set":
            logger.info("Master password set")
        elif event_type == "password_removed":
            logger.info("Master password removed")
    
    @classmethod
    def get_remaining_lockout_time(cls) -> int:
        if cls._is_permanently_locked:
            return -1
        if cls._lockout_until <= time.time():
            return 0
        return int(cls._lockout_until - time.time())
    
    @classmethod
    def get_attempts_remaining(cls) -> int:
        if cls._is_permanently_locked:
            return 0
        if cls._attempt_count >= MAX_ATTEMPTS:
            return 0
        return MAX_ATTEMPTS - cls._attempt_count
    
    @classmethod
    def is_permanently_locked(cls) -> bool:
        return cls._is_permanently_locked
    
    @classmethod
    def get_lockout_info(cls) -> dict:
        remaining = cls.get_remaining_lockout_time()
        return {
            'attempts': cls._attempt_count,
            'max_attempts': MAX_ATTEMPTS,
            'remaining_attempts': cls.get_attempts_remaining(),
            'lockout_seconds': remaining if remaining > 0 else 0,
            'is_locked': remaining > 0,
            'is_permanently_locked': cls._is_permanently_locked
        }
    
    @classmethod
    def get_audit_log(cls) -> List[Dict[str, Any]]:
        """Возвращает копию лога аудита"""
        return cls._audit_log.copy()

    @classmethod
    def _derive_key_pbkdf2(cls, password: bytes, salt: bytes) -> bytes:
        return hashlib.pbkdf2_hmac('sha256', password, salt, cls.PBKDF2_ITERATIONS, dklen=32)

    @classmethod
    def _hash_argon2(cls, password: str) -> str:
        if not _ARGON2_OK or _ph is None:
            raise RuntimeError("Argon2 is not available")
        return _ph.hash(password)

    @classmethod
    def _verify_argon2(cls, password: str, stored_hash: str) -> bool:
        try:
            if not _ARGON2_OK or _ph is None:
                return False
            _ph.verify(stored_hash, password)
            return True
        except (VerifyMismatchError, VerificationError, InvalidHashError):
            return False

    @classmethod
    def is_set(cls) -> bool:
        return os.path.exists(MASTER_FILE)

    @classmethod
    def verify(cls, password: str, record_attempt: bool = True, source: str = "unknown") -> bool:
        is_allowed, remaining = cls._apply_rate_limit()
        if not is_allowed:
            logger.warning(f"Rate limit applied, locked for {remaining} seconds")
            return False
        
        if not cls.is_set():
            if record_attempt:
                cls._reset_attempts()
            return True
        
        try:
            with open(MASTER_FILE, 'rb') as f:
                version = f.read(1)
                if version == b'\x02':
                    stored_hash = f.read().decode('utf-8')
                    result = cls._verify_argon2(password, stored_hash)
                elif version == b'\x01':
                    salt = f.read(cls.SALT_SIZE)
                    stored_hash = f.read()
                    if len(salt) != cls.SALT_SIZE or len(stored_hash) != 32:
                        result = False
                    else:
                        derived = cls._derive_key_pbkdf2(password.encode('utf-8'), salt)
                        result = hmac.compare_digest(derived, stored_hash)
                else:
                    result = False
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Error reading master file: {e}")
            result = False
        except UnicodeDecodeError as e:
            logger.error(f"Master file decode error: {e}")
            result = False
        
        if result:
            if record_attempt:
                cls._reset_attempts()
                cls._log_audit_event("successful_auth", {"source": source})
        else:
            if record_attempt:
                cls._record_failed_attempt(source)
        
        return result

    @classmethod
    def set_password(cls, password: str) -> None:
        if not password:
            raise MasterPasswordError("Master password must not be empty")
        
        if len(password) < 8:
            raise MasterPasswordError("Password too short. Minimum 8 characters.")
        
        import re
        if not re.search(r"[0-9!@#$%^&*()_+=\[\]{};:,.<>/?@%-]", password):
            raise MasterPasswordError("Password too weak. Add a digit or special character.")

        os.makedirs(CONFIG_DIR, exist_ok=True)
        _hide_dir(CONFIG_DIR)

        try:
            if cls.USE_ARGON2:
                hashed = cls._hash_argon2(password)
                _secure_write(MASTER_FILE, b'\x02' + hashed.encode('utf-8'))
            else:
                salt = secrets.token_bytes(cls.SALT_SIZE)
                derived = cls._derive_key_pbkdf2(password.encode('utf-8'), salt)
                _secure_write(MASTER_FILE, b'\x01' + salt + derived)
        except (ValueError, TypeError, RuntimeError) as e:
            raise MasterPasswordError(f"Failed to set password: {e}")
        
        cls._reset_attempts()
        cls._log_audit_event("password_set", {"method": "Argon2id" if cls.USE_ARGON2 else "PBKDF2"})

    @classmethod
    def remove(cls) -> None:
        try:
            if os.path.exists(MASTER_FILE):
                os.remove(MASTER_FILE)
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to remove master file: {e}")
        
        try:
            if os.path.exists(LOCKOUT_FILE):
                os.remove(LOCKOUT_FILE)
        except (OSError, IOError, PermissionError):
            pass
        
        cls._reset_attempts()
        cls._log_audit_event("password_removed", {})

    @classmethod
    def change_password(cls, old_password: str, new_password: str) -> bool:
        """Смена мастер-пароля с проверкой старого"""
        if not cls.verify(old_password, source="password_change"):
            logger.warning("Password change failed: invalid old password")
            return False
        
        try:
            cls.set_password(new_password)
            logger.info("Password changed successfully")
            return True
        except MasterPasswordError as e:
            logger.error(f"Password change error: {e}")
            return False

    @classmethod
    def prompt_on_startup(cls, lang: str = "RU", theme: str = "dark") -> bool:
        """
        Запрос мастер-пароля при запуске.
        ВАЖНО: Если мастер-пароль НЕ установлен - программа запускается без запроса.
        Мастер-пароль можно установить ТОЛЬКО через настройки.
        """
        # Загружаем состояние блокировки при запуске
        _load_lockout_state()
        
        # Если мастер-пароль НЕ установлен - просто запускаем программу без запроса
        if not cls.is_set():
            return True

        try:
            import customtkinter as ctk
            from localization.lang import LANGUAGES
            from security.encryption import set_key_from_master
            from utils.helpers import center_screen
            from gui.dialogs import CTkMessageBox
        except ImportError as e:
            logger.error(f"Failed to import GUI modules: {e}")
            return True

        L = LANGUAGES.get(lang, LANGUAGES.get("RU", {}))
        
        # Определяем цвета в зависимости от темы
        if theme == "light":
            bg_color = "#F3F3F3"
            fg_color = "#000000"
            entry_bg = "#FFFFFF"
            btn_fg = "#2d6a4f"
            btn_hover = "#40916c"
        else:
            bg_color = "#1d1e1e"
            fg_color = "#FFFFFF"
            entry_bg = "#2b2b2b"
            btn_fg = "#2d6a4f"
            btn_hover = "#40916c"

        # Создаём окно
        root = ctk.CTk()
        root.title(L.get("master_title", "Master password"))
        root.resizable(False, False)
        root.configure(fg_color=bg_color)
        center_screen(root, 380, 280)

        result = {"ok": False}
        max_attempts = cls.MAX_ATTEMPTS
        is_closing = False

        # Основной фрейм
        main_frame = ctk.CTkFrame(root, fg_color="transparent")
        main_frame.pack(expand=True, fill="both", padx=25, pady=20)

        # Иконка замка
        ctk.CTkLabel(
            main_frame,
            text="🔒",
            font=("Segoe UI", 32),
            text_color="#4EC9B0"
        ).pack(pady=(0, 8))

        # Текст
        ctk.CTkLabel(
            main_frame,
            text=L.get("master_prompt", "Enter master password to access the program:"),
            font=("Segoe UI", 13),
            text_color=fg_color,
        ).pack(pady=(0, 12))

        # Поле ввода пароля
        entry = ctk.CTkEntry(
            main_frame,
            width=280,
            height=38,
            show="*",
            fg_color=entry_bg,
            text_color=fg_color,
            corner_radius=12,
        )
        entry.pack(pady=(0, 12))
        entry.focus_set()

        # Статус (ошибки)
        status = ctk.CTkLabel(
            main_frame, 
            text="", 
            font=("Segoe UI", 11), 
            text_color="#E24B4A",
            wraplength=300
        )
        status.pack(pady=(0, 8))

        # Рамка для кнопок
        btn_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        btn_frame.pack()

        def update_status():
            if is_closing:
                return
            info = cls.get_lockout_info()
            if info['is_locked']:
                status.configure(text=f"⏳ {L.get('lock_wait', 'Подождите')} {info['lockout_seconds']} {L.get('seconds_short', 'сек')}...")
                entry.configure(state="disabled")
                submit_btn.configure(state="disabled")
                cancel_btn.configure(state="disabled")
                root.after(1000, update_status)
            elif info['is_permanently_locked']:
                status.configure(text=L.get("master_blocked", "Превышено число попыток. Программа закрыта."))
                entry.configure(state="disabled")
                submit_btn.configure(state="disabled")
                cancel_btn.configure(state="disabled")
                root.after(2000, _safe_exit)
            else:
                entry.configure(state="normal")
                submit_btn.configure(state="normal")
                cancel_btn.configure(state="normal")
                if info['attempts'] > 0:
                    status.configure(text=L["master_wrong"].format(info['attempts'], max_attempts))
                else:
                    status.configure(text="")
        
        def _safe_exit():
            nonlocal is_closing
            is_closing = True
            try:
                root.destroy()
            except Exception:
                pass
            sys.exit(0)
        
        def finish_ok() -> None:
            if is_closing:
                return
            result["ok"] = True
            root.destroy()

        def cancel() -> None:
            nonlocal is_closing
            is_closing = True
            result["ok"] = False
            root.destroy()

        def submit() -> None:
            if is_closing:
                return
            
            if cls.get_remaining_lockout_time() > 0:
                update_status()
                return
            
            pwd = entry.get()
            if cls.verify(pwd, source="startup"):
                try:
                    set_key_from_master(pwd)
                except (ValueError, TypeError, RuntimeError) as e:
                    logger.error(f"Failed to set key from master: {e}")
                    return
                finish_ok()
                return

            info = cls.get_lockout_info()
            if info['is_permanently_locked']:
                status.configure(text=L.get("master_blocked", "Превышено число попыток. Программа закрыта."))
                entry.configure(state="disabled")
                submit_btn.configure(state="disabled")
                cancel_btn.configure(state="disabled")
                root.after(2000, _safe_exit)
            elif info['is_locked']:
                status.configure(text=f"⏳ {L.get('lock_wait', 'Подождите')} {info['lockout_seconds']} {L.get('seconds_short', 'сек')}...")
                entry.delete(0, "end")
                entry.configure(state="disabled")
                submit_btn.configure(state="disabled")
                cancel_btn.configure(state="disabled")
                root.after(1000, update_status)
            else:
                status.configure(text=L["master_wrong"].format(info['attempts'], max_attempts))
                entry.delete(0, "end")
                entry.focus_set()

        # Кнопка OK
        submit_btn = ctk.CTkButton(
            btn_frame,
            text=L.get("ok", "OK"),
            width=100,
            height=34,
            corner_radius=17,
            fg_color=btn_fg,
            hover_color=btn_hover,
            font=("Segoe UI", 12, "bold"),
            command=submit,
        )
        submit_btn.pack(side="left", padx=6)
        
        # Кнопка Отмена
        cancel_btn = ctk.CTkButton(
            btn_frame,
            text=L.get("cancel", "Отмена"),
            width=100,
            height=34,
            corner_radius=17,
            fg_color="#8b0000",
            hover_color="#cc0000",
            font=("Segoe UI", 12, "bold"),
            command=cancel,
        )
        cancel_btn.pack(side="left", padx=6)

        entry.bind("<Return>", lambda _e: submit())
        entry.bind("<Escape>", lambda _e: cancel())
        root.protocol("WM_DELETE_WINDOW", cancel)
        
        update_status()
        
        root.mainloop()
        return result["ok"]