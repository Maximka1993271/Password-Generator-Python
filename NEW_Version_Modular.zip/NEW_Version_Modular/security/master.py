"""
Master password management with Argon2id and rate limiting
"""
import os
import sys
import ctypes
import hashlib
import hmac
import secrets
import time
import tempfile
import json
from typing import Optional, Tuple, Dict, Any, List
from datetime import datetime

# Логгер будет инициализирован позже
def _get_logger():
    try:
        from utils.logger import get_logger
        return get_logger("master")
    except ImportError:
        import logging
        return logging.getLogger("master")

logger = _get_logger()

try:
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError, VerificationError, InvalidHashError
    _ARGON2_OK = True
except ImportError as e:
    PasswordHasher = None
    VerifyMismatchError = VerificationError = InvalidHashError = Exception
    _ARGON2_OK = False
    logger.debug(f"Argon2 not available: {e}")

# ==================== PORTABLE PATH LOGIC ====================
if getattr(sys, 'frozen', False):
    _BASE_DIR = os.path.dirname(sys.executable)
else:
    _BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CONFIG_DIR = os.path.join(_BASE_DIR, "data")
MASTER_FILE = os.path.join(CONFIG_DIR, "master.key")
LOCKOUT_FILE = os.path.join(CONFIG_DIR, "lockout.json")
AUDIT_LOG_FILE = os.path.join(CONFIG_DIR, "auth_audit.json")
# =============================================================

_ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=4, hash_len=32) if _ARGON2_OK else None

MAX_ATTEMPTS = 5
LOCKOUT_TIMES = {
    1: 0,
    2: 0,
    3: 5,
    4: 10,
    5: 30,
}
PERMANENT_LOCKOUT_AFTER = MAX_ATTEMPTS
AUDIT_LOG_MAX_ENTRIES = 100
AUDIT_LOG_RETENTION_DAYS = 90


class MasterPasswordError(Exception):
    """Исключение для ошибок мастер-пароля"""
    pass


class LockoutError(MasterPasswordError):
    """Исключение при блокировке"""
    pass


class AuditError(MasterPasswordError):
    """Исключение при ошибках аудита"""
    pass


def _hide_dir(path: str) -> None:
    if sys.platform == "win32":
        try:
            ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
        except (AttributeError, OSError, TypeError) as e:
            logger.debug(f"Hide dir failed: {e}")


def _secure_write(path: str, data: bytes) -> None:
    """Атомарная запись с безопасной очисткой"""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(prefix=".tmp-", dir=os.path.dirname(path))
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, path)
            if sys.platform == "win32":
                try:
                    ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
                except (AttributeError, OSError, TypeError):
                    pass
            else:
                try:
                    os.chmod(path, 0o600)
                except (PermissionError, OSError):
                    pass
        except (PermissionError, OSError, IOError) as e:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            raise IOError(f"Cannot write to {path}: {e}")
    except (OSError, IOError, PermissionError) as e:
        raise IOError(f"Cannot create directory for {path}: {e}")


def _secure_read(path: str) -> Optional[bytes]:
    """Безопасное чтение файла"""
    try:
        if not os.path.exists(path):
            return None
        with open(path, 'rb') as f:
            return f.read()
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Failed to read {path}: {e}")
        return None


def _save_lockout_state() -> None:
    """Сохраняет состояние блокировки в файл"""
    try:
        state = {
            "attempt_count": MasterPassword._attempt_count,
            "last_attempt_time": MasterPassword._last_attempt_time,
            "lockout_until": MasterPassword._lockout_until,
            "is_permanently_locked": MasterPassword._is_permanently_locked,
            "last_update": datetime.now().isoformat()
        }
        _secure_write(LOCKOUT_FILE, json.dumps(state, indent=2).encode('utf-8'))
    except (OSError, IOError, PermissionError, TypeError) as e:
        logger.debug(f"Failed to save lockout state: {e}")


def _load_lockout_state() -> None:
    """Загружает состояние блокировки из файла"""
    if not os.path.exists(LOCKOUT_FILE):
        return
    
    try:
        content = _secure_read(LOCKOUT_FILE)
        if content:
            state = json.loads(content.decode('utf-8'))
        
            MasterPassword._attempt_count = state.get("attempt_count", 0)
            MasterPassword._last_attempt_time = state.get("last_attempt_time", 0)
            MasterPassword._lockout_until = state.get("lockout_until", 0)
            MasterPassword._is_permanently_locked = state.get("is_permanently_locked", False)
            
            # Проверяем, не истекла ли блокировка
            if MasterPassword._lockout_until > 0 and MasterPassword._lockout_until <= time.time():
                MasterPassword._reset_attempts()
            
            logger.debug("Lockout state loaded")
    except (json.JSONDecodeError, OSError, IOError, KeyError, UnicodeDecodeError) as e:
        logger.debug(f"Failed to load lockout state: {e}")


def _save_audit_log() -> None:
    """Сохраняет журнал аудита в файл"""
    try:
        # Очистка старых записей
        MasterPassword._cleanup_audit_log()
        
        audit_data = {
            "entries": MasterPassword._audit_log,
            "last_update": datetime.now().isoformat(),
            "version": 2
        }
        _secure_write(AUDIT_LOG_FILE, json.dumps(audit_data, indent=2).encode('utf-8'))
    except (OSError, IOError, PermissionError, TypeError) as e:
        logger.debug(f"Failed to save audit log: {e}")


def _load_audit_log() -> None:
    """Загружает журнал аудита из файла"""
    if not os.path.exists(AUDIT_LOG_FILE):
        return
    
    try:
        content = _secure_read(AUDIT_LOG_FILE)
        if content:
            audit_data = json.loads(content.decode('utf-8'))
            entries = audit_data.get("entries", [])
            if isinstance(entries, list):
                MasterPassword._audit_log = entries[-AUDIT_LOG_MAX_ENTRIES:]
            logger.debug(f"Loaded {len(MasterPassword._audit_log)} audit entries")
    except (json.JSONDecodeError, OSError, IOError, UnicodeDecodeError, KeyError) as e:
        logger.debug(f"Failed to load audit log: {e}")


class MasterPassword:
    """Master password handler with Argon2id hashing and rate limiting"""

    MAX_ATTEMPTS = MAX_ATTEMPTS
    SALT_SIZE = 32
    PBKDF2_ITERATIONS = 600000
    USE_ARGON2 = _ARGON2_OK
    
    _attempt_count = 0
    _last_attempt_time = 0
    _lockout_until = 0
    _is_permanently_locked = False
    _audit_log: List[Dict[str, Any]] = []
    
    # ==================== 2FA ДОПОЛНЕНИЯ ====================
    _cached_config = None
    _skip_2fa_once = False
    _trusted_devices: List[str] = []
    _recovery_tokens: List[str] = []

    @classmethod
    def _get_lockout_delay(cls, attempts: int) -> int:
        return LOCKOUT_TIMES.get(attempts, LOCKOUT_TIMES[MAX_ATTEMPTS])
    
    @classmethod
    def _apply_rate_limit(cls) -> Tuple[bool, int]:
        current_time = time.time()
        
        if cls._is_permanently_locked:
            return False, -1
        
        if cls._lockout_until > current_time:
            return False, int(cls._lockout_until - current_time)
        
        # Сброс после 30 минут бездействия
        if current_time - cls._last_attempt_time > 1800:
            cls._attempt_count = 0
            cls._lockout_until = 0
            _save_lockout_state()
        
        return True, 0
    
    @classmethod
    def _record_failed_attempt(cls, source: str = "unknown") -> int:
        cls._attempt_count += 1
        cls._last_attempt_time = time.time()
        
        cls._log_audit_event("failed_attempt", {
            "attempts": cls._attempt_count,
            "source": source,
            "timestamp": datetime.now().isoformat()
        })
        
        if cls._attempt_count >= PERMANENT_LOCKOUT_AFTER:
            cls._is_permanently_locked = True
            _save_lockout_state()
            logger.warning(f"Permanent lockout triggered after {cls._attempt_count} attempts")
            return -1
        
        delay = cls._get_lockout_delay(cls._attempt_count)
        if delay > 0:
            cls._lockout_until = cls._last_attempt_time + delay
            logger.warning(f"Lockout for {delay} seconds after {cls._attempt_count} attempts")
        
        _save_lockout_state()
        return delay
    
    @classmethod
    def _reset_attempts(cls) -> None:
        cls._attempt_count = 0
        cls._lockout_until = 0
        cls._is_permanently_locked = False
        cls._last_attempt_time = 0
        _save_lockout_state()
        logger.debug("Attempts reset")
    
    @classmethod
    def _cleanup_audit_log(cls) -> None:
        """Очищает старые записи аудита"""
        try:
            current_time = datetime.now()
            cutoff_time = current_time.timestamp() - (AUDIT_LOG_RETENTION_DAYS * 24 * 3600)
            
            # Фильтруем старые записи
            filtered_log = []
            for entry in cls._audit_log:
                try:
                    entry_time = datetime.fromisoformat(entry.get("timestamp", "2000-01-01T00:00:00")).timestamp()
                    if entry_time > cutoff_time:
                        filtered_log.append(entry)
                except (ValueError, TypeError):
                    # Если не можем распарсить, оставляем запись
                    filtered_log.append(entry)
            
            # Ограничиваем количество записей
            if len(filtered_log) > AUDIT_LOG_MAX_ENTRIES:
                filtered_log = filtered_log[-AUDIT_LOG_MAX_ENTRIES:]
            
            cls._audit_log = filtered_log
        except (ValueError, TypeError, OSError) as e:
            logger.debug(f"Audit log cleanup error: {e}")
    
    @classmethod
    def _log_audit_event(cls, event_type: str, details: Dict[str, Any]) -> None:
        """Логирует событие аудита с защитой от ошибок"""
        try:
            event = {
                "event": event_type,
                "timestamp": datetime.now().isoformat(),
                "details": details.copy() if details else {}
            }
            cls._audit_log.append(event)
            
            # Ограничиваем размер
            if len(cls._audit_log) > AUDIT_LOG_MAX_ENTRIES:
                cls._audit_log = cls._audit_log[-AUDIT_LOG_MAX_ENTRIES:]
            
            # Асинхронное сохранение (не блокируем)
            try:
                _save_audit_log()
            except (OSError, IOError, PermissionError) as e:
                logger.debug(f"Audit log save error: {e}")
            
            # Логирование в зависимости от типа события
            if event_type == "failed_attempt":
                logger.warning(f"Auth failed: {details.get('attempts', 0)} attempts from {details.get('source', 'unknown')}")
            elif event_type == "successful_auth":
                logger.info(f"Successful authentication from {details.get('source', 'unknown')}")
            elif event_type == "password_set":
                logger.info("Master password set")
            elif event_type == "password_removed":
                logger.info("Master password removed")
            elif event_type == "password_changed":
                logger.info("Master password changed")
            elif event_type == "2fa_verification_failed":
                logger.warning(f"2FA verification failed from {details.get('source', 'unknown')}")
            elif event_type == "2fa_verification_success":
                logger.info(f"2FA verification successful from {details.get('source', 'unknown')}")
            elif event_type == "2fa_backup_used":
                logger.info(f"Backup code used for 2FA verification from {details.get('source', 'unknown')}")
            elif event_type == "lockout_reset":
                logger.info("Lockout state reset")
        except (TypeError, ValueError, KeyError) as e:
            logger.debug(f"Audit logging error: {e}")
    
    @classmethod
    def get_remaining_lockout_time(cls) -> int:
        if cls._is_permanently_locked:
            return -1
        if cls._lockout_until <= time.time():
            return 0
        return int(cls._lockout_until - time.time())
    
    @classmethod
    def get_attempts_remaining(cls) -> int:
        if cls._is_permanently_locked:
            return 0
        if cls._attempt_count >= MAX_ATTEMPTS:
            return 0
        return MAX_ATTEMPTS - cls._attempt_count
    
    @classmethod
    def is_permanently_locked(cls) -> bool:
        return cls._is_permanently_locked
    
    @classmethod
    def get_lockout_info(cls) -> dict:
        remaining = cls.get_remaining_lockout_time()
        return {
            'attempts': cls._attempt_count,
            'max_attempts': MAX_ATTEMPTS,
            'remaining_attempts': cls.get_attempts_remaining(),
            'lockout_seconds': remaining if remaining > 0 else 0,
            'is_locked': remaining > 0,
            'is_permanently_locked': cls._is_permanently_locked
        }
    
    @classmethod
    def get_audit_log(cls) -> List[Dict[str, Any]]:
        """Возвращает копию журнала аудита"""
        return cls._audit_log.copy()
    
    @classmethod
    def clear_audit_log(cls) -> bool:
        """Очищает журнал аудита"""
        try:
            cls._audit_log = []
            _save_audit_log()
            logger.info("Audit log cleared")
            return True
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to clear audit log: {e}")
            return False
    
    @classmethod
    def reset_lockout(cls) -> bool:
        """Сбрасывает состояние блокировки (требует админских прав)"""
        if not cls.is_permanently_locked() and cls.get_remaining_lockout_time() == 0:
            return True
        
        cls._reset_attempts()
        cls._log_audit_event("lockout_reset", {"source": "admin"})
        logger.info("Lockout state reset")
        return True

    @classmethod
    def _derive_key_pbkdf2(cls, password: bytes, salt: bytes) -> bytes:
        return hashlib.pbkdf2_hmac('sha256', password, salt, cls.PBKDF2_ITERATIONS, dklen=32)

    @classmethod
    def _hash_argon2(cls, password: str) -> str:
        if not _ARGON2_OK or _ph is None:
            raise RuntimeError("Argon2 is not available")
        try:
            return _ph.hash(password)
        except (ValueError, TypeError, RuntimeError) as e:
            logger.error(f"Argon2 hash error: {e}")
            raise RuntimeError(f"Failed to hash password: {e}")

    @classmethod
    def _verify_argon2(cls, password: str, stored_hash: str) -> bool:
        try:
            if not _ARGON2_OK or _ph is None:
                return False
            _ph.verify(stored_hash, password)
            # Проверка на необходимость перехеширования
            if _ph.check_needs_rehash(stored_hash):
                logger.debug("Password hash needs rehash")
            return True
        except (VerifyMismatchError, VerificationError, InvalidHashError, TypeError, ValueError) as e:
            logger.debug(f"Argon2 verification failed: {type(e).__name__}")
            return False

    @classmethod
    def is_set(cls) -> bool:
        return os.path.exists(MASTER_FILE)

    @classmethod
    def verify(cls, password: str, record_attempt: bool = True, source: str = "unknown") -> bool:
        is_allowed, remaining = cls._apply_rate_limit()
        if not is_allowed:
            logger.warning(f"Rate limit applied, locked for {remaining} seconds")
            return False
        
        if not cls.is_set():
            if record_attempt:
                cls._reset_attempts()
            return True
        
        try:
            content = _secure_read(MASTER_FILE)
            if content is None:
                logger.error("Failed to read master file")
                if record_attempt:
                    cls._record_failed_attempt(source)
                return False
            
            version = content[:1]
            rest = content[1:]
            
            if version == b'\x02':
                stored_hash = rest.decode('utf-8')
                result = cls._verify_argon2(password, stored_hash)
            elif version == b'\x01':
                if len(rest) < cls.SALT_SIZE + 32:
                    logger.error("Invalid master file format")
                    if record_attempt:
                        cls._record_failed_attempt(source)
                    return False
                salt = rest[:cls.SALT_SIZE]
                stored_hash = rest[cls.SALT_SIZE:]
                if len(salt) != cls.SALT_SIZE or len(stored_hash) != 32:
                    logger.error("Invalid salt or hash length")
                    if record_attempt:
                        cls._record_failed_attempt(source)
                    return False
                derived = cls._derive_key_pbkdf2(password.encode('utf-8'), salt)
                result = hmac.compare_digest(derived, stored_hash)
            else:
                logger.error(f"Unknown master file version: {version}")
                if record_attempt:
                    cls._record_failed_attempt(source)
                return False
        except (OSError, IOError, PermissionError, UnicodeDecodeError, ValueError, TypeError) as e:
            logger.error(f"Error reading master file: {e}")
            if record_attempt:
                cls._record_failed_attempt(source)
            return False
        
        if result:
            if record_attempt:
                cls._reset_attempts()
                cls._log_audit_event("successful_auth", {"source": source})
        else:
            if record_attempt:
                cls._record_failed_attempt(source)
        
        return result

    @classmethod
    def set_password(cls, password: str) -> None:
        if not password:
            raise MasterPasswordError("Master password must not be empty")
        
        if len(password) < 8:
            raise MasterPasswordError("Password too short. Minimum 8 characters.")
        
        import re
        if not re.search(r"[0-9!@#$%^&*()_+=\[\]{};:,.<>/?@%-]", password):
            raise MasterPasswordError("Password too weak. Add a digit or special character.")

        try:
            os.makedirs(CONFIG_DIR, exist_ok=True)
            _hide_dir(CONFIG_DIR)
        except (PermissionError, OSError, IOError) as e:
            raise MasterPasswordError(f"Cannot create config directory: {e}")

        try:
            if cls.USE_ARGON2:
                hashed = cls._hash_argon2(password)
                _secure_write(MASTER_FILE, b'\x02' + hashed.encode('utf-8'))
            else:
                salt = secrets.token_bytes(cls.SALT_SIZE)
                derived = cls._derive_key_pbkdf2(password.encode('utf-8'), salt)
                _secure_write(MASTER_FILE, b'\x01' + salt + derived)
        except (ValueError, TypeError, RuntimeError, OSError, IOError) as e:
            raise MasterPasswordError(f"Failed to set password: {e}")
        
        cls._reset_attempts()
        cls._log_audit_event("password_set", {"method": "Argon2id" if cls.USE_ARGON2 else "PBKDF2"})

    @classmethod
    def remove(cls) -> None:
        try:
            if os.path.exists(MASTER_FILE):
                os.remove(MASTER_FILE)
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to remove master file: {e}")
        
        try:
            if os.path.exists(LOCKOUT_FILE):
                os.remove(LOCKOUT_FILE)
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"Failed to remove lockout file: {e}")
        
        cls._reset_attempts()
        cls._log_audit_event("password_removed", {})

    @classmethod
    def change_password(cls, old_password: str, new_password: str) -> bool:
        if not cls.verify(old_password, source="password_change"):
            logger.warning("Password change failed: invalid old password")
            cls._log_audit_event("failed_attempt", {"source": "password_change", "reason": "invalid_old"})
            return False
        
        if len(new_password) < 8:
            logger.warning("Password change failed: new password too short")
            return False
        
        try:
            cls.set_password(new_password)
            logger.info("Password changed successfully")
            cls._log_audit_event("password_changed", {})
            return True
        except MasterPasswordError as e:
            logger.error(f"Password change error: {e}")
            return False

    # ==================== PASSWORD HISTORY PROTECTION ====================
    
    _password_history: List[str] = []
    _password_history_max = 5
    
    @classmethod
    def add_to_history(cls, password_hash: str) -> None:
        """Добавляет хеш пароля в историю"""
        try:
            cls._password_history.append(password_hash)
            if len(cls._password_history) > cls._password_history_max:
                cls._password_history = cls._password_history[-cls._password_history_max:]
        except (TypeError, ValueError) as e:
            logger.debug(f"Failed to add to history: {e}")
    
    @classmethod
    def is_password_reused(cls, password_hash: str) -> bool:
        """Проверяет, использовался ли пароль ранее"""
        return password_hash in cls._password_history
    
    @classmethod
    def clear_history(cls) -> None:
        """Очищает историю паролей"""
        cls._password_history = []
        logger.debug("Password history cleared")

    # ==================== 2FA ДОПОЛНЕНИЯ ====================
    
    @classmethod
    def set_config(cls, config) -> None:
        cls._cached_config = config
    
    @classmethod
    def is_2fa_required(cls) -> bool:
        if cls._cached_config is None:
            return False
        try:
            return cls._cached_config.is_2fa_enabled()
        except AttributeError:
            return False
    
    @classmethod
    def set_skip_2fa_once(cls, skip: bool) -> None:
        cls._skip_2fa_once = skip
    
    @classmethod
    def should_skip_2fa(cls) -> bool:
        if cls._skip_2fa_once:
            cls._skip_2fa_once = False
            return True
        return False
    
    @classmethod
    def verify_with_2fa(cls, password: str, source: str = "startup") -> Tuple[bool, Optional[str]]:
        if not cls.verify(password, source=source):
            return False, "master_password_incorrect"
        
        if not cls.is_2fa_required() or cls.should_skip_2fa():
            return True, None
        
        try:
            from security.totp import TOTP, get_totp_manager
            
            secret = cls._cached_config.get_2fa_secret()
            if not secret:
                logger.error("2FA enabled but no secret found")
                cls._log_audit_event("2fa_verification_failed", {"reason": "no_secret", "source": source})
                return False, "2fa_missing_secret"
            
            totp = TOTP(secret)
            
            from gui.dialogs import CTkInputDialog
            from localization.lang import LANGUAGES
            import customtkinter as ctk
            
            lang = cls._cached_config.get("LANG", "RU")
            L = LANGUAGES.get(lang, LANGUAGES["RU"])
            
            code = CTkInputDialog.ask(
                None,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_enter_code", "Enter verification code:"),
                show="",
                theme="dark",
                lang=lang
            )
            
            if code is None:
                cls._log_audit_event("2fa_verification_failed", {"reason": "cancelled", "source": source})
                return False, "2fa_cancelled"
            
            # Очищаем код от нецифровых символов
            code_clean = ''.join(filter(str.isdigit, str(code)))
            
            if totp.verify(code_clean)[0]:
                cls._log_audit_event("2fa_verification_success", {"source": source})
                return True, None
            
            manager = get_totp_manager()
            if manager.verify_backup_code(code_clean):
                cls._log_audit_event("2fa_backup_used", {"source": source})
                if cls._cached_config:
                    cls._cached_config.set_2fa_backup_hashes(manager.get_backup_codes_hashes())
                    cls._cached_config.save()
                return True, None
            
            cls._log_audit_event("2fa_verification_failed", {"reason": "invalid_code", "source": source})
            return False, "2fa_invalid_code"
            
        except ImportError as e:
            logger.error(f"Failed to import 2FA modules: {e}")
            return False, "2fa_module_error"
        except (ValueError, TypeError, AttributeError) as e:
            logger.error(f"2FA verification error: {e}")
            return False, "2fa_error"

    @classmethod
    def prompt_on_startup(cls, lang: str = "RU", theme: str = "dark") -> bool:
        """
        Запрос мастер-пароля при запуске.
        """
        _load_lockout_state()
        _load_audit_log()
        
        if not cls.is_set():
            return True

        try:
            import customtkinter as ctk
            from localization.lang import LANGUAGES
            from security.encryption import set_key_from_master
            from utils.helpers import center_screen
            from gui.dialogs import CTkMessageBox, CTkInputDialog
        except ImportError as e:
            logger.error(f"Failed to import GUI modules: {e}")
            return True

        L = LANGUAGES.get(lang, LANGUAGES.get("RU", {}))
        
        if theme == "light":
            bg_color = "#F3F3F3"
            fg_color = "#000000"
            entry_bg = "#FFFFFF"
            btn_fg = "#2d6a4f"
            btn_hover = "#40916c"
        else:
            bg_color = "#1d1e1e"
            fg_color = "#FFFFFF"
            entry_bg = "#2b2b2b"
            btn_fg = "#2d6a4f"
            btn_hover = "#40916c"

        root = ctk.CTk()
        root.title(L.get("master_title", "Master password"))
        root.resizable(False, False)
        root.configure(fg_color=bg_color)
        center_screen(root, 380, 280)

        result = {"ok": False}
        max_attempts = cls.MAX_ATTEMPTS
        is_closing = False

        main_frame = ctk.CTkFrame(root, fg_color="transparent")
        main_frame.pack(expand=True, fill="both", padx=25, pady=20)

        ctk.CTkLabel(
            main_frame,
            text="",
            font=("Segoe UI", 32),
            text_color="#4EC9B0"
        ).pack(pady=(0, 8))

        ctk.CTkLabel(
            main_frame,
            text=L.get("master_prompt", "Enter master password to access the program:"),
            font=("Segoe UI", 13),
            text_color=fg_color,
        ).pack(pady=(0, 12))

        entry = ctk.CTkEntry(
            main_frame,
            width=280,
            height=38,
            show="*",
            fg_color=entry_bg,
            text_color=fg_color,
            corner_radius=12,
        )
        entry.pack(pady=(0, 12))
        entry.focus_set()

        status = ctk.CTkLabel(
            main_frame, 
            text="", 
            font=("Segoe UI", 11), 
            text_color="#E24B4A",
            wraplength=300
        )
        status.pack(pady=(0, 8))

        btn_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        btn_frame.pack(pady=(10, 0))

        def update_status():
            if is_closing:
                return
            try:
                info = cls.get_lockout_info()
                if info['is_locked']:
                    status.configure(text=f"{L.get('lock_wait', 'Please wait')} {info['lockout_seconds']} {L.get('seconds_short', 'sec')}...")
                    entry.configure(state="disabled")
                    submit_btn.configure(state="disabled")
                    cancel_btn.configure(state="disabled")
                    root.after(1000, update_status)
                elif info['is_permanently_locked']:
                    status.configure(text=L.get("master_blocked", "Too many attempts. Program closed."))
                    entry.configure(state="disabled")
                    submit_btn.configure(state="disabled")
                    cancel_btn.configure(state="disabled")
                    root.after(2000, _safe_exit)
                else:
                    entry.configure(state="normal")
                    submit_btn.configure(state="normal")
                    cancel_btn.configure(state="normal")
                    if info['attempts'] > 0:
                        status.configure(text=L["master_wrong"].format(info['attempts'], max_attempts))
                    else:
                        status.configure(text="")
            except (KeyError, AttributeError, tk.TclError) as e:
                logger.debug(f"Update status error: {e}")
        
        def _safe_exit():
            nonlocal is_closing
            is_closing = True
            try:
                root.destroy()
            except tk.TclError:
                pass
            sys.exit(0)
        
        def finish_ok() -> None:
            if is_closing:
                return
            result["ok"] = True
            try:
                root.destroy()
            except tk.TclError:
                pass

        def cancel() -> None:
            nonlocal is_closing
            is_closing = True
            result["ok"] = False
            try:
                root.destroy()
            except tk.TclError:
                pass

        def submit() -> None:
            if is_closing:
                return
            
            if cls.get_remaining_lockout_time() > 0:
                update_status()
                return
            
            pwd = entry.get()
            if pwd:
                success, error_code = cls.verify_with_2fa(pwd, source="startup")
                
                if success:
                    try:
                        set_key_from_master(pwd)
                    except (ValueError, TypeError, RuntimeError) as e:
                        logger.error(f"Failed to set key from master: {e}")
                        return
                    finish_ok()
                    return
                elif error_code == "2fa_missing_secret":
                    logger.warning("2FA secret missing, disabling 2FA as fallback")
                    if cls._cached_config:
                        try:
                            cls._cached_config.set_2fa_enabled(False)
                            cls._cached_config.save()
                        except (AttributeError, OSError) as e:
                            logger.debug(f"Failed to disable 2FA: {e}")
                    if cls.verify(pwd, source="startup"):
                        try:
                            set_key_from_master(pwd)
                        except (ValueError, TypeError, RuntimeError) as e:
                            logger.error(f"Failed to set key from master: {e}")
                            return
                        finish_ok()
                        return
                elif error_code == "2fa_cancelled":
                    cancel()
                    return
                elif error_code == "2fa_invalid_code":
                    status.configure(text=L.get("2fa_invalid_code", "Invalid verification code"))
                    entry.delete(0, "end")
                    entry.focus_set()
                    return

            info = cls.get_lockout_info()
            if info['is_permanently_locked']:
                status.configure(text=L.get("master_blocked", "Too many attempts. Program closed."))
                entry.configure(state="disabled")
                submit_btn.configure(state="disabled")
                cancel_btn.configure(state="disabled")
                root.after(2000, _safe_exit)
            elif info['is_locked']:
                status.configure(text=f"{L.get('lock_wait', 'Please wait')} {info['lockout_seconds']} {L.get('seconds_short', 'sec')}...")
                entry.delete(0, "end")
                entry.configure(state="disabled")
                submit_btn.configure(state="disabled")
                cancel_btn.configure(state="disabled")
                root.after(1000, update_status)
            else:
                status.configure(text=L["master_wrong"].format(info['attempts'], max_attempts))
                entry.delete(0, "end")
                entry.focus_set()

        # Кнопка Разблокировать - слева
        submit_btn = ctk.CTkButton(
            btn_frame,
            text=L.get("unlock", "Unlock"),
            width=100,
            height=34,
            corner_radius=17,
            fg_color=btn_fg,
            hover_color=btn_hover,
            font=("Segoe UI", 12, "bold"),
            command=submit,
        )
        submit_btn.pack(side="left", padx=6)
        
        # Кнопка Закрыть - справа
        cancel_btn = ctk.CTkButton(
            btn_frame,
            text=L.get("close", "Close"),
            width=100,
            height=34,
            corner_radius=17,
            fg_color="#8b0000",
            hover_color="#cc0000",
            font=("Segoe UI", 12, "bold"),
            command=cancel,
        )
        cancel_btn.pack(side="left", padx=6)

        entry.bind("<Return>", lambda _e: submit())
        entry.bind("<Escape>", lambda _e: cancel())
        root.protocol("WM_DELETE_WINDOW", cancel)
        
        update_status()
        
        try:
            root.mainloop()
        except (KeyboardInterrupt, SystemExit) as e:
            logger.debug(f"Startup prompt interrupted: {e}")
            return False
        
        return result["ok"]