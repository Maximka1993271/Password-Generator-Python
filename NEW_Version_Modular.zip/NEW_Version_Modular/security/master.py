"""
Master password management with Argon2id and rate limiting
"""
import os
import sys
import ctypes
import hashlib
import hmac
import secrets
import time
import tempfile
from typing import Optional
try:
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError, VerificationError, InvalidHashError
    _ARGON2_OK = True
except ImportError:
    PasswordHasher = None
    VerifyMismatchError = VerificationError = InvalidHashError = Exception
    _ARGON2_OK = False

# ==================== PORTABLE PATH LOGIC ====================
if getattr(sys, 'frozen', False):
    _BASE_DIR = os.path.dirname(sys.executable)
else:
    _BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CONFIG_DIR = os.path.join(_BASE_DIR, "data")
MASTER_FILE = os.path.join(CONFIG_DIR, "master.key")
# =============================================================

_ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=4, hash_len=32) if _ARGON2_OK else None

# Rate limiting settings
MAX_ATTEMPTS = 5
LOCKOUT_TIMES = {  # seconds
    1: 0,      # 1 попытка -> без задержки
    2: 0,      # 2 попытки -> без задержки
    3: 5,      # 3 попытки -> 5 секунд
    4: 10,     # 4 попытки -> 10 секунд
    5: 30,     # 5 попыток -> 30 секунд
}


def _hide_dir(path: str) -> None:
    """Скрывает папку на Windows (атрибут Hidden)."""
    if sys.platform == "win32":
        try:
            ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
        except AttributeError:
            pass
        except OSError:
            pass


def _secure_write(path: str, data: bytes) -> None:
    """Write sensitive file atomically to avoid half-written master.key."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".tmp-", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
        if sys.platform == "win32":
            try:
                ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
            except AttributeError:
                pass
            except OSError:
                pass
        else:
            try:
                os.chmod(path, 0o600)
            except PermissionError:
                pass
            except OSError:
                pass
    except PermissionError as e:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        raise IOError(f"Cannot write to {path}: {e}")
    except OSError as e:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        raise IOError(f"OS error writing to {path}: {e}")


class MasterPassword:
    """Master password handler with Argon2id hashing and rate limiting"""

    MAX_ATTEMPTS = MAX_ATTEMPTS
    SALT_SIZE = 32
    PBKDF2_ITERATIONS = 600000
    USE_ARGON2 = _ARGON2_OK
    
    # Rate limiting state (class-level to persist across instances)
    _attempt_count = 0
    _last_attempt_time = 0
    _lockout_until = 0

    @classmethod
    def _get_lockout_delay(cls, attempts: int) -> int:
        """Get lockout delay in seconds based on attempt count"""
        return LOCKOUT_TIMES.get(attempts, LOCKOUT_TIMES[MAX_ATTEMPTS])
    
    @classmethod
    def _apply_rate_limit(cls) -> bool:
        """Apply rate limiting. Returns True if allowed, False if locked out."""
        current_time = time.time()
        
        # Check if currently locked out
        if cls._lockout_until > current_time:
            return False
        
        # Reset counter after successful login or long idle
        if current_time - cls._last_attempt_time > 300:  # 5 minutes idle
            cls._attempt_count = 0
        
        return True
    
    @classmethod
    def _record_failed_attempt(cls) -> int:
        """Record failed attempt and return lockout delay"""
        cls._attempt_count += 1
        cls._last_attempt_time = time.time()
        
        delay = cls._get_lockout_delay(cls._attempt_count)
        if delay > 0:
            cls._lockout_until = cls._last_attempt_time + delay
        
        return delay
    
    @classmethod
    def _reset_attempts(cls) -> None:
        """Reset attempt counter after successful login"""
        cls._attempt_count = 0
        cls._lockout_until = 0
        cls._last_attempt_time = 0
    
    @classmethod
    def get_remaining_lockout_time(cls) -> int:
        """Get remaining lockout time in seconds"""
        if cls._lockout_until <= time.time():
            return 0
        return int(cls._lockout_until - time.time())
    
    @classmethod
    def get_attempts_remaining(cls) -> int:
        """Get remaining attempts before lockout"""
        if cls._attempt_count >= MAX_ATTEMPTS:
            return 0
        return MAX_ATTEMPTS - cls._attempt_count
    
    @classmethod
    def get_lockout_info(cls) -> dict:
        """Get current lockout information"""
        return {
            'attempts': cls._attempt_count,
            'max_attempts': MAX_ATTEMPTS,
            'remaining_attempts': cls.get_attempts_remaining(),
            'lockout_seconds': cls.get_remaining_lockout_time(),
            'is_locked': cls.get_remaining_lockout_time() > 0
        }

    @classmethod
    def _derive_key_pbkdf2(cls, password: bytes, salt: bytes) -> bytes:
        return hashlib.pbkdf2_hmac('sha256', password, salt, cls.PBKDF2_ITERATIONS, dklen=32)

    @classmethod
    def _hash_argon2(cls, password: str) -> str:
        if not _ARGON2_OK or _ph is None:
            raise RuntimeError("Argon2 is not available")
        return _ph.hash(password)

    @classmethod
    def _verify_argon2(cls, password: str, stored_hash: str) -> bool:
        try:
            if not _ARGON2_OK or _ph is None:
                return False
            _ph.verify(stored_hash, password)
            return True
        except (VerifyMismatchError, VerificationError, InvalidHashError):
            return False

    @classmethod
    def is_set(cls) -> bool:
        return os.path.exists(MASTER_FILE)

    @classmethod
    def verify(cls, password: str) -> bool:
        """Verify master password with rate limiting"""
        # Check rate limiting first
        if not cls._apply_rate_limit():
            return False
        
        if not cls.is_set():
            cls._reset_attempts()
            return True
        
        try:
            with open(MASTER_FILE, 'rb') as f:
                version = f.read(1)
                if version == b'\x02':
                    stored_hash = f.read().decode('utf-8')
                    result = cls._verify_argon2(password, stored_hash)
                elif version == b'\x01':
                    salt = f.read(cls.SALT_SIZE)
                    stored_hash = f.read()
                    if len(salt) != cls.SALT_SIZE or len(stored_hash) != 32:
                        result = False
                    else:
                        derived = cls._derive_key_pbkdf2(password.encode('utf-8'), salt)
                        result = hmac.compare_digest(derived, stored_hash)
                else:
                    result = False
        except (OSError, IOError, ValueError) as e:
            print(f"[Master] Error reading master file: {e}")
            result = False
        
        if result:
            cls._reset_attempts()
        else:
            cls._record_failed_attempt()
        
        return result

    @classmethod
    def set_password(cls, password: str) -> None:
        if not password:
            raise ValueError("Master password must not be empty")

        os.makedirs(CONFIG_DIR, exist_ok=True)
        _hide_dir(CONFIG_DIR)

        if cls.USE_ARGON2:
            hashed = cls._hash_argon2(password)
            _secure_write(MASTER_FILE, b'\x02' + hashed.encode('utf-8'))
        else:
            salt = secrets.token_bytes(cls.SALT_SIZE)
            derived = cls._derive_key_pbkdf2(password.encode('utf-8'), salt)
            _secure_write(MASTER_FILE, b'\x01' + salt + derived)
        
        # Reset rate limiting on successful set
        cls._reset_attempts()

    @classmethod
    def remove(cls) -> None:
        try:
            os.remove(MASTER_FILE)
        except (OSError, IOError):
            pass
        cls._reset_attempts()

    @classmethod
    def prompt_on_startup(cls, lang: str = "RU", theme: str = "dark") -> bool:
        """Ask for the master password before the main window is created."""
        if not cls.is_set():
            return True

        try:
            import customtkinter as ctk
            from localization.lang import LANGUAGES
            from security.encryption import set_key_from_master
            from utils.helpers import center_screen, get_global_radius
        except ImportError as e:
            print(f"[Master] Import error: {e}")
            return False

        L = LANGUAGES.get(lang, LANGUAGES.get("RU", {}))
        colors = {
            "light": {"bg": "#F3F3F3", "fg": "#000000", "entry": "#FFFFFF"},
            "dark": {"bg": "#1d1e1e", "fg": "#FFFFFF", "entry": "#2b2b2b"},
        }.get(theme, {"bg": "#1d1e1e", "fg": "#FFFFFF", "entry": "#2b2b2b"})

        root = ctk.CTk()
        root.title(L.get("master_title", "Master password"))
        root.resizable(False, False)
        root.configure(fg_color=colors["bg"])
        center_screen(root, 430, 300)

        result = {"ok": False}
        max_attempts = cls.MAX_ATTEMPTS

        ctk.CTkLabel(
            root,
            text=L.get("master_prompt", "Enter master password:"),
            font=("Segoe UI", 14),
            text_color=colors["fg"],
            wraplength=360,
        ).pack(padx=20, pady=(24, 10))

        entry = ctk.CTkEntry(
            root,
            width=350,
            height=40,
            show="*",
            fg_color=colors["entry"],
            text_color=colors["fg"],
            corner_radius=get_global_radius(),
        )
        entry.pack(padx=20, pady=(0, 8))

        status = ctk.CTkLabel(root, text="", font=("Segoe UI", 12), text_color="#E24B4A")
        status.pack(pady=(0, 10))

        def update_status():
            info = cls.get_lockout_info()
            if info['is_locked']:
                status.configure(text=f"⏳ {L.get('lock_wait', 'Подождите')} {info['lockout_seconds']} {L.get('seconds_short', 'сек')}...")
                entry.configure(state="disabled")
                submit_btn.configure(state="disabled")
                root.after(1000, update_status)
            else:
                entry.configure(state="normal")
                submit_btn.configure(state="normal")
                if info['attempts'] > 0:
                    status.configure(text=L["master_wrong"].format(info['attempts'], max_attempts))
                else:
                    status.configure(text="")
        
        def finish_ok() -> None:
            result["ok"] = True
            root.destroy()

        def cancel() -> None:
            result["ok"] = False
            root.destroy()

        def submit() -> None:
            # Check lockout before trying
            if cls.get_remaining_lockout_time() > 0:
                update_status()
                return
            
            pwd = entry.get()
            if cls.verify(pwd):
                set_key_from_master(pwd)
                finish_ok()
                return

            # Update status after failed attempt
            info = cls.get_lockout_info()
            if info['is_locked']:
                status.configure(text=f"⏳ {L.get('lock_wait', 'Подождите')} {info['lockout_seconds']} {L.get('seconds_short', 'сек')}...")
                entry.delete(0, "end")
                entry.configure(state="disabled")
                submit_btn.configure(state="disabled")
                root.after(1000, update_status)
            else:
                status.configure(text=L["master_wrong"].format(info['attempts'], max_attempts))
                entry.delete(0, "end")
                entry.focus_set()

        buttons = ctk.CTkFrame(root, fg_color="transparent")
        buttons.pack(pady=(0, 18))
        
        submit_btn = ctk.CTkButton(
            buttons,
            text=L.get("ok", "OK"),
            width=120,
            height=36,
            fg_color="#2d6a4f",
            command=submit,
        )
        submit_btn.pack(side="left", padx=8)
        
        ctk.CTkButton(
            buttons,
            text=L.get("cancel", "Cancel"),
            width=120,
            height=36,
            fg_color="#8b0000",
            command=cancel,
        ).pack(side="left", padx=8)

        entry.bind("<Return>", lambda _e: submit())
        entry.bind("<Escape>", lambda _e: cancel())
        root.protocol("WM_DELETE_WINDOW", cancel)
        root.after(100, entry.focus_set)
        root.mainloop()
        return result["ok"]