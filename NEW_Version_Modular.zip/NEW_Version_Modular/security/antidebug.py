"""
Anti-debugging and anti-analysis protection for SecurePassPro

ВАЖНО: Anti-debugging в Python:
- Никогда не будет полностью надёжным
- Опытный reverse engineer обойдёт его
- Это дополнительный слой защиты, а не основная безопасность

Но как дополнительный слой защиты — очень хорошо.
"""

import sys
import os
import ctypes
import platform
import subprocess
import time
import hashlib
import threading
from typing import Tuple, List, Optional, Dict, Any
from utils.logger import get_logger

logger = get_logger("antidebug")

# Глобальное состояние
_debug_detected = False
_vm_detected = False
_integrity_verified = False
_self_check_timer: Optional[threading.Timer] = None


class AntiDebugError(Exception):
    """Исключение при обнаружении отладки"""
    pass


# ==================== ОСНОВНЫЕ ФУНКЦИИ ОБНАРУЖЕНИЯ ====================

def is_debugger_present() -> bool:
    """Check if debugger is attached (Windows only)"""
    global _debug_detected
    
    if platform.system() != "Windows":
        return False
    
    try:
        kernel32 = ctypes.windll.kernel32
        if kernel32.IsDebuggerPresent():
            logger.warning("Debugger detected via IsDebuggerPresent")
            _debug_detected = True
            return True
        
        ntdll = ctypes.windll.ntdll
        if ntdll.NtQueryInformationProcess:
            PROCESS_INFO_CLASS = 0x7
            debug_port = ctypes.c_void_p()
            size = ctypes.sizeof(debug_port)
            status = ntdll.NtQueryInformationProcess(
                ctypes.windll.kernel32.GetCurrentProcess(),
                PROCESS_INFO_CLASS,
                ctypes.byref(debug_port),
                size,
                None
            )
            if status == 0 and debug_port.value is not None:
                logger.warning("Debugger detected via NtQueryInformationProcess")
                _debug_detected = True
                return True
    except (AttributeError, OSError, TypeError, ValueError) as e:
        logger.debug(f"Debugger check failed: {e}")
    
    return False


def check_debug_registers() -> bool:
    """Check debug registers for hardware breakpoints (Windows only)"""
    if platform.system() != "Windows":
        return False
    
    try:
        # Проверка на наличие аппаратных точек останова
        # через контекст потока
        import ctypes.wintypes
        
        CONTEXT_DEBUG_REGISTERS = 0x10010
        DR0_OFFSET = 0x04
        DR1_OFFSET = 0x08
        DR2_OFFSET = 0x0C
        DR3_OFFSET = 0x10
        
        kernel32 = ctypes.windll.kernel32
        current_thread = kernel32.GetCurrentThread()
        
        # Получаем контекст потока
        class CONTEXT(ctypes.Structure):
            _fields_ = [
                ("ContextFlags", ctypes.c_uint32),
                ("Dr0", ctypes.c_uint32),
                ("Dr1", ctypes.c_uint32),
                ("Dr2", ctypes.c_uint32),
                ("Dr3", ctypes.c_uint32),
                ("Dr6", ctypes.c_uint32),
                ("Dr7", ctypes.c_uint32),
            ]
        
        context = CONTEXT()
        context.ContextFlags = CONTEXT_DEBUG_REGISTERS
        
        if kernel32.GetThreadContext(current_thread, ctypes.byref(context)):
            if context.Dr0 != 0 or context.Dr1 != 0 or context.Dr2 != 0 or context.Dr3 != 0:
                logger.warning("Hardware breakpoint detected")
                return True
    except Exception as e:
        logger.debug(f"Debug registers check failed: {e}")
    
    return False


def is_debugger_present_silent() -> bool:
    """Silent version of debugger detection (no logging)"""
    if platform.system() != "Windows":
        return False
    
    try:
        kernel32 = ctypes.windll.kernel32
        if kernel32.IsDebuggerPresent():
            return True
    except (AttributeError, OSError, TypeError):
        pass
    
    return False


# ==================== VM DETECTION ====================

def is_vm_detected() -> bool:
    """Basic VM detection (VMware, VirtualBox, Hyper-V)"""
    global _vm_detected
    
    vm_indicators = [
        "vbox", "vmware", "virtual", "hyper-v", 
        "qemu", "bochs", "parallels", "xen",
        "kvm", "virtualbox", "oracle"
    ]
    
    try:
        if platform.system() == "Windows":
            result = subprocess.run(
                ["wmic", "bios", "get", "serialnumber"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                bios = result.stdout.lower()
                for indicator in vm_indicators:
                    if indicator in bios:
                        logger.warning(f"VM detected via BIOS: {indicator}")
                        _vm_detected = True
                        return True
    except (subprocess.SubprocessError, FileNotFoundError, TimeoutError, OSError) as e:
        logger.debug(f"BIOS VM detection failed: {e}")
    
    try:
        import uuid
        mac = uuid.getnode()
        mac_str = format(mac, '012x')
        vm_macs = ['000569', '000c29', '001c42', '005056', '080027', '525400', '00ffaa']
        for vm_mac in vm_macs:
            if mac_str.startswith(vm_mac):
                logger.warning(f"VM detected via MAC: {vm_mac}")
                _vm_detected = True
                return True
    except (ValueError, TypeError, AttributeError, OSError) as e:
        logger.debug(f"MAC VM detection failed: {e}")
    
    # Проверка CPU
    try:
        cpu_count = os.cpu_count() or 0
        if cpu_count <= 1:
            logger.warning(f"VM detected via CPU count: {cpu_count}")
            _vm_detected = True
            return True
    except (ValueError, TypeError) as e:
        logger.debug(f"CPU count detection failed: {e}")
    
    # Проверка через cpuid (VMware/VirtualBox)
    try:
        if platform.system() == "Windows":
            import ctypes
            # Проверка гипервизора через cpuid
            # Это сложно в Python, используем альтернативы
            pass
    except Exception:
        pass
    
    return False


def is_vm_detected_silent() -> bool:
    """Silent version of VM detection (no logging)"""
    vm_indicators = ["vbox", "vmware", "virtual", "hyper-v", "qemu", "bochs", "parallels", "xen"]
    
    try:
        if platform.system() == "Windows":
            result = subprocess.run(
                ["wmic", "bios", "get", "serialnumber"],
                capture_output=True, text=True, timeout=3
            )
            if result.returncode == 0:
                bios = result.stdout.lower()
                for indicator in vm_indicators:
                    if indicator in bios:
                        return True
    except (subprocess.SubprocessError, FileNotFoundError, TimeoutError, OSError):
        pass
    
    try:
        import uuid
        mac = uuid.getnode()
        mac_str = format(mac, '012x')
        vm_macs = ['000569', '000c29', '001c42', '005056', '080027']
        for vm_mac in vm_macs:
            if mac_str.startswith(vm_mac):
                return True
    except (ValueError, TypeError, AttributeError, OSError):
        pass
    
    return False


def detect_hypervisor() -> bool:
    """Detect hypervisor presence"""
    try:
        if platform.system() == "Windows":
            result = subprocess.run(
                ["systeminfo", "|", "findstr", "/i", "hypervisor"],
                shell=True, capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0 and "Hyper-V" in result.stdout:
                logger.warning("Hyper-V detected")
                return True
    except (subprocess.SubprocessError, TimeoutError, OSError):
        pass
    
    return False


# ==================== INTEGRITY SELF-CHECKS ====================

def calculate_file_hash(file_path: str) -> Optional[str]:
    """Calculate SHA-256 hash of a file"""
    try:
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    except (OSError, IOError, PermissionError) as e:
        logger.debug(f"File hash calculation failed: {e}")
        return None


def verify_file_integrity(file_path: str, expected_hash: Optional[str] = None) -> bool:
    """Verify file integrity against expected hash"""
    if not os.path.exists(file_path):
        logger.warning(f"File not found: {file_path}")
        return False
    
    if expected_hash is None:
        # Если хеш не указан, считаем файл валидным
        return True
    
    actual_hash = calculate_file_hash(file_path)
    if actual_hash is None:
        return False
    
    import hmac
    if hmac.compare_digest(actual_hash.lower(), expected_hash.lower()):
        return True
    else:
        logger.warning(f"File integrity check failed: {file_path}")
        return False


def perform_self_check() -> bool:
    """Perform integrity self-check on critical files"""
    global _integrity_verified
    
    critical_files = [
        ("security/antidebug.py", None),
        ("security/encryption.py", None),
        ("security/master.py", None),
    ]
    
    all_valid = True
    for file_path, expected_hash in critical_files:
        if not verify_file_integrity(file_path, expected_hash):
            all_valid = False
    
    _integrity_verified = all_valid
    return all_valid


# ==================== КОМПЛЕКСНЫЕ ПРОВЕРКИ ====================

def is_debugged() -> Tuple[bool, List[str]]:
    """Comprehensive debug detection"""
    checks = []
    
    try:
        if is_debugger_present():
            checks.append("Debugger detected")
        
        if check_debug_registers():
            checks.append("Hardware breakpoint detected")
        
        debug_env_vars = ['PYCHARM_HOSTED', 'PYDEV_CONSOLE_ENCODING', 'DEBUGPY_LAUNCHER']
        for var in debug_env_vars:
            try:
                if os.environ.get(var):
                    checks.append(f"Debug environment: {var}")
                    break
            except (KeyError, TypeError) as e:
                logger.debug(f"Env var check failed for {var}: {e}")
    except (KeyError, TypeError, AttributeError) as e:
        logger.debug(f"Debug env check failed: {e}")
    
    return len(checks) > 0, checks


def is_sandboxed() -> bool:
    """Detect sandbox/VM environment"""
    indicators = []
    
    # Check for small disk size (typical for VMs)
    try:
        import shutil
        total, used, free = shutil.disk_usage("/")
        if total < 50 * 1024 * 1024 * 1024:  # Less than 50GB
            indicators.append("small_disk")
    except Exception:
        pass
    
    # Check for limited memory
    try:
        import psutil
        mem = psutil.virtual_memory()
        if mem.total < 2 * 1024 * 1024 * 1024:  # Less than 2GB
            indicators.append("low_memory")
    except ImportError:
        pass
    
    return len(indicators) >= 2


# ==================== ЗАЩИТНЫЕ МЕРЫ ====================

def protect_from_debugging() -> None:
    """Apply anti-debugging measures"""
    try:
        debugged, reasons = is_debugged()
        
        if debugged:
            logger.warning(f"Anti-debugging: {', '.join(reasons)}")
            time.sleep(2)
            
    except (ImportError, AttributeError, OSError, TimeoutError) as e:
        logger.error(f"Anti-debugging failed: {e}")


def protect_from_timing_analysis() -> None:
    """Protect against timing analysis"""
    try:
        import random
        delay = random.uniform(0.001, 0.01)
        time.sleep(delay)
    except (ImportError, ValueError) as e:
        logger.debug(f"Timing analysis protection failed: {e}")


def detect_ptrace() -> bool:
    """Detect ptrace (Linux anti-debugging)"""
    if platform.system() != "Linux":
        return False
    
    try:
        import fcntl
        return False
    except ImportError:
        return True


# ==================== ФОНОВЫЕ ПРОВЕРКИ ====================

def _background_self_check() -> None:
    """Background thread for periodic self-checks"""
    global _self_check_timer
    
    try:
        perform_self_check()
        is_vm_detected()
        is_debugger_present()
    except Exception as e:
        logger.debug(f"Background self-check error: {e}")
    
    # Запускаем следующую проверку через 30 секунд
    _self_check_timer = threading.Timer(30.0, _background_self_check)
    _self_check_timer.daemon = True
    _self_check_timer.start()


def start_background_checks(interval: int = 30) -> None:
    """Start background anti-debug checks"""
    global _self_check_timer
    
    if _self_check_timer is not None:
        return
    
    _self_check_timer = threading.Timer(interval, _background_self_check)
    _self_check_timer.daemon = True
    _self_check_timer.start()
    logger.info(f"Background anti-debug checks started (interval: {interval}s)")


def stop_background_checks() -> None:
    """Stop background anti-debug checks"""
    global _self_check_timer
    
    if _self_check_timer:
        _self_check_timer.cancel()
        _self_check_timer = None
        logger.info("Background anti-debug checks stopped")


def get_detection_status() -> Dict[str, Any]:
    """Get current detection status"""
    return {
        "debug_detected": _debug_detected,
        "vm_detected": _vm_detected,
        "integrity_verified": _integrity_verified,
        "platform": platform.system(),
        "python_version": sys.version,
    }


def reset_detection_state() -> None:
    """Reset detection state (for testing)"""
    global _debug_detected, _vm_detected, _integrity_verified
    _debug_detected = False
    _vm_detected = False
    _integrity_verified = False


# ==================== ИНИЦИАЛИЗАЦИЯ ====================

def init_anti_debug(enable_background_checks: bool = False) -> None:
    """Initialize all anti-debugging protections"""
    try:
        protect_from_debugging()
        protect_from_timing_analysis()
        
        if enable_background_checks:
            start_background_checks()
        
        logger.debug("Anti-debugging protections initialized")
    except Exception as e:
        logger.error(f"Anti-debug init failed: {e}")


# ==================== LEGACY FUNCTIONS ====================

def is_debugger_present_legacy() -> bool:
    """Legacy function name for backward compatibility"""
    return is_debugger_present()


def is_vm_detected_legacy() -> bool:
    """Legacy function name for backward compatibility"""
    return is_vm_detected()


# Экспорт
__all__ = [
    'is_debugger_present',
    'is_debugger_present_silent',
    'check_debug_registers',
    'is_vm_detected',
    'is_vm_detected_silent',
    'detect_hypervisor',
    'detect_ptrace',
    'is_debugged',
    'is_sandboxed',
    'protect_from_debugging',
    'protect_from_timing_analysis',
    'perform_self_check',
    'verify_file_integrity',
    'calculate_file_hash',
    'start_background_checks',
    'stop_background_checks',
    'get_detection_status',
    'reset_detection_state',
    'init_anti_debug',
    'is_debugger_present_legacy',
    'is_vm_detected_legacy',
    'AntiDebugError',
]