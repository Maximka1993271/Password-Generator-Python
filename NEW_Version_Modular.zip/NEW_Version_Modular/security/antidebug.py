"""
Anti-debugging and anti-analysis protection for SecurePassPro
"""
import sys
import os
import ctypes
import platform
from utils.logger import get_logger

logger = get_logger("antidebug")


def is_debugger_present() -> bool:
    """Check if debugger is attached (Windows only)"""
    if platform.system() != "Windows":
        return False
    
    try:
        kernel32 = ctypes.windll.kernel32
        if kernel32.IsDebuggerPresent():
            logger.warning("Debugger detected via IsDebuggerPresent")
            return True
        
        ntdll = ctypes.windll.ntdll
        if ntdll.NtQueryInformationProcess:
            PROCESS_INFO_CLASS = 0x7
            debug_port = ctypes.c_void_p()
            size = ctypes.sizeof(debug_port)
            status = ntdll.NtQueryInformationProcess(
                ctypes.windll.kernel32.GetCurrentProcess(),
                PROCESS_INFO_CLASS,
                ctypes.byref(debug_port),
                size,
                None
            )
            if status == 0 and debug_port.value is not None:
                logger.warning("Debugger detected via NtQueryInformationProcess")
                return True
    except (AttributeError, OSError, TypeError) as e:
        logger.debug(f"Debugger check failed: {e}")
    
    return False


def is_vm_detected() -> bool:
    """Basic VM detection (VMware, VirtualBox, Hyper-V)"""
    vm_indicators = [
        "vbox", "vmware", "virtual", "hyper-v", 
        "qemu", "bochs", "parallels", "xen"
    ]
    
    try:
        if platform.system() == "Windows":
            import subprocess
            result = subprocess.run(
                ["wmic", "bios", "get", "serialnumber"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                bios = result.stdout.lower()
                for indicator in vm_indicators:
                    if indicator in bios:
                        logger.warning(f"VM detected via BIOS: {indicator}")
                        return True
        
        import uuid
        mac = uuid.getnode()
        mac_str = format(mac, '012x')
        vm_macs = ['000569', '000c29', '001c42', '005056', '080027']
        for vm_mac in vm_macs:
            if mac_str.startswith(vm_mac):
                logger.warning(f"VM detected via MAC: {vm_mac}")
                return True
        
        cpu_count = os.cpu_count() or 0
        if cpu_count <= 1:
            logger.warning(f"VM detected via CPU count: {cpu_count}")
            return True
        
    except (subprocess.SubprocessError, OSError, ValueError, AttributeError) as e:
        logger.debug(f"VM detection failed: {e}")
    
    return False


def is_debugged() -> tuple[bool, list]:
    """Comprehensive debug detection"""
    checks = []
    
    try:
        if is_debugger_present():
            checks.append("Debugger detected")
        
        debug_env_vars = ['PYCHARM_HOSTED', 'PYDEV_CONSOLE_ENCODING', 'DEBUGPY_LAUNCHER']
        for var in debug_env_vars:
            if os.environ.get(var):
                checks.append(f"Debug environment: {var}")
                break
    except (KeyError, TypeError) as e:
        logger.debug(f"Debug env check failed: {e}")
    
    return len(checks) > 0, checks


def protect_from_debugging() -> None:
    """Apply anti-debugging measures"""
    try:
        debugged, reasons = is_debugged()
        
        if debugged:
            logger.warning(f"Anti-debugging: {', '.join(reasons)}")
            import time
            time.sleep(2)
            
    except (ImportError, AttributeError, OSError) as e:
        logger.error(f"Anti-debugging failed: {e}")


def init_anti_debug() -> None:
    """Initialize all anti-debugging protections"""
    try:
        protect_from_debugging()
    except Exception as e:
        logger.error(f"Anti-debug init failed: {e}")