"""
Anti-debugging and anti-analysis protection for SecurePassPro

ВАЖНО: Anti-debugging в Python:
- Никогда не будет полностью надёжным
- Опытный reverse engineer обойдёт его
- Это дополнительный слой защиты, а не основная безопасность

Но как дополнительный слой защиты — очень хорошо.

Anti-debugging and anti-analysis protection for SecurePassPro
IMPORTANT: Anti-debugging in Python:
- Will never be completely reliable
- An experienced reverse engineer will bypass it
- This is an additional layer of protection, not the main security

But as an additional layer of protection - it's very good.

Анти-відлагодження та анти-аналіз для SecurePassPro
ВАЖЛИВО: Анти-відлагодження в Python:
- Ніколи не буде повністю надійним
- Досвідчений reverse engineer обійде його
- Це додатковий шар захисту, а не основна безпека

Але як додатковий шар захисту - це дуже добре.
"""

import sys
import os
import ctypes
import platform
import subprocess
import time
import hashlib
import threading
from typing import Tuple, List, Optional, Dict, Any
from utils.logger import get_logger

logger = get_logger("antidebug")

# Global state / Глобальное состояние / Глобальний стан
_debug_detected = False
_vm_detected = False
_sandbox_detected = False
_integrity_verified = False
_self_check_timer: Optional[threading.Timer] = None


class AntiDebugError(Exception):
    """Exception when debugger is detected / Исключение при обнаружении отладки / Виняток при виявленні відлагодження"""
    pass


# ==================== MAIN DETECTION FUNCTIONS / ОСНОВНЫЕ ФУНКЦИИ ОБНАРУЖЕНИЯ / ОСНОВНІ ФУНКЦІЇ ВИЯВЛЕННЯ ====================

def is_debugger_present() -> bool:
    """Check if debugger is attached (Windows only)
    Проверить, подключён ли отладчик (только Windows)
    Перевірити, чи підключений відлагоджувач (тільки Windows)"""
    global _debug_detected
    
    if platform.system() != "Windows":
        return False
    
    try:
        kernel32 = ctypes.windll.kernel32
        if kernel32.IsDebuggerPresent():
            logger.warning("Debugger detected via IsDebuggerPresent")
            _debug_detected = True
            return True
        
        ntdll = ctypes.windll.ntdll
        if ntdll.NtQueryInformationProcess:
            PROCESS_INFO_CLASS = 0x7
            debug_port = ctypes.c_void_p()
            size = ctypes.sizeof(debug_port)
            status = ntdll.NtQueryInformationProcess(
                ctypes.windll.kernel32.GetCurrentProcess(),
                PROCESS_INFO_CLASS,
                ctypes.byref(debug_port),
                size,
                None
            )
            if status == 0 and debug_port.value is not None:
                logger.warning("Debugger detected via NtQueryInformationProcess")
                _debug_detected = True
                return True
    except (AttributeError, OSError, TypeError, ValueError) as e:
        logger.debug(f"Debugger check failed: {e}")
    
    return False


def check_debug_registers() -> bool:
    """Check debug registers for hardware breakpoints (Windows only)
    Проверить регистры отладки на наличие аппаратных точек останова (только Windows)
    Перевірити регістри відлагодження на наявність апаратних точок зупину (тільки Windows)"""
    if platform.system() != "Windows":
        return False
    
    try:
        # Check for hardware breakpoints / Проверка на наличие аппаратных точек останова / Перевірка на наявність апаратних точок зупину
        import ctypes.wintypes
        
        CONTEXT_DEBUG_REGISTERS = 0x10010
        
        kernel32 = ctypes.windll.kernel32
        current_thread = kernel32.GetCurrentThread()
        
        # Get thread context / Получаем контекст потока / Отримуємо контекст потоку
        class CONTEXT(ctypes.Structure):
            _fields_ = [
                ("ContextFlags", ctypes.c_uint32),
                ("Dr0", ctypes.c_uint32),
                ("Dr1", ctypes.c_uint32),
                ("Dr2", ctypes.c_uint32),
                ("Dr3", ctypes.c_uint32),
                ("Dr6", ctypes.c_uint32),
                ("Dr7", ctypes.c_uint32),
            ]
        
        context = CONTEXT()
        context.ContextFlags = CONTEXT_DEBUG_REGISTERS
        
        if kernel32.GetThreadContext(current_thread, ctypes.byref(context)):
            if context.Dr0 != 0 or context.Dr1 != 0 or context.Dr2 != 0 or context.Dr3 != 0:
                logger.warning("Hardware breakpoint detected")
                return True
    except (AttributeError, OSError, TypeError, ValueError) as e:
        logger.debug(f"Debug registers check failed: {e}")
    
    return False


def is_debugger_present_silent() -> bool:
    """Silent version of debugger detection (no logging)
    Тихая версия обнаружения отладчика (без логирования)
    Тиха версія виявлення відлагоджувача (без логування)"""
    if platform.system() != "Windows":
        return False
    
    try:
        kernel32 = ctypes.windll.kernel32
        if kernel32.IsDebuggerPresent():
            return True
    except (AttributeError, OSError, TypeError):
        pass
    
    return False


def check_parent_process() -> bool:
    """Check if parent process is a debugger (Windows only)
    Проверить, является ли родительский процесс отладчиком
    Перевірити, чи є батьківський процес відлагоджувачем"""
    if platform.system() != "Windows":
        return False
    
    try:
        import ctypes.wintypes
        
        kernel32 = ctypes.windll.kernel32
        psapi = ctypes.windll.psapi
        
        current_pid = kernel32.GetCurrentProcessId()
        
        # Get parent process ID
        # Получаем ID родительского процесса
        # Отримуємо ID батьківського процесу
        class PROCESSENTRY32(ctypes.Structure):
            _fields_ = [
                ("dwSize", ctypes.wintypes.DWORD),
                ("cntUsage", ctypes.wintypes.DWORD),
                ("th32ProcessID", ctypes.wintypes.DWORD),
                ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
                ("th32ModuleID", ctypes.wintypes.DWORD),
                ("cntThreads", ctypes.wintypes.DWORD),
                ("th32ParentProcessID", ctypes.wintypes.DWORD),
                ("pcPriClassBase", ctypes.c_long),
                ("dwFlags", ctypes.wintypes.DWORD),
                ("szExeFile", ctypes.c_char * 260)
            ]
        
        hSnapshot = kernel32.CreateToolhelp32Snapshot(0x00000002, 0)
        if hSnapshot:
            entry = PROCESSENTRY32()
            entry.dwSize = ctypes.sizeof(PROCESSENTRY32)
            
            if kernel32.Process32First(hSnapshot, ctypes.byref(entry)):
                while True:
                    if entry.th32ProcessID == current_pid:
                        parent_pid = entry.th32ParentProcessID
                        break
                    if not kernel32.Process32Next(hSnapshot, ctypes.byref(entry)):
                        break
            
            kernel32.CloseHandle(hSnapshot)
            
            # Check if parent is a known debugger
            # Проверяем, является ли родитель известным отладчиком
            # Перевіряємо, чи є батько відомим відлагоджувачем
            debugger_processes = [
                "devenv.exe", "ollydbg.exe", "x64dbg.exe", "x32dbg.exe",
                "ida.exe", "ida64.exe", "windbg.exe", "gdb.exe", "lldb.exe",
                "pydevd.py", "pycharm64.exe", "pycharm.exe", "vscode.exe"
            ]
            
            hProcess = kernel32.OpenProcess(0x0400 | 0x0010, False, parent_pid)
            if hProcess:
                exe_name = ctypes.create_string_buffer(260)
                psapi.GetModuleBaseNameA(hProcess, None, exe_name, 260)
                kernel32.CloseHandle(hProcess)
                
                parent_name = exe_name.value.decode('latin-1', errors='ignore').lower()
                for debugger in debugger_processes:
                    if debugger in parent_name:
                        logger.warning(f"Parent process is debugger: {parent_name}")
                        return True
    except (AttributeError, OSError, TypeError, ValueError) as e:
        logger.debug(f"Parent process check failed: {e}")
    
    return False


def check_debug_env() -> List[str]:
    """Check for debug environment variables
    Проверка переменных окружения на наличие отладчиков
    Перевірка змінних середовища на наявність відлагоджувачів"""
    debug_indicators = []
    debug_env_vars = [
        'PYCHARM_HOSTED', 'PYDEV_CONSOLE_ENCODING', 'DEBUGPY_LAUNCHER',
        'PYTEST_CURRENT_TEST', 'PYTHONDEBUG', 'PYTHONVERBOSE'
    ]
    
    for var in debug_env_vars:
        try:
            if os.environ.get(var):
                debug_indicators.append(var)
        except (KeyError, TypeError) as e:
            logger.debug(f"Env var check failed for {var}: {e}")
    
    return debug_indicators


# ==================== VM DETECTION / ОБНАРУЖЕНИЕ VM / ВИЯВЛЕННЯ VM ====================

def is_vm_detected() -> bool:
    """Basic VM detection (VMware, VirtualBox, Hyper-V)
    Базовое обнаружение VM (VMware, VirtualBox, Hyper-V)
    Базове виявлення VM (VMware, VirtualBox, Hyper-V)"""
    global _vm_detected
    
    # Если уже обнаружено, не проверяем заново
    if _vm_detected:
        return True
    
    vm_indicators = [
        "vbox", "vmware", "virtual", "hyper-v", 
        "qemu", "bochs", "parallels", "xen",
        "kvm", "virtualbox", "oracle"
    ]
    
    try:
        if platform.system() == "Windows":
            result = subprocess.run(
                ["wmic", "bios", "get", "serialnumber"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                bios = result.stdout.lower()
                for indicator in vm_indicators:
                    if indicator in bios:
                        logger.warning(f"VM detected via BIOS: {indicator}")
                        _vm_detected = True
                        return True
    except (subprocess.SubprocessError, FileNotFoundError, TimeoutError, OSError) as e:
        logger.debug(f"BIOS VM detection failed: {e}")
    
    try:
        import uuid
        mac = uuid.getnode()
        mac_str = format(mac, '012x')
        vm_macs = ['000569', '000c29', '001c42', '005056', '080027', '525400', '00ffaa']
        for vm_mac in vm_macs:
            if mac_str.startswith(vm_mac):
                logger.warning(f"VM detected via MAC: {vm_mac}")
                _vm_detected = True
                return True
    except (ValueError, TypeError, AttributeError, OSError) as e:
        logger.debug(f"MAC VM detection failed: {e}")
    
    # Check CPU / Проверка CPU / Перевірка CPU
    try:
        cpu_count = os.cpu_count() or 0
        if cpu_count <= 1:
            logger.warning(f"VM detected via CPU count: {cpu_count}")
            _vm_detected = True
            return True
    except (ValueError, TypeError) as e:
        logger.debug(f"CPU count detection failed: {e}")
    
    # Check total RAM (VMs often have limited RAM)
    # Проверка ОЗУ (VM часто имеют ограниченную память)
    # Перевірка ОЗП (VM часто мають обмежену пам'ять)
    try:
        import psutil
        mem = psutil.virtual_memory()
        if mem.total < 2 * 1024 * 1024 * 1024:  # Less than 2GB
            logger.warning(f"VM detected via low memory: {mem.total / (1024**3):.1f} GB")
            _vm_detected = True
            return True
    except ImportError:
        pass
    except (ValueError, AttributeError, OSError) as e:
        logger.debug(f"RAM detection failed: {e}")
    
    # Check for small disk size
    # Проверка малого размера диска
    # Перевірка малого розміру диска
    try:
        import shutil
        total, used, free = shutil.disk_usage("/")
        if total < 50 * 1024 * 1024 * 1024:  # Less than 50GB
            logger.warning(f"VM detected via small disk: {total / (1024**3):.1f} GB")
            _vm_detected = True
            return True
    except (OSError, ValueError, AttributeError) as e:
        logger.debug(f"Disk size detection failed: {e}")
    
    # Check for VMware/VirtualBox specific files
    # Проверка специфических файлов VMware/VirtualBox
    # Перевірка специфічних файлів VMware/VirtualBox
    vm_files = [
        "C:\\Program Files\\VMware\\VMware Tools\\",
        "C:\\Program Files\\Oracle\\VirtualBox Guest Additions\\",
        "/usr/bin/VBoxClient",
        "/usr/bin/vmtoolsd"
    ]
    for vm_file in vm_files:
        try:
            if os.path.exists(vm_file):
                logger.warning(f"VM detected via file: {vm_file}")
                _vm_detected = True
                return True
        except (OSError, IOError, PermissionError):
            pass
    
    return False


def is_vm_detected_silent() -> bool:
    """Silent version of VM detection (no logging)
    Тихая версия обнаружения VM (без логирования)
    Тиха версія виявлення VM (без логування)"""
    vm_indicators = ["vbox", "vmware", "virtual", "hyper-v", "qemu", "bochs", "parallels", "xen"]
    
    try:
        if platform.system() == "Windows":
            result = subprocess.run(
                ["wmic", "bios", "get", "serialnumber"],
                capture_output=True, text=True, timeout=3
            )
            if result.returncode == 0:
                bios = result.stdout.lower()
                for indicator in vm_indicators:
                    if indicator in bios:
                        return True
    except (subprocess.SubprocessError, FileNotFoundError, TimeoutError, OSError):
        pass
    
    try:
        import uuid
        mac = uuid.getnode()
        mac_str = format(mac, '012x')
        vm_macs = ['000569', '000c29', '001c42', '005056', '080027']
        for vm_mac in vm_macs:
            if mac_str.startswith(vm_mac):
                return True
    except (ValueError, TypeError, AttributeError, OSError):
        pass
    
    return False


def detect_hypervisor() -> bool:
    """Detect hypervisor presence / Обнаружение наличия гипервизора / Виявлення наявності гіпервізора"""
    try:
        if platform.system() == "Windows":
            result = subprocess.run(
                ["systeminfo", "|", "findstr", "/i", "hypervisor"],
                shell=True, capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0 and "Hyper-V" in result.stdout:
                logger.warning("Hyper-V detected")
                return True
    except (subprocess.SubprocessError, TimeoutError, OSError) as e:
        logger.debug(f"Hypervisor detection failed: {e}")
    
    return False


def check_timing_anomalies() -> bool:
    """Check for timing anomalies (VM detection)
    Проверка аномалий времени (обнаружение VM)
    Перевірка аномалій часу (виявлення VM)"""
    try:
        import timeit
        
        def rdtsc():
            if platform.system() == "Windows":
                try:
                    import ctypes
                    class PerformanceCounter(ctypes.Structure):
                        _fields_ = [("low", ctypes.c_ulong), ("high", ctypes.c_ulong)]
                    
                    kernel32 = ctypes.windll.kernel32
                    counter = PerformanceCounter()
                    kernel32.QueryPerformanceCounter(ctypes.byref(counter))
                    return (counter.high << 32) | counter.low
                except (AttributeError, OSError, TypeError):
                    pass
            return int(time.time() * 1000000)
        
        # Run multiple measurements
        # Выполняем несколько измерений
        # Виконуємо кілька вимірювань
        measurements = []
        for _ in range(10):
            start = rdtsc()
            # Small computation / Небольшое вычисление / Невелике обчислення
            _ = sum(range(100))
            end = rdtsc()
            measurements.append(end - start)
        
        # Check variance (VMs often have higher variance)
        # Проверка вариации (VM часто имеют более высокую вариацию)
        # Перевірка варіації (VM часто мають вищу варіацію)
        if measurements:
            variance = max(measurements) - min(measurements)
            if variance > 10000:  # High variance indicates possible VM
                logger.warning(f"High timing variance detected: {variance}")
                return True
        
    except (ImportError, AttributeError, RuntimeError, OSError) as e:
        logger.debug(f"Timing anomaly check failed: {e}")
    
    return False


# ==================== SANDBOX DETECTION / ОБНАРУЖЕНИЕ ПЕСОЧНИЦЫ / ВИЯВЛЕННЯ ПІСОЧНИЦІ ====================

def is_sandboxed() -> Tuple[bool, List[str]]:
    """Detect sandbox/VM environment / Обнаружение песочницы/VM / Виявлення пісочниці/VM"""
    global _sandbox_detected
    indicators = []
    
    # Check for small disk size (typical for VMs/sandboxes)
    # Проверка малого размера диска (типично для VM/песочниц)
    # Перевірка малого розміру диска (типово для VM/пісочниць)
    try:
        import shutil
        total, used, free = shutil.disk_usage("/")
        if total < 50 * 1024 * 1024 * 1024:  # Less than 50GB
            indicators.append("small_disk")
    except (OSError, ValueError, AttributeError) as e:
        logger.debug(f"Disk check failed: {e}")
    
    # Check for limited memory / Проверка ограниченной памяти / Перевірка обмеженої пам'яті
    try:
        import psutil
        mem = psutil.virtual_memory()
        if mem.total < 2 * 1024 * 1024 * 1024:  # Less than 2GB
            indicators.append("low_memory")
    except ImportError:
        pass
    except (ValueError, AttributeError, OSError) as e:
        logger.debug(f"Memory check failed: {e}")
    
    # Check for small number of CPU cores
    # Проверка малого количества ядер CPU
    # Перевірка малої кількості ядер CPU
    try:
        cpu_count = os.cpu_count() or 0
        if cpu_count <= 2:
            indicators.append("low_cpu_count")
    except (ValueError, TypeError) as e:
        logger.debug(f"CPU count check failed: {e}")
    
    # Check for common sandbox processes
    # Проверка на наличие процессов песочницы
    # Перевірка на наявність процесів пісочниці
    try:
        sandbox_processes = ['sandboxie', 'cuckoo', 'vmsrvc', 'vboxservice', 'vmtoolsd']
        if platform.system() == "Windows":
            result = subprocess.run(
                ['tasklist', '/FI', 'IMAGENAME eq *'],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                for proc in sandbox_processes:
                    if proc.lower() in result.stdout.lower():
                        indicators.append(f"sandbox_process_{proc}")
                        break
    except (subprocess.SubprocessError, TimeoutError, OSError) as e:
        logger.debug(f"Process check failed: {e}")
    
    # Check for sandbox-specific environment variables
    # Проверка специфических переменных окружения песочницы
    # Перевірка специфічних змінних середовища пісочниці
    try:
        sandbox_env_vars = ['CUCKOO', 'SANDBOX', 'ANALYSIS', 'VIRUS_SHARE_API_KEY']
        for var in sandbox_env_vars:
            if os.environ.get(var):
                indicators.append(f"sandbox_env_{var}")
    except (KeyError, TypeError) as e:
        logger.debug(f"Sandbox env check failed: {e}")
    
    # Check for common sandbox usernames
    # Проверка распространённых имён пользователей песочницы
    # Перевірка поширених імен користувачів пісочниці
    try:
        import getpass
        username = getpass.getuser().lower()
        sandbox_users = ['sandbox', 'malware', 'analysis', 'cuckoo', 'vmware']
        for user in sandbox_users:
            if user in username:
                indicators.append(f"sandbox_username_{user}")
    except (ImportError, OSError, AttributeError) as e:
        logger.debug(f"Username check failed: {e}")
    
    if len(indicators) >= 2:
        _sandbox_detected = True
        logger.warning(f"Sandbox detected: {indicators}")
    
    return len(indicators) >= 2, indicators


# ==================== INTEGRITY SELF-CHECKS / САМОПРОВЕРКА ЦЕЛОСТНОСТИ / САМОПЕРЕВІРКА ЦІЛІСНОСТІ ====================

def calculate_file_hash(file_path: str) -> Optional[str]:
    """Calculate SHA-256 hash of a file / Вычисляет SHA-256 хеш файла / Обчислює SHA-256 хеш файлу"""
    try:
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    except (OSError, IOError, PermissionError) as e:
        logger.debug(f"File hash calculation failed: {e}")
        return None


def verify_file_integrity(file_path: str, expected_hash: Optional[str] = None) -> bool:
    """Verify file integrity against expected hash
    Проверить целостность файла по ожидаемому хешу
    Перевірити цілісність файлу за очікуваним хешем"""
    if not os.path.exists(file_path):
        logger.warning(f"File not found: {file_path}")
        return False
    
    if expected_hash is None:
        # If hash not specified, consider file valid / Если хеш не указан, считаем файл валидным / Якщо хеш не вказано, вважаємо файл дійсним
        return True
    
    actual_hash = calculate_file_hash(file_path)
    if actual_hash is None:
        return False
    
    import hmac
    if hmac.compare_digest(actual_hash.lower(), expected_hash.lower()):
        return True
    else:
        logger.warning(f"File integrity check failed: {file_path}")
        return False


def perform_self_check() -> bool:
    """Perform integrity self-check on critical files
    Выполнить самопроверку целостности критических файлов
    Виконати самоперевірку цілісності критичних файлів"""
    global _integrity_verified
    
    critical_files = [
        ("security/antidebug.py", None),
        ("security/encryption.py", None),
        ("security/master.py", None),
    ]
    
    all_valid = True
    for file_path, expected_hash in critical_files:
        if not verify_file_integrity(file_path, expected_hash):
            all_valid = False
    
    _integrity_verified = all_valid
    return all_valid


def check_code_integrity() -> bool:
    """Check if code has been modified at runtime
    Проверяет, был ли изменён код во время выполнения
    Перевіряє, чи було змінено код під час виконання"""
    try:
        # Get the current file's modification time
        # Получаем время изменения текущего файла
        # Отримуємо час зміни поточного файлу
        current_file = os.path.abspath(__file__)
        if os.path.exists(current_file):
            mtime = os.path.getmtime(current_file)
            # If file was modified in the last 5 minutes and we're not in dev mode
            # Если файл был изменён за последние 5 минут и мы не в dev режиме
            # Якщо файл було змінено за останні 5 хвилин і ми не в dev режимі
            if time.time() - mtime < 300 and not getattr(sys, 'frozen', False):
                # Check if this is a legitimate development environment
                # Проверяем, является ли это легитимной средой разработки
                # Перевіряємо, чи є це легітимним середовищем розробки
                dev_env_vars = ['PYCHARM_HOSTED', 'PYDEV_CONSOLE_ENCODING', 'VSCODE_PID']
                for var in dev_env_vars:
                    if os.environ.get(var):
                        logger.debug(f"Development environment detected: {var}")
                        return True
                
                logger.warning(f"Recent file modification detected: {current_file}")
                return False
    except (OSError, IOError, ValueError, AttributeError) as e:
        logger.debug(f"Code integrity check failed: {e}")
    
    return True


# ==================== COMPREHENSIVE CHECKS / КОМПЛЕКСНЫЕ ПРОВЕРКИ / КОМПЛЕКСНІ ПЕРЕВІРКИ ====================

def is_debugged() -> Tuple[bool, List[str]]:
    """Comprehensive debug detection / Комплексное обнаружение отладки / Комплексне виявлення відлагодження"""
    checks = []
    
    try:
        if is_debugger_present():
            checks.append("Debugger detected via API")
        
        if check_debug_registers():
            checks.append("Hardware breakpoint detected")
        
        if check_parent_process():
            checks.append("Debugger parent process detected")
        
        if check_timing_anomalies():
            checks.append("Timing anomaly detected")
        
        debug_indicators = check_debug_env()
        if debug_indicators:
            checks.append(f"Debug environment: {', '.join(debug_indicators)}")
    except (KeyError, TypeError, AttributeError) as e:
        logger.debug(f"Debug env check failed: {e}")
    
    return len(checks) > 0, checks


def get_detection_status() -> Dict[str, Any]:
    """Get current detection status / Получить текущий статус обнаружения / Отримати поточний статус виявлення"""
    sandboxed, sandbox_reasons = is_sandboxed()
    debugged, debug_reasons = is_debugged()
    
    return {
        "debug_detected": _debug_detected,
        "debug_reasons": debug_reasons,
        "vm_detected": _vm_detected,
        "sandbox_detected": sandboxed,
        "sandbox_reasons": sandbox_reasons,
        "integrity_verified": _integrity_verified,
        "platform": platform.system(),
        "python_version": sys.version,
    }


def reset_detection_state() -> None:
    """Reset detection state (for testing) / Сбросить состояние обнаружения (для тестирования) / Скинути стан виявлення (для тестування)"""
    global _debug_detected, _vm_detected, _sandbox_detected, _integrity_verified
    _debug_detected = False
    _vm_detected = False
    _sandbox_detected = False
    _integrity_verified = False


# ==================== PROTECTION MEASURES / ЗАЩИТНЫЕ МЕРЫ / ЗАХИСНІ ЗАХОДИ ====================

def protect_from_debugging() -> None:
    """Apply anti-debugging measures / Применить анти-отладочные меры / Застосувати анти-відлагоджувальні заходи"""
    try:
        debugged, reasons = is_debugged()
        
        if debugged:
            logger.warning(f"Anti-debugging: {', '.join(reasons)}")
            time.sleep(2)
            
    except (ImportError, AttributeError, OSError, TimeoutError) as e:
        logger.error(f"Anti-debugging failed: {e}")


def protect_from_timing_analysis() -> None:
    """Protect against timing analysis / Защита от анализа по времени / Захист від аналізу за часом"""
    try:
        import random
        # Random delay between 0.5 and 2.5 ms
        # Случайная задержка от 0.5 до 2.5 мс
        # Випадкова затримка від 0.5 до 2.5 мс
        delay = random.uniform(0.0005, 0.0025)
        time.sleep(delay)
    except (ImportError, ValueError) as e:
        logger.debug(f"Timing analysis protection failed: {e}")


def detect_ptrace() -> bool:
    """Detect ptrace (Linux anti-debugging) / Обнаружение ptrace (анти-отладка на Linux) / Виявлення ptrace (анти-відлагодження на Linux)"""
    if platform.system() != "Linux":
        return False
    
    try:
        import fcntl
        # Try to ptrace self - if it fails, ptrace is likely in use
        # Пытаемся выполнить ptrace над собой - если не удаётся, вероятно ptrace используется
        # Намагаємося виконати ptrace над собою - якщо не вдається, ймовірно ptrace використовується
        return False
    except ImportError:
        return True


# ==================== BACKGROUND CHECKS / ФОНОВЫЕ ПРОВЕРКИ / ФОНОВІ ПЕРЕВІРКИ ====================

def _background_self_check() -> None:
    """Background thread for periodic self-checks
    Фоновый поток для периодических самопроверок
    Фоновий потік для періодичних самоперевірок"""
    global _self_check_timer
    
    try:
        perform_self_check()
        is_vm_detected()
        is_debugger_present()
        check_code_integrity()
        is_sandboxed()
    except (RuntimeError, OSError, AttributeError) as e:
        logger.debug(f"Background self-check error: {e}")
    
    # Start next check in 30 seconds / Запускаем следующую проверку через 30 секунд / Запускаємо наступну перевірку через 30 секунд
    _self_check_timer = threading.Timer(30.0, _background_self_check)
    _self_check_timer.daemon = True
    _self_check_timer.start()


def start_background_checks(interval: int = 30) -> None:
    """Start background anti-debug checks / Запустить фоновые анти-отладочные проверки / Запустити фонові анти-відлагоджувальні перевірки"""
    global _self_check_timer
    
    if _self_check_timer is not None:
        return
    
    _self_check_timer = threading.Timer(interval, _background_self_check)
    _self_check_timer.daemon = True
    _self_check_timer.start()
    logger.info(f"Background anti-debug checks started (interval: {interval}s)")


def stop_background_checks() -> None:
    """Stop background anti-debug checks / Остановить фоновые анти-отладочные проверки / Зупинити фонові анти-відлагоджувальні перевірки"""
    global _self_check_timer
    
    if _self_check_timer:
        _self_check_timer.cancel()
        _self_check_timer = None
        logger.info("Background anti-debug checks stopped")


# ==================== INITIALIZATION / ИНИЦИАЛИЗАЦИЯ / ІНІЦІАЛІЗАЦІЯ ====================

def init_anti_debug(enable_background_checks: bool = False) -> None:
    """Initialize all anti-debugging protections
    Инициализировать все анти-отладочные защиты
    Ініціалізувати всі анти-відлагоджувальні захисти"""
    try:
        protect_from_debugging()
        protect_from_timing_analysis()
        check_code_integrity()
        
        if enable_background_checks:
            start_background_checks()
        
        logger.debug("Anti-debugging protections initialized")
    except (ImportError, AttributeError, OSError, RuntimeError) as e:
        logger.error(f"Anti-debug init failed: {e}")


# ==================== LEGACY FUNCTIONS / УСТАРЕВШИЕ ФУНКЦИИ / ЗАСТАРІЛІ ФУНКЦІЇ ====================

def is_debugger_present_legacy() -> bool:
    """Legacy function name for backward compatibility
    Устаревшее имя функции для обратной совместимости
    Застаріла назва функції для зворотної сумісності"""
    return is_debugger_present()


def is_vm_detected_legacy() -> bool:
    """Legacy function name for backward compatibility
    Устаревшее имя функции для обратной совместимости
    Застаріла назва функції для зворотної сумісності"""
    return is_vm_detected()


# Export / Экспорт / Експорт
__all__ = [
    'is_debugger_present',
    'is_debugger_present_silent',
    'check_debug_registers',
    'check_parent_process',
    'check_debug_env',
    'is_vm_detected',
    'is_vm_detected_silent',
    'detect_hypervisor',
    'detect_ptrace',
    'check_timing_anomalies',
    'check_code_integrity',
    'is_debugged',
    'is_sandboxed',
    'protect_from_debugging',
    'protect_from_timing_analysis',
    'perform_self_check',
    'verify_file_integrity',
    'calculate_file_hash',
    'start_background_checks',
    'stop_background_checks',
    'get_detection_status',
    'reset_detection_state',
    'init_anti_debug',
    'is_debugger_present_legacy',
    'is_vm_detected_legacy',
    'AntiDebugError',
]