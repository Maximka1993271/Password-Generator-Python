"""
Anti-debugging and anti-analysis protection for SecurePassPro
"""
import sys
import os
import ctypes
import platform


def is_debugger_present() -> bool:
    """Check if debugger is attached (Windows only)"""
    if platform.system() != "Windows":
        return False
    
    try:
        # Check using IsDebuggerPresent
        kernel32 = ctypes.windll.kernel32
        if kernel32.IsDebuggerPresent():
            return True
        
        # Check using NtQueryInformationProcess
        ntdll = ctypes.windll.ntdll
        if ntdll.NtQueryInformationProcess:
            PROCESS_INFO_CLASS = 0x7  # ProcessDebugPort
            debug_port = ctypes.c_void_p()
            size = ctypes.sizeof(debug_port)
            status = ntdll.NtQueryInformationProcess(
                ctypes.windll.kernel32.GetCurrentProcess(),
                PROCESS_INFO_CLASS,
                ctypes.byref(debug_port),
                size,
                None
            )
            if status == 0 and debug_port.value is not None:
                return True
    except Exception:
        pass
    
    return False


def is_vm_detected() -> bool:
    """Basic VM detection (VMware, VirtualBox, Hyper-V)"""
    vm_indicators = [
        "vbox", "vmware", "virtual", "hyper-v", 
        "qemu", "bochs", "parallels", "xen"
    ]
    
    try:
        # Check BIOS/DMI info (Windows)
        if platform.system() == "Windows":
            import subprocess
            result = subprocess.run(
                ["wmic", "bios", "get", "serialnumber"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                bios = result.stdout.lower()
                for indicator in vm_indicators:
                    if indicator in bios:
                        return True
        
        # Check MAC addresses
        import uuid
        mac = uuid.getnode()
        mac_str = format(mac, '012x')
        vm_macs = ['000569', '000c29', '001c42', '005056', '080027']
        for vm_mac in vm_macs:
            if mac_str.startswith(vm_mac):
                return True
        
        # Check CPU count (VMs often have 1-2 cores)
        cpu_count = os.cpu_count() or 0
        if cpu_count <= 1:
            return True
        
    except Exception:
        pass
    
    return False


def is_debugged() -> bool:
    """Comprehensive debug detection"""
    checks = []
    
    # Check for debugger
    if is_debugger_present():
        checks.append("Debugger detected")
    
    # Check for VM (optional, can be disabled)
    # if is_vm_detected():
    #     checks.append("Virtual machine detected")
    
    # Check for common debugger environment variables
    debug_env_vars = ['PYCHARM_HOSTED', 'PYDEV_CONSOLE_ENCODING', 'DEBUGPY_LAUNCHER']
    for var in debug_env_vars:
        if os.environ.get(var):
            checks.append(f"Debug environment: {var}")
            break
    
    return len(checks) > 0, checks


def protect_from_debugging() -> None:
    """Apply anti-debugging measures"""
    try:
        # Check for debugger
        debugged, reasons = is_debugged()
        
        if debugged:
            # Show warning but don't crash (user experience)
            print(f"[Security] {', '.join(reasons)}")
            
            # Optional: delay execution to frustrate debuggers
            import time
            time.sleep(2)
            
            # Optional: terminate if debugger found (uncomment for strict mode)
            # if is_debugger_present():
            #     sys.exit(0)
            
    except Exception:
        pass


def protect_memory_from_dump() -> None:
    """Prevent memory dumps (Windows only)"""
    if platform.system() != "Windows":
        return
    
    try:
        # Set process to not be dumpable
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetCurrentProcess()
        
        # Set process critical flag (if terminated, system bluescreens)
        # WARNING: Use with caution!
        # kernel32.SetProcessCritical(handle, True)
        
        # Disable crash dumps
        ctypes.windll.kernel32.SetProcessDEPPolicy(0x3)  # Enable DEP
        
    except Exception:
        pass


def hide_console() -> None:
    """Hide console window on Windows (for debug builds)"""
    if platform.system() == "Windows":
        try:
            ctypes.windll.user32.ShowWindow(
                ctypes.windll.kernel32.GetConsoleWindow(), 0
            )
        except Exception:
            pass


def init_anti_debug() -> None:
    """Initialize all anti-debugging protections"""
    # Don't break normal execution, just warn
    protect_from_debugging()
    
    # Optional memory protection
    # protect_memory_from_dump()