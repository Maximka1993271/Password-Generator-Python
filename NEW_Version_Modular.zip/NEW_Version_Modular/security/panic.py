"""
Global panic cleanup handler for SecurePassPro
"""
import sys
import signal
import atexit
import os
import tempfile
import time
import threading
from typing import Optional, List, Callable
from utils.logger import get_logger

logger = get_logger("panic")


class PanicCleanup:
    """Global panic handler for emergency cleanup"""
    
    _clipboard_callbacks: List[Callable] = []
    _temp_files: List[str] = []
    _callbacks: List[Callable] = []
    _memory_cleanup_callbacks: List[Callable] = []
    _db_cleanup_callbacks: List[Callable] = []
    _panic_triggered = False
    _panic_lock = threading.Lock()
    
    @classmethod
    def register_clipboard_cleanup(cls, callback: Callable) -> None:
        """Register clipboard cleanup function"""
        if callback not in cls._clipboard_callbacks:
            cls._clipboard_callbacks.append(callback)
    
    @classmethod
    def register_temp_file(cls, file_path: str) -> None:
        """Register temporary file for cleanup"""
        if file_path not in cls._temp_files:
            cls._temp_files.append(file_path)
    
    @classmethod
    def register_cleanup_callback(cls, callback: Callable) -> None:
        """Register general cleanup callback"""
        if callback not in cls._callbacks:
            cls._callbacks.append(callback)
    
    @classmethod
    def register_memory_cleanup(cls, callback: Callable) -> None:
        """Register memory cleanup callback"""
        if callback not in cls._memory_cleanup_callbacks:
            cls._memory_cleanup_callbacks.append(callback)
    
    @classmethod
    def register_db_cleanup(cls, callback: Callable) -> None:
        """Register database cleanup callback"""
        if callback not in cls._db_cleanup_callbacks:
            cls._db_cleanup_callbacks.append(callback)
    
    @classmethod
    def emergency_cleanup(cls, reason: str = "unknown") -> None:
        """Emergency cleanup on crash/exit"""
        with cls._panic_lock:
            if cls._panic_triggered:
                return
            cls._panic_triggered = True
        
        logger.warning(f"Emergency cleanup triggered: {reason}")
        start_time = time.time()
        
        # Clean clipboard (multiple methods for reliability)
        for callback in cls._clipboard_callbacks:
            try:
                callback()
            except Exception as e:
                logger.debug(f"Clipboard cleanup error: {e}")
        
        # Try Windows API clipboard clear as fallback
        cls._emergency_clipboard_clear_windows()
        
        # Clean temp files
        for file_path in cls._temp_files[:]:  # Iterate over copy
            try:
                if os.path.exists(file_path):
                    # Overwrite before delete
                    try:
                        with open(file_path, 'wb') as f:
                            f.write(os.urandom(1024))
                    except Exception:
                        pass
                    os.remove(file_path)
                    if file_path in cls._temp_files:
                        cls._temp_files.remove(file_path)
            except Exception as e:
                logger.debug(f"Temp file cleanup error: {e}")
        
        # Run memory cleanup callbacks
        for callback in cls._memory_cleanup_callbacks:
            try:
                callback()
            except Exception as e:
                logger.debug(f"Memory cleanup error: {e}")
        
        # Run database cleanup callbacks
        for callback in cls._db_cleanup_callbacks:
            try:
                callback()
            except Exception as e:
                logger.debug(f"DB cleanup error: {e}")
        
        # Run general callbacks
        for callback in cls._callbacks:
            try:
                callback()
            except Exception as e:
                logger.debug(f"General cleanup error: {e}")
        
        elapsed = time.time() - start_time
        logger.info(f"Emergency cleanup completed in {elapsed:.3f}s")
    
    @classmethod
    def _emergency_clipboard_clear_windows(cls) -> None:
        """Windows-specific clipboard clear"""
        if sys.platform != "win32":
            return
        
        try:
            import ctypes
            user32 = ctypes.windll.user32
            if user32.OpenClipboard(0):
                user32.EmptyClipboard()
                user32.CloseClipboard()
        except Exception as e:
            logger.debug(f"Windows clipboard clear error: {e}")
    
    @classmethod
    def emergency_db_wipe(cls, db_path: str) -> bool:
        """
        Emergency database wipe - overwrites and deletes the database file.
        Returns True if successful.
        """
        if not os.path.exists(db_path):
            return True
        
        try:
            # Overwrite with random data multiple times
            size = os.path.getsize(db_path)
            if size > 0 and size < 100 * 1024 * 1024:  # Only for DBs under 100MB
                with open(db_path, 'wb') as f:
                    for _ in range(3):
                        f.write(os.urandom(size))
                        f.flush()
                        os.fsync(f.fileno())
                        f.seek(0)
            
            # Delete the file
            os.remove(db_path)
            logger.info(f"Emergency DB wipe completed: {db_path}")
            return True
        except Exception as e:
            logger.error(f"Emergency DB wipe failed: {e}")
            return False
    
    @classmethod
    def secure_shutdown(cls, exit_code: int = 0) -> None:
        """
        Perform secure shutdown with emergency cleanup.
        """
        cls.emergency_cleanup(reason="secure_shutdown")
        
        # Final memory cleanup
        import gc
        gc.collect()
        
        sys.exit(exit_code)
    
    @classmethod
    def is_panic_triggered(cls) -> bool:
        """Check if panic cleanup has been triggered"""
        return cls._panic_triggered
    
    @classmethod
    def reset(cls) -> None:
        """Reset panic state (for testing)"""
        with cls._panic_lock:
            cls._panic_triggered = False
            cls._clipboard_callbacks.clear()
            cls._temp_files.clear()
            cls._callbacks.clear()
            cls._memory_cleanup_callbacks.clear()
            cls._db_cleanup_callbacks.clear()
    
    @classmethod
    def _signal_handler(cls, signum: int, frame) -> None:
        """Signal handler for crashes"""
        signal_names = {
            signal.SIGINT: "SIGINT",
            signal.SIGTERM: "SIGTERM",
        }
        if sys.platform != "win32":
            signal_names[signal.SIGQUIT] = "SIGQUIT"
        
        name = signal_names.get(signum, f"signal_{signum}")
        cls.emergency_cleanup(reason=name)
        sys.exit(1)
    
    @classmethod
    def _windows_exception_handler(cls, exception_type, exception_value, traceback) -> None:
        """Windows-specific exception handler"""
        cls.emergency_cleanup(reason="unhandled_exception")
        # Call original exception handler
        sys.__excepthook__(exception_type, exception_value, traceback)
    
    @classmethod
    def init(cls) -> None:
        """Initialize panic handlers"""
        # Register atexit
        atexit.register(lambda: cls.emergency_cleanup(reason="atexit"))
        
        # Register signal handlers
        try:
            signal.signal(signal.SIGTERM, cls._signal_handler)
            signal.signal(signal.SIGINT, cls._signal_handler)
        except (ValueError, AttributeError) as e:
            logger.debug(f"Signal handler registration error: {e}")
        
        # Unix-specific signals
        if sys.platform != "win32":
            try:
                signal.signal(signal.SIGQUIT, cls._signal_handler)
            except (ValueError, AttributeError):
                pass
        
        # Windows-specific
        if sys.platform == "win32":
            try:
                import ctypes
                # Set error mode to prevent crash dialogs
                ctypes.windll.kernel32.SetErrorMode(0x8001)
                
                # Set unhandled exception handler
                sys.excepthook = cls._windows_exception_handler
            except Exception as e:
                logger.debug(f"Windows exception handler error: {e}")
        
        logger.info("Panic cleanup system initialized")


# Global hotkey for panic cleanup (Ctrl+Alt+Shift+P)
_panic_hotkey_thread = None
_panic_hotkey_running = False


def _panic_hotkey_listener() -> None:
    """Background thread for panic hotkey detection"""
    global _panic_hotkey_running
    
    try:
        import keyboard
    except ImportError:
        logger.debug("Keyboard module not available, panic hotkey disabled")
        return
    
    def on_panic():
        logger.warning("Panic hotkey triggered! Performing emergency cleanup...")
        PanicCleanup.emergency_cleanup(reason="hotkey")
    
    try:
        keyboard.add_hotkey('ctrl+alt+shift+p', on_panic)
        while _panic_hotkey_running:
            time.sleep(0.1)
    except Exception as e:
        logger.debug(f"Hotkey listener error: {e}")


def start_panic_hotkey() -> None:
    """Start panic hotkey listener (Ctrl+Alt+Shift+P)"""
    global _panic_hotkey_thread, _panic_hotkey_running
    
    if _panic_hotkey_thread is not None and _panic_hotkey_thread.is_alive():
        return
    
    _panic_hotkey_running = True
    _panic_hotkey_thread = threading.Thread(target=_panic_hotkey_listener, daemon=True)
    _panic_hotkey_thread.start()
    logger.info("Panic hotkey enabled: Ctrl+Alt+Shift+P")


def stop_panic_hotkey() -> None:
    """Stop panic hotkey listener"""
    global _panic_hotkey_running, _panic_hotkey_thread
    
    _panic_hotkey_running = False
    if _panic_hotkey_thread and _panic_hotkey_thread.is_alive():
        _panic_hotkey_thread.join(timeout=1.0)
    _panic_hotkey_thread = None


def init_panic_cleanup(enable_hotkey: bool = False) -> None:
    """
    Initialize panic cleanup system.
    
    Args:
        enable_hotkey: Enable panic hotkey (Ctrl+Alt+Shift+P)
    """
    PanicCleanup.init()
    
    if enable_hotkey:
        try:
            start_panic_hotkey()
        except Exception as e:
            logger.debug(f"Failed to start panic hotkey: {e}")


# Для обратной совместимости
def register_clipboard_cleanup(callback):
    PanicCleanup.register_clipboard_cleanup(callback)


def register_temp_file(file_path):
    PanicCleanup.register_temp_file(file_path)


def register_cleanup_callback(callback):
    PanicCleanup.register_cleanup_callback(callback)


# Экспорт
__all__ = [
    'PanicCleanup',
    'init_panic_cleanup',
    'start_panic_hotkey',
    'stop_panic_hotkey',
    'register_clipboard_cleanup',
    'register_temp_file',
    'register_cleanup_callback',
]