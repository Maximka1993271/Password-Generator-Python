"""
Global panic cleanup handler for SecurePassPro

Глобальный обработчик аварийной очистки для SecurePassPro
Глобальний обробник аварійного очищення для SecurePassPro
"""
import sys
import signal
import atexit
import os
import tempfile
import time
import threading
from typing import Optional, List, Callable
from utils.logger import get_logger

logger = get_logger("panic")


class PanicCleanup:
    """Global panic handler for emergency cleanup
    Глобальный обработчик паники для аварийной очистки
    Глобальний обробник паніки для аварійного очищення"""
    
    _clipboard_callbacks: List[Callable] = []
    _temp_files: List[str] = []
    _callbacks: List[Callable] = []
    _memory_cleanup_callbacks: List[Callable] = []
    _db_cleanup_callbacks: List[Callable] = []
    _panic_triggered = False
    _panic_lock = threading.Lock()
    _cleanup_completed = False
    
    @classmethod
    def register_clipboard_cleanup(cls, callback: Callable) -> None:
        """Register clipboard cleanup function
        Регистрирует функцию очистки буфера обмена
        Реєструє функцію очищення буфера обміну"""
        if callback not in cls._clipboard_callbacks:
            cls._clipboard_callbacks.append(callback)
    
    @classmethod
    def register_temp_file(cls, file_path: str) -> None:
        """Register temporary file for cleanup
        Регистрирует временный файл для очистки
        Реєструє тимчасовий файл для очищення"""
        if file_path not in cls._temp_files:
            cls._temp_files.append(file_path)
    
    @classmethod
    def register_cleanup_callback(cls, callback: Callable) -> None:
        """Register general cleanup callback
        Регистрирует общий callback очистки
        Реєструє загальний callback очищення"""
        if callback not in cls._callbacks:
            cls._callbacks.append(callback)
    
    @classmethod
    def register_memory_cleanup(cls, callback: Callable) -> None:
        """Register memory cleanup callback
        Регистрирует callback очистки памяти
        Реєструє callback очищення пам'яті"""
        if callback not in cls._memory_cleanup_callbacks:
            cls._memory_cleanup_callbacks.append(callback)
    
    @classmethod
    def register_db_cleanup(cls, callback: Callable) -> None:
        """Register database cleanup callback
        Регистрирует callback очистки базы данных
        Реєструє callback очищення бази даних"""
        if callback not in cls._db_cleanup_callbacks:
            cls._db_cleanup_callbacks.append(callback)
    
    @classmethod
    def emergency_cleanup(cls, reason: str = "unknown") -> None:
        """
        Emergency cleanup on crash/exit.
        Fail-closed: guarantees cleanup even on errors.
        
        Аварийная очистка при сбое/завершении.
        Fail-closed: гарантирует очистку даже при ошибках.
        
        Аварійне очищення при збої/завершенні.
        Fail-closed: гарантує очищення навіть при помилках.
        """
        with cls._panic_lock:
            if cls._panic_triggered:
                return
            cls._panic_triggered = True
        
        logger.warning(f"Emergency cleanup triggered: {reason}")
        start_time = time.time()
        
        # List of errors for logging (does not interrupt cleanup)
        # Список ошибок для логирования (не прерывает очистку)
        # Список помилок для логування (не перериває очищення)
        errors = []
        
        # ========== 1. Clipboard cleanup (critical) / Очистка буфера обмена (критично) / Очищення буфера обміну (критично) ==========
        for callback in cls._clipboard_callbacks:
            try:
                callback()
            except (AttributeError, RuntimeError, OSError, TypeError) as e:
                err_msg = f"Clipboard cleanup callback error: {e}"
                logger.debug(err_msg)
                errors.append(err_msg)
        
        # Additional Windows API clipboard cleanup (fallback)
        # Дополнительная очистка через Windows API (fallback)
        # Додаткове очищення через Windows API (fallback)
        try:
            cls._emergency_clipboard_clear_windows()
        except (AttributeError, OSError, RuntimeError) as e:
            err_msg = f"Windows clipboard clear error: {e}"
            logger.debug(err_msg)
            errors.append(err_msg)
        
        # ========== 2. Temporary files cleanup with overwrite / Очистка временных файлов с перезаписью / Очищення тимчасових файлів з перезаписом ==========
        for file_path in cls._temp_files[:]:  # Copy of list / Копия списка / Копія списку
            try:
                if os.path.exists(file_path):
                    # Overwrite before deletion / Перезапись перед удалением / Перезапис перед видаленням
                    try:
                        size = os.path.getsize(file_path)
                        if 0 < size < 10 * 1024 * 1024:  # Only files up to 10MB / Только файлы до 10MB / Тільки файли до 10MB
                            with open(file_path, 'wb') as f:
                                f.write(os.urandom(size))
                                f.flush()
                                os.fsync(f.fileno())
                    except (OSError, IOError, PermissionError, ValueError) as e:
                        logger.debug(f"File overwrite failed: {e}")
                    
                    # Delete / Удаление / Видалення
                    try:
                        os.remove(file_path)
                    except (OSError, IOError, PermissionError) as e:
                        err_msg = f"Temp file remove error: {e}"
                        logger.debug(err_msg)
                        errors.append(err_msg)
                    
                    if file_path in cls._temp_files:
                        cls._temp_files.remove(file_path)
            except (OSError, AttributeError, RuntimeError) as e:
                err_msg = f"Temp file cleanup error: {e}"
                logger.debug(err_msg)
                errors.append(err_msg)
        
        # ========== 3. Memory cleanup / Очистка памяти / Очищення пам'яті ==========
        for callback in cls._memory_cleanup_callbacks:
            try:
                callback()
            except (AttributeError, RuntimeError, TypeError, MemoryError) as e:
                err_msg = f"Memory cleanup error: {e}"
                logger.debug(err_msg)
                errors.append(err_msg)
        
        # ========== 4. Database cleanup / Очистка базы данных / Очищення бази даних ==========
        for callback in cls._db_cleanup_callbacks:
            try:
                callback()
            except (AttributeError, RuntimeError, OSError) as e:
                err_msg = f"DB cleanup error: {e}"
                logger.debug(err_msg)
                errors.append(err_msg)
        
        # ========== 5. General callbacks / Общие колбэки / Загальні колбеки ==========
        for callback in cls._callbacks:
            try:
                callback()
            except (AttributeError, RuntimeError, TypeError, OSError) as e:
                err_msg = f"General callback error: {e}"
                logger.debug(err_msg)
                errors.append(err_msg)
        
        # ========== 6. Force garbage collection / Принудительный сбор мусора / Примусове збирання сміття ==========
        try:
            import gc
            gc.collect()
        except (ImportError, RuntimeError) as e:
            logger.debug(f"GC collect error: {e}")
        
        cls._cleanup_completed = True
        elapsed = time.time() - start_time
        
        if errors:
            logger.warning(f"Emergency cleanup completed with {len(errors)} errors in {elapsed:.3f}s")
        else:
            logger.info(f"Emergency cleanup completed successfully in {elapsed:.3f}s")
    
    @classmethod
    def _emergency_clipboard_clear_windows(cls) -> None:
        """Windows-specific clipboard clear / Windows-специфичная очистка буфера обмена / Windows-специфічне очищення буфера обміну"""
        if sys.platform != "win32":
            return
        
        try:
            import ctypes
            user32 = ctypes.windll.user32
            if user32.OpenClipboard(0):
                try:
                    user32.EmptyClipboard()
                except (AttributeError, OSError) as e:
                    logger.debug(f"EmptyClipboard error: {e}")
                finally:
                    try:
                        user32.CloseClipboard()
                    except (AttributeError, OSError) as e:
                        logger.debug(f"CloseClipboard error: {e}")
        except (ImportError, AttributeError, OSError, TypeError) as e:
            logger.debug(f"Windows clipboard clear error: {e}")
    
    @classmethod
    def emergency_db_wipe(cls, db_path: str) -> bool:
        """
        Emergency database wipe - overwrites and deletes the database file.
        Returns True if successful.
        
        Аварийное удаление базы данных - перезаписывает и удаляет файл БД.
        Возвращает True при успехе.
        
        Аварійне видалення бази даних - перезаписує та видаляє файл БД.
        Повертає True при успіху.
        """
        if not os.path.exists(db_path):
            return True
        
        try:
            # Overwrite with random data multiple times / Перезапись случайными данными несколько раз / Перезапис випадковими даними кілька разів
            size = os.path.getsize(db_path)
            if 0 < size < 100 * 1024 * 1024:  # Only for DBs under 100MB / Только для БД до 100MB / Тільки для БД до 100MB
                with open(db_path, 'wb') as f:
                    for _ in range(3):
                        try:
                            f.write(os.urandom(size))
                            f.flush()
                            os.fsync(f.fileno())
                            f.seek(0)
                        except (OSError, IOError, ValueError) as e:
                            logger.debug(f"Overwrite error: {e}")
                            break
            
            # Delete the file / Удаление файла / Видалення файлу
            os.remove(db_path)
            logger.info(f"Emergency DB wipe completed: {db_path}")
            return True
        except (OSError, IOError, PermissionError, ValueError) as e:
            logger.error(f"Emergency DB wipe failed: {e}")
            return False
    
    @classmethod
    def secure_shutdown(cls, exit_code: int = 0) -> None:
        """
        Perform secure shutdown with emergency cleanup.
        Guarantees cleanup even on errors.
        
        Выполняет безопасное завершение с аварийной очисткой.
        Гарантирует очистку даже при ошибках.
        
        Виконує безпечне завершення з аварійним очищенням.
        Гарантує очищення навіть при помилках.
        """
        try:
            cls.emergency_cleanup(reason="secure_shutdown")
        except (RuntimeError, SystemExit, KeyboardInterrupt) as e:
            logger.error(f"Cleanup failed during shutdown: {e}")
        finally:
            # Final memory cleanup / Финальная очистка памяти / Фінальне очищення пам'яті
            try:
                import gc
                gc.collect()
            except (ImportError, RuntimeError):
                pass
        
        sys.exit(exit_code)
    
    @classmethod
    def is_panic_triggered(cls) -> bool:
        """Check if panic cleanup has been triggered
        Проверяет, была ли запущена аварийная очистка
        Перевіряє, чи було запущено аварійне очищення"""
        return cls._panic_triggered
    
    @classmethod
    def is_cleanup_completed(cls) -> bool:
        """Check if cleanup has completed successfully
        Проверяет, завершилась ли очистка успешно
        Перевіряє, чи завершилось очищення успішно"""
        return cls._cleanup_completed
    
    @classmethod
    def reset(cls) -> None:
        """Reset panic state (for testing) / Сбросить состояние паники (для тестирования) / Скинути стан паніки (для тестування)"""
        with cls._panic_lock:
            cls._panic_triggered = False
            cls._cleanup_completed = False
            cls._clipboard_callbacks.clear()
            cls._temp_files.clear()
            cls._callbacks.clear()
            cls._memory_cleanup_callbacks.clear()
            cls._db_cleanup_callbacks.clear()
    
    @classmethod
    def _signal_handler(cls, signum: int, frame) -> None:
        """Signal handler for crashes / Обработчик сигналов для сбоев / Обробник сигналів для збоїв"""
        signal_names = {
            signal.SIGINT: "SIGINT",
            signal.SIGTERM: "SIGTERM",
        }
        if sys.platform != "win32":
            try:
                signal_names[signal.SIGQUIT] = "SIGQUIT"
            except AttributeError:
                pass
        
        name = signal_names.get(signum, f"signal_{signum}")
        try:
            cls.emergency_cleanup(reason=name)
        except (RuntimeError, SystemExit) as e:
            logger.error(f"Signal handler cleanup error: {e}")
        sys.exit(1)
    
    @classmethod
    def _windows_exception_handler(cls, exception_type, exception_value, traceback) -> None:
        """Windows-specific exception handler / Windows-специфичный обработчик исключений / Windows-специфічний обробник винятків"""
        try:
            cls.emergency_cleanup(reason="unhandled_exception")
        except (RuntimeError, SystemExit) as e:
            logger.error(f"Exception handler cleanup error: {e}")
        # Call original exception handler / Вызов оригинального обработчика / Виклик оригінального обробника
        try:
            sys.__excepthook__(exception_type, exception_value, traceback)
        except (TypeError, AttributeError, RuntimeError):
            pass
    
    @classmethod
    def init(cls) -> None:
        """Initialize panic handlers / Инициализация обработчиков паники / Ініціалізація обробників паніки"""
        # Register atexit / Регистрация atexit / Реєстрація atexit
        try:
            atexit.register(lambda: cls.emergency_cleanup(reason="atexit"))
        except (TypeError, RuntimeError) as e:
            logger.debug(f"Atexit registration error: {e}")
        
        # Register signal handlers / Регистрация обработчиков сигналов / Реєстрація обробників сигналів
        try:
            signal.signal(signal.SIGTERM, cls._signal_handler)
            signal.signal(signal.SIGINT, cls._signal_handler)
        except (ValueError, AttributeError, OSError) as e:
            logger.debug(f"Signal handler registration error: {e}")
        
        # Unix-specific signals / Unix-специфичные сигналы / Unix-специфічні сигнали
        if sys.platform != "win32":
            try:
                signal.signal(signal.SIGQUIT, cls._signal_handler)
            except (ValueError, AttributeError, OSError) as e:
                logger.debug(f"SIGQUIT handler registration error: {e}")
        
        # Windows-specific / Windows-специфичное / Windows-специфічне
        if sys.platform == "win32":
            try:
                import ctypes
                # Set error mode to prevent crash dialogs / Установка режима ошибок для предотвращения диалогов сбоя / Встановлення режиму помилок для запобігання діалогам збою
                ctypes.windll.kernel32.SetErrorMode(0x8001)
            except (ImportError, AttributeError, OSError) as e:
                logger.debug(f"Windows error mode setting error: {e}")
            
            try:
                # Set unhandled exception handler / Установка обработчика необработанных исключений / Встановлення обробника необроблених винятків
                sys.excepthook = cls._windows_exception_handler
            except (TypeError, AttributeError, RuntimeError) as e:
                logger.debug(f"Windows exception handler error: {e}")
        
        logger.info("Panic cleanup system initialized")


# Global hotkey for panic cleanup (Ctrl+Alt+Shift+P)
# Глобальная горячая клавиша для аварийной очистки (Ctrl+Alt+Shift+P)
# Глобальна гаряча клавіша для аварійного очищення (Ctrl+Alt+Shift+P)
_panic_hotkey_thread = None
_panic_hotkey_running = False


def _panic_hotkey_listener() -> None:
    """Background thread for panic hotkey detection
    Фоновый поток для обнаружения горячей клавиши паники
    Фоновий потік для виявлення гарячої клавіші паніки"""
    global _panic_hotkey_running
    
    try:
        import keyboard
    except ImportError as e:
        logger.debug(f"Keyboard module not available, panic hotkey disabled: {e}")
        return
    
    def on_panic():
        logger.warning("Panic hotkey triggered! Performing emergency cleanup...")
        PanicCleanup.emergency_cleanup(reason="hotkey")
    
    try:
        keyboard.add_hotkey('ctrl+alt+shift+p', on_panic)
        while _panic_hotkey_running:
            time.sleep(0.1)
    except (ImportError, AttributeError, OSError, RuntimeError) as e:
        logger.debug(f"Hotkey listener error: {e}")
    finally:
        _panic_hotkey_running = False


def start_panic_hotkey() -> None:
    """Start panic hotkey listener (Ctrl+Alt+Shift+P)
    Запустить прослушивание горячей клавиши паники (Ctrl+Alt+Shift+P)
    Запустити прослуховування гарячої клавіші паніки (Ctrl+Alt+Shift+P)"""
    global _panic_hotkey_thread, _panic_hotkey_running
    
    if _panic_hotkey_thread is not None and _panic_hotkey_thread.is_alive():
        return
    
    _panic_hotkey_running = True
    _panic_hotkey_thread = threading.Thread(target=_panic_hotkey_listener, daemon=True)
    try:
        _panic_hotkey_thread.start()
        logger.info("Panic hotkey enabled: Ctrl+Alt+Shift+P")
    except (RuntimeError, threading.ThreadError) as e:
        logger.debug(f"Failed to start panic hotkey thread: {e}")
        _panic_hotkey_running = False


def stop_panic_hotkey() -> None:
    """Stop panic hotkey listener / Остановить прослушивание горячей клавиши паники / Зупинити прослуховування гарячої клавіші паніки"""
    global _panic_hotkey_running, _panic_hotkey_thread
    
    _panic_hotkey_running = False
    if _panic_hotkey_thread and _panic_hotkey_thread.is_alive():
        try:
            _panic_hotkey_thread.join(timeout=1.0)
        except (RuntimeError, threading.ThreadError) as e:
            logger.debug(f"Hotkey thread join error: {e}")
    _panic_hotkey_thread = None


def init_panic_cleanup(enable_hotkey: bool = False) -> None:
    """
    Initialize panic cleanup system.
    
    Инициализировать систему аварийной очистки.
    Ініціалізувати систему аварійного очищення.
    
    Args:
        enable_hotkey: Enable panic hotkey (Ctrl+Alt+Shift+P) / Включить горячую клавишу паники / Увімкнути гарячу клавішу паніки
    """
    PanicCleanup.init()
    
    if enable_hotkey:
        try:
            start_panic_hotkey()
        except (ImportError, RuntimeError, AttributeError) as e:
            logger.debug(f"Failed to start panic hotkey: {e}")


# For backward compatibility / Для обратной совместимости / Для зворотної сумісності
def register_clipboard_cleanup(callback: Callable) -> None:
    PanicCleanup.register_clipboard_cleanup(callback)


def register_temp_file(file_path: str) -> None:
    PanicCleanup.register_temp_file(file_path)


def register_cleanup_callback(callback: Callable) -> None:
    PanicCleanup.register_cleanup_callback(callback)


# Export / Экспорт / Експорт
__all__ = [
    'PanicCleanup',
    'init_panic_cleanup',
    'start_panic_hotkey',
    'stop_panic_hotkey',
    'register_clipboard_cleanup',
    'register_temp_file',
    'register_cleanup_callback',
]