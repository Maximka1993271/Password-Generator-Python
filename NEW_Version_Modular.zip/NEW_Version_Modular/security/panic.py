"""
Global panic cleanup handler for SecurePassPro
"""
import sys
import signal
import atexit
import os
import tempfile
from typing import Optional


class PanicCleanup:
    """Global panic handler for emergency cleanup"""
    
    _clipboard_callbacks = []
    _temp_files = []
    _callbacks = []
    
    @classmethod
    def register_clipboard_cleanup(cls, callback):
        """Register clipboard cleanup function"""
        cls._clipboard_callbacks.append(callback)
    
    @classmethod
    def register_temp_file(cls, file_path: str):
        """Register temporary file for cleanup"""
        cls._temp_files.append(file_path)
    
    @classmethod
    def register_cleanup_callback(cls, callback):
        """Register general cleanup callback"""
        cls._callbacks.append(callback)
    
    @classmethod
    def emergency_cleanup(cls):
        """Emergency cleanup on crash/exit"""
        # Clean clipboard
        for callback in cls._clipboard_callbacks:
            try:
                callback()
            except Exception:
                pass
        
        # Clean temp files
        for file_path in cls._temp_files:
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception:
                pass
        
        # Run general callbacks
        for callback in cls._callbacks:
            try:
                callback()
            except Exception:
                pass
    
    @classmethod
    def _signal_handler(cls, signum, frame):
        """Signal handler for crashes"""
        cls.emergency_cleanup()
        sys.exit(1)
    
    @classmethod
    def init(cls):
        """Initialize panic handlers"""
        # Register atexit
        atexit.register(cls.emergency_cleanup)
        
        # Register signal handlers
        signal.signal(signal.SIGTERM, cls._signal_handler)
        signal.signal(signal.SIGINT, cls._signal_handler)
        
        # Windows-specific
        if sys.platform == "win32":
            try:
                import ctypes
                # Set error mode to prevent crash dialogs
                ctypes.windll.kernel32.SetErrorMode(0x8001)
            except Exception:
                pass


def init_panic_cleanup():
    """Initialize panic cleanup system"""
    PanicCleanup.init()