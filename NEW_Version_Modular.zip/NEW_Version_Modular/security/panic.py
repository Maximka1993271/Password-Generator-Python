"""
Global panic cleanup handler for SecurePassPro
"""
import sys
import signal
import atexit
import os
import tempfile
import time
import threading
from typing import Optional, List, Callable
from utils.logger import get_logger

logger = get_logger("panic")


class PanicCleanup:
    """Global panic handler for emergency cleanup"""
    
    _clipboard_callbacks: List[Callable] = []
    _temp_files: List[str] = []
    _callbacks: List[Callable] = []
    _memory_cleanup_callbacks: List[Callable] = []
    _db_cleanup_callbacks: List[Callable] = []
    _panic_triggered = False
    _panic_lock = threading.Lock()
    _cleanup_completed = False
    
    @classmethod
    def register_clipboard_cleanup(cls, callback: Callable) -> None:
        """Register clipboard cleanup function"""
        if callback not in cls._clipboard_callbacks:
            cls._clipboard_callbacks.append(callback)
    
    @classmethod
    def register_temp_file(cls, file_path: str) -> None:
        """Register temporary file for cleanup"""
        if file_path not in cls._temp_files:
            cls._temp_files.append(file_path)
    
    @classmethod
    def register_cleanup_callback(cls, callback: Callable) -> None:
        """Register general cleanup callback"""
        if callback not in cls._callbacks:
            cls._callbacks.append(callback)
    
    @classmethod
    def register_memory_cleanup(cls, callback: Callable) -> None:
        """Register memory cleanup callback"""
        if callback not in cls._memory_cleanup_callbacks:
            cls._memory_cleanup_callbacks.append(callback)
    
    @classmethod
    def register_db_cleanup(cls, callback: Callable) -> None:
        """Register database cleanup callback"""
        if callback not in cls._db_cleanup_callbacks:
            cls._db_cleanup_callbacks.append(callback)
    
    @classmethod
    def emergency_cleanup(cls, reason: str = "unknown") -> None:
        """
        Emergency cleanup on crash/exit.
        Fail-closed: гарантирует очистку даже при ошибках.
        """
        with cls._panic_lock:
            if cls._panic_triggered:
                return
            cls._panic_triggered = True
        
        logger.warning(f"Emergency cleanup triggered: {reason}")
        start_time = time.time()
        
        # Список ошибок для логирования (не прерывает cleanup)
        errors = []
        
        # ========== 1. Очистка буфера обмена (критично) ==========
        for callback in cls._clipboard_callbacks:
            try:
                callback()
            except (AttributeError, RuntimeError, OSError, TypeError) as e:
                err_msg = f"Clipboard cleanup callback error: {e}"
                logger.debug(err_msg)
                errors.append(err_msg)
        
        # Дополнительная очистка через Windows API (fallback)
        try:
            cls._emergency_clipboard_clear_windows()
        except (AttributeError, OSError, RuntimeError) as e:
            err_msg = f"Windows clipboard clear error: {e}"
            logger.debug(err_msg)
            errors.append(err_msg)
        
        # ========== 2. Очистка временных файлов с перезаписью ==========
        for file_path in cls._temp_files[:]:  # Копия списка
            try:
                if os.path.exists(file_path):
                    # Перезапись перед удалением
                    try:
                        size = os.path.getsize(file_path)
                        if 0 < size < 10 * 1024 * 1024:  # Только файлы до 10MB
                            with open(file_path, 'wb') as f:
                                f.write(os.urandom(size))
                                f.flush()
                                os.fsync(f.fileno())
                    except (OSError, IOError, PermissionError, ValueError) as e:
                        logger.debug(f"File overwrite failed: {e}")
                    
                    # Удаление
                    try:
                        os.remove(file_path)
                    except (OSError, IOError, PermissionError) as e:
                        err_msg = f"Temp file remove error: {e}"
                        logger.debug(err_msg)
                        errors.append(err_msg)
                    
                    if file_path in cls._temp_files:
                        cls._temp_files.remove(file_path)
            except (OSError, AttributeError, RuntimeError) as e:
                err_msg = f"Temp file cleanup error: {e}"
                logger.debug(err_msg)
                errors.append(err_msg)
        
        # ========== 3. Очистка памяти ==========
        for callback in cls._memory_cleanup_callbacks:
            try:
                callback()
            except (AttributeError, RuntimeError, TypeError, MemoryError) as e:
                err_msg = f"Memory cleanup error: {e}"
                logger.debug(err_msg)
                errors.append(err_msg)
        
        # ========== 4. Очистка базы данных ==========
        for callback in cls._db_cleanup_callbacks:
            try:
                callback()
            except (AttributeError, RuntimeError, OSError, sqlite3.Error) as e:
                # sqlite3.Error может быть не импортирован, используем общий
                err_msg = f"DB cleanup error: {e}"
                logger.debug(err_msg)
                errors.append(err_msg)
        
        # ========== 5. Общие колбэки ==========
        for callback in cls._callbacks:
            try:
                callback()
            except (AttributeError, RuntimeError, TypeError, OSError) as e:
                err_msg = f"General callback error: {e}"
                logger.debug(err_msg)
                errors.append(err_msg)
        
        # ========== 6. Принудительный сбор мусора ==========
        try:
            import gc
            gc.collect()
        except (ImportError, RuntimeError) as e:
            logger.debug(f"GC collect error: {e}")
        
        cls._cleanup_completed = True
        elapsed = time.time() - start_time
        
        if errors:
            logger.warning(f"Emergency cleanup completed with {len(errors)} errors in {elapsed:.3f}s")
        else:
            logger.info(f"Emergency cleanup completed successfully in {elapsed:.3f}s")
    
    @classmethod
    def _emergency_clipboard_clear_windows(cls) -> None:
        """Windows-specific clipboard clear"""
        if sys.platform != "win32":
            return
        
        try:
            import ctypes
            user32 = ctypes.windll.user32
            if user32.OpenClipboard(0):
                try:
                    user32.EmptyClipboard()
                except (AttributeError, OSError) as e:
                    logger.debug(f"EmptyClipboard error: {e}")
                finally:
                    try:
                        user32.CloseClipboard()
                    except (AttributeError, OSError) as e:
                        logger.debug(f"CloseClipboard error: {e}")
        except (ImportError, AttributeError, OSError, TypeError) as e:
            logger.debug(f"Windows clipboard clear error: {e}")
    
    @classmethod
    def emergency_db_wipe(cls, db_path: str) -> bool:
        """
        Emergency database wipe - overwrites and deletes the database file.
        Returns True if successful.
        """
        if not os.path.exists(db_path):
            return True
        
        try:
            # Overwrite with random data multiple times
            size = os.path.getsize(db_path)
            if 0 < size < 100 * 1024 * 1024:  # Only for DBs under 100MB
                with open(db_path, 'wb') as f:
                    for _ in range(3):
                        try:
                            f.write(os.urandom(size))
                            f.flush()
                            os.fsync(f.fileno())
                            f.seek(0)
                        except (OSError, IOError, ValueError) as e:
                            logger.debug(f"Overwrite error: {e}")
                            break
            
            # Delete the file
            os.remove(db_path)
            logger.info(f"Emergency DB wipe completed: {db_path}")
            return True
        except (OSError, IOError, PermissionError, ValueError) as e:
            logger.error(f"Emergency DB wipe failed: {e}")
            return False
    
    @classmethod
    def secure_shutdown(cls, exit_code: int = 0) -> None:
        """
        Perform secure shutdown with emergency cleanup.
        Гарантирует очистку даже при ошибках.
        """
        try:
            cls.emergency_cleanup(reason="secure_shutdown")
        except (RuntimeError, SystemExit, KeyboardInterrupt) as e:
            logger.error(f"Cleanup failed during shutdown: {e}")
        finally:
            # Final memory cleanup
            try:
                import gc
                gc.collect()
            except (ImportError, RuntimeError):
                pass
        
        sys.exit(exit_code)
    
    @classmethod
    def is_panic_triggered(cls) -> bool:
        """Check if panic cleanup has been triggered"""
        return cls._panic_triggered
    
    @classmethod
    def is_cleanup_completed(cls) -> bool:
        """Check if cleanup has completed successfully"""
        return cls._cleanup_completed
    
    @classmethod
    def reset(cls) -> None:
        """Reset panic state (for testing)"""
        with cls._panic_lock:
            cls._panic_triggered = False
            cls._cleanup_completed = False
            cls._clipboard_callbacks.clear()
            cls._temp_files.clear()
            cls._callbacks.clear()
            cls._memory_cleanup_callbacks.clear()
            cls._db_cleanup_callbacks.clear()
    
    @classmethod
    def _signal_handler(cls, signum: int, frame) -> None:
        """Signal handler for crashes"""
        signal_names = {
            signal.SIGINT: "SIGINT",
            signal.SIGTERM: "SIGTERM",
        }
        if sys.platform != "win32":
            try:
                signal_names[signal.SIGQUIT] = "SIGQUIT"
            except AttributeError:
                pass
        
        name = signal_names.get(signum, f"signal_{signum}")
        try:
            cls.emergency_cleanup(reason=name)
        except (RuntimeError, SystemExit) as e:
            logger.error(f"Signal handler cleanup error: {e}")
        sys.exit(1)
    
    @classmethod
    def _windows_exception_handler(cls, exception_type, exception_value, traceback) -> None:
        """Windows-specific exception handler"""
        try:
            cls.emergency_cleanup(reason="unhandled_exception")
        except (RuntimeError, SystemExit) as e:
            logger.error(f"Exception handler cleanup error: {e}")
        # Call original exception handler
        try:
            sys.__excepthook__(exception_type, exception_value, traceback)
        except (TypeError, AttributeError, RuntimeError):
            pass
    
    @classmethod
    def init(cls) -> None:
        """Initialize panic handlers"""
        # Register atexit
        try:
            atexit.register(lambda: cls.emergency_cleanup(reason="atexit"))
        except (TypeError, RuntimeError) as e:
            logger.debug(f"Atexit registration error: {e}")
        
        # Register signal handlers
        try:
            signal.signal(signal.SIGTERM, cls._signal_handler)
            signal.signal(signal.SIGINT, cls._signal_handler)
        except (ValueError, AttributeError, OSError) as e:
            logger.debug(f"Signal handler registration error: {e}")
        
        # Unix-specific signals
        if sys.platform != "win32":
            try:
                signal.signal(signal.SIGQUIT, cls._signal_handler)
            except (ValueError, AttributeError, OSError) as e:
                logger.debug(f"SIGQUIT handler registration error: {e}")
        
        # Windows-specific
        if sys.platform == "win32":
            try:
                import ctypes
                # Set error mode to prevent crash dialogs
                ctypes.windll.kernel32.SetErrorMode(0x8001)
            except (ImportError, AttributeError, OSError) as e:
                logger.debug(f"Windows error mode setting error: {e}")
            
            try:
                # Set unhandled exception handler
                sys.excepthook = cls._windows_exception_handler
            except (TypeError, AttributeError, RuntimeError) as e:
                logger.debug(f"Windows exception handler error: {e}")
        
        logger.info("Panic cleanup system initialized")


# Global hotkey for panic cleanup (Ctrl+Alt+Shift+P)
_panic_hotkey_thread = None
_panic_hotkey_running = False


def _panic_hotkey_listener() -> None:
    """Background thread for panic hotkey detection"""
    global _panic_hotkey_running
    
    try:
        import keyboard
    except ImportError as e:
        logger.debug(f"Keyboard module not available, panic hotkey disabled: {e}")
        return
    
    def on_panic():
        logger.warning("Panic hotkey triggered! Performing emergency cleanup...")
        PanicCleanup.emergency_cleanup(reason="hotkey")
    
    try:
        keyboard.add_hotkey('ctrl+alt+shift+p', on_panic)
        while _panic_hotkey_running:
            time.sleep(0.1)
    except (ImportError, AttributeError, OSError, RuntimeError) as e:
        logger.debug(f"Hotkey listener error: {e}")
    finally:
        _panic_hotkey_running = False


def start_panic_hotkey() -> None:
    """Start panic hotkey listener (Ctrl+Alt+Shift+P)"""
    global _panic_hotkey_thread, _panic_hotkey_running
    
    if _panic_hotkey_thread is not None and _panic_hotkey_thread.is_alive():
        return
    
    _panic_hotkey_running = True
    _panic_hotkey_thread = threading.Thread(target=_panic_hotkey_listener, daemon=True)
    try:
        _panic_hotkey_thread.start()
        logger.info("Panic hotkey enabled: Ctrl+Alt+Shift+P")
    except (RuntimeError, threading.ThreadError) as e:
        logger.debug(f"Failed to start panic hotkey thread: {e}")
        _panic_hotkey_running = False


def stop_panic_hotkey() -> None:
    """Stop panic hotkey listener"""
    global _panic_hotkey_running, _panic_hotkey_thread
    
    _panic_hotkey_running = False
    if _panic_hotkey_thread and _panic_hotkey_thread.is_alive():
        try:
            _panic_hotkey_thread.join(timeout=1.0)
        except (RuntimeError, threading.ThreadError) as e:
            logger.debug(f"Hotkey thread join error: {e}")
    _panic_hotkey_thread = None


def init_panic_cleanup(enable_hotkey: bool = False) -> None:
    """
    Initialize panic cleanup system.
    
    Args:
        enable_hotkey: Enable panic hotkey (Ctrl+Alt+Shift+P)
    """
    PanicCleanup.init()
    
    if enable_hotkey:
        try:
            start_panic_hotkey()
        except (ImportError, RuntimeError, AttributeError) as e:
            logger.debug(f"Failed to start panic hotkey: {e}")


# Для обратной совместимости
def register_clipboard_cleanup(callback: Callable) -> None:
    PanicCleanup.register_clipboard_cleanup(callback)


def register_temp_file(file_path: str) -> None:
    PanicCleanup.register_temp_file(file_path)


def register_cleanup_callback(callback: Callable) -> None:
    PanicCleanup.register_cleanup_callback(callback)


# Экспорт
__all__ = [
    'PanicCleanup',
    'init_panic_cleanup',
    'start_panic_hotkey',
    'stop_panic_hotkey',
    'register_clipboard_cleanup',
    'register_temp_file',
    'register_cleanup_callback',
]