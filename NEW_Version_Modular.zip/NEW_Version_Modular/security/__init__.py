"""
Security module - master password, encryption, integrity, anti-debug and clipboard
"""
from security.master import MasterPassword
from security.integrity import verify_file_integrity, save_file_with_hash
from security.encryption import encrypt, decrypt, set_key_from_master, clear_master_key
from security.antidebug import init_anti_debug, is_debugger_present, is_vm_detected
from security.clipboard import SecureClipboard, FallbackClipboard, set_clipboard, clear_clipboard

__all__ = [
    'MasterPassword',
    'verify_file_integrity',
    'save_file_with_hash',
    'encrypt',
    'decrypt',
    'set_key_from_master',
    'clear_master_key',
    'init_anti_debug',
    'is_debugger_present',
    'is_vm_detected',
    'SecureClipboard',
    'FallbackClipboard',
    'set_clipboard',
    'clear_clipboard'
]
