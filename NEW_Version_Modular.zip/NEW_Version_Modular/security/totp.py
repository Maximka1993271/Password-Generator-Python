"""
TOTP (Time-based One-Time Password) for two-factor authentication
Compatible with Google Authenticator, Authy, Microsoft Authenticator and others

TOTP (Time-based One-Time Password) для двухфакторной аутентификации
Совместим с Google Authenticator, Authy, Microsoft Authenticator и др.

TOTP (Time-based One-Time Password) для двофакторної аутентифікації
Сумісний з Google Authenticator, Authy, Microsoft Authenticator та ін.
"""

import os
import time
import base64
import hashlib
import hmac
import struct
import secrets
import binascii
from typing import Optional, Tuple
from datetime import datetime

# Remove dependency on utils.logger / Убираем зависимость от utils.logger / Прибираємо залежність від utils.logger
try:
    from utils.logger import get_logger
except ImportError:
    # Create stub logger / Создаем заглушку для логгера / Створюємо заглушку для логера
    import logging
    def get_logger(name):
        logger = logging.getLogger(name)
        logger.setLevel(logging.WARNING)
        if not logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
            logger.addHandler(handler)
        return logger

logger = get_logger("totp")

# TOTP constants / Константы TOTP / Константи TOTP
DEFAULT_INTERVAL = 30
DEFAULT_DIGITS = 6
DEFAULT_ALGORITHM = "SHA1"

MAX_VERIFY_ATTEMPTS = 5
VERIFY_ATTEMPT_WINDOW = 60


class TOTPError(Exception):
    pass


class TOTPInvalidSecretError(TOTPError):
    pass


class TOTPRateLimitError(TOTPError):
    pass


class TOTP:
    """Time-based One-Time Password generator
    Генератор одноразовых паролей на основе времени
    Генератор одноразових паролів на основі часу"""
    
    _used_codes = {}
    _verify_attempts = {}
    
    def __init__(self, secret: Optional[str] = None, digits: int = DEFAULT_DIGITS,
                 interval: int = DEFAULT_INTERVAL, algorithm: str = DEFAULT_ALGORITHM):
        self.digits = digits
        self.interval = interval
        self.algorithm = algorithm.upper()
        
        if secret is None:
            self.secret = self.generate_secret()
        else:
            self.secret = secret.upper().replace(" ", "").replace("-", "")
            logger.debug(f"Secret set, length: {len(self.secret)}")
        
        self._validate_secret()
    
    def _validate_secret(self) -> None:
        import re
        if not re.match(r'^[A-Z2-7]+$', self.secret):
            logger.warning(f"Invalid TOTP secret format: {self.secret[:10]}...")
    
    @staticmethod
    def generate_secret(length: int = 16) -> str:
        """Generate random secret key in base32 (16 bytes = 26 characters)
        Генерирует случайный секретный ключ в base32 (16 байт = 26 символов)
        Генерує випадковий секретний ключ у base32 (16 байт = 26 символів)"""
        try:
            random_bytes = secrets.token_bytes(length)
            secret = base64.b32encode(random_bytes).decode('utf-8').rstrip('=')
            logger.debug(f"Generated new TOTP secret of length {len(secret)}")
            return secret
        except (ValueError, TypeError, binascii.Error) as e:
            logger.error(f"Failed to generate secret: {e}")
            raise TOTPError(f"Secret generation failed: {e}")
    
    @staticmethod
    def get_provisioning_uri(secret: str, account_name: str, issuer_name: str = "SecurePassPro") -> str:
        """Get provisioning URI for QR code / Получить URI для QR-кода / Отримати URI для QR-коду"""
        from urllib.parse import quote
        secret_clean = secret.upper().replace(" ", "").replace("-", "")
        uri = f"otpauth://totp/{quote(issuer_name)}:{quote(account_name)}?secret={secret_clean}&issuer={quote(issuer_name)}&period=30&digits=6"
        logger.debug(f"Generated provisioning URI for {account_name}")
        return uri
    
    def _get_hotp_token(self, counter: int) -> str:
        try:
            # Remove spaces and dashes from secret / Убираем пробелы и дефисы из секрета / Прибираємо пробіли та дефіси з секрету
            clean_secret = self.secret.replace(" ", "").replace("-", "")
            # Add padding if needed / Добавляем паддинг если нужно / Додаємо паддинг якщо потрібно
            padding = (8 - len(clean_secret) % 8) % 8
            secret_padded = clean_secret + '=' * padding
            key = base64.b32decode(secret_padded)
        except (binascii.Error, ValueError, TypeError) as e:
            logger.error(f"Failed to decode secret: {e}")
            raise TOTPInvalidSecretError(f"Secret decoding failed: {e}")
        
        counter_bytes = struct.pack(">Q", counter)
        
        try:
            if self.algorithm == "SHA1":
                h = hmac.new(key, counter_bytes, hashlib.sha1).digest()
            elif self.algorithm == "SHA256":
                h = hmac.new(key, counter_bytes, hashlib.sha256).digest()
            elif self.algorithm == "SHA512":
                h = hmac.new(key, counter_bytes, hashlib.sha512).digest()
            else:
                raise TOTPError(f"Unsupported algorithm: {self.algorithm}")
        except (TypeError, ValueError) as e:
            logger.error(f"HMAC computation failed: {e}")
            raise TOTPError(f"HMAC failed: {e}")
        
        offset = h[-1] & 0x0F
        code = (
            ((h[offset] & 0x7F) << 24) |
            ((h[offset + 1] & 0xFF) << 16) |
            ((h[offset + 2] & 0xFF) << 8) |
            (h[offset + 3] & 0xFF)
        )
        
        code_str = str(code % (10 ** self.digits)).zfill(self.digits)
        return code_str
    
    def generate_code(self, timestamp: Optional[float] = None) -> str:
        if timestamp is None:
            timestamp = time.time()
        counter = int(timestamp // self.interval)
        return self._get_hotp_token(counter)
    
    def get_current_code(self) -> str:
        """Get current valid code / Получить текущий код / Отримати поточний код"""
        return self.generate_code()
    
    @classmethod
    def _check_rate_limit(cls, source: str) -> bool:
        current_time = time.time()
        if source in cls._verify_attempts:
            cls._verify_attempts[source] = [
                t for t in cls._verify_attempts[source]
                if current_time - t < VERIFY_ATTEMPT_WINDOW
            ]
        attempts = len(cls._verify_attempts.get(source, []))
        if attempts >= MAX_VERIFY_ATTEMPTS:
            logger.warning(f"Rate limit exceeded for source: {source}")
            return False
        return True
    
    @classmethod
    def _record_attempt(cls, source: str) -> None:
        current_time = time.time()
        if source not in cls._verify_attempts:
            cls._verify_attempts[source] = []
        cls._verify_attempts[source].append(current_time)
        if len(cls._verify_attempts[source]) > MAX_VERIFY_ATTEMPTS * 2:
            cls._verify_attempts[source] = cls._verify_attempts[source][-MAX_VERIFY_ATTEMPTS:]
    
    @classmethod
    def _is_code_reused(cls, code: str) -> bool:
        current_time = time.time()
        code_hash = hashlib.sha256(code.encode()).hexdigest()
        expired = []
        for stored_hash, timestamp in cls._used_codes.items():
            if current_time - timestamp > DEFAULT_INTERVAL:
                expired.append(stored_hash)
        for expired_hash in expired:
            del cls._used_codes[expired_hash]
        if code_hash in cls._used_codes:
            logger.warning(f"Code reuse detected: {code[:3]}...")
            return True
        return False
    
    @classmethod
    def _mark_code_used(cls, code: str) -> None:
        code_hash = hashlib.sha256(code.encode()).hexdigest()
        cls._used_codes[code_hash] = time.time()
        if len(cls._used_codes) > 100:
            sorted_items = sorted(cls._used_codes.items(), key=lambda x: x[1])
            for old_hash, _ in sorted_items[:50]:
                del cls._used_codes[old_hash]
    
    def verify(self, code: str, timestamp: Optional[float] = None, 
               window: int = 2, source: str = "unknown") -> Tuple[bool, int]:
        """
        Verify TOTP code with time drift window.
        
        Проверить TOTP код с учётом временного дрейфа.
        Перевірити TOTP код з урахуванням часового дрейфу.
        """
        if not self._check_rate_limit(source):
            raise TOTPRateLimitError(f"Rate limit exceeded for {source}")
        
        self._record_attempt(source)
        
        if timestamp is None:
            timestamp = time.time()
        
        try:
            code_clean = ''.join(filter(str.isdigit, str(code)))
        except (TypeError, AttributeError) as e:
            logger.debug(f"Code cleaning error: {e}")
            return False, 0
        
        if len(code_clean) != self.digits:
            logger.warning(f"Invalid code length: expected {self.digits}, got {len(code_clean)}")
            return False, 0
        
        if self._is_code_reused(code_clean):
            logger.warning(f"Replay attack detected from {source}")
            return False, 0
        
        for drift in range(-window, window + 1):
            test_timestamp = timestamp + (drift * self.interval)
            expected_code = self.generate_code(test_timestamp)
            if hmac.compare_digest(code_clean, expected_code):
                logger.debug(f"TOTP verification successful (drift={drift}, source={source})")
                self._mark_code_used(code_clean)
                return True, drift
        
        logger.warning(f"TOTP verification failed for source: {source}")
        return False, 0
    
    def get_time_remaining(self, timestamp: Optional[float] = None) -> int:
        """Get seconds remaining until code changes
        Получить секунд до смены кода
        Отримати секунд до зміни коду"""
        if timestamp is None:
            timestamp = time.time()
        return self.interval - int(timestamp) % self.interval
    
    def get_backup_codes(self, count: int = 10, length: int = 8) -> list:
        """Generate backup codes / Генерирует резервные коды / Генерує резервні коди"""
        backup_codes = []
        for i in range(count):
            code = ''.join(str(secrets.randbelow(10)) for _ in range(length))
            if length == 8:
                code = f"{code[:4]}-{code[4:]}"
            backup_codes.append(code)
        logger.debug(f"Generated {count} backup codes")
        return backup_codes
    
    @staticmethod
    def hash_backup_code(code: str) -> str:
        """Hash backup code for storage / Хеширует резервный код для хранения / Хешує резервний код для зберігання"""
        try:
            code_clean = code.replace("-", "").replace(" ", "")
            return hashlib.sha256(code_clean.encode('utf-8')).hexdigest()
        except (TypeError, AttributeError) as e:
            logger.error(f"Backup code hashing error: {e}")
            raise TOTPError(f"Failed to hash backup code: {e}")
    
    @staticmethod
    def verify_backup_code(code: str, stored_hash: str) -> bool:
        """Verify backup code against stored hash / Проверяет резервный код по хешу / Перевіряє резервний код за хешем"""
        try:
            code_clean = code.replace("-", "").replace(" ", "")
            computed_hash = TOTP.hash_backup_code(code_clean)
            return hmac.compare_digest(computed_hash, stored_hash.lower())
        except (TypeError, AttributeError, ValueError) as e:
            logger.debug(f"Backup code verification error: {e}")
            return False
    
    @classmethod
    def reset_rate_limit(cls, source: Optional[str] = None) -> None:
        """Reset rate limit for TOTP verification
        Сбросить ограничение частоты для проверки TOTP
        Скинути обмеження частоти для перевірки TOTP"""
        if source is None:
            cls._verify_attempts.clear()
        elif source in cls._verify_attempts:
            del cls._verify_attempts[source]
        logger.debug(f"Rate limit reset for source: {source or 'all'}")
    
    @classmethod
    def get_rate_limit_status(cls, source: str) -> dict:
        """Get rate limit status for source
        Получить статус ограничения частоты для источника
        Отримати статус обмеження частоти для джерела"""
        attempts = len(cls._verify_attempts.get(source, []))
        return {
            "attempts": attempts,
            "max_attempts": MAX_VERIFY_ATTEMPTS,
            "remaining": max(0, MAX_VERIFY_ATTEMPTS - attempts),
            "window_seconds": VERIFY_ATTEMPT_WINDOW
        }


class TOTPManager:
    """TOTP Manager for 2FA state management
    Менеджер TOTP для управления состоянием 2FA
    Менеджер TOTP для керування станом 2FA"""
    
    def __init__(self):
        self._enabled = False
        self._secret: Optional[str] = None
        self._backup_codes_hashes: list = []
        self._account_name: str = "SecurePassPro_User"
        self._totp_instance: Optional[TOTP] = None
    
    def enable_2fa(self, secret: Optional[str] = None) -> Tuple[str, str]:
        """Enable 2FA and return secret and provisioning URI
        Включить 2FA и вернуть секрет и URI для настройки
        Увімкнути 2FA та повернути секрет та URI для налаштування"""
        try:
            if secret is None:
                secret = TOTP.generate_secret()
            self._secret = secret.upper().replace(" ", "").replace("-", "")
            self._enabled = True
            self._totp_instance = TOTP(self._secret)
            provisioning_uri = TOTP.get_provisioning_uri(self._secret, self._account_name, "SecurePassPro")
            logger.info("2FA enabled")
            return self._secret, provisioning_uri
        except (TOTPError, TOTPInvalidSecretError, ValueError) as e:
            logger.error(f"Failed to enable 2FA: {e}")
            raise TOTPError(f"Cannot enable 2FA: {e}")
    
    def disable_2fa(self) -> None:
        """Disable 2FA and clear all data / Отключить 2FA и очистить все данные / Вимкнути 2FA та очистити всі дані"""
        self._secret = None
        self._enabled = False
        self._backup_codes_hashes = []
        self._totp_instance = None
        logger.info("2FA disabled")
    
    def is_enabled(self) -> bool:
        """Check if 2FA is enabled / Проверить, включена ли 2FA / Перевірити, чи увімкнено 2FA"""
        return self._enabled
    
    def verify_code(self, code: str, window: int = 2, source: str = "unknown") -> bool:
        """Verify TOTP code / Проверить TOTP код / Перевірити TOTP код"""
        if not self._enabled or not self._secret:
            return False
        if self._totp_instance is None:
            self._totp_instance = TOTP(self._secret)
        try:
            is_valid, _ = self._totp_instance.verify(code, window=window, source=source)
            return is_valid
        except TOTPRateLimitError as e:
            logger.warning(f"Rate limit during verification: {e}")
            return False
        except TOTPError as e:
            logger.error(f"Verification error: {e}")
            return False
    
    def verify_backup_code(self, code: str) -> bool:
        """Verify backup code and remove it if valid
        Проверить резервный код и удалить его если верен
        Перевірити резервний код та видалити його якщо вірний"""
        if not self._enabled or not self._backup_codes_hashes:
            return False
        try:
            code_clean = code.replace("-", "").replace(" ", "").upper()
        except (TypeError, AttributeError) as e:
            logger.debug(f"Backup code cleaning error: {e}")
            return False
        for i, stored_hash in enumerate(self._backup_codes_hashes):
            if TOTP.verify_backup_code(code_clean, stored_hash):
                self._backup_codes_hashes.pop(i)
                logger.info("Backup code used and removed")
                return True
        return False
    
    def set_backup_codes(self, codes: list) -> None:
        """Set backup codes (stores hashes) / Установить резервные коды (хранит хеши) / Встановити резервні коди (зберігає хеші)"""
        try:
            self._backup_codes_hashes = [TOTP.hash_backup_code(c) for c in codes]
            logger.debug(f"Stored {len(codes)} backup code hashes")
        except (TypeError, ValueError, TOTPError) as e:
            logger.error(f"Failed to set backup codes: {e}")
            raise TOTPError(f"Cannot set backup codes: {e}")
    
    def get_backup_codes_hashes(self) -> list:
        """Get stored backup code hashes / Получить хеши резервных кодов / Отримати хеші резервних кодів"""
        return self._backup_codes_hashes.copy()
    
    def get_secret(self) -> Optional[str]:
        """Get current TOTP secret / Получить текущий секрет TOTP / Отримати поточний секрет TOTP"""
        return self._secret
    
    def set_secret(self, secret: str) -> None:
        """Set TOTP secret from config / Установить секрет TOTP из конфига / Встановити секрет TOTP з конфігу"""
        try:
            self._secret = secret.upper().replace(" ", "").replace("-", "")
            if self._secret:
                self._enabled = True
                self._totp_instance = TOTP(self._secret)
        except (TOTPInvalidSecretError, ValueError) as e:
            logger.error(f"Failed to set secret: {e}")
            self._enabled = False
            self._secret = None
    
    def set_account_name(self, name: str) -> None:
        """Set account name for QR code / Установить имя аккаунта для QR-кода / Встановити ім'я акаунта для QR-коду"""
        self._account_name = name
    
    def get_provisioning_uri(self) -> Optional[str]:
        """Get provisioning URI for current secret / Получить URI для текущего секрета / Отримати URI для поточного секрету"""
        if self._secret:
            return TOTP.get_provisioning_uri(self._secret, self._account_name, "SecurePassPro")
        return None
    
    def get_backup_codes_count(self) -> int:
        """Get number of remaining backup codes / Получить количество оставшихся резервных кодов / Отримати кількість резервних кодів, що залишилися"""
        return len(self._backup_codes_hashes)
    
    def generate_new_backup_codes(self, count: int = 10, length: int = 8) -> list:
        """Generate new backup codes / Сгенерировать новые резервные коды / Згенерувати нові резервні коди"""
        if not self._enabled:
            raise TOTPError("2FA is not enabled")
        totp = TOTP(self._secret)
        new_codes = totp.get_backup_codes(count, length)
        self.set_backup_codes(new_codes)
        return new_codes


# Global instance / Глобальный экземпляр / Глобальний екземпляр
_totp_manager = TOTPManager()


def get_totp_manager() -> TOTPManager:
    """Get global TOTP manager instance / Возвращает глобальный экземпляр TOTPManager / Повертає глобальний екземпляр TOTPManager"""
    return _totp_manager


def init_totp_from_config(config) -> None:
    """
    Initialize TOTP from saved configuration.
    
    Инициализирует TOTP из сохранённой конфигурации.
    Ініціалізує TOTP із збереженої конфігурації.
    
    Args:
        config: Config object / Объект Config / Об'єкт Config
    """
    try:
        if config.get("2fa_enabled", False):
            secret = config.get("2fa_secret", "")
            if secret:
                _totp_manager.set_secret(secret)
                backup_hashes = config.get("2fa_backup_hashes", [])
                if isinstance(backup_hashes, list):
                    _totp_manager._backup_codes_hashes = backup_hashes
                account = config.get("2fa_account_name", "SecurePassPro_User")
                _totp_manager.set_account_name(account)
                logger.info("TOTP initialized from config")
    except (AttributeError, TypeError, ValueError) as e:
        logger.error(f"Failed to init TOTP from config: {e}")


def save_totp_to_config(config) -> None:
    """
    Save TOTP state to configuration.
    
    Сохраняет состояние TOTP в конфигурацию.
    Зберігає стан TOTP у конфігурацію.
    
    Args:
        config: Config object / Объект Config / Об'єкт Config
    """
    try:
        config.set("2fa_enabled", _totp_manager.is_enabled())
        if _totp_manager.get_secret():
            config.set("2fa_secret", _totp_manager.get_secret())
        config.set("2fa_backup_hashes", _totp_manager.get_backup_codes_hashes())
        config.save()
        logger.debug("TOTP state saved to config")
    except (AttributeError, TypeError, OSError) as e:
        logger.error(f"Failed to save TOTP to config: {e}")


def is_2fa_enabled() -> bool:
    """Check if 2FA is enabled / Проверяет, включена ли 2FA / Перевіряє, чи увімкнено 2FA"""
    return _totp_manager.is_enabled()


def generate_2fa_qr_data(account_name: str = "SecurePassPro_User") -> Tuple[str, str]:
    """
    Generate data for 2FA setup.
    
    Генерирует данные для настройки 2FA.
    Генерує дані для налаштування 2FA.
    
    Args:
        account_name: Account name (email or login) / Имя аккаунта (email или логин) / Ім'я акаунта (email або логін)
    
    Returns:
        (secret, provisioning_uri)
    
    Raises:
        TOTPError: On generation error / При ошибке генерації / При помилці генерації
    """
    try:
        secret = TOTP.generate_secret()
        provisioning_uri = TOTP.get_provisioning_uri(secret, account_name, "SecurePassPro")
        return secret, provisioning_uri
    except (TOTPError, ValueError, TypeError) as e:
        logger.error(f"Failed to generate 2FA QR data: {e}")
        raise TOTPError(f"Cannot generate QR data: {e}")


def verify_2fa_code(code: str, source: str = "unknown") -> bool:
    """
    Verify 2FA code (simplified function).
    
    Проверяет 2FA код (упрощённая функция).
    Перевіряє 2FA код (спрощена функція).
    
    Args:
        code: Code to verify / Код для проверки / Код для перевірки
        source: Request source / Источник запроса / Джерело запиту
    
    Returns:
        True if code is valid / True если код верен / True якщо код вірний
    """
    try:
        return _totp_manager.verify_code(code, source=source)
    except TOTPRateLimitError:
        logger.warning(f"Rate limit exceeded for source: {source}")
        return False
    except TOTPError as e:
        logger.error(f"2FA verification error: {e}")
        return False


def reset_2fa_rate_limit(source: Optional[str] = None) -> None:
    """Reset rate limit for 2FA / Сбрасывает ограничение частоты для 2FA / Скидає обмеження частоти для 2FA"""
    TOTP.reset_rate_limit(source)


def get_2fa_rate_limit_status(source: str) -> dict:
    """Get rate limit status for 2FA / Возвращает статус ограничения частоты для 2FA / Повертає статус обмеження частоти для 2FA"""
    return TOTP.get_rate_limit_status(source)


__all__ = [
    'TOTP',
    'TOTPManager',
    'TOTPError',
    'TOTPInvalidSecretError',
    'TOTPRateLimitError',
    'get_totp_manager',
    'init_totp_from_config',
    'save_totp_to_config',
    'is_2fa_enabled',
    'generate_2fa_qr_data',
    'verify_2fa_code',
    'reset_2fa_rate_limit',
    'get_2fa_rate_limit_status',
]