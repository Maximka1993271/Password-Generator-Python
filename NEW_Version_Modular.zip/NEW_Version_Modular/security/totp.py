"""
TOTP (Time-based One-Time Password) для двухфакторной аутентификации
Совместим с Google Authenticator, Authy, Microsoft Authenticator и др.
"""

import os
import time
import base64
import hashlib
import hmac
import struct
import secrets
import binascii
from typing import Optional, Tuple
from datetime import datetime
from utils.logger import get_logger

logger = get_logger("totp")

# Константы TOTP
DEFAULT_INTERVAL = 30  # секунд
DEFAULT_DIGITS = 6     # количество цифр в коде
DEFAULT_ALGORITHM = "SHA1"  # SHA1, SHA256, SHA512

# Максимальное количество попыток верификации подряд (anti-replay)
MAX_VERIFY_ATTEMPTS = 5
VERIFY_ATTEMPT_WINDOW = 60  # секунд


class TOTPError(Exception):
    """Исключение для ошибок TOTP"""
    pass


class TOTPInvalidSecretError(TOTPError):
    """Исключение для неверного формата секрета"""
    pass


class TOTPRateLimitError(TOTPError):
    """Исключение для превышения лимита попыток"""
    pass


class TOTP:
    """
    TOTP генератор и верификатор.
    Совместим с RFC 6238.
    """
    
    # Anti-replay: хранение использованных кодов
    _used_codes: dict = {}  # code_hash -> timestamp
    _verify_attempts: dict = {}  # source -> [timestamps]
    
    def __init__(self, secret: Optional[str] = None, digits: int = DEFAULT_DIGITS,
                 interval: int = DEFAULT_INTERVAL, algorithm: str = DEFAULT_ALGORITHM):
        """
        Инициализация TOTP.
        
        Args:
            secret: Секретный ключ (base32). Если None - будет сгенерирован.
            digits: Количество цифр в коде (6 или 8)
            interval: Интервал в секундах (обычно 30)
            algorithm: Алгоритм хеширования (SHA1, SHA256, SHA512)
        
        Raises:
            TOTPInvalidSecretError: Если секрет имеет неверный формат
        """
        self.digits = digits
        self.interval = interval
        self.algorithm = algorithm.upper()
        
        if secret is None:
            self.secret = self.generate_secret()
        else:
            # ОЧИЩАЕМ СЕКРЕТ ОТ ПРОБЕЛОВ, ДЕФИСОВ И ПРИВОДИМ К ВЕРХНЕМУ РЕГИСТРУ
            self.secret = secret.upper().replace(" ", "").replace("-", "")
            logger.debug(f"Secret set, length: {len(self.secret)}")
        
        # Проверка валидности secret
        self._validate_secret()
    
    def _validate_secret(self) -> None:
        """Проверяет, что секрет является валидной base32 строкой"""
        import re
        # Base32 символы: A-Z и 2-7
        if not re.match(r'^[A-Z2-7]+$', self.secret):
            raise TOTPInvalidSecretError(f"Invalid TOTP secret format: {self.secret[:10]}...")
    
    @staticmethod
    def generate_secret(length: int = 20) -> str:
        """
        Генерирует случайный секретный ключ в base32.
        
        Args:
            length: Количество байт для генерации (рекомендуется 20)
        
        Returns:
            base32 строка для использования в TOTP
        """
        try:
            random_bytes = secrets.token_bytes(length)
            secret = base64.b32encode(random_bytes).decode('utf-8').rstrip('=')
            logger.debug(f"Generated new TOTP secret of length {len(secret)}")
            return secret
        except (ValueError, TypeError, binascii.Error) as e:
            logger.error(f"Failed to generate secret: {e}")
            raise TOTPError(f"Secret generation failed: {e}")
    
    @staticmethod
    def get_provisioning_uri(secret: str, account_name: str, issuer_name: str = "SecurePassPro") -> str:
        """
        Создаёт URI для импорта в приложения-аутентификаторы.
        
        Args:
            secret: Секретный ключ
            account_name: Имя аккаунта (email или логин)
            issuer_name: Название сервиса
        
        Returns:
            otpauth:// URI для сканирования QR-кода
        """
        from urllib.parse import quote
        
        # ОЧИЩАЕМ СЕКРЕТ ОТ ПРОБЕЛОВ И ДЕФИСОВ
        secret_clean = secret.upper().replace(" ", "").replace("-", "")
        
        # Кодируем параметры для URL
        uri = f"otpauth://totp/{quote(issuer_name)}:{quote(account_name)}?secret={secret_clean}&issuer={quote(issuer_name)}&period=30&digits=6"
        
        logger.debug(f"Generated provisioning URI for {account_name}")
        return uri
    
    def _get_hotp_token(self, counter: int) -> str:
        """
        Генерирует HOTP токен для заданного счётчика.
        
        Args:
            counter: Счётчик (обычно временной слот)
        
        Returns:
            TOTP код
        """
        try:
            # Декодируем секрет из base32
            # Добавляем padding если нужно
            padding = (8 - len(self.secret) % 8) % 8
            secret_padded = self.secret + '=' * padding
            
            key = base64.b32decode(secret_padded)
        except (binascii.Error, ValueError, TypeError) as e:
            logger.error(f"Failed to decode secret: {e}")
            raise TOTPInvalidSecretError(f"Secret decoding failed: {e}")
        
        # Упаковываем counter в 8 байт (big-endian)
        counter_bytes = struct.pack(">Q", counter)
        
        # Вычисляем HMAC
        try:
            if self.algorithm == "SHA1":
                h = hmac.new(key, counter_bytes, hashlib.sha1).digest()
            elif self.algorithm == "SHA256":
                h = hmac.new(key, counter_bytes, hashlib.sha256).digest()
            elif self.algorithm == "SHA512":
                h = hmac.new(key, counter_bytes, hashlib.sha512).digest()
            else:
                raise TOTPError(f"Unsupported algorithm: {self.algorithm}")
        except (TypeError, ValueError) as e:
            logger.error(f"HMAC computation failed: {e}")
            raise TOTPError(f"HMAC failed: {e}")
        
        # Dynamic truncation
        offset = h[-1] & 0x0F
        code = (
            ((h[offset] & 0x7F) << 24) |
            ((h[offset + 1] & 0xFF) << 16) |
            ((h[offset + 2] & 0xFF) << 8) |
            (h[offset + 3] & 0xFF)
        )
        
        # Форматируем код с ведущими нулями
        code_str = str(code % (10 ** self.digits)).zfill(self.digits)
        
        return code_str
    
    def generate_code(self, timestamp: Optional[float] = None) -> str:
        """
        Генерирует TOTP код для текущего времени.
        
        Args:
            timestamp: Временная метка (None = текущее время)
        
        Returns:
            TOTP код из digits цифр
        """
        if timestamp is None:
            timestamp = time.time()
        
        # Вычисляем временной слот
        counter = int(timestamp // self.interval)
        
        return self._get_hotp_token(counter)
    
    def get_current_code(self) -> str:
        """Получает текущий TOTP код"""
        return self.generate_code()
    
    @classmethod
    def _check_rate_limit(cls, source: str) -> bool:
        """Проверяет ограничение частоты попыток верификации"""
        current_time = time.time()
        
        # Очищаем старые записи
        if source in cls._verify_attempts:
            # Удаляем попытки старше окна
            cls._verify_attempts[source] = [
                t for t in cls._verify_attempts[source]
                if current_time - t < VERIFY_ATTEMPT_WINDOW
            ]
        
        attempts = len(cls._verify_attempts.get(source, []))
        
        if attempts >= MAX_VERIFY_ATTEMPTS:
            logger.warning(f"Rate limit exceeded for source: {source}")
            return False
        
        return True
    
    @classmethod
    def _record_attempt(cls, source: str) -> None:
        """Записывает попытку верификации"""
        current_time = time.time()
        
        if source not in cls._verify_attempts:
            cls._verify_attempts[source] = []
        
        cls._verify_attempts[source].append(current_time)
        
        # Ограничиваем размер списка
        if len(cls._verify_attempts[source]) > MAX_VERIFY_ATTEMPTS * 2:
            cls._verify_attempts[source] = cls._verify_attempts[source][-MAX_VERIFY_ATTEMPTS:]
    
    @classmethod
    def _is_code_reused(cls, code: str) -> bool:
        """Проверяет, не использовался ли код ранее (anti-replay)"""
        current_time = time.time()
        code_hash = hashlib.sha256(code.encode()).hexdigest()
        
        # Очищаем старые коды (старше интервала)
        expired = []
        for stored_hash, timestamp in cls._used_codes.items():
            if current_time - timestamp > cls.DEFAULT_INTERVAL:
                expired.append(stored_hash)
        
        for expired_hash in expired:
            del cls._used_codes[expired_hash]
        
        if code_hash in cls._used_codes:
            logger.warning(f"Code reuse detected: {code[:3]}...")
            return True
        
        return False
    
    @classmethod
    def _mark_code_used(cls, code: str) -> None:
        """Отмечает код как использованный"""
        code_hash = hashlib.sha256(code.encode()).hexdigest()
        cls._used_codes[code_hash] = time.time()
        
        # Ограничиваем размер словаря
        if len(cls._used_codes) > 100:
            # Удаляем самые старые
            sorted_items = sorted(cls._used_codes.items(), key=lambda x: x[1])
            for old_hash, _ in sorted_items[:50]:
                del cls._used_codes[old_hash]
    
    def verify(self, code: str, timestamp: Optional[float] = None, 
               window: int = 1, source: str = "unknown") -> Tuple[bool, int]:
        """
        Проверяет TOTP код с защитой от replay и rate limiting.
        
        Args:
            code: Код для проверки (6-8 цифр)
            timestamp: Временная метка (None = текущее время)
            window: Количество соседних временных слотов для проверки (1-5)
            source: Источник запроса (для rate limiting)
        
        Returns:
            (is_valid, drift_slots) - валидность и смещение временного слота
        
        Raises:
            TOTPRateLimitError: При превышении лимита попыток
        """
        if not self._check_rate_limit(source):
            raise TOTPRateLimitError(f"Rate limit exceeded for {source}")
        
        self._record_attempt(source)
        
        if timestamp is None:
            timestamp = time.time()
        
        # ОЧИЩАЕМ КОД - ТОЛЬКО ЦИФРЫ (удаляем пробелы, дефисы, буквы)
        try:
            code_clean = ''.join(filter(str.isdigit, str(code)))
        except (TypeError, AttributeError) as e:
            logger.debug(f"Code cleaning error: {e}")
            return False, 0
        
        if len(code_clean) != self.digits:
            logger.warning(f"Invalid code length: expected {self.digits}, got {len(code_clean)}")
            return False, 0
        
        # Anti-replay: проверка на повторное использование кода
        if self._is_code_reused(code_clean):
            logger.warning(f"Replay attack detected from {source}")
            return False, 0
        
        # Проверяем текущий и соседние слоты
        for drift in range(-window, window + 1):
            test_timestamp = timestamp + (drift * self.interval)
            expected_code = self.generate_code(test_timestamp)
            
            # Используем hmac.compare_digest для защиты от timing attack
            if hmac.compare_digest(code_clean, expected_code):
                logger.debug(f"TOTP verification successful (drift={drift}, source={source})")
                # Отмечаем код как использованный
                self._mark_code_used(code_clean)
                return True, drift
        
        logger.warning(f"TOTP verification failed for source: {source}")
        return False, 0
    
    def get_time_remaining(self, timestamp: Optional[float] = None) -> int:
        """
        Возвращает количество секунд до смены кода.
        
        Returns:
            Секунд до следующего кода
        """
        if timestamp is None:
            timestamp = time.time()
        
        return self.interval - int(timestamp) % self.interval
    
    def get_backup_codes(self, count: int = 10, length: int = 8) -> list:
        """
        Генерирует резервные коды для входа при потере доступа к 2FA.
        
        Args:
            count: Количество кодов
            length: Длина каждого кода (цифр)
        
        Returns:
            Список резервных кодов
        """
        backup_codes = []
        for i in range(count):
            # Генерируем код из цифр
            code = ''.join(str(secrets.randbelow(10)) for _ in range(length))
            # Добавляем форматирование для читаемости (XXXX-XXXX)
            if length == 8:
                code = f"{code[:4]}-{code[4:]}"
            backup_codes.append(code)
        
        logger.debug(f"Generated {count} backup codes")
        return backup_codes
    
    @staticmethod
    def hash_backup_code(code: str) -> str:
        """
        Хеширует резервный код для безопасного хранения.
        
        Args:
            code: Резервный код
        
        Returns:
            SHA-256 хеш кода
        """
        # ОЧИЩАЕМ КОД ОТ ДЕФИСОВ
        try:
            code_clean = code.replace("-", "").replace(" ", "")
            return hashlib.sha256(code_clean.encode('utf-8')).hexdigest()
        except (TypeError, AttributeError) as e:
            logger.error(f"Backup code hashing error: {e}")
            raise TOTPError(f"Failed to hash backup code: {e}")
    
    @staticmethod
    def verify_backup_code(code: str, stored_hash: str) -> bool:
        """
        Проверяет резервный код по хешу.
        
        Args:
            code: Введённый код
            stored_hash: Сохранённый хеш
        
        Returns:
            True если код верен
        """
        try:
            code_clean = code.replace("-", "").replace(" ", "")
            computed_hash = TOTP.hash_backup_code(code_clean)
            return hmac.compare_digest(computed_hash, stored_hash.lower())
        except (TypeError, AttributeError, ValueError) as e:
            logger.debug(f"Backup code verification error: {e}")
            return False
    
    @classmethod
    def reset_rate_limit(cls, source: Optional[str] = None) -> None:
        """Сбрасывает ограничение частоты для источника"""
        if source is None:
            cls._verify_attempts.clear()
        elif source in cls._verify_attempts:
            del cls._verify_attempts[source]
        logger.debug(f"Rate limit reset for source: {source or 'all'}")
    
    @classmethod
    def get_rate_limit_status(cls, source: str) -> dict:
        """Возвращает статус ограничения частоты"""
        attempts = len(cls._verify_attempts.get(source, []))
        return {
            "attempts": attempts,
            "max_attempts": MAX_VERIFY_ATTEMPTS,
            "remaining": max(0, MAX_VERIFY_ATTEMPTS - attempts),
            "window_seconds": VERIFY_ATTEMPT_WINDOW
        }


class TOTPManager:
    """
    Менеджер TOTP для управления состоянием 2FA пользователя.
    """
    
    def __init__(self):
        self._enabled = False
        self._secret: Optional[str] = None
        self._backup_codes_hashes: list = []
        self._account_name: str = "SecurePassPro_User"
        self._totp_instance: Optional[TOTP] = None
    
    def enable_2fa(self, secret: Optional[str] = None) -> Tuple[str, str]:
        """
        Включает 2FA и возвращает секрет и provisioning URI.
        
        Args:
            secret: Секретный ключ (если None - генерируется)
        
        Returns:
            (secret, provisioning_uri)
        
        Raises:
            TOTPError: При ошибке генерации
        """
        try:
            if secret is None:
                secret = TOTP.generate_secret()
            
            # ОЧИЩАЕМ СЕКРЕТ
            self._secret = secret.upper().replace(" ", "").replace("-", "")
            self._enabled = True
            
            self._totp_instance = TOTP(self._secret)
            
            provisioning_uri = TOTP.get_provisioning_uri(self._secret, self._account_name, "SecurePassPro")
            
            logger.info("2FA enabled")
            return self._secret, provisioning_uri
        except (TOTPError, TOTPInvalidSecretError, ValueError) as e:
            logger.error(f"Failed to enable 2FA: {e}")
            raise TOTPError(f"Cannot enable 2FA: {e}")
    
    def disable_2fa(self) -> None:
        """Отключает 2FA и очищает все данные"""
        self._secret = None
        self._enabled = False
        self._backup_codes_hashes = []
        self._totp_instance = None
        logger.info("2FA disabled")
    
    def is_enabled(self) -> bool:
        """Проверяет, включена ли 2FA"""
        return self._enabled
    
    def verify_code(self, code: str, window: int = 1, source: str = "unknown") -> bool:
        """
        Проверяет TOTP код.
        
        Args:
            code: Код для проверки
            window: Окно проверки (1-5)
            source: Источник запроса
        
        Returns:
            True если код верен
        """
        if not self._enabled or not self._secret:
            return False
        
        if self._totp_instance is None:
            self._totp_instance = TOTP(self._secret)
        
        try:
            is_valid, _ = self._totp_instance.verify(code, window=window, source=source)
            return is_valid
        except TOTPRateLimitError as e:
            logger.warning(f"Rate limit during verification: {e}")
            return False
        except TOTPError as e:
            logger.error(f"Verification error: {e}")
            return False
    
    def verify_backup_code(self, code: str) -> bool:
        """
        Проверяет резервный код.
        
        Args:
            code: Резервный код
        
        Returns:
            True если код найден и удаляется из списка
        """
        if not self._enabled or not self._backup_codes_hashes:
            return False
        
        # ОЧИЩАЕМ КОД ОТ ДЕФИСОВ И ПРОБЕЛОВ
        try:
            code_clean = code.replace("-", "").replace(" ", "").upper()
        except (TypeError, AttributeError) as e:
            logger.debug(f"Backup code cleaning error: {e}")
            return False
        
        for i, stored_hash in enumerate(self._backup_codes_hashes):
            if TOTP.verify_backup_code(code_clean, stored_hash):
                # Удаляем использованный код
                self._backup_codes_hashes.pop(i)
                logger.info("Backup code used and removed")
                return True
        
        return False
    
    def set_backup_codes(self, codes: list) -> None:
        """
        Устанавливает резервные коды (сохраняет хеши).
        
        Args:
            codes: Список резервных кодов
        """
        try:
            self._backup_codes_hashes = [TOTP.hash_backup_code(c) for c in codes]
            logger.debug(f"Stored {len(codes)} backup code hashes")
        except (TypeError, ValueError, TOTPError) as e:
            logger.error(f"Failed to set backup codes: {e}")
            raise TOTPError(f"Cannot set backup codes: {e}")
    
    def get_backup_codes_hashes(self) -> list:
        """Возвращает хеши резервных кодов (для сохранения)"""
        return self._backup_codes_hashes.copy()
    
    def get_secret(self) -> Optional[str]:
        """Возвращает секрет"""
        return self._secret
    
    def set_secret(self, secret: str) -> None:
        """Устанавливает секрет (при загрузке из конфига)"""
        try:
            # ОЧИЩАЕМ СЕКРЕТ
            self._secret = secret.upper().replace(" ", "").replace("-", "")
            if self._secret:
                self._enabled = True
                self._totp_instance = TOTP(self._secret)
        except (TOTPInvalidSecretError, ValueError) as e:
            logger.error(f"Failed to set secret: {e}")
            self._enabled = False
            self._secret = None
    
    def set_account_name(self, name: str) -> None:
        """Устанавливает имя аккаунта для provisioning URI"""
        self._account_name = name
    
    def get_provisioning_uri(self) -> Optional[str]:
        """Возвращает provisioning URI"""
        if self._secret:
            return TOTP.get_provisioning_uri(self._secret, self._account_name, "SecurePassPro")
        return None
    
    def get_backup_codes_count(self) -> int:
        """Возвращает количество сохранённых резервных кодов"""
        return len(self._backup_codes_hashes)
    
    def generate_new_backup_codes(self, count: int = 10, length: int = 8) -> list:
        """
        Генерирует новые резервные коды.
        
        Args:
            count: Количество кодов
            length: Длина каждого кода
        
        Returns:
            Список новых резервных кодов
        """
        if not self._enabled:
            raise TOTPError("2FA is not enabled")
        
        totp = TOTP(self._secret)
        new_codes = totp.get_backup_codes(count, length)
        self.set_backup_codes(new_codes)
        return new_codes


# Глобальный экземпляр менеджера TOTP
_totp_manager = TOTPManager()


def get_totp_manager() -> TOTPManager:
    """Возвращает глобальный экземпляр TOTPManager"""
    return _totp_manager


def init_totp_from_config(config) -> None:
    """
    Инициализирует TOTP из сохранённой конфигурации.
    
    Args:
        config: Объект Config
    """
    try:
        if config.get("2fa_enabled", False):
            secret = config.get("2fa_secret", "")
            if secret:
                _totp_manager.set_secret(secret)
                backup_hashes = config.get("2fa_backup_hashes", [])
                if isinstance(backup_hashes, list):
                    _totp_manager._backup_codes_hashes = backup_hashes
                account = config.get("2fa_account_name", "SecurePassPro_User")
                _totp_manager.set_account_name(account)
                logger.info("TOTP initialized from config")
    except (AttributeError, TypeError, ValueError) as e:
        logger.error(f"Failed to init TOTP from config: {e}")


def save_totp_to_config(config) -> None:
    """
    Сохраняет состояние TOTP в конфигурацию.
    
    Args:
        config: Объект Config
    """
    try:
        config.set("2fa_enabled", _totp_manager.is_enabled())
        if _totp_manager.get_secret():
            config.set("2fa_secret", _totp_manager.get_secret())
        config.set("2fa_backup_hashes", _totp_manager.get_backup_codes_hashes())
        config.save()
        logger.debug("TOTP state saved to config")
    except (AttributeError, TypeError, OSError) as e:
        logger.error(f"Failed to save TOTP to config: {e}")


def is_2fa_enabled() -> bool:
    """Проверяет, включена ли 2FA"""
    return _totp_manager.is_enabled()


def generate_2fa_qr_data(account_name: str = "SecurePassPro_User") -> Tuple[str, str]:
    """
    Генерирует данные для настройки 2FA.
    
    Args:
        account_name: Имя аккаунта (email или логин)
    
    Returns:
        (secret, provisioning_uri)
    
    Raises:
        TOTPError: При ошибке генерации
    """
    try:
        secret = TOTP.generate_secret()
        provisioning_uri = TOTP.get_provisioning_uri(secret, account_name, "SecurePassPro")
        return secret, provisioning_uri
    except (TOTPError, ValueError, TypeError) as e:
        logger.error(f"Failed to generate 2FA QR data: {e}")
        raise TOTPError(f"Cannot generate QR data: {e}")


def verify_2fa_code(code: str, source: str = "unknown") -> bool:
    """
    Проверяет 2FA код (упрощённая функция).
    
    Args:
        code: Код для проверки
        source: Источник запроса
    
    Returns:
        True если код верен
    """
    try:
        return _totp_manager.verify_code(code, source=source)
    except TOTPRateLimitError:
        logger.warning(f"Rate limit exceeded for source: {source}")
        return False
    except TOTPError as e:
        logger.error(f"2FA verification error: {e}")
        return False


def reset_2fa_rate_limit(source: Optional[str] = None) -> None:
    """Сбрасывает ограничение частоты для 2FA"""
    TOTP.reset_rate_limit(source)


def get_2fa_rate_limit_status(source: str) -> dict:
    """Возвращает статус ограничения частоты для 2FA"""
    return TOTP.get_rate_limit_status(source)


__all__ = [
    'TOTP',
    'TOTPManager',
    'TOTPError',
    'TOTPInvalidSecretError',
    'TOTPRateLimitError',
    'get_totp_manager',
    'init_totp_from_config',
    'save_totp_to_config',
    'is_2fa_enabled',
    'generate_2fa_qr_data',
    'verify_2fa_code',
    'reset_2fa_rate_limit',
    'get_2fa_rate_limit_status',
]