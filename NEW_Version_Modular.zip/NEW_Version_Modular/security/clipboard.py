"""
Secure clipboard management for Windows
"""
import sys
import platform
import time
import ctypes
from ctypes import wintypes


class SecureClipboard:
    """Protected clipboard operations with Windows API"""
    
    @staticmethod
    def is_windows() -> bool:
        return platform.system() == "Windows"
    
    @staticmethod
    def secure_set_text(text: str) -> bool:
        """Set clipboard text with limited access (Windows only)"""
        if not SecureClipboard.is_windows():
            return False
        
        try:
            # Windows API constants
            CF_UNICODETEXT = 13
            GMEM_MOVEABLE = 0x0002
            
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            
            # Open clipboard
            if not user32.OpenClipboard(0):
                return False
            
            try:
                # Empty clipboard
                user32.EmptyClipboard()
                
                # Allocate global memory
                text_bytes = text.encode('utf-16le')
                hMem = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(text_bytes) + 2)
                if not hMem:
                    return False
                
                try:
                    # Lock memory and copy text
                    pMem = kernel32.GlobalLock(hMem)
                    ctypes.memmove(pMem, text_bytes, len(text_bytes))
                    kernel32.GlobalUnlock(hMem)
                    
                    # Set clipboard data
                    if user32.SetClipboardData(CF_UNICODETEXT, hMem):
                        # Memory now owned by clipboard
                        hMem = None
                        return True
                finally:
                    if hMem:
                        kernel32.GlobalFree(hMem)
            finally:
                user32.CloseClipboard()
                
        except Exception:
            return False
        
        return False
    
    @staticmethod
    def secure_clear() -> bool:
        """Clear clipboard and prevent reading"""
        if not SecureClipboard.is_windows():
            return False
        
        try:
            user32 = ctypes.windll.user32
            
            # Open and clear clipboard
            if user32.OpenClipboard(0):
                user32.EmptyClipboard()
                user32.CloseClipboard()
                return True
        except Exception:
            pass
        
        return False
    
    @staticmethod
    def set_with_timeout(text: str, timeout_sec: int, callback=None) -> None:
        """Set clipboard with auto-clear after timeout"""
        import threading
        
        SecureClipboard.secure_set_text(text)
        
        def clear():
            time.sleep(timeout_sec)
            SecureClipboard.secure_clear()
            if callback:
                callback()
        
        thread = threading.Thread(target=clear, daemon=True)
        thread.start()


# Fallback to tkinter clipboard for non-Windows
class FallbackClipboard:
    """Fallback clipboard using tkinter"""
    
    @staticmethod
    def set_text(root, text: str) -> bool:
        try:
            root.clipboard_clear()
            root.clipboard_append(text)
            return True
        except Exception:
            return False
    
    @staticmethod
    def clear(root) -> bool:
        try:
            root.clipboard_clear()
            return True
        except Exception:
            return False


def set_clipboard(root, text: str) -> bool:
    """Set clipboard using best available method"""
    if SecureClipboard.is_windows():
        return SecureClipboard.secure_set_text(text)
    else:
        return FallbackClipboard.set_text(root, text)


def clear_clipboard(root) -> bool:
    """Clear clipboard using best available method"""
    if SecureClipboard.is_windows():
        return SecureClipboard.secure_clear()
    else:
        return FallbackClipboard.clear(root)