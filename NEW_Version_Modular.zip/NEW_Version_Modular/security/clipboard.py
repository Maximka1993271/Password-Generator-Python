"""
Secure clipboard management for Windows
"""
import sys
import platform
import time
import ctypes
import tkinter as tk
import threading
import secrets
from typing import Optional, Callable, List
from utils.logger import get_logger

logger = get_logger("clipboard")


class ClipboardError(Exception):
    """Исключение для ошибок буфера обмена"""
    pass


class ClipboardOwnershipError(ClipboardError):
    """Исключение при проблемах с владением буфера обмена"""
    pass


class SecureClipboard:
    """Protected clipboard operations with Windows API"""
    
    # Константы Windows API
    CF_UNICODETEXT = 13
    GMEM_MOVEABLE = 0x0002
    GMEM_DDESHARE = 0x2000
    
    _clipboard_owner = None
    _clipboard_timer: Optional[threading.Timer] = None
    _active_timeouts: List[threading.Timer] = []
    
    @staticmethod
    def is_windows() -> bool:
        return platform.system() == "Windows"
    
    @staticmethod
    def get_clipboard_owner() -> Optional[str]:
        """Получить текущего владельца буфера обмена"""
        if not SecureClipboard.is_windows():
            return None
        return SecureClipboard._clipboard_owner
    
    @staticmethod
    def is_owned_by_us() -> bool:
        """Проверить, принадлежит ли буфер обмена нам"""
        return SecureClipboard._clipboard_owner is not None
    
    @staticmethod
    def secure_set_text(text: str, owner: str = "unknown") -> bool:
        """Set clipboard text with limited access (Windows only)"""
        if not SecureClipboard.is_windows():
            return False
        
        try:
            # Windows API constants
            CF_UNICODETEXT = 13
            GMEM_MOVEABLE = 0x0002
            
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            
            # Open clipboard
            if not user32.OpenClipboard(0):
                raise ClipboardError("Failed to open clipboard")
            
            try:
                # Empty clipboard
                if not user32.EmptyClipboard():
                    raise ClipboardError("Failed to empty clipboard")
                
                # Allocate global memory
                text_bytes = text.encode('utf-16le')
                hMem = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(text_bytes) + 2)
                if not hMem:
                    raise ClipboardError("Failed to allocate global memory")
                
                try:
                    # Lock memory and copy text
                    pMem = kernel32.GlobalLock(hMem)
                    ctypes.memmove(pMem, text_bytes, len(text_bytes))
                    kernel32.GlobalUnlock(hMem)
                    
                    # Set clipboard data
                    if not user32.SetClipboardData(CF_UNICODETEXT, hMem):
                        raise ClipboardError("Failed to set clipboard data")
                    
                    # Memory now owned by clipboard
                    hMem = None
                    SecureClipboard._clipboard_owner = owner
                    logger.debug(f"Clipboard set by: {owner}, size: {len(text)} chars")
                    return True
                finally:
                    if hMem:
                        kernel32.GlobalFree(hMem)
            finally:
                user32.CloseClipboard()
                
        except ClipboardError as e:
            logger.error(f"Clipboard error: {e}")
            return False
        except (AttributeError, OSError, TypeError) as e:
            logger.debug(f"Secure clipboard set error: {e}")
            return False
    
    @staticmethod
    def secure_clear(owner: str = "unknown") -> bool:
        """Clear clipboard and prevent reading (Windows only)"""
        if not SecureClipboard.is_windows():
            return False
        
        try:
            user32 = ctypes.windll.user32
            
            # Open and clear clipboard
            if user32.OpenClipboard(0):
                try:
                    user32.EmptyClipboard()
                    SecureClipboard._clipboard_owner = None
                    logger.debug(f"Clipboard cleared by: {owner}")
                    return True
                finally:
                    user32.CloseClipboard()
        except (AttributeError, OSError, TypeError) as e:
            logger.debug(f"Secure clipboard clear error: {e}")
        
        return False
    
    @staticmethod
    def secure_clear_multiple(passes: int = 5, owner: str = "unknown") -> bool:
        """
        Очищает буфер обмена с многократной перезаписью.
        
        Args:
            passes: количество проходов перезаписи
            owner: идентификатор владельца (для логов)
        """
        if not SecureClipboard.is_windows():
            return False
        
        success = True
        for i in range(passes):
            # Генерируем случайные данные
            junk = secrets.token_hex(256)
            if not SecureClipboard.secure_set_text(junk, owner):
                success = False
            time.sleep(0.01)  # Небольшая задержка между проходами
        
        # Финальная очистка
        if not SecureClipboard.secure_clear(owner):
            success = False
        
        logger.debug(f"Clipboard secure clear completed: {passes} passes")
        return success
    
    @staticmethod
    def set_with_timeout(text: str, timeout_sec: int, 
                         callback: Optional[Callable] = None,
                         owner: str = "unknown") -> threading.Timer:
        """Set clipboard with auto-clear after timeout"""
        # Отменяем предыдущие таймеры
        SecureClipboard.cancel_all_timeouts()
        
        # Устанавливаем текст
        SecureClipboard.secure_set_text(text, owner)
        
        def clear():
            SecureClipboard.secure_clear_multiple(passes=3, owner=owner)
            if callback:
                callback()
        
        timer = threading.Timer(timeout_sec, clear)
        timer.daemon = True
        timer.start()
        SecureClipboard._active_timeouts.append(timer)
        SecureClipboard._clipboard_timer = timer
        
        logger.debug(f"Clipboard timeout set: {timeout_sec}s, owner: {owner}")
        return timer
    
    @staticmethod
    def cancel_timeout(timer: Optional[threading.Timer] = None) -> None:
        """Отменяет таймер очистки буфера"""
        if timer is None:
            timer = SecureClipboard._clipboard_timer
        
        if timer and timer.is_alive():
            timer.cancel()
            if timer in SecureClipboard._active_timeouts:
                SecureClipboard._active_timeouts.remove(timer)
        
        if timer == SecureClipboard._clipboard_timer:
            SecureClipboard._clipboard_timer = None
    
    @staticmethod
    def cancel_all_timeouts() -> None:
        """Отменяет все активные таймеры"""
        for timer in SecureClipboard._active_timeouts[:]:
            if timer and timer.is_alive():
                timer.cancel()
        SecureClipboard._active_timeouts.clear()
        SecureClipboard._clipboard_timer = None
    
    @staticmethod
    def get_timeout_count() -> int:
        """Возвращает количество активных таймеров"""
        return len(SecureClipboard._active_timeouts)
    
    @staticmethod
    def verify_clipboard_clear() -> bool:
        """
        Проверяет, что буфер обмена действительно очищен.
        Возвращает True если буфер пуст или содержит только мусор.
        """
        if not SecureClipboard.is_windows():
            return True
        
        try:
            import ctypes
            user32 = ctypes.windll.user32
            
            if user32.OpenClipboard(0):
                try:
                    # Проверяем наличие данных
                    if not user32.IsClipboardFormatAvailable(SecureClipboard.CF_UNICODETEXT):
                        return True
                    
                    # Пытаемся получить данные
                    hData = user32.GetClipboardData(SecureClipboard.CF_UNICODETEXT)
                    if not hData:
                        return True
                    
                    # Данные есть - буфер не очищен
                    return False
                finally:
                    user32.CloseClipboard()
        except Exception as e:
            logger.debug(f"Clipboard verification error: {e}")
        
        return True


# Fallback to tkinter clipboard for non-Windows
class FallbackClipboard:
    """Fallback clipboard using tkinter"""
    
    _clipboard_owner = None
    _clipboard_timer: Optional[threading.Timer] = None
    
    @staticmethod
    def set_text(root, text: str, owner: str = "unknown") -> bool:
        try:
            root.clipboard_clear()
            root.clipboard_append(text)
            FallbackClipboard._clipboard_owner = owner
            logger.debug(f"Fallback clipboard set by: {owner}")
            return True
        except (tk.TclError, OSError) as e:
            logger.debug(f"Fallback set error: {e}")
            return False
    
    @staticmethod
    def clear(root, owner: str = "unknown") -> bool:
        try:
            root.clipboard_clear()
            FallbackClipboard._clipboard_owner = None
            logger.debug(f"Fallback clipboard cleared by: {owner}")
            return True
        except (tk.TclError, OSError) as e:
            logger.debug(f"Fallback clear error: {e}")
            return False
    
    @staticmethod
    def clear_multiple(root, passes: int = 5, owner: str = "unknown") -> bool:
        """Очистка с многократной перезаписью (fallback)"""
        success = True
        for _ in range(passes):
            try:
                root.clipboard_clear()
                # Перезаписываем случайными данными
                junk = secrets.token_hex(64)
                root.clipboard_append(junk)
                root.update()
                time.sleep(0.01)
            except Exception as e:
                logger.debug(f"Fallback clear pass error: {e}")
                success = False
        
        # Финальная очистка
        try:
            root.clipboard_clear()
            FallbackClipboard._clipboard_owner = None
        except Exception:
            success = False
        
        return success
    
    @staticmethod
    def set_with_timeout(root, text: str, timeout_sec: int,
                         callback: Optional[Callable] = None,
                         owner: str = "unknown") -> threading.Timer:
        """Set clipboard with auto-clear after timeout (fallback)"""
        # Отменяем предыдущий таймер
        if FallbackClipboard._clipboard_timer:
            FallbackClipboard._clipboard_timer.cancel()
        
        FallbackClipboard.set_text(root, text, owner)
        
        def clear():
            FallbackClipboard.clear_multiple(root, passes=3, owner=owner)
            if callback:
                callback()
        
        timer = threading.Timer(timeout_sec, clear)
        timer.daemon = True
        timer.start()
        FallbackClipboard._clipboard_timer = timer
        
        return timer
    
    @staticmethod
    def cancel_timeout() -> None:
        """Отменяет таймер очистки"""
        if FallbackClipboard._clipboard_timer and FallbackClipboard._clipboard_timer.is_alive():
            FallbackClipboard._clipboard_timer.cancel()
        FallbackClipboard._clipboard_timer = None


# Глобальные функции для удобства использования
_clipboard_root = None
_clipboard_owner = "unknown"


def init_clipboard(root=None) -> None:
    """Инициализирует глобальный буфер обмена"""
    global _clipboard_root
    _clipboard_root = root
    logger.info("Clipboard system initialized")


def set_clipboard(text: str, owner: str = "unknown", timeout: Optional[int] = None) -> bool:
    """
    Set clipboard using best available method.
    
    Args:
        text: Текст для копирования
        owner: Идентификатор владельца (для отслеживания)
        timeout: Автоматическая очистка через N секунд (опционально)
    """
    if SecureClipboard.is_windows():
        if timeout:
            SecureClipboard.set_with_timeout(text, timeout, owner=owner)
            return True
        else:
            return SecureClipboard.secure_set_text(text, owner)
    else:
        if _clipboard_root is None:
            logger.error("Clipboard not initialized. Call init_clipboard() first.")
            return False
        
        if timeout:
            FallbackClipboard.set_with_timeout(_clipboard_root, text, timeout, owner=owner)
            return True
        else:
            return FallbackClipboard.set_text(_clipboard_root, text, owner)


def clear_clipboard(owner: str = "unknown", secure: bool = True) -> bool:
    """
    Clear clipboard using best available method.
    
    Args:
        owner: Идентификатор владельца (для отслеживания)
        secure: Выполнять многократную перезапись
    """
    if SecureClipboard.is_windows():
        if secure:
            return SecureClipboard.secure_clear_multiple(passes=5, owner=owner)
        else:
            return SecureClipboard.secure_clear(owner)
    else:
        if _clipboard_root is None:
            logger.error("Clipboard not initialized. Call init_clipboard() first.")
            return False
        
        if secure:
            return FallbackClipboard.clear_multiple(_clipboard_root, passes=5, owner=owner)
        else:
            return FallbackClipboard.clear(_clipboard_root, owner)


def get_clipboard_owner() -> Optional[str]:
    """Возвращает идентификатор владельца буфера обмена"""
    if SecureClipboard.is_windows():
        return SecureClipboard.get_clipboard_owner()
    else:
        return FallbackClipboard._clipboard_owner


def cancel_clipboard_timeout() -> None:
    """Отменяет автоматическую очистку буфера обмена"""
    if SecureClipboard.is_windows():
        SecureClipboard.cancel_all_timeouts()
    else:
        FallbackClipboard.cancel_timeout()


def verify_clipboard_clear() -> bool:
    """Проверяет, что буфер обмена очищен"""
    if SecureClipboard.is_windows():
        return SecureClipboard.verify_clipboard_clear()
    return True


# Экспорт
__all__ = [
    'SecureClipboard',
    'FallbackClipboard',
    'init_clipboard',
    'set_clipboard',
    'clear_clipboard',
    'get_clipboard_owner',
    'cancel_clipboard_timeout',
    'verify_clipboard_clear',
    'ClipboardError',
    'ClipboardOwnershipError',
]