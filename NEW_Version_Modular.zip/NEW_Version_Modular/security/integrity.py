"""
File integrity checking - DISABLED for SHA-256 files.
SHA-256 file creation has been removed per user request.
Only simple file save without hash file.
"""

import os
import tempfile

HASH_EXTENSION = ".sha256"


def _atomic_write(path: str, content: bytes) -> None:
    """
    Атомарная запись файла (без создания .sha256)
    """
    directory = os.path.dirname(os.path.abspath(path)) or "."
    fd, tmp_path = tempfile.mkstemp(prefix=".tmp-", dir=directory)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.remove(tmp_path)
        except Exception:
            pass
        raise


def verify_file_integrity(file_path: str) -> bool:
    """
    Проверка целостности файла.
    Так как SHA-256 файлы больше не создаются, всегда возвращает True.
    """
    # SHA-256 файлы больше не создаются, поэтому всегда считаем файл валидным
    return True


def save_file_with_hash(file_path: str, content: bytes) -> bool:
    """
    Сохраняет ТОЛЬКО файл.
    НЕ создаёт .sha256 файл!
    
    Args:
        file_path: путь для сохранения файла
        content: содержимое файла в байтах
    
    Returns:
        True если файл успешно сохранён, False в случае ошибки
    """
    try:
        _atomic_write(file_path, content)
        
        # Проверяем, что файл действительно записан
        if os.path.exists(file_path) and os.path.getsize(file_path) == len(content):
            return True
        return False
    except Exception:
        return False