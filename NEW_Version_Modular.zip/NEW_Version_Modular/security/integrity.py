"""
File integrity checking - DISABLED for SHA-256 files.
SHA-256 file creation has been removed per user request.
Only simple file save without hash file.

Проверка целостности файлов - ОТКЛЮЧЕНА для SHA-256 файлов.
Создание SHA-256 файлов удалено по запросу пользователя.
Только простое сохранение файлов без хеш-файла.

Перевірка цілісності файлів - ВИМКНЕНА для SHA-256 файлів.
Створення SHA-256 файлів видалено за запитом користувача.
Тільки просте збереження файлів без хеш-файлу.
"""

import os
import tempfile
import hashlib
import hmac
from typing import Optional, Tuple
from utils.logger import get_logger

logger = get_logger("integrity")

HASH_EXTENSION = ".sha256"


class IntegrityError(Exception):
    """Exception for file integrity violation / Исключение при нарушении целостности файла / Виняток при порушенні цілісності файлу"""
    pass


def _atomic_write(path: str, content: bytes) -> None:
    """
    Atomic file write (without creating .sha256)
    
    Атомарная запись файла (без создания .sha256)
    Атомарний запис файлу (без створення .sha256)
    """
    directory = os.path.dirname(os.path.abspath(path)) or "."
    fd, tmp_path = tempfile.mkstemp(prefix=".tmp-", dir=directory)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    except (PermissionError, OSError, IOError) as e:
        try:
            os.remove(tmp_path)
        except (OSError, PermissionError):
            pass
        raise IntegrityError(f"Failed to write file atomically: {e}")


def _calculate_file_hash(file_path: str, algorithm: str = "sha256") -> Optional[str]:
    """Calculate file hash / Вычисляет хеш файла / Обчислює хеш файлу"""
    if not os.path.exists(file_path):
        return None
    
    try:
        if algorithm == "sha256":
            hasher = hashlib.sha256()
        elif algorithm == "sha3-256":
            hasher = hashlib.sha3_256()
        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")
        
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                hasher.update(chunk)
        return hasher.hexdigest()
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Failed to calculate hash for {file_path}: {e}")
        return None


def verify_file_integrity(file_path: str, expected_hash: Optional[str] = None) -> bool:
    """
    Verify file integrity.
    
    Проверка целостности файла.
    Перевірка цілісності файлу.
    
    Args:
        file_path: path to file / путь к файлу / шлях до файлу
        expected_hash: expected hash (optional) / ожидаемый хеш (опционально) / очікуваний хеш (опціонально)
    
    Returns:
        True if file is intact, False if integrity is violated
        True если файл цел, False в случае нарушения
        True якщо файл цілий, False у разі порушення
    """
    if not os.path.exists(file_path):
        logger.warning(f"File not found: {file_path}")
        return False
    
    try:
        # If hash not provided, look for hash file next to it
        # Если хеш не предоставлен, ищем рядом файл с хешем
        # Якщо хеш не надано, шукаємо поруч файл з хешем
        if expected_hash is None:
            hash_file = file_path + HASH_EXTENSION
            if os.path.exists(hash_file):
                try:
                    with open(hash_file, 'r', encoding='utf-8') as f:
                        expected_hash = f.read().strip()
                except (OSError, IOError, UnicodeDecodeError) as e:
                    logger.warning(f"Failed to read hash file: {e}")
                    return True  # If no hash, consider file valid / Если нет хеша, считаем файл валидным / Якщо немає хеша, вважаємо файл дійсним
        
        if expected_hash:
            actual_hash = _calculate_file_hash(file_path)
            if actual_hash is None:
                return False
            
            # Timing attack protected comparison / Сравнение защищённое от timing attack / Порівняння захищене від timing attack
            if hmac.compare_digest(actual_hash.lower(), expected_hash.lower()):
                logger.debug(f"Integrity check passed for {file_path}")
                return True
            else:
                logger.error(f"Integrity check FAILED for {file_path}")
                logger.error(f"  Expected: {expected_hash[:16]}...")
                logger.error(f"  Actual:   {actual_hash[:16]}...")
                return False
        
        return True
        
    except (OSError, IOError, ValueError) as e:
        logger.error(f"Integrity verification error: {e}")
        return False


def save_file_with_hash(file_path: str, content: bytes, create_hash: bool = False) -> bool:
    """
    Save file and optionally create .sha256 file.
    
    Сохраняет файл и опционально создаёт .sha256 файл.
    Зберігає файл та опціонально створює .sha256 файл.
    
    Args:
        file_path: path to save file / путь для сохранения файла / шлях для збереження файлу
        content: file content in bytes / содержимое файла в байтах / вміст файлу в байтах
        create_hash: whether to create hash file (default False) / создавать ли файл с хешем (по умолчанию False) / створювати чи файл з хешем (за замовчуванням False)
    
    Returns:
        True if file saved successfully, False on error
        True если файл успешно сохранён, False в случае ошибки
        True якщо файл успішно збережено, False у разі помилки
    """
    try:
        _atomic_write(file_path, content)
        
        # Check that file was actually written / Проверяем, что файл действительно записан / Перевіряємо, що файл дійсно записано
        if not os.path.exists(file_path) or os.path.getsize(file_path) != len(content):
            raise IntegrityError("File size mismatch after write")
        
        # Create hash file if needed / Создаём хеш файл если нужно / Створюємо хеш файл якщо потрібно
        if create_hash:
            file_hash = _calculate_file_hash(file_path)
            if file_hash:
                hash_path = file_path + HASH_EXTENSION
                _atomic_write(hash_path, file_hash.encode('utf-8'))
                logger.debug(f"Hash file created: {hash_path}")
        
        logger.debug(f"File saved successfully: {file_path}")
        return True
        
    except IntegrityError as e:
        logger.error(f"Integrity error saving file: {e}")
        return False
    except (PermissionError, OSError, IOError) as e:
        logger.error(f"Failed to save file {file_path}: {e}")
        return False


def verify_and_open(file_path: str, expected_hash: Optional[str] = None) -> Optional[bytes]:
    """
    Verify file integrity and return its contents.
    Fail-closed: returns None if integrity is violated.
    
    Проверяет целостность файла и возвращает его содержимое.
    Fail-closed: при нарушении целостности возвращает None.
    
    Перевіряє цілісність файлу та повертає його вміст.
    Fail-closed: при порушенні цілісності повертає None.
    
    Returns:
        File contents or None on error / Содержимое файла или None при ошибке / Вміст файлу або None при помилці
    """
    if not verify_file_integrity(file_path, expected_hash):
        logger.error(f"File integrity check failed, refusing to open: {file_path}")
        return None
    
    try:
        with open(file_path, 'rb') as f:
            return f.read()
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Failed to open file after integrity check: {e}")
        return None