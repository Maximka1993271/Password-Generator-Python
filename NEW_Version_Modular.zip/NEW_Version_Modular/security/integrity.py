"""
File integrity checking - DISABLED for SHA-256 files.
SHA-256 file creation has been removed per user request.
Only simple file save without hash file.
"""

import os
import tempfile
import hashlib
import hmac
from typing import Optional, Tuple
from utils.logger import get_logger

logger = get_logger("integrity")

HASH_EXTENSION = ".sha256"


class IntegrityError(Exception):
    """Исключение при нарушении целостности файла"""
    pass


def _atomic_write(path: str, content: bytes) -> None:
    """
    Атомарная запись файла (без создания .sha256)
    """
    directory = os.path.dirname(os.path.abspath(path)) or "."
    fd, tmp_path = tempfile.mkstemp(prefix=".tmp-", dir=directory)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    except (PermissionError, OSError, IOError) as e:
        try:
            os.remove(tmp_path)
        except (OSError, PermissionError):
            pass
        raise IntegrityError(f"Failed to write file atomically: {e}")


def _calculate_file_hash(file_path: str, algorithm: str = "sha256") -> Optional[str]:
    """Вычисляет хеш файла"""
    if not os.path.exists(file_path):
        return None
    
    try:
        if algorithm == "sha256":
            hasher = hashlib.sha256()
        elif algorithm == "sha3-256":
            hasher = hashlib.sha3_256()
        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")
        
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                hasher.update(chunk)
        return hasher.hexdigest()
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Failed to calculate hash for {file_path}: {e}")
        return None


def verify_file_integrity(file_path: str, expected_hash: Optional[str] = None) -> bool:
    """
    Проверка целостности файла.
    
    Args:
        file_path: путь к файлу
        expected_hash: ожидаемый хеш (опционально)
    
    Returns:
        True если файл цел, False в случае нарушения
    """
    if not os.path.exists(file_path):
        logger.warning(f"File not found: {file_path}")
        return False
    
    try:
        # Если хеш не предоставлен, ищем рядом файл с хешем
        if expected_hash is None:
            hash_file = file_path + HASH_EXTENSION
            if os.path.exists(hash_file):
                try:
                    with open(hash_file, 'r', encoding='utf-8') as f:
                        expected_hash = f.read().strip()
                except (OSError, IOError, UnicodeDecodeError) as e:
                    logger.warning(f"Failed to read hash file: {e}")
                    return True  # Если нет хеша, считаем файл валидным
        
        if expected_hash:
            actual_hash = _calculate_file_hash(file_path)
            if actual_hash is None:
                return False
            
            # Сравнение защищённое от timing attack
            if hmac.compare_digest(actual_hash.lower(), expected_hash.lower()):
                logger.debug(f"Integrity check passed for {file_path}")
                return True
            else:
                logger.error(f"Integrity check FAILED for {file_path}")
                logger.error(f"  Expected: {expected_hash[:16]}...")
                logger.error(f"  Actual:   {actual_hash[:16]}...")
                return False
        
        return True
        
    except (OSError, IOError, ValueError) as e:
        logger.error(f"Integrity verification error: {e}")
        return False


def save_file_with_hash(file_path: str, content: bytes, create_hash: bool = False) -> bool:
    """
    Сохраняет файл и опционально создаёт .sha256 файл.
    
    Args:
        file_path: путь для сохранения файла
        content: содержимое файла в байтах
        create_hash: создавать ли файл с хешем (по умолчанию False)
    
    Returns:
        True если файл успешно сохранён, False в случае ошибки
    """
    try:
        _atomic_write(file_path, content)
        
        # Проверяем, что файл действительно записан
        if not os.path.exists(file_path) or os.path.getsize(file_path) != len(content):
            raise IntegrityError("File size mismatch after write")
        
        # Создаём хеш файл если нужно
        if create_hash:
            file_hash = _calculate_file_hash(file_path)
            if file_hash:
                hash_path = file_path + HASH_EXTENSION
                _atomic_write(hash_path, file_hash.encode('utf-8'))
                logger.debug(f"Hash file created: {hash_path}")
        
        logger.debug(f"File saved successfully: {file_path}")
        return True
        
    except IntegrityError as e:
        logger.error(f"Integrity error saving file: {e}")
        return False
    except (PermissionError, OSError, IOError) as e:
        logger.error(f"Failed to save file {file_path}: {e}")
        return False


def verify_and_open(file_path: str, expected_hash: Optional[str] = None) -> Optional[bytes]:
    """
    Проверяет целостность файла и возвращает его содержимое.
    Fail-closed: при нарушении целостности возвращает None.
    
    Returns:
        Содержимое файла или None при ошибке
    """
    if not verify_file_integrity(file_path, expected_hash):
        logger.error(f"File integrity check failed, refusing to open: {file_path}")
        return None
    
    try:
        with open(file_path, 'rb') as f:
            return f.read()
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Failed to open file after integrity check: {e}")
        return None