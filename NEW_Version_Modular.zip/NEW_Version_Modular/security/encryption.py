"""
AES-256-GCM field-level encryption for password storage.
Support for key rotation, hardware-backed encryption (DPAPI/TPM), and SQLCipher.
"""

from __future__ import annotations
import os
import sys
import base64
import ctypes
import hashlib
import hmac
import platform
import uuid as _uuid_mod
import time
from typing import Optional, Tuple

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes as _hashes
    from cryptography.exceptions import InvalidTag
    _CRYPTO_OK = True
except ImportError as e:
    _CRYPTO_OK = False
    InvalidTag = Exception

from utils.logger import get_logger
from utils.secure_file_ops import secure_write, secure_read, secure_delete

logger = get_logger("encryption")


class CryptoUnavailableError(RuntimeError):
    """Encryption is required but the cryptography package is unavailable."""


class EncryptionError(Exception):
    """Ошибка при шифровании/дешифровании"""
    pass


class TamperDetectedError(EncryptionError):
    """Обнаружено вмешательство в зашифрованные данные"""
    pass


class KeyDerivationError(EncryptionError):
    """Ошибка при derivation ключа"""
    pass


class KeyRotationError(EncryptionError):
    """Ошибка при ротации ключа"""
    pass


# ── Paths ─────────────────────────────────────────────────────────────────────
if getattr(sys, 'frozen', False):
    _BASE_DIR = os.path.dirname(sys.executable)
else:
    _BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_DATA_DIR   = os.path.join(_BASE_DIR, "data")
_SALT_FILE  = os.path.join(_DATA_DIR, "db.salt")
_UUID_FILE  = os.path.join(_DATA_DIR, "machine.id")
_KEY_VERSION_FILE = os.path.join(_DATA_DIR, "key.version")
_SQLCIPHER_SALT_FILE = os.path.join(_DATA_DIR, "sqlcipher.salt")

# ── In-memory keys ────────────────────────────────────────────────────
_master_key:  Optional[bytearray] = None
_machine_key: Optional[bytearray] = None
_key_version: int = 1

# ── SQLCipher support ─────────────────────────────────────────────────
_sqlcipher_available = False
_sqlcipher_key: Optional[bytes] = None
_sqlcipher_key_hex: Optional[str] = None
_sqlcipher_salt: Optional[bytes] = None

try:
    from sqlcipher3 import dbapi2 as sqlcipher
    _sqlcipher_available = True
    logger.info("SQLCipher available")
except ImportError as e:
    try:
        import sqlite3
        sqlcipher = sqlite3
        logger.info(f"SQLCipher not available, using standard SQLite: {e}")
    except ImportError as e2:
        logger.error(f"SQLite import error: {e2}")

# ── Hardware encryption (DPAPI for Windows) ───────────────────────────
_DPAPI_AVAILABLE = False
_TPM_AVAILABLE = False

try:
    if sys.platform == "win32":
        import ctypes.wintypes
        
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", ctypes.wintypes.DWORD),
                       ("pbData", ctypes.POINTER(ctypes.c_char))]
        
        crypt32 = ctypes.windll.crypt32
        kernel32 = ctypes.windll.kernel32
        
        crypt32.CryptProtectData.argtypes = [ctypes.POINTER(DATA_BLOB), ctypes.c_wchar_p,
                                             ctypes.POINTER(DATA_BLOB), ctypes.c_void_p,
                                             ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(DATA_BLOB)]
        crypt32.CryptProtectData.restype = ctypes.c_bool
        
        crypt32.CryptUnprotectData.argtypes = [ctypes.POINTER(DATA_BLOB), ctypes.POINTER(ctypes.c_wchar_p),
                                               ctypes.POINTER(DATA_BLOB), ctypes.c_void_p,
                                               ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(DATA_BLOB)]
        crypt32.CryptUnprotectData.restype = ctypes.c_bool
        
        _DPAPI_AVAILABLE = True
        logger.info("DPAPI available for hardware-backed encryption")
except (ImportError, AttributeError, OSError, TypeError) as e:
    logger.debug(f"DPAPI not available: {e}")


def _dpapi_encrypt(data: bytes) -> Optional[bytes]:
    """Encrypt data using Windows DPAPI"""
    if not _DPAPI_AVAILABLE:
        return None
    
    try:
        blob_in = DATA_BLOB()
        blob_in.cbData = len(data)
        blob_in.pbData = ctypes.cast(ctypes.create_string_buffer(data), ctypes.POINTER(ctypes.c_char))
        
        blob_out = DATA_BLOB()
        if crypt32.CryptProtectData(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
            result = ctypes.string_at(blob_out.pbData, blob_out.cbData)
            kernel32.LocalFree(blob_out.pbData)
            return result
    except (OSError, TypeError, ValueError, AttributeError) as e:
        logger.error(f"DPAPI encrypt error: {e}")
    
    return None


def _dpapi_decrypt(encrypted_data: bytes) -> Optional[bytes]:
    """Decrypt data using Windows DPAPI"""
    if not _DPAPI_AVAILABLE:
        return None
    
    try:
        blob_in = DATA_BLOB()
        blob_in.cbData = len(encrypted_data)
        blob_in.pbData = ctypes.cast(ctypes.create_string_buffer(encrypted_data), ctypes.POINTER(ctypes.c_char))
        
        blob_out = DATA_BLOB()
        if crypt32.CryptUnprotectData(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
            result = ctypes.string_at(blob_out.pbData, blob_out.cbData)
            kernel32.LocalFree(blob_out.pbData)
            return result
    except (OSError, TypeError, ValueError, AttributeError) as e:
        logger.error(f"DPAPI decrypt error: {e}")
    
    return None


def _secure_zero(data: bytearray) -> None:
    """Обнуляет bytearray через ctypes.memset"""
    if data is None:
        return
    try:
        length = len(data)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(data)), 0, length)
        # Дополнительный проход для надёжности
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(data)), 0, length)
    except (TypeError, AttributeError, OSError) as e:
        logger.debug(f"Memory zeroing failed: {e}")
        for i in range(len(data)):
            data[i] = 0


def _clear_bytes(data: Optional[bytes]) -> None:
    """Очищает bytes (преобразует в bytearray и обнуляет)"""
    if data is None:
        return
    try:
        ba = bytearray(data)
        _secure_zero(ba)
    except (TypeError, MemoryError, OSError) as e:
        logger.debug(f"Bytes clearing failed: {e}")


def _clear_string(s: str) -> None:
    """Очищает строку (преобразует в bytearray и обнуляет)"""
    if not s:
        return
    if s.startswith("[encrypted"):
        return
    try:
        ba = bytearray(s.encode('utf-8'))
        _secure_zero(ba)
    except (UnicodeEncodeError, TypeError, MemoryError) as e:
        logger.debug(f"String clearing failed: {e}")


def _clear_bytearray(data: Optional[bytearray]) -> None:
    """Очищает bytearray"""
    if data is None:
        return
    _secure_zero(data)


def _hide_dir(path: str) -> None:
    """Скрывает папку на Windows"""
    if sys.platform == "win32":
        try:
            ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
        except (AttributeError, OSError, TypeError) as e:
            logger.debug(f"Hide dir failed: {e}")


def _ensure_data_dir() -> None:
    """Создаёт папку для данных"""
    try:
        os.makedirs(_DATA_DIR, exist_ok=True)
        _hide_dir(_DATA_DIR)
    except (PermissionError, OSError, IOError) as e:
        logger.error(f"Cannot create data dir: {e}")
        raise


def _secure_write_file(path: str, data: bytes) -> bool:
    """Атомарная запись файла с использованием secure_file_ops"""
    _ensure_data_dir()
    return secure_write(path, data, make_hidden=True)


def _get_key_version() -> int:
    """Получает текущую версию ключа для key rotation"""
    global _key_version
    if os.path.exists(_KEY_VERSION_FILE):
        try:
            content = secure_read(_KEY_VERSION_FILE)
            if content:
                _key_version = int(content.decode('utf-8').strip())
        except (ValueError, OSError, IOError, UnicodeDecodeError) as e:
            logger.debug(f"Key version read error: {e}")
    return _key_version


def _set_key_version(version: int) -> None:
    """Сохраняет версию ключа"""
    global _key_version
    _key_version = version
    try:
        _secure_write_file(_KEY_VERSION_FILE, str(version).encode('utf-8'))
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Failed to save key version: {e}")


def _get_salt() -> bytes:
    """Получает или создаёт соль для шифрования"""
    if os.path.exists(_SALT_FILE):
        try:
            content = secure_read(_SALT_FILE)
            if content and len(content) == 32:
                return content
            raise ValueError("Invalid encryption salt length")
        except (OSError, IOError, ValueError) as e:
            logger.error(f"Error reading salt: {e}")
            raise
    _ensure_data_dir()
    salt = os.urandom(32)
    _secure_write_file(_SALT_FILE, salt)
    return salt


def _get_machine_uuid() -> str:
    """Получает или создаёт UUID машины"""
    if os.path.exists(_UUID_FILE):
        try:
            content = secure_read(_UUID_FILE)
            if content:
                value = content.decode('utf-8').strip()
                try:
                    _uuid_mod.UUID(value)
                except ValueError as e:
                    logger.error(f"Invalid machine id: {e}")
                    raise ValueError("Invalid machine id") from e
                return value
        except (OSError, IOError, ValueError, UnicodeDecodeError) as e:
            logger.error(f"Error reading UUID: {e}")
            raise
    _ensure_data_dir()
    new_uuid = str(_uuid_mod.uuid4())
    _secure_write_file(_UUID_FILE, new_uuid.encode("utf-8"))
    return new_uuid


def _pbkdf2(secret: bytes, salt: bytes, iterations: int = 600_000) -> bytearray:
    """PBKDF2 ключа"""
    result = None
    try:
        if _CRYPTO_OK:
            kdf = PBKDF2HMAC(
                algorithm=_hashes.SHA256(),
                length=32, salt=salt, iterations=iterations)
            result = bytearray(kdf.derive(secret))
        else:
            result = bytearray(
                hashlib.pbkdf2_hmac('sha256', secret, salt, iterations, dklen=32))
        return result
    except (TypeError, ValueError, MemoryError, RuntimeError) as e:
        logger.error(f"PBKDF2 error: {e}")
        raise KeyDerivationError(f"Key derivation failed: {e}")
    finally:
        if result:
            _clear_bytes(secret)


def _get_machine_key() -> bytearray:
    """Получает ключ для machine-based fallback"""
    global _machine_key
    if _machine_key is None:
        machine_str = (
            _get_machine_uuid() + "|" +
            platform.node() + "|" +
            platform.machine() + "|" +
            sys.platform
        )
        key = _pbkdf2(
            machine_str.encode('utf-8', errors='replace'),
            _get_salt(), iterations=200_000)
        _machine_key = key
        _clear_string(machine_str)
    return _machine_key


def set_key_from_master(master_password: str) -> None:
    """Устанавливает ключ из мастер-пароля"""
    global _master_key
    _zero(_master_key)
    try:
        _master_key = _pbkdf2(
            master_password.encode('utf-8'), _get_salt())
    except KeyDerivationError as e:
        logger.error(f"Failed to derive key from master: {e}")
        raise
    finally:
        _clear_string(master_password)
    if master_password:
        set_sqlcipher_key(master_password)


def clear_master_key() -> None:
    """Очищает мастер-ключ из памяти"""
    global _master_key
    _zero(_master_key)
    _master_key = None
    clear_sqlcipher_key()


def _active_key() -> bytearray:
    """Возвращает активный ключ (master или machine)"""
    return _master_key if _master_key is not None else _get_machine_key()


_ENC_PREFIX = "enc1:"
_FALLBACK_PREFIX = "enc2:"
_DPAPI_PREFIX = "enc3:"  # Hardware-backed encryption via DPAPI
_ENC_VERSION = 2  # Текущая версия формата шифрования


def _xor_stream(data: bytes, key: bytes, nonce: bytes) -> bytes:
    """XOR шифрование для fallback"""
    out = bytearray()
    counter = 0
    try:
        while len(out) < len(data):
            counter_bytes = counter.to_bytes(8, "big")
            out.extend(hmac.new(key, nonce + counter_bytes, hashlib.sha256).digest())
            counter += 1
        return bytes(a ^ b for a, b in zip(data, out))
    except (TypeError, ValueError, MemoryError) as e:
        logger.error(f"XOR stream error: {e}")
        raise EncryptionError(f"XOR encryption failed: {e}")
    finally:
        _clear_bytes(key)


def _encrypt_fallback(plaintext: str, key: bytes) -> str:
    """Fallback шифрование"""
    try:
        nonce = os.urandom(16)
        ct = _xor_stream(plaintext.encode("utf-8"), key, nonce)
        tag = hmac.new(key, nonce + ct, hashlib.sha256).digest()
        result = _FALLBACK_PREFIX + base64.b64encode(nonce + tag + ct).decode("ascii")
        _clear_bytes(ct)
        _clear_bytes(tag)
        _clear_string(plaintext)
        return result
    except (TypeError, ValueError, MemoryError, OSError) as e:
        logger.error(f"Fallback encryption error: {e}")
        raise EncryptionError(f"Fallback encryption failed: {e}")


def _encrypt_hardware(plaintext: str) -> str:
    """Шифрование через аппаратное обеспечение (DPAPI)"""
    if _DPAPI_AVAILABLE:
        try:
            encrypted = _dpapi_encrypt(plaintext.encode('utf-8'))
            if encrypted:
                result = _DPAPI_PREFIX + base64.b64encode(encrypted).decode("ascii")
                _clear_string(plaintext)
                return result
        except (OSError, TypeError, ValueError, AttributeError) as e:
            logger.error(f"Hardware encryption error: {e}")
    
    return _encrypt_fallback(plaintext, bytes(_get_machine_key()))


def _decrypt_hardware(value: str) -> str:
    """Дешифрование через аппаратное обеспечение"""
    try:
        if value.startswith(_DPAPI_PREFIX):
            raw = base64.b64decode(value[len(_DPAPI_PREFIX):])
            decrypted = _dpapi_decrypt(raw)
            if decrypted:
                return decrypted.decode('utf-8')
    except (base64.binascii.Error, ValueError, UnicodeDecodeError, TypeError) as e:
        logger.error(f"Hardware decryption error: {e}")
        raise EncryptionError(f"Hardware decryption failed: {e}") from e
    
    raise EncryptionError("Hardware decryption failed")


def _decrypt_fallback(value: str, key: bytes) -> str:
    """Fallback дешифрование"""
    try:
        raw = base64.b64decode(value[len(_FALLBACK_PREFIX):], validate=True)
        if len(raw) < 48:
            raise ValueError("Invalid encrypted value length")
        nonce, tag, ct = raw[:16], raw[16:48], raw[48:]
        expected = hmac.new(key, nonce + ct, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, expected):
            raise TamperDetectedError("Encrypted value authentication failed - possible tampering")
        result = _xor_stream(ct, key, nonce).decode("utf-8")
        return result
    except (base64.binascii.Error, ValueError, UnicodeDecodeError, TypeError) as e:
        logger.error(f"Fallback decryption error: {e}")
        raise EncryptionError(f"Invalid encrypted data: {e}") from e
    except TamperDetectedError:
        raise
    finally:
        _clear_bytes(ct)
        _clear_bytes(tag)
        _clear_bytes(expected)
        _clear_bytes(key)


def encrypt(plaintext: str, use_hardware: bool = False) -> str:
    """
    Шифрует строку.
    Если use_hardware=True и доступен DPAPI — использует аппаратное шифрование.
    """
    if not plaintext:
        return ""
    
    if use_hardware and _DPAPI_AVAILABLE:
        return _encrypt_hardware(plaintext)
    
    key = bytes(_active_key())
    if not _CRYPTO_OK:
        return _encrypt_fallback(plaintext, key)
    
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)
    ciphertext = None
    try:
        ciphertext = aesgcm.encrypt(nonce, plaintext.encode('utf-8'), None)
        result = _ENC_PREFIX + base64.b64encode(nonce + ciphertext).decode('ascii')
        return result
    except InvalidTag as e:
        logger.error(f"Invalid tag during encryption: {e}")
        raise TamperDetectedError(f"Encryption authentication failed: {e}")
    except (TypeError, ValueError, MemoryError, RuntimeError) as e:
        logger.error(f"Encrypt error: {e}")
        raise EncryptionError(f"Encryption failed: {e}")
    finally:
        _clear_bytes(key)
        _clear_string(plaintext)
        if ciphertext:
            _clear_bytes(ciphertext)


def decrypt(value: str) -> str:
    """
    Дешифрует строку.
    Если строка не зашифрована — возвращает как есть.
    """
    if not value:
        return ""
    
    if not value.startswith(_ENC_PREFIX) and not value.startswith(_FALLBACK_PREFIX) and not value.startswith(_DPAPI_PREFIX):
        return value
    
    key = bytes(_active_key())
    result = value
    
    try:
        if value.startswith(_DPAPI_PREFIX):
            result = _decrypt_hardware(value)
            return result
        
        if value.startswith(_FALLBACK_PREFIX):
            result = _decrypt_fallback(value, key)
            return result
        
        if not _CRYPTO_OK:
            logger.warning("Cryptography not available, cannot decrypt AES-GCM")
            return value
        
        raw_b64 = value[len(_ENC_PREFIX):]
        data = base64.b64decode(raw_b64)
        if len(data) < 12:
            raise ValueError("Invalid encrypted data length")
        nonce, ct = data[:12], data[12:]
        
        # Проверка длины
        if len(nonce) != 12:
            raise ValueError("Invalid nonce length")
        
        aesgcm = AESGCM(key)
        result = aesgcm.decrypt(nonce, ct, None).decode('utf-8')
        return result
    except InvalidTag as e:
        logger.error(f"Invalid authentication tag - possible tampering: {e}")
        raise TamperDetectedError("Authentication failed - data may have been tampered") from e
    except (base64.binascii.Error, ValueError, UnicodeDecodeError, TypeError) as e:
        logger.error(f"Decryption decode error: {e}")
        raise EncryptionError(f"Decryption failed: {e}") from e
    finally:
        _clear_bytes(key)
        if result != value:
            _clear_string(value)


def reencrypt_all(old_master: Optional[str], new_master: Optional[str]) -> None:
    """
    Перешифровывает все пароли в БД одной атомарной SQLite-транзакцией.
    """
    import sqlite3
    from storage.database import DB_FILE

    global _master_key

    if old_master:
        try:
            set_key_from_master(old_master)
        except KeyDerivationError as e:
            logger.error(f"Failed to set key from old master: {e}")
            raise KeyRotationError(f"Cannot reencrypt: {e}")
        finally:
            _clear_string(old_master)
    else:
        _zero(_master_key)
        _master_key = None

    if not os.path.exists(DB_FILE):
        logger.info("Database file not found, nothing to reencrypt")
        return

    conn = None
    record_ids = []
    try:
        conn = sqlite3.connect(DB_FILE)
        rows = conn.execute("SELECT i, p FROM p ORDER BY i").fetchall()
        record_ids = [(row[0], row[1]) for row in rows]
    except sqlite3.OperationalError as e:
        logger.error(f"Database operational error during reencrypt: {e}")
        raise KeyRotationError(f"Cannot read database: {e}")
    except sqlite3.Error as e:
        logger.error(f"Database read error during reencrypt: {e}")
        raise KeyRotationError(f"Cannot read database: {e}")
    finally:
        if conn:
            conn.close()
    
    if not record_ids:
        logger.info("No records to reencrypt")
        return
    
    decrypted_passwords = []
    for record_id, encrypted_password in record_ids:
        try:
            decrypted = decrypt(encrypted_password)
            decrypted_passwords.append((record_id, decrypted))
        except (ValueError, TypeError, EncryptionError, TamperDetectedError) as e:
            logger.error(f"Decrypt error for id {record_id}: {e}")
            decrypted_passwords.append((record_id, encrypted_password))
        except (UnicodeDecodeError, AttributeError) as e:
            logger.error(f"Decode error for id {record_id}: {e}")
            decrypted_passwords.append((record_id, encrypted_password))
    
    if new_master:
        try:
            set_key_from_master(new_master)
        except KeyDerivationError as e:
            logger.error(f"Failed to set key from new master: {e}")
            raise KeyRotationError(f"Cannot reencrypt: {e}")
        finally:
            _clear_string(new_master)
    else:
        _zero(_master_key)
        _master_key = None
    
    conn = None
    try:
        conn = sqlite3.connect(DB_FILE)
        conn.execute("BEGIN EXCLUSIVE")
        for record_id, decrypted in decrypted_passwords:
            if decrypted.startswith(("[encrypted", "enc1:", "enc2:", "enc3:")):
                encrypted = decrypted
            else:
                try:
                    encrypted = encrypt(decrypted)
                except EncryptionError as e:
                    logger.error(f"Encrypt error for id {record_id}: {e}")
                    encrypted = decrypted
            conn.execute(
                "UPDATE p SET p=? WHERE i=?",
                (encrypted, record_id))
        conn.commit()
        logger.info(f"Reencrypted {len(decrypted_passwords)} records")
    except sqlite3.OperationalError as e:
        if conn:
            try:
                conn.rollback()
            except sqlite3.Error:
                pass
        logger.error(f"Database write error during reencrypt: {e}")
        raise KeyRotationError(f"Reencryption failed: {e}") from e
    except sqlite3.Error as e:
        if conn:
            try:
                conn.rollback()
            except sqlite3.Error:
                pass
        logger.error(f"Database error during reencrypt: {e}")
        raise KeyRotationError(f"Reencryption failed: {e}") from e
    finally:
        if conn:
            conn.close()
        for _, decrypted in decrypted_passwords:
            _clear_string(decrypted)


def rotate_key(old_master: Optional[str], new_master: Optional[str]) -> bool:
    """
    Ротация ключа шифрования.
    Перешифровывает все данные с новым ключом.
    """
    try:
        reencrypt_all(old_master, new_master)
        _set_key_version(_get_key_version() + 1)
        logger.info(f"Key rotation completed, new version: {_get_key_version()}")
        return True
    except (ValueError, sqlite3.Error, OSError, IOError, EncryptionError, KeyRotationError, KeyDerivationError) as e:
        logger.error(f"Key rotation failed: {e}")
        return False


def _zero(buf: Optional[bytearray]) -> None:
    """Обнуляет bytearray"""
    if buf is None:
        return
    try:
        ctypes.memset(
            (ctypes.c_char * len(buf)).from_buffer(buf), 0, len(buf))
        ctypes.memset(
            (ctypes.c_char * len(buf)).from_buffer(buf), 0, len(buf))
    except (TypeError, AttributeError, OSError) as e:
        logger.debug(f"Zero buffer failed: {e}")
        for i in range(len(buf)):
            buf[i] = 0


def _get_sqlcipher_salt() -> bytes:
    """Get or create SQLCipher salt"""
    if os.path.exists(_SQLCIPHER_SALT_FILE):
        try:
            content = secure_read(_SQLCIPHER_SALT_FILE)
            if content and len(content) == 32:
                return content
        except (OSError, IOError) as e:
            logger.error(f"Failed to read SQLCipher salt: {e}")
    
    # Генерируем новую соль
    salt = os.urandom(32)
    _ensure_data_dir()
    _secure_write_file(_SQLCIPHER_SALT_FILE, salt)
    return salt


# ==================== CRYPTO SELF-TESTS ====================

def _run_crypto_self_test() -> bool:
    """Запускает self-test криптографии при инициализации"""
    try:
        test_data = "SecurePassPro_SelfTest_2024"
        
        # Тест AES-GCM
        if _CRYPTO_OK:
            test_key = os.urandom(32)
            aesgcm = AESGCM(test_key)
            nonce = os.urandom(12)
            ciphertext = aesgcm.encrypt(nonce, test_data.encode('utf-8'), None)
            decrypted = aesgcm.decrypt(nonce, ciphertext, None).decode('utf-8')
            if decrypted != test_data:
                logger.error("AES-GCM self-test failed: decrypt mismatch")
                return False
            logger.debug("AES-GCM self-test passed")
        
        # Тест PBKDF2
        test_salt = os.urandom(16)
        test_secret = b"test_secret"
        derived = hashlib.pbkdf2_hmac('sha256', test_secret, test_salt, 1000, dklen=32)
        if len(derived) != 32:
            logger.error("PBKDF2 self-test failed: wrong length")
            return False
        logger.debug("PBKDF2 self-test passed")
        
        # Тест XOR fallback
        test_key_fb = os.urandom(32)
        test_nonce = os.urandom(16)
        test_plain = b"test_plaintext"
        encrypted = _xor_stream(test_plain, test_key_fb, test_nonce)
        decrypted = _xor_stream(encrypted, test_key_fb, test_nonce)
        if decrypted != test_plain:
            logger.error("XOR self-test failed: decrypt mismatch")
            return False
        logger.debug("XOR self-test passed")
        
        logger.info("Crypto self-tests passed")
        return True
        
    except (ImportError, OSError, TypeError, ValueError, MemoryError) as e:
        logger.error(f"Crypto self-test failed: {e}")
        return False
    except InvalidTag as e:
        logger.error(f"Crypto self-test invalid tag: {e}")
        return False


# Запускаем self-test при импорте модуля
_CRYPTO_SELF_TEST_PASSED = _run_crypto_self_test() if _CRYPTO_OK else False
if _CRYPTO_OK and not _CRYPTO_SELF_TEST_PASSED:
    logger.warning("Crypto self-test failed - encryption may be unreliable")


# ==================== SQLCipher SUPPORT ====================

def set_sqlcipher_key(master_password: str, salt: Optional[bytes] = None) -> None:
    """Set SQLCipher encryption key derived from master password"""
    global _sqlcipher_key, _sqlcipher_key_hex, _sqlcipher_salt
    
    if not _sqlcipher_available:
        logger.warning("SQLCipher not available, cannot set key")
        return
    
    if salt is None:
        _sqlcipher_salt = _get_sqlcipher_salt()
    else:
        _sqlcipher_salt = salt
    
    # Генерируем ключ как bytes (безопаснее)
    try:
        key = hashlib.pbkdf2_hmac('sha256', master_password.encode('utf-8'), _sqlcipher_salt, 64000, dklen=32)
        _sqlcipher_key = key
        _sqlcipher_key_hex = key.hex()
        
        try:
            from storage.database import set_sqlcipher_key as db_set_key
            db_set_key(master_password)
        except ImportError as e:
            logger.debug(f"Database module not available: {e}")
    except (ValueError, TypeError, MemoryError) as e:
        logger.error(f"Failed to set SQLCipher key: {e}")
        raise KeyDerivationError(f"SQLCipher key derivation failed: {e}")


def clear_sqlcipher_key() -> None:
    """Clear SQLCipher encryption key from memory with secure zeroing"""
    global _sqlcipher_key, _sqlcipher_key_hex
    if _sqlcipher_key:
        _secure_zero_bytes(_sqlcipher_key)
        _sqlcipher_key = None
    if _sqlcipher_key_hex:
        _clear_string(_sqlcipher_key_hex)
        _sqlcipher_key_hex = None


def _secure_zero_bytes(data: bytes) -> None:
    """Обнуляет bytes (конвертирует в bytearray и обнуляет)"""
    if data is None:
        return
    try:
        ba = bytearray(data)
        _secure_zero(ba)
    except (TypeError, MemoryError, OSError) as e:
        logger.debug(f"Bytes zeroing failed: {e}")


def get_sqlcipher_key() -> Optional[bytes]:
    """Get current SQLCipher key (as bytes)"""
    return _sqlcipher_key


def get_sqlcipher_key_hex() -> Optional[str]:
    """Get current SQLCipher key as hex string"""
    return _sqlcipher_key_hex


def get_sqlcipher_salt() -> Optional[bytes]:
    """Get SQLCipher salt"""
    if _sqlcipher_salt:
        return _sqlcipher_salt
    return _get_sqlcipher_salt()


def is_sqlcipher_available() -> bool:
    """Check if SQLCipher is available"""
    return _sqlcipher_available


def is_dpapi_available() -> bool:
    """Check if DPAPI is available"""
    return _DPAPI_AVAILABLE


def get_key_version() -> int:
    """Get current key version"""
    return _get_key_version()


def get_encryption_version() -> int:
    """Get current encryption format version"""
    return _ENC_VERSION


def verify_encryption() -> bool:
    """Проверяет работоспособность шифрования"""
    test_data = "test_data_123"
    try:
        encrypted = encrypt(test_data)
        decrypted = decrypt(encrypted)
        return decrypted == test_data
    except (ValueError, TypeError, EncryptionError, TamperDetectedError) as e:
        logger.error(f"Encryption verification failed: {e}")
        return False
    except (UnicodeDecodeError, AttributeError) as e:
        logger.error(f"Encryption verification error: {e}")
        return False