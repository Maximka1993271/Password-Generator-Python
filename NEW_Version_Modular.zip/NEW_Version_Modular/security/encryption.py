"""
AES-256-GCM field-level encryption for password storage.
"""

from __future__ import annotations
import os
import sys
import base64
import ctypes
import hashlib
import hmac
import platform
import tempfile
import uuid as _uuid_mod
from typing import Optional

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes as _hashes
    from cryptography.exceptions import InvalidTag
    _CRYPTO_OK = True
except ImportError:
    _CRYPTO_OK = False
    InvalidTag = Exception

from utils.logger import get_logger

logger = get_logger("encryption")


class CryptoUnavailableError(RuntimeError):
    """Encryption is required but the cryptography package is unavailable."""


# ── Paths ─────────────────────────────────────────────────────────────────────
if getattr(sys, 'frozen', False):
    _BASE_DIR = os.path.dirname(sys.executable)
else:
    _BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_DATA_DIR   = os.path.join(_BASE_DIR, "data")
_SALT_FILE  = os.path.join(_DATA_DIR, "db.salt")
_UUID_FILE  = os.path.join(_DATA_DIR, "machine.id")

# ── In-memory keys ────────────────────────────────────────────────────
_master_key:  Optional[bytearray] = None
_machine_key: Optional[bytearray] = None


def _secure_zero(data: bytearray) -> None:
    """Обнуляет bytearray через ctypes.memset"""
    if data is None:
        return
    try:
        length = len(data)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(data)), 0, length)
    except (TypeError, AttributeError, OSError) as e:
        logger.debug(f"Memory zeroing failed: {e}")
        for i in range(len(data)):
            data[i] = 0


def _clear_bytes(data: Optional[bytes]) -> None:
    """Очищает bytes (преобразует в bytearray и обнуляет)"""
    if data is None:
        return
    try:
        ba = bytearray(data)
        _secure_zero(ba)
    except (TypeError, MemoryError, OSError) as e:
        logger.debug(f"Bytes clearing failed: {e}")


def _clear_string(s: str) -> None:
    """Очищает строку (преобразует в bytearray и обнуляет)"""
    if not s:
        return
    if s.startswith("[encrypted"):
        return
    try:
        ba = bytearray(s.encode('utf-8'))
        _secure_zero(ba)
    except (UnicodeEncodeError, TypeError, MemoryError) as e:
        logger.debug(f"String clearing failed: {e}")


def _clear_bytearray(data: Optional[bytearray]) -> None:
    """Очищает bytearray"""
    if data is None:
        return
    _secure_zero(data)


def _hide_dir(path: str) -> None:
    """Скрывает папку на Windows"""
    if sys.platform == "win32":
        try:
            ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
        except (AttributeError, OSError, TypeError) as e:
            logger.debug(f"Hide dir failed: {e}")


def _ensure_data_dir() -> None:
    """Создаёт папку для данных"""
    try:
        os.makedirs(_DATA_DIR, exist_ok=True)
        _hide_dir(_DATA_DIR)
    except (PermissionError, OSError) as e:
        logger.error(f"Cannot create data dir: {e}")
        raise


def _secure_write(path: str, data: bytes) -> None:
    """Атомарная запись файла"""
    _ensure_data_dir()
    fd, tmp_path = tempfile.mkstemp(prefix=".tmp-", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
        if sys.platform == "win32":
            try:
                ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
            except (AttributeError, OSError) as e:
                logger.debug(f"Hide file failed: {e}")
        else:
            try:
                os.chmod(path, 0o600)
            except (PermissionError, OSError) as e:
                logger.debug(f"Chmod failed: {e}")
    except (PermissionError, OSError, IOError) as e:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        logger.error(f"Cannot write to {path}: {e}")
        raise IOError(f"Cannot write to {path}: {e}")


def _zero(buf: Optional[bytearray]) -> None:
    """Обнуляет bytearray"""
    if buf is None:
        return
    try:
        ctypes.memset(
            (ctypes.c_char * len(buf)).from_buffer(buf), 0, len(buf))
    except (TypeError, AttributeError, OSError) as e:
        logger.debug(f"Zero buffer failed: {e}")
        for i in range(len(buf)):
            buf[i] = 0


def _get_salt() -> bytes:
    """Получает или создаёт соль для шифрования"""
    if os.path.exists(_SALT_FILE):
        try:
            with open(_SALT_FILE, 'rb') as f:
                salt = f.read()
            if len(salt) != 32:
                raise ValueError("Invalid encryption salt")
            return salt
        except (OSError, IOError, ValueError) as e:
            logger.error(f"Error reading salt: {e}")
            raise
    _ensure_data_dir()
    salt = os.urandom(32)
    _secure_write(_SALT_FILE, salt)
    return salt


def _get_machine_uuid() -> str:
    """Получает или создаёт UUID машины"""
    if os.path.exists(_UUID_FILE):
        try:
            with open(_UUID_FILE, 'r', encoding='utf-8') as f:
                value = f.read().strip()
            try:
                _uuid_mod.UUID(value)
            except ValueError as e:
                logger.error(f"Invalid machine id: {e}")
                raise ValueError("Invalid machine id") from e
            return value
        except (OSError, IOError, ValueError) as e:
            logger.error(f"Error reading UUID: {e}")
            raise
    _ensure_data_dir()
    new_uuid = str(_uuid_mod.uuid4())
    _secure_write(_UUID_FILE, new_uuid.encode("utf-8"))
    return new_uuid


def _pbkdf2(secret: bytes, salt: bytes, iterations: int = 600_000) -> bytearray:
    """PBKDF2 ключа"""
    result = None
    try:
        if _CRYPTO_OK:
            kdf = PBKDF2HMAC(
                algorithm=_hashes.SHA256(),
                length=32, salt=salt, iterations=iterations)
            result = bytearray(kdf.derive(secret))
        else:
            result = bytearray(
                hashlib.pbkdf2_hmac('sha256', secret, salt, iterations, dklen=32))
        return result
    except (TypeError, ValueError, MemoryError) as e:
        logger.error(f"PBKDF2 error: {e}")
        raise
    finally:
        if result:
            _clear_bytes(secret)


def _get_machine_key() -> bytearray:
    """Получает ключ для machine-based fallback"""
    global _machine_key
    if _machine_key is None:
        machine_str = (
            _get_machine_uuid() + "|" +
            platform.node() + "|" +
            platform.machine() + "|" +
            sys.platform
        )
        key = _pbkdf2(
            machine_str.encode('utf-8', errors='replace'),
            _get_salt(), iterations=200_000)
        _machine_key = key
        _clear_string(machine_str)
    return _machine_key


def set_key_from_master(master_password: str) -> None:
    """Устанавливает ключ из мастер-пароля"""
    global _master_key
    _zero(_master_key)
    _master_key = _pbkdf2(
        master_password.encode('utf-8'), _get_salt())
    _clear_string(master_password)


def clear_master_key() -> None:
    """Очищает мастер-ключ из памяти"""
    global _master_key
    _zero(_master_key)
    _master_key = None


def _active_key() -> bytearray:
    """Возвращает активный ключ (master или machine)"""
    return _master_key if _master_key is not None else _get_machine_key()


_ENC_PREFIX = "enc1:"
_FALLBACK_PREFIX = "enc2:"


def _xor_stream(data: bytes, key: bytes, nonce: bytes) -> bytes:
    """XOR шифрование для fallback"""
    out = bytearray()
    counter = 0
    try:
        while len(out) < len(data):
            counter_bytes = counter.to_bytes(8, "big")
            out.extend(hmac.new(key, nonce + counter_bytes, hashlib.sha256).digest())
            counter += 1
        return bytes(a ^ b for a, b in zip(data, out))
    finally:
        _clear_bytes(key)


def _encrypt_fallback(plaintext: str, key: bytes) -> str:
    """Fallback шифрование"""
    nonce = os.urandom(16)
    ct = _xor_stream(plaintext.encode("utf-8"), key, nonce)
    tag = hmac.new(key, nonce + ct, hashlib.sha256).digest()
    result = _FALLBACK_PREFIX + base64.b64encode(nonce + tag + ct).decode("ascii")
    _clear_bytes(ct)
    _clear_bytes(tag)
    _clear_string(plaintext)
    return result


def _decrypt_fallback(value: str, key: bytes) -> str:
    """Fallback дешифрование"""
    try:
        raw = base64.b64decode(value[len(_FALLBACK_PREFIX):], validate=True)
        if len(raw) < 48:
            raise ValueError("Invalid encrypted value")
        nonce, tag, ct = raw[:16], raw[16:48], raw[48:]
        expected = hmac.new(key, nonce + ct, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, expected):
            raise ValueError("Encrypted value authentication failed")
        result = _xor_stream(ct, key, nonce).decode("utf-8")
        return result
    except (base64.binascii.Error, ValueError, UnicodeDecodeError) as e:
        logger.error(f"Fallback decryption error: {e}")
        raise ValueError("Invalid encrypted data") from e
    finally:
        _clear_bytes(ct)
        _clear_bytes(tag)
        _clear_bytes(expected)
        _clear_bytes(key)


def encrypt(plaintext: str) -> str:
    """
    Шифрует строку AES-256-GCM → "enc1:<base64>".
    """
    key = bytes(_active_key())
    if not _CRYPTO_OK:
        return _encrypt_fallback(plaintext, key)
    
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)
    ciphertext = None
    try:
        ciphertext = aesgcm.encrypt(nonce, plaintext.encode('utf-8'), None)
        result = _ENC_PREFIX + base64.b64encode(nonce + ciphertext).decode('ascii')
        return result
    except (TypeError, ValueError, MemoryError) as e:
        logger.error(f"Encrypt error: {e}")
        raise
    finally:
        _clear_bytes(key)
        _clear_string(plaintext)
        if ciphertext:
            _clear_bytes(ciphertext)


def decrypt(value: str) -> str:
    """
    Дешифрует строку.
    Если строка не зашифрована — возвращает как есть.
    """
    if not value.startswith(_ENC_PREFIX) and not value.startswith(_FALLBACK_PREFIX):
        return value
    
    key = bytes(_active_key())
    result = value
    
    try:
        if value.startswith(_FALLBACK_PREFIX):
            result = _decrypt_fallback(value, key)
            return result
        
        if not _CRYPTO_OK:
            return value
        
        raw_b64 = value[len(_ENC_PREFIX):]
        data = base64.b64decode(raw_b64)
        nonce, ct = data[:12], data[12:]
        # Исправлено: конкретные исключения вместо Exception
        result = AESGCM(key).decrypt(nonce, ct, None).decode('utf-8')
        return result
    except InvalidTag as e:
        logger.error(f"Invalid authentication tag: {e}")
        return "[encrypted - invalid key or corrupted data]"
    except (base64.binascii.Error, ValueError, UnicodeDecodeError) as e:
        logger.error(f"Decryption decode error: {e}")
        return "[encryption error]"
    finally:
        _clear_bytes(key)
        if result != value:
            _clear_string(value)


def reencrypt_all(old_master: Optional[str], new_master: Optional[str]) -> None:
    """
    Перешифровывает все пароли в БД одной атомарной SQLite-транзакцией.
    """
    import sqlite3
    from storage.database import DB_FILE, CONFIG_DIR

    global _master_key

    # Устанавливаем старый ключ для чтения
    if old_master:
        set_key_from_master(old_master)
        _clear_string(old_master)
    else:
        _zero(_master_key)
        _master_key = None

    if not os.path.exists(DB_FILE):
        return

    # Читаем все зашифрованные пароли
    conn = None
    record_ids = []
    try:
        conn = sqlite3.connect(DB_FILE)
        rows = conn.execute("SELECT id, password FROM passwords ORDER BY id").fetchall()
        record_ids = [(row[0], row[1]) for row in rows]
    except sqlite3.Error as e:
        logger.error(f"Database read error during reencrypt: {e}")
        return
    finally:
        if conn:
            conn.close()
    
    if not record_ids:
        return
    
    # Расшифровываем старым ключом
    decrypted_passwords = []
    for record_id, encrypted_password in record_ids:
        try:
            decrypted = decrypt(encrypted_password)
            decrypted_passwords.append((record_id, decrypted))
        except (ValueError, TypeError) as e:
            logger.error(f"Decrypt error for id {record_id}: {e}")
            decrypted_passwords.append((record_id, encrypted_password))
    
    # Переключаемся на новый ключ
    if new_master:
        set_key_from_master(new_master)
        _clear_string(new_master)
    else:
        _zero(_master_key)
        _master_key = None
    
    # Перешифровываем и сохраняем
    conn = None
    try:
        conn = sqlite3.connect(DB_FILE)
        conn.execute("BEGIN EXCLUSIVE")
        for record_id, decrypted in decrypted_passwords:
            # Пропускаем уже зашифрованные записи (если не удалось расшифровать)
            if decrypted.startswith("[encrypted"):
                encrypted = decrypted
            else:
                encrypted = encrypt(decrypted)
            conn.execute(
                "UPDATE passwords SET password=? WHERE id=?",
                (encrypted, record_id))
        conn.commit()
    except sqlite3.Error as e:
        if conn:
            conn.rollback()
        logger.error(f"Database write error during reencrypt: {e}")
        raise
    finally:
        if conn:
            conn.close()
        for _, decrypted in decrypted_passwords:
            _clear_string(decrypted)