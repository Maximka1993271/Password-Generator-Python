#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Secure Pass Pro v4.0 - Build Script
===================================
English: Cross-platform build script using PyInstaller
Русский: Кросс-платформенный скрипт сборки с использованием PyInstaller
Українська: Кросплатформений скрипт збірки з використанням PyInstaller

Author: Maxim Melnikov
License: MIT
"""

import os
import sys
import platform
import shutil
import subprocess
import json
import argparse
from pathlib import Path
from datetime import datetime

# ==================== LANGUAGE DICTIONARIES / СЛОВАРИ ЯЗЫКОВ / СЛОВНИКИ МОВ ====================

TEXTS = {
    "EN": {
        # Header
        "app_name": "Secure Pass Pro v4.0 - Build Script",
        "separator": "=" * 60,
        
        # Messages
        "cleaning": "🧹 Cleaning previous builds...",
        "cleaned": "🧹 Cleaned: {}",
        "cannot_clean": "⚠️ Could not clean {}: {}",
        "building": "🏗️ Building for platform: {}",
        "running": "📦 Running PyInstaller...",
        "command": "🔧 Command: {}",
        "success": "✅ Build completed successfully!",
        "failed": "❌ Build failed!",
        "output_dir": "📁 Output directory: {}",
        "generated_files": "📄 Generated files:",
        "file_info": "   📄 {} ({})",
        "version": "🔢 Version: {}",
        "python_version": "🐍 Python: {}",
        "platform": "🖥️ Platform: {}",
        "checking_deps": "📦 Checking dependencies...",
        "deps_missing": "⚠️ Missing dependencies: {}",
        "deps_ok": "✅ All dependencies are available",
        "install_deps": "💡 Run: pip install -r requirements.txt",
        "creating_resources": "📁 Creating resources directory...",
        "resources_ready": "✅ Resources directory ready",
        "no_resources": "⚠️ No resources directory found",
        "build_start": "🔐 Starting build process...",
        "build_end": "🏁 Build process finished",
        "elapsed_time": "⏱️ Elapsed time: {:.2f} seconds",
        
        # Errors
        "error_no_main": "❌ Error: main.py not found!",
        "error_no_pyinstaller": "❌ Error: PyInstaller not installed! Run: pip install pyinstaller",
        "error_build_failed": "❌ Build failed with code: {}",
        
        # Help
        "help_clean": "Clean build directories before building",
        "help_verbose": "Verbose output",
        "help_help": "Show this help message",
        
        # Interactive
        "continue_anyway": "⚠️ Continue anyway? (y/n): ",
        "build_cancelled": "❌ Build cancelled by user",
    },
    "RU": {
        # Header
        "app_name": "Secure Pass Pro v4.0 - Скрипт сборки",
        "separator": "=" * 60,
        
        # Messages
        "cleaning": "🧹 Очистка предыдущих сборок...",
        "cleaned": "🧹 Очищено: {}",
        "cannot_clean": "⚠️ Не удалось очистить {}: {}",
        "building": "🏗️ Сборка для платформы: {}",
        "running": "📦 Запуск PyInstaller...",
        "command": "🔧 Команда: {}",
        "success": "✅ Сборка успешно завершена!",
        "failed": "❌ Ошибка сборки!",
        "output_dir": "📁 Папка вывода: {}",
        "generated_files": "📄 Сгенерированные файлы:",
        "file_info": "   📄 {} ({})",
        "version": "🔢 Версия: {}",
        "python_version": "🐍 Python: {}",
        "platform": "🖥️ Платформа: {}",
        "checking_deps": "📦 Проверка зависимостей...",
        "deps_missing": "⚠️ Отсутствуют зависимости: {}",
        "deps_ok": "✅ Все зависимости доступны",
        "install_deps": "💡 Выполните: pip install -r requirements.txt",
        "creating_resources": "📁 Создание папки resources...",
        "resources_ready": "✅ Папка resources готова",
        "no_resources": "⚠️ Папка resources не найдена",
        "build_start": "🔐 Запуск процесса сборки...",
        "build_end": "🏁 Процесс сборки завершён",
        "elapsed_time": "⏱️ Затрачено времени: {:.2f} секунд",
        
        # Errors
        "error_no_main": "❌ Ошибка: main.py не найден!",
        "error_no_pyinstaller": "❌ Ошибка: PyInstaller не установлен! Выполните: pip install pyinstaller",
        "error_build_failed": "❌ Ошибка сборки с кодом: {}",
        
        # Help
        "help_clean": "Очистить папки сборки перед сборкой",
        "help_verbose": "Подробный вывод",
        "help_help": "Показать это сообщение",
        
        # Interactive
        "continue_anyway": "⚠️ Продолжить? (д/н): ",
        "build_cancelled": "❌ Сборка отменена пользователем",
    },
    "UA": {
        # Header
        "app_name": "Secure Pass Pro v4.0 - Скрипт збірки",
        "separator": "=" * 60,
        
        # Messages
        "cleaning": "🧹 Очищення попередніх збірок...",
        "cleaned": "🧹 Очищено: {}",
        "cannot_clean": "⚠️ Не вдалося очистити {}: {}",
        "building": "🏗️ Збірка для платформи: {}",
        "running": "📦 Запуск PyInstaller...",
        "command": "🔧 Команда: {}",
        "success": "✅ Збірка успішно завершена!",
        "failed": "❌ Помилка збірки!",
        "output_dir": "📁 Папка виведення: {}",
        "generated_files": "📄 Згенеровані файли:",
        "file_info": "   📄 {} ({})",
        "version": "🔢 Версія: {}",
        "python_version": "🐍 Python: {}",
        "platform": "🖥️ Платформа: {}",
        "checking_deps": "📦 Перевірка залежностей...",
        "deps_missing": "⚠️ Відсутні залежності: {}",
        "deps_ok": "✅ Всі залежності доступні",
        "install_deps": "💡 Виконайте: pip install -r requirements.txt",
        "creating_resources": "📁 Створення папки resources...",
        "resources_ready": "✅ Папка resources готова",
        "no_resources": "⚠️ Папка resources не знайдена",
        "build_start": "🔐 Запуск процесу збірки...",
        "build_end": "🏁 Процес збірки завершено",
        "elapsed_time": "⏱️ Витрачено часу: {:.2f} секунд",
        
        # Errors
        "error_no_main": "❌ Помилка: main.py не знайдено!",
        "error_no_pyinstaller": "❌ Помилка: PyInstaller не встановлено! Виконайте: pip install pyinstaller",
        "error_build_failed": "❌ Помилка збірки з кодом: {}",
        
        # Help
        "help_clean": "Очистити папки збірки перед збіркою",
        "help_verbose": "Детальний вивід",
        "help_help": "Показати це повідомлення",
        
        # Interactive
        "continue_anyway": "⚠️ Продовжити? (т/н): ",
        "build_cancelled": "❌ Збірка скасована користувачем",
    }
}

# Default language / Язык по умолчанию / Мова за замовчуванням
DEFAULT_LANG = "RU"

# ==================== CONFIGURATION / КОНФИГУРАЦИЯ / КОНФІГУРАЦІЯ ====================

APP_NAME = "SecurePassPro"
VERSION = "4.0.0"
AUTHOR = "Maxim Melnikov"
COPYRIGHT = f"Copyright (c) 2024-2025 {AUTHOR}"


def get_language() -> str:
    """Detect language from config file or system
    Определяет язык из файла конфигурации или системы
    Визначає мову з файлу конфігурації або системи"""
    
    # Try to read from config file / Пробуем прочитать из config.json / Пробуємо прочитати з config.json
    config_paths = [
        "config.json",
        "data/config.json",
        ".securepass/config.json",
    ]
    
    for config_path in config_paths:
        if os.path.exists(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                    lang = config.get("LANG", "")
                    if lang in ["RU", "EN", "UA"]:
                        return lang
            except (json.JSONDecodeError, OSError, IOError, PermissionError):
                pass
    
    # Try system language / Пробуем определить системный язык / Пробуємо визначити системну мову
    system_lang = platform.system()
    
    # For Windows / Для Windows / Для Windows
    if system_lang == "Windows":
        try:
            import ctypes
            windll = ctypes.windll.kernel32
            lang_id = windll.GetUserDefaultUILanguage()
            # 0x419 = Russian, 0x409 = English, 0x422 = Ukrainian
            if lang_id == 0x419:
                return "RU"
            elif lang_id == 0x422:
                return "UA"
            else:
                return "EN"
        except (ImportError, AttributeError, OSError):
            pass
    
    return DEFAULT_LANG


def get_text(key: str, lang: str = None) -> str:
    """Get localized text
    Получить локализованный текст
    Отримати локалізований текст"""
    if lang is None:
        lang = get_language()
    return TEXTS.get(lang, TEXTS["RU"]).get(key, key)


# ==================== BUILD FUNCTIONS / ФУНКЦИИ СБОРКИ / ФУНКЦІЇ ЗБІРКИ ====================

def clean_build_dirs(lang: str = "RU") -> None:
    """Clean previous build directories
    Очищает предыдущие папки сборки
    Очищує попередні папки збірки"""
    texts = TEXTS.get(lang, TEXTS["RU"])
    dirs_to_clean = ["build", "dist", "__pycache__"]
    
    print(texts["cleaning"])
    
    for dir_name in dirs_to_clean:
        if os.path.exists(dir_name):
            try:
                shutil.rmtree(dir_name, ignore_errors=True)
                print(texts["cleaned"].format(dir_name))
            except Exception as e:
                print(texts["cannot_clean"].format(dir_name, e))


def check_dependencies(lang: str = "RU") -> bool:
    """Check if required dependencies are installed
    Проверяет установку необходимых зависимостей
    Перевіряє встановлення необхідних залежностей"""
    texts = TEXTS.get(lang, TEXTS["RU"])
    
    print(texts["checking_deps"])
    
    # Check PyInstaller / Проверяем PyInstaller / Перевіряємо PyInstaller
    missing = []
    try:
        import PyInstaller
    except ImportError:
        missing.append("pyinstaller")
    
    # Check other critical dependencies / Проверяем другие критические зависимости / Перевіряємо інші критичні залежності
    critical_modules = [
        ("customtkinter", "customtkinter"),
        ("PIL", "Pillow"),
        ("cryptography", "cryptography"),
    ]
    
    for module_name, package_name in critical_modules:
        try:
            __import__(module_name)
        except ImportError:
            missing.append(package_name)
    
    if missing:
        print(texts["deps_missing"].format(", ".join(missing)))
        print(texts["install_deps"])
        
        # Ask user to continue / Спрашиваем пользователя / Питаємо користувача
        response = input(texts["continue_anyway"]).lower()
        if response in ['y', 'yes', 'д', 'да', 'yes', 'так', 'т']:
            return True
        else:
            print(texts["build_cancelled"])
            return False
    
    print(texts["deps_ok"])
    return True


def ensure_resources(lang: str = "RU") -> None:
    """Ensure resources directory exists
    Создаёт папку ресурсов если её нет
    Створює папку ресурсів якщо її немає"""
    texts = TEXTS.get(lang, TEXTS["RU"])
    
    resources_dir = Path("resources")
    
    if not resources_dir.exists():
        print(texts["creating_resources"])
        resources_dir.mkdir(exist_ok=True)
        print(texts["resources_ready"])
    else:
        print(texts["resources_ready"])


def get_pyinstaller_command(lang: str = "RU") -> list:
    """Generate PyInstaller command based on platform
    Генерирует команду PyInstaller в зависимости от платформы
    Генерує команду PyInstaller залежно від платформи"""
    
    # Main script / Главный скрипт / Головний скрипт
    if platform.system() == "Windows":
        main_script = "Secure_Pass_Pro.pyw"
        if not os.path.exists(main_script):
            main_script = "main.py"
    else:
        main_script = "main.py"
        if not os.path.exists(main_script):
            main_script = "Secure_Pass_Pro.pyw"
    
    # Base command / Базовая команда / Базова команда
    cmd = [
        "pyinstaller",
        "--noconfirm",
        "--clean",
        "--name", APP_NAME,
        "--onefile",
    ]
    
    # Console mode / Режим консоли / Режим консолі
    if platform.system() == "Windows":
        cmd.append("--noconsole")
    else:
        cmd.append("--console")
    
    # Add data files / Добавляем файлы данных / Додаємо файли даних
    if os.path.exists("resources"):
        cmd.extend(["--add-data", f"resources{os.pathsep}resources"])
    
    # Hidden imports / Скрытые импорты / Приховані імпорти
    hidden_imports = [
        "customtkinter",
        "PIL",
        "PIL._tkinter_finder",
        "cryptography",
        "cryptography.hazmat.backends.openssl",
        "cryptography.hazmat.backends.openssl.aead",
        "argon2",
        "qrcode",
        "requests",
        "psutil",
    ]
    
    for imp in hidden_imports:
        cmd.extend(["--hidden-import", imp])
    
    # Add icon / Добавляем иконку / Додаємо іконку
    if platform.system() == "Windows":
        icon_path = "resources/icon.ico"
        if os.path.exists(icon_path):
            cmd.extend(["--icon", icon_path])
    elif platform.system() == "Darwin":  # macOS
        icon_path = "resources/icon.icns"
        if os.path.exists(icon_path):
            cmd.extend(["--icon", icon_path])
            cmd.append("--osx-bundle-identifier=com.securepasspro.app")
            cmd.append("--target-arch=universal2")
    elif platform.system() == "Linux":
        cmd.append("--strip")
    
    # Add main script / Добавляем главный скрипт / Додаємо головний скрипт
    cmd.append(main_script)
    
    return cmd


def get_file_size_str(size: int) -> str:
    """Format file size for display
    Форматирует размер файла для отображения
    Форматує розмір файлу для відображення"""
    if size > 1024 * 1024:
        return f"{size / (1024*1024):.1f} MB"
    elif size > 1024:
        return f"{size / 1024:.1f} KB"
    else:
        return f"{size} B"


def build(lang: str = "RU", clean: bool = True, verbose: bool = False) -> bool:
    """Main build function
    Основная функция сборки
    Головна функція збірки"""
    
    texts = TEXTS.get(lang, TEXTS["RU"])
    start_time = datetime.now()
    
    print(texts["separator"])
    print(texts["app_name"])
    print(texts["separator"])
    
    print(texts["version"].format(VERSION))
    print(texts["python_version"].format(sys.version.split()[0]))
    print(texts["platform"].format(platform.system()))
    print(texts["separator"])
    
    # Check if main.py exists / Проверяем наличие main.py / Перевіряємо наявність main.py
    if not os.path.exists("main.py") and not os.path.exists("Secure_Pass_Pro.pyw"):
        print(texts["error_no_main"])
        return False
    
    # Check dependencies / Проверяем зависимости / Перевіряємо залежності
    if not check_dependencies(lang):
        return False
    
    # Clean build directories / Очищаем папки сборки / Очищуємо папки збірки
    if clean:
        clean_build_dirs(lang)
    
    # Ensure resources directory / Создаём папку ресурсов / Створюємо папку ресурсів
    ensure_resources(lang)
    
    # Get PyInstaller command / Получаем команду PyInstaller / Отримуємо команду PyInstaller
    cmd = get_pyinstaller_command(lang)
    
    print(texts["separator"])
    print(texts["building"].format(platform.system()))
    print(texts["running"])
    
    if verbose:
        print(texts["command"].format(" ".join(cmd)))
    
    print(texts["separator"])
    
    # Run PyInstaller / Запускаем PyInstaller / Запускаємо PyInstaller
    result = subprocess.run(cmd)
    
    elapsed = (datetime.now() - start_time).total_seconds()
    
    print(texts["separator"])
    
    if result.returncode == 0:
        print(texts["success"])
        print(texts["output_dir"].format("dist/"))
        
        # Show generated files / Показываем сгенерированные файлы / Показуємо згенеровані файли
        if os.path.exists("dist"):
            files = os.listdir("dist")
            if files:
                print(texts["generated_files"])
                for f in files:
                    fpath = os.path.join("dist", f)
                    size = os.path.getsize(fpath)
                    print(texts["file_info"].format(f, get_file_size_str(size)))
        
        print(texts["elapsed_time"].format(elapsed))
        print(texts["build_end"])
        print(texts["separator"])
        return True
    else:
        print(texts["failed"])
        print(texts["error_build_failed"].format(result.returncode))
        print(texts["separator"])
        return False


# ==================== MAIN ENTRY POINT / ТОЧКА ВХОДА / ТОЧКА ВХОДУ ====================

def main():
    """Main entry point
    Главная точка входа
    Головна точка входу"""
    
    parser = argparse.ArgumentParser(
        description="Secure Pass Pro - Build Script / Скрипт сборки / Скрипт збірки"
    )
    parser.add_argument(
        "--no-clean", 
        action="store_true", 
        help=get_text("help_clean", "EN")
    )
    parser.add_argument(
        "-v", "--verbose", 
        action="store_true", 
        help=get_text("help_verbose", "EN")
    )
    parser.add_argument(
        "--lang", 
        choices=["RU", "EN", "UA"], 
        default=None,
        help="Language / Язык / Мова"
    )
    
    args = parser.parse_args()
    
    # Determine language / Определяем язык / Визначаємо мову
    lang = args.lang if args.lang else get_language()
    
    # Run build / Запускаем сборку / Запускаємо збірку
    success = build(
        lang=lang,
        clean=not args.no_clean,
        verbose=args.verbose
    )
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()