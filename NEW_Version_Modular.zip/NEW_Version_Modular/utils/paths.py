"""
Path management for SecurePassPro
Centralized portable path logic for EXE and script modes
"""
import os
import sys
import ctypes
import tempfile
import platform
import time
from typing import Optional, Dict, List

# НЕ импортируем logger здесь, чтобы избежать циклического импорта
# Будем использовать простой print для ошибок на этом этапе


class PathManager:
    """Centralized path management with fallback support"""
    
    _instance = None
    _base_dir: Optional[str] = None
    _config_dir: Optional[str] = None
    _logs_dir: Optional[str] = None
    _data_dir: Optional[str] = None
    _cache_dir: Optional[str] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @classmethod
    def get_base_dir(cls) -> str:
        """Get base directory (works for EXE and script)"""
        if cls._base_dir is not None:
            return cls._base_dir
        
        if getattr(sys, 'frozen', False):
            cls._base_dir = os.path.dirname(sys.executable)
        else:
            cls._base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        return cls._base_dir
    
    @classmethod
    def get_config_dir(cls) -> str:
        """
        Get configuration directory (creates if not exists)
        Uses OS-appropriate locations with fallback
        """
        if cls._config_dir is not None:
            return cls._config_dir
        
        base_dir = cls.get_base_dir()
        config_dir = os.path.join(base_dir, "data")
        
        # Проверяем возможность записи в текущую директорию
        if cls._is_writable(config_dir):
            cls._config_dir = config_dir
            cls._ensure_dir(config_dir)
            cls._hide_dir(config_dir)
            return cls._config_dir
        
        # Fallback для разных ОС
        system = platform.system()
        
        if system == "Windows":
            # Windows: используем AppData
            appdata = os.environ.get('APPDATA', '')
            if appdata:
                config_dir = os.path.join(appdata, "SecurePassPro")
            else:
                config_dir = os.path.join(tempfile.gettempdir(), "securepasspro")
        
        elif system == "Darwin":  # macOS
            home = os.path.expanduser("~")
            config_dir = os.path.join(home, "Library", "Application Support", "SecurePassPro")
        
        else:  # Linux and others
            home = os.path.expanduser("~")
            config_dir = os.path.join(home, ".config", "securepasspro")
        
        cls._config_dir = config_dir
        cls._ensure_dir(config_dir)
        cls._hide_dir(config_dir)
        
        return cls._config_dir
    
    @classmethod
    def get_data_dir(cls) -> str:
        """Get data directory (for user data)"""
        if cls._data_dir is not None:
            return cls._data_dir
        
        cls._data_dir = cls.get_config_dir()
        return cls._data_dir
    
    @classmethod
    def get_cache_dir(cls) -> str:
        """Get cache directory"""
        if cls._cache_dir is not None:
            return cls._cache_dir
        
        system = platform.system()
        
        if system == "Windows":
            local_appdata = os.environ.get('LOCALAPPDATA', '')
            if local_appdata:
                cls._cache_dir = os.path.join(local_appdata, "SecurePassPro", "Cache")
            else:
                cls._cache_dir = os.path.join(cls.get_config_dir(), "cache")
        
        elif system == "Darwin":  # macOS
            home = os.path.expanduser("~")
            cls._cache_dir = os.path.join(home, "Library", "Caches", "SecurePassPro")
        
        else:  # Linux
            home = os.path.expanduser("~")
            cls._cache_dir = os.path.join(home, ".cache", "securepasspro")
        
        cls._ensure_dir(cls._cache_dir)
        return cls._cache_dir
    
    @classmethod
    def get_logs_dir(cls) -> str:
        """Get logs directory path"""
        if cls._logs_dir is not None:
            return cls._logs_dir
        
        base_dir = cls.get_base_dir()
        logs_dir = os.path.join(base_dir, "logs")
        
        if cls._is_writable(logs_dir):
            cls._logs_dir = logs_dir
        else:
            # Fallback to cache or temp
            logs_dir = os.path.join(cls.get_cache_dir(), "logs")
            cls._logs_dir = logs_dir
        
        cls._ensure_dir(cls._logs_dir)
        return cls._logs_dir
    
    @classmethod
    def get_config_file(cls) -> str:
        """Get config.json file path"""
        return os.path.join(cls.get_config_dir(), "config.json")
    
    @classmethod
    def get_db_file(cls) -> str:
        """Get passwords.db file path"""
        return os.path.join(cls.get_data_dir(), "passwords.db")
    
    @classmethod
    def get_salt_file(cls) -> str:
        """Get db.salt file path"""
        return os.path.join(cls.get_data_dir(), "db.salt")
    
    @classmethod
    def get_master_file(cls) -> str:
        """Get master.key file path"""
        return os.path.join(cls.get_data_dir(), "master.key")
    
    @classmethod
    def get_uuid_file(cls) -> str:
        """Get machine.id file path"""
        return os.path.join(cls.get_data_dir(), "machine.id")
    
    @classmethod
    def get_key_version_file(cls) -> str:
        """Get key.version file path"""
        return os.path.join(cls.get_data_dir(), "key.version")
    
    @classmethod
    def get_sqlcipher_salt_file(cls) -> str:
        """Get sqlcipher.salt file path"""
        return os.path.join(cls.get_data_dir(), "sqlcipher.salt")
    
    @classmethod
    def get_lockout_file(cls) -> str:
        """Get lockout.json file path"""
        return os.path.join(cls.get_data_dir(), "lockout.json")
    
    @classmethod
    def get_backup_dir(cls) -> str:
        """Get backup directory"""
        backup_dir = os.path.join(cls.get_data_dir(), "backups")
        cls._ensure_dir(backup_dir)
        return backup_dir
    
    @classmethod
    def get_temp_dir(cls) -> str:
        """Get temporary directory for the app"""
        temp_dir = os.path.join(tempfile.gettempdir(), "securepasspro")
        cls._ensure_dir(temp_dir)
        return temp_dir
    
    @classmethod
    def _is_writable(cls, path: str) -> bool:
        """Check if directory is writable"""
        try:
            if not os.path.exists(path):
                os.makedirs(path, exist_ok=True)
            test_file = os.path.join(path, ".write_test")
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
            return True
        except (PermissionError, OSError, IOError):
            return False
    
    @classmethod
    def _ensure_dir(cls, path: str) -> None:
        """Ensure directory exists"""
        try:
            os.makedirs(path, exist_ok=True)
        except (PermissionError, OSError) as e:
            # Не используем logger здесь из-за циклического импорта
            print(f"[Paths] Failed to create directory {path}: {e}")
    
    @classmethod
    def _hide_dir(cls, path: str) -> None:
        """Hide directory on Windows"""
        if platform.system() == "Windows":
            try:
                ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
            except (AttributeError, OSError) as e:
                pass
    
    @classmethod
    def cleanup_temp_files(cls, max_age_hours: int = 24) -> int:
        """Clean up old temporary files"""
        temp_dir = cls.get_temp_dir()
        if not os.path.exists(temp_dir):
            return 0
        
        deleted = 0
        current_time = time.time()
        max_age_seconds = max_age_hours * 3600
        
        try:
            for filename in os.listdir(temp_dir):
                file_path = os.path.join(temp_dir, filename)
                try:
                    if os.path.isfile(file_path):
                        file_age = current_time - os.path.getmtime(file_path)
                        if file_age > max_age_seconds:
                            os.remove(file_path)
                            deleted += 1
                except (OSError, IOError, PermissionError):
                    continue
        except (OSError, IOError) as e:
            pass
        
        return deleted
    
    @classmethod
    def get_all_paths(cls) -> Dict[str, str]:
        """Get all important paths for debugging"""
        return {
            "base_dir": cls.get_base_dir(),
            "config_dir": cls.get_config_dir(),
            "data_dir": cls.get_data_dir(),
            "cache_dir": cls.get_cache_dir(),
            "logs_dir": cls.get_logs_dir(),
            "backup_dir": cls.get_backup_dir(),
            "temp_dir": cls.get_temp_dir(),
            "config_file": cls.get_config_file(),
            "db_file": cls.get_db_file(),
        }


# ==================== ОБРАТНАЯ СОВМЕСТИМОСТЬ ====================

_path_manager = PathManager()


def get_base_dir() -> str:
    return _path_manager.get_base_dir()


def get_config_dir() -> str:
    return _path_manager.get_config_dir()


def get_data_dir() -> str:
    return _path_manager.get_data_dir()


def get_cache_dir() -> str:
    return _path_manager.get_cache_dir()


def get_logs_dir() -> str:
    return _path_manager.get_logs_dir()


def get_backup_dir() -> str:
    return _path_manager.get_backup_dir()


def get_temp_dir() -> str:
    return _path_manager.get_temp_dir()


def get_config_file() -> str:
    return _path_manager.get_config_file()


def get_db_file() -> str:
    return _path_manager.get_db_file()


def get_salt_file() -> str:
    return _path_manager.get_salt_file()


def get_master_file() -> str:
    return _path_manager.get_master_file()


def get_uuid_file() -> str:
    return _path_manager.get_uuid_file()


def get_key_version_file() -> str:
    return _path_manager.get_key_version_file()


def get_sqlcipher_salt_file() -> str:
    return _path_manager.get_sqlcipher_salt_file()


def get_lockout_file() -> str:
    return _path_manager.get_lockout_file()


def hide_dir(path: str) -> None:
    _path_manager._hide_dir(path)


def ensure_dir(path: str) -> None:
    _path_manager._ensure_dir(path)


def cleanup_temp_files(max_age_hours: int = 24) -> int:
    return _path_manager.cleanup_temp_files(max_age_hours)


def get_all_paths() -> Dict[str, str]:
    return _path_manager.get_all_paths()


# Экспорт
__all__ = [
    'get_base_dir',
    'get_config_dir',
    'get_data_dir',
    'get_cache_dir',
    'get_logs_dir',
    'get_backup_dir',
    'get_temp_dir',
    'get_config_file',
    'get_db_file',
    'get_salt_file',
    'get_master_file',
    'get_uuid_file',
    'get_key_version_file',
    'get_sqlcipher_salt_file',
    'get_lockout_file',
    'hide_dir',
    'ensure_dir',
    'cleanup_temp_files',
    'get_all_paths',
    'PathManager',
]