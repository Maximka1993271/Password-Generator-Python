"""
Path management for SecurePassPro
Centralized portable path logic for EXE and script modes
FIXED: Добавлена поддержка roaming/local appdata, portable mode, безопасные временные пути

Управление путями для SecurePassPro
Централизованная портативная логика путей для EXE и скрипта
FIXED: Добавлена поддержка roaming/local appdata, portable mode, безопасные временные пути

Керування шляхами для SecurePassPro
Централізована портативна логіка шляхів для EXE та скрипта
FIXED: Додано підтримку roaming/local appdata, portable mode, безпечні тимчасові шляхи
"""
import os
import sys
import ctypes
import tempfile
import platform
import time
import shutil
from typing import Optional, Dict, List, Tuple
from enum import Enum

# Do NOT import logger here to avoid circular imports
# Use simple print for errors at this stage
# НЕ импортируем logger здесь, чтобы избежать циклического импорта
# Будем использовать простой print для ошибок на этом этапе
# НЕ імпортуємо logger тут, щоб уникнути циклічного імпорту
# Будемо використовувати простий print для помилок на цьому етапі


class PathMode(Enum):
    """Path operation mode / Режим работы с путями / Режим роботи з шляхами"""
    PORTABLE = "portable"      # Portable mode (all data in program folder) / Переносимый режим (все данные в папке с программой) / Переносимий режим (всі дані в папці з програмою)
    LOCAL = "local"            # Local data (AppData/Local) / Локальные данные (AppData/Local) / Локальні дані (AppData/Local)
    ROAMING = "roaming"        # Roaming data (AppData/Roaming) / Роуминговые данные (AppData/Roaming) / Роумінгові дані (AppData/Roaming)


class PathManager:
    """Centralized path management with fallback support
    Централизованное управление путями с поддержкой fallback
    Централізоване керування шляхами з підтримкою fallback"""
    
    _instance = None
    _base_dir: Optional[str] = None
    _config_dir: Optional[str] = None
    _logs_dir: Optional[str] = None
    _data_dir: Optional[str] = None
    _cache_dir: Optional[str] = None
    _temp_dir: Optional[str] = None
    _backup_dir: Optional[str] = None
    _mode: PathMode = PathMode.PORTABLE
    _portable_flag_file: str = "PORTABLE.txt"
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._detect_mode()
        return cls._instance
    
    def _detect_mode(self) -> None:
        """
        Detect operation mode:
        - PORTABLE: if PORTABLE.txt exists in root or data folder
        - LOCAL: by default on Windows
        - ROAMING: if specified in config (will be loaded later)
        
        Определяет режим работы:
        - PORTABLE: если есть файл PORTABLE.txt в корне или в папке data
        - LOCAL: по умолчанию на Windows
        - ROAMING: если указано в конфиге (будет загружено позже)
        
        Визначає режим роботи:
        - PORTABLE: якщо є файл PORTABLE.txt в корені або в папці data
        - LOCAL: за замовчуванням на Windows
        - ROAMING: якщо вказано в конфігу (буде завантажено пізніше)
        """
        base_dir = self.get_base_dir()
        
        # Check for PORTABLE.txt file / Проверяем наличие файла PORTABLE.txt / Перевіряємо наявність файлу PORTABLE.txt
        portable_file = os.path.join(base_dir, self._portable_flag_file)
        if os.path.exists(portable_file):
            self._mode = PathMode.PORTABLE
            print(f"[Paths] Portable mode detected via {self._portable_flag_file}")
            return
        
        # Check for data folder in root (sign of portable mode)
        # Проверяем наличие папки data в корне (признак portable режима)
        # Перевіряємо наявність папки data в корені (ознака portable режиму)
        data_dir = os.path.join(base_dir, "data")
        if os.path.exists(data_dir) and os.path.isdir(data_dir):
            # Check if we can write to this folder / Проверяем, можем ли мы писать в эту папку / Перевіряємо, чи можемо ми писати в цю папку
            if self._is_writable(data_dir):
                self._mode = PathMode.PORTABLE
                print("[Paths] Portable mode detected (data directory exists)")
                return
        
        # Use local mode by default / По умолчанию используем локальный режим / За замовчуванням використовуємо локальний режим
        self._mode = PathMode.LOCAL
        print(f"[Paths] Using {self._mode.value} mode")
    
    def set_mode(self, mode: PathMode) -> None:
        """Set operation mode (restart required to apply)
        Устанавливает режим работы (требует перезапуска для применения)
        Встановлює режим роботи (вимагає перезапуску для застосування)"""
        if mode in [PathMode.LOCAL, PathMode.ROAMING, PathMode.PORTABLE]:
            self._mode = mode
            # Clear cached paths / Сбрасываем кэшированные пути / Скидаємо кешовані шляхи
            self._config_dir = None
            self._logs_dir = None
            self._data_dir = None
            self._cache_dir = None
            self._temp_dir = None
            self._backup_dir = None
            print(f"[Paths] Mode changed to {mode.value} (restart may be required)")
    
    def get_mode(self) -> PathMode:
        """Return current operation mode / Возвращает текущий режим работы / Повертає поточний режим роботи"""
        return self._mode
    
    def create_portable_flag(self) -> bool:
        """Create PORTABLE.txt file to enable portable mode
        Создаёт файл PORTABLE.txt для включения portable режима
        Створює файл PORTABLE.txt для ввімкнення portable режиму"""
        try:
            flag_path = os.path.join(self.get_base_dir(), self._portable_flag_file)
            with open(flag_path, 'w') as f:
                f.write("# Secure Pass Pro - Portable Mode\n")
                f.write("# This file enables portable mode (all data stored in the application directory)\n")
            print(f"[Paths] Portable flag created: {flag_path}")
            return True
        except (OSError, IOError, PermissionError) as e:
            print(f"[Paths] Failed to create portable flag: {e}")
            return False
    
    def remove_portable_flag(self) -> bool:
        """Remove PORTABLE.txt file to disable portable mode
        Удаляет файл PORTABLE.txt для отключения portable режима
        Видаляє файл PORTABLE.txt для вимкнення portable режиму"""
        try:
            flag_path = os.path.join(self.get_base_dir(), self._portable_flag_file)
            if os.path.exists(flag_path):
                os.remove(flag_path)
                print(f"[Paths] Portable flag removed: {flag_path}")
            return True
        except (OSError, IOError, PermissionError) as e:
            print(f"[Paths] Failed to remove portable flag: {e}")
            return False
    
    def is_portable(self) -> bool:
        """Check if portable mode is enabled / Проверяет, включён ли portable режим / Перевіряє, чи увімкнено portable режим"""
        return self._mode == PathMode.PORTABLE
    
    @classmethod
    def get_base_dir(cls) -> str:
        """Get base directory (works for EXE and script)
        Получить базовую директорию (работает для EXE и скрипта)
        Отримати базову директорію (працює для EXE та скрипта)"""
        if cls._base_dir is not None:
            return cls._base_dir
        
        if getattr(sys, 'frozen', False):
            cls._base_dir = os.path.dirname(sys.executable)
        else:
            cls._base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        return cls._base_dir
    
    def _get_portable_config_dir(self) -> str:
        """Get path for portable mode / Получает путь для portable режима / Отримує шлях для portable режиму"""
        return os.path.join(self.get_base_dir(), "data")
    
    def _get_local_config_dir(self) -> str:
        """Get path for local mode (Windows AppData/Local)
        Получает путь для локального режима (Windows AppData/Local)
        Отримує шлях для локального режиму (Windows AppData/Local)"""
        system = platform.system()
        
        if system == "Windows":
            local_appdata = os.environ.get('LOCALAPPDATA', '')
            if local_appdata:
                return os.path.join(local_appdata, "SecurePassPro")
            else:
                return os.path.join(tempfile.gettempdir(), "securepasspro")
        
        elif system == "Darwin":  # macOS
            home = os.path.expanduser("~")
            return os.path.join(home, "Library", "Application Support", "SecurePassPro")
        
        else:  # Linux and others / Linux и другие / Linux та інші
            home = os.path.expanduser("~")
            return os.path.join(home, ".local", "share", "securepasspro")
    
    def _get_roaming_config_dir(self) -> str:
        """Get path for roaming mode (Windows AppData/Roaming)
        Получает путь для роумингового режима (Windows AppData/Roaming)
        Отримує шлях для роумінгового режиму (Windows AppData/Roaming)"""
        system = platform.system()
        
        if system == "Windows":
            appdata = os.environ.get('APPDATA', '')
            if appdata:
                return os.path.join(appdata, "SecurePassPro")
            else:
                return self._get_local_config_dir()
        
        elif system == "Darwin":  # macOS
            home = os.path.expanduser("~")
            return os.path.join(home, "Library", "Application Support", "SecurePassPro")
        
        else:  # Linux
            home = os.path.expanduser("~")
            return os.path.join(home, ".config", "securepasspro")
    
    def get_config_dir(self) -> str:
        """
        Get configuration directory (creates if not exists)
        Uses OS-appropriate locations with fallback
        
        Получить директорию конфигурации (создаёт если не существует)
        Использует подходящие для ОС пути с fallback
        
        Отримати директорію конфігурації (створює якщо не існує)
        Використовує відповідні для ОС шляхи з fallback
        """
        if self._config_dir is not None:
            return self._config_dir
        
        # Choose directory based on mode / Выбираем директорию в зависимости от режима / Вибираємо директорію залежно від режиму
        if self._mode == PathMode.PORTABLE:
            config_dir = self._get_portable_config_dir()
        elif self._mode == PathMode.ROAMING:
            config_dir = self._get_roaming_config_dir()
        else:  # LOCAL
            config_dir = self._get_local_config_dir()
        
        # Check writeability / Проверяем возможность записи / Перевіряємо можливість запису
        if not self._is_writable(config_dir):
            # Fallback to portable mode / Fallback к portable режиму / Fallback до portable режиму
            fallback_dir = self._get_portable_config_dir()
            if self._is_writable(fallback_dir):
                print(f"[Paths] Fallback to portable mode: {fallback_dir}")
                self._mode = PathMode.PORTABLE
                config_dir = fallback_dir
            else:
                # Last fallback: temp directory / Последний fallback: temp directory / Останній fallback: temp directory
                config_dir = os.path.join(tempfile.gettempdir(), "securepasspro")
                print(f"[Paths] Using temp directory as fallback: {config_dir}")
        
        self._config_dir = config_dir
        self._ensure_dir(config_dir)
        self._hide_dir(config_dir)
        
        return self._config_dir
    
    def get_data_dir(self) -> str:
        """Get data directory (for user data)
        Получить директорию данных (для пользовательских данных)
        Отримати директорію даних (для користувацьких даних)"""
        if self._data_dir is not None:
            return self._data_dir
        
        self._data_dir = self.get_config_dir()
        return self._data_dir
    
    def get_cache_dir(self) -> str:
        """Get cache directory / Получить кэш-директорию / Отримати кеш-директорію"""
        if self._cache_dir is not None:
            return self._cache_dir
        
        if self._mode == PathMode.PORTABLE:
            self._cache_dir = os.path.join(self.get_config_dir(), "cache")
        else:
            system = platform.system()
            
            if system == "Windows":
                local_appdata = os.environ.get('LOCALAPPDATA', '')
                if local_appdata:
                    self._cache_dir = os.path.join(local_appdata, "SecurePassPro", "Cache")
                else:
                    self._cache_dir = os.path.join(self.get_config_dir(), "cache")
            
            elif system == "Darwin":  # macOS
                home = os.path.expanduser("~")
                self._cache_dir = os.path.join(home, "Library", "Caches", "SecurePassPro")
            
            else:  # Linux
                home = os.path.expanduser("~")
                self._cache_dir = os.path.join(home, ".cache", "securepasspro")
        
        self._ensure_dir(self._cache_dir)
        return self._cache_dir
    
    def get_logs_dir(self) -> str:
        """Get logs directory path / Получить путь к директории логов / Отримати шлях до директорії логів"""
        if self._logs_dir is not None:
            return self._logs_dir
        
        if self._mode == PathMode.PORTABLE:
            self._logs_dir = os.path.join(self.get_base_dir(), "logs")
        else:
            self._logs_dir = os.path.join(self.get_cache_dir(), "logs")
        
        self._ensure_dir(self._logs_dir)
        return self._logs_dir
    
    def get_temp_dir(self) -> str:
        """Get temporary directory for the app with cleanup support
        Получить временную директорию для приложения с поддержкой очистки
        Отримати тимчасову директорію для додатку з підтримкою очищення"""
        if self._temp_dir is not None:
            return self._temp_dir
        
        if self._mode == PathMode.PORTABLE:
            self._temp_dir = os.path.join(self.get_config_dir(), "temp")
        else:
            # Use system temp directory with app subfolder / Используем системную temp директорию с подпапкой приложения / Використовуємо системну temp директорію з підпапкою додатку
            system_temp = tempfile.gettempdir()
            self._temp_dir = os.path.join(system_temp, "securepasspro")
        
        self._ensure_dir(self._temp_dir)
        
        # Clean old temporary files (at startup) / Очищаем старые временные файлы (при запуске) / Очищуємо старі тимчасові файли (при запуску)
        self._cleanup_old_temp_files()
        
        return self._temp_dir
    
    def get_backup_dir(self) -> str:
        """Get backup directory / Получить директорию бэкапов / Отримати директорію бекапів"""
        if self._backup_dir is not None:
            return self._backup_dir
        
        self._backup_dir = os.path.join(self.get_config_dir(), "backups")
        self._ensure_dir(self._backup_dir)
        return self._backup_dir
    
    def get_config_file(self) -> str:
        """Get config.json file path / Получить путь к config.json / Отримати шлях до config.json"""
        return os.path.join(self.get_config_dir(), "config.json")
    
    def get_db_file(self) -> str:
        """Get passwords.db file path / Получить путь к passwords.db / Отримати шлях до passwords.db"""
        return os.path.join(self.get_data_dir(), "passwords.db")
    
    def get_salt_file(self) -> str:
        """Get db.salt file path / Получить путь к db.salt / Отримати шлях до db.salt"""
        return os.path.join(self.get_data_dir(), "db.salt")
    
    def get_master_file(self) -> str:
        """Get master.key file path / Получить путь к master.key / Отримати шлях до master.key"""
        return os.path.join(self.get_data_dir(), "master.key")
    
    def get_uuid_file(self) -> str:
        """Get machine.id file path / Получить путь к machine.id / Отримати шлях до machine.id"""
        return os.path.join(self.get_data_dir(), "machine.id")
    
    def get_key_version_file(self) -> str:
        """Get key.version file path / Получить путь к key.version / Отримати шлях до key.version"""
        return os.path.join(self.get_data_dir(), "key.version")
    
    def get_sqlcipher_salt_file(self) -> str:
        """Get sqlcipher.salt file path / Получить путь к sqlcipher.salt / Отримати шлях до sqlcipher.salt"""
        return os.path.join(self.get_data_dir(), "sqlcipher.salt")
    
    def get_lockout_file(self) -> str:
        """Get lockout.json file path / Получить путь к lockout.json / Отримати шлях до lockout.json"""
        return os.path.join(self.get_data_dir(), "lockout.json")
    
    def get_audit_file(self) -> str:
        """Get auth_audit.json file path / Получить путь к auth_audit.json / Отримати шлях до auth_audit.json"""
        return os.path.join(self.get_data_dir(), "auth_audit.json")
    
    @staticmethod
    def _is_writable(path: str) -> bool:
        """Check if directory is writable / Проверить, доступна ли директория для записи / Перевірити, чи доступна директорія для запису"""
        try:
            if not os.path.exists(path):
                os.makedirs(path, exist_ok=True)
            test_file = os.path.join(path, ".write_test")
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
            return True
        except (PermissionError, OSError, IOError) as e:
            return False
    
    @staticmethod
    def _ensure_dir(path: str) -> None:
        """Ensure directory exists / Проверить существование директории / Перевірити існування директорії"""
        try:
            os.makedirs(path, exist_ok=True)
        except (PermissionError, OSError) as e:
            # Do not use logger here due to circular import
            # Не используем logger здесь из-за циклического импорта
            # Не використовуємо logger тут через циклічний імпорт
            print(f"[Paths] Failed to create directory {path}: {e}")
    
    @staticmethod
    def _hide_dir(path: str) -> None:
        """Hide directory on Windows / Скрыть директорию на Windows / Приховати директорію на Windows"""
        if platform.system() == "Windows":
            try:
                ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
            except (AttributeError, OSError, TypeError) as e:
                pass
    
    def _cleanup_old_temp_files(self, max_age_hours: int = 24) -> int:
        """Clean up old temporary files / Очистить старые временные файлы / Очистити старі тимчасові файли"""
        temp_dir = self.get_temp_dir()
        if not os.path.exists(temp_dir):
            return 0
        
        deleted = 0
        current_time = time.time()
        max_age_seconds = max_age_hours * 3600
        
        try:
            for filename in os.listdir(temp_dir):
                file_path = os.path.join(temp_dir, filename)
                try:
                    if os.path.isfile(file_path):
                        file_age = current_time - os.path.getmtime(file_path)
                        if file_age > max_age_seconds:
                            # Overwrite before deletion for security / Перезаписываем перед удалением для безопасности / Перезаписуємо перед видаленням для безпеки
                            try:
                                size = os.path.getsize(file_path)
                                if 0 < size < 1024 * 1024:  # Only files up to 1MB / Только файлы до 1MB / Тільки файли до 1MB
                                    with open(file_path, 'wb') as f:
                                        f.write(os.urandom(size))
                                        f.flush()
                            except (OSError, IOError, PermissionError):
                                pass
                            os.remove(file_path)
                            deleted += 1
                except (OSError, IOError, PermissionError, ValueError):
                    continue
        except (OSError, IOError, PermissionError) as e:
            print(f"[Paths] Temp cleanup error: {e}")
        
        if deleted > 0:
            print(f"[Paths] Cleaned up {deleted} old temp files")
        
        return deleted
    
    def cleanup_temp_files(self, max_age_hours: int = 24) -> int:
        """Public method to clean up temporary files
        Публичный метод для очистки временных файлов
        Публічний метод для очищення тимчасових файлів"""
        return self._cleanup_old_temp_files(max_age_hours)
    
    def get_all_paths(self) -> Dict[str, str]:
        """Get all important paths for debugging
        Получить все важные пути для отладки
        Отримати всі важливі шляхи для налагодження"""
        return {
            "mode": self._mode.value,
            "base_dir": self.get_base_dir(),
            "config_dir": self.get_config_dir(),
            "data_dir": self.get_data_dir(),
            "cache_dir": self.get_cache_dir(),
            "logs_dir": self.get_logs_dir(),
            "backup_dir": self.get_backup_dir(),
            "temp_dir": self.get_temp_dir(),
            "config_file": self.get_config_file(),
            "db_file": self.get_db_file(),
            "master_file": self.get_master_file(),
            "lockout_file": self.get_lockout_file(),
        }
    
    def migrate_from_old_location(self, old_path: str) -> bool:
        """
        Migrate data from old location to new one.
        
        Миграция данных из старой локации в новую.
        Міграція даних зі старої локації до нової.
        
        Args:
            old_path: Old path to data folder / Старый путь к папке данных / Старий шлях до папки даних
        
        Returns:
            True if migration successful / True если миграция успешна / True якщо міграція успішна
        """
        if not os.path.exists(old_path):
            return False
        
        new_path = self.get_config_dir()
        if old_path == new_path:
            return True
        
        try:
            # Copy all files from old location / Копируем все файлы из старой локации / Копіюємо всі файли зі старої локації
            for item in os.listdir(old_path):
                old_item = os.path.join(old_path, item)
                new_item = os.path.join(new_path, item)
                
                if os.path.isfile(old_item) and not os.path.exists(new_item):
                    shutil.copy2(old_item, new_item)
                    print(f"[Paths] Migrated: {item}")
            
            print(f"[Paths] Migration completed from {old_path} to {new_path}")
            return True
            
        except (OSError, IOError, PermissionError, shutil.Error) as e:
            print(f"[Paths] Migration failed: {e}")
            return False


# ==================== BACKWARD COMPATIBILITY / ОБРАТНАЯ СОВМЕСТИМОСТЬ / ЗВОРОТНЯ СУМІСНІСТЬ ====================

_path_manager = PathManager()


def get_base_dir() -> str:
    return _path_manager.get_base_dir()


def get_config_dir() -> str:
    return _path_manager.get_config_dir()


def get_data_dir() -> str:
    return _path_manager.get_data_dir()


def get_cache_dir() -> str:
    return _path_manager.get_cache_dir()


def get_logs_dir() -> str:
    return _path_manager.get_logs_dir()


def get_backup_dir() -> str:
    return _path_manager.get_backup_dir()


def get_temp_dir() -> str:
    return _path_manager.get_temp_dir()


def get_config_file() -> str:
    return _path_manager.get_config_file()


def get_db_file() -> str:
    return _path_manager.get_db_file()


def get_salt_file() -> str:
    return _path_manager.get_salt_file()


def get_master_file() -> str:
    return _path_manager.get_master_file()


def get_uuid_file() -> str:
    return _path_manager.get_uuid_file()


def get_key_version_file() -> str:
    return _path_manager.get_key_version_file()


def get_sqlcipher_salt_file() -> str:
    return _path_manager.get_sqlcipher_salt_file()


def get_lockout_file() -> str:
    return _path_manager.get_lockout_file()


def get_audit_file() -> str:
    return _path_manager.get_audit_file()


def hide_dir(path: str) -> None:
    _path_manager._hide_dir(path)


def ensure_dir(path: str) -> None:
    _path_manager._ensure_dir(path)


def cleanup_temp_files(max_age_hours: int = 24) -> int:
    return _path_manager.cleanup_temp_files(max_age_hours)


def get_all_paths() -> Dict[str, str]:
    return _path_manager.get_all_paths()


def is_portable() -> bool:
    """Check if portable mode is enabled / Проверяет, включён ли portable режим / Перевіряє, чи увімкнено portable режим"""
    return _path_manager.is_portable()


def set_portable_mode(enabled: bool) -> bool:
    """
    Enable/disable portable mode.
    
    Включает/выключает portable режим.
    Увімкнює/вимикає portable режим.
    
    Args:
        enabled: True to enable portable mode / True для включения portable режима / True для ввімкнення portable режиму
    
    Returns:
        True if operation successful / True если операция успешна / True якщо операція успішна
    """
    if enabled:
        return _path_manager.create_portable_flag()
    else:
        return _path_manager.remove_portable_flag()


def get_path_mode() -> str:
    """Return current path operation mode / Возвращает текущий режим работы с путями / Повертає поточний режим роботи з шляхами"""
    return _path_manager.get_mode().value


def migrate_from_old_location(old_path: str) -> bool:
    """Migrate data from old location / Миграция данных из старой локации / Міграція даних зі старої локації"""
    return _path_manager.migrate_from_old_location(old_path)


# Export / Экспорт / Експорт
__all__ = [
    'get_base_dir',
    'get_config_dir',
    'get_data_dir',
    'get_cache_dir',
    'get_logs_dir',
    'get_backup_dir',
    'get_temp_dir',
    'get_config_file',
    'get_db_file',
    'get_salt_file',
    'get_master_file',
    'get_uuid_file',
    'get_key_version_file',
    'get_sqlcipher_salt_file',
    'get_lockout_file',
    'get_audit_file',
    'hide_dir',
    'ensure_dir',
    'cleanup_temp_files',
    'get_all_paths',
    'is_portable',
    'set_portable_mode',
    'get_path_mode',
    'migrate_from_old_location',
    'PathManager',
    'PathMode',
]