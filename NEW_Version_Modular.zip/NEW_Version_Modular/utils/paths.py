"""
Path management for SecurePassPro
"""
import os
import sys
import ctypes
import tempfile


def get_base_dir() -> str:
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def get_config_dir() -> str:
    base_dir = get_base_dir()
    config_dir = os.path.join(base_dir, "data")
    
    try:
        os.makedirs(config_dir, exist_ok=True)
        if sys.platform == "win32":
            try:
                ctypes.windll.kernel32.SetFileAttributesW(config_dir, 0x02)
            except Exception:
                pass
    except Exception:
        config_dir = os.path.join(tempfile.gettempdir(), "securepasspro")
        os.makedirs(config_dir, exist_ok=True)
    
    return config_dir


def get_config_file() -> str:
    return os.path.join(get_config_dir(), "config.json")


def get_db_file() -> str:
    return os.path.join(get_config_dir(), "passwords.db")


def get_salt_file() -> str:
    return os.path.join(get_config_dir(), "db.salt")


def get_master_file() -> str:
    return os.path.join(get_config_dir(), "master.key")


def get_uuid_file() -> str:
    return os.path.join(get_config_dir(), "machine.id")


def hide_dir(path: str) -> None:
    if sys.platform == "win32":
        try:
            ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
        except Exception:
            pass