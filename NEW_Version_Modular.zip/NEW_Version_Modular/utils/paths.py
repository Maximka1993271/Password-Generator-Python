"""
Path management for SecurePassPro
"""
import os
import sys
import ctypes
import tempfile


def get_base_dir() -> str:
    """Get base directory (works for EXE and script)"""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def get_config_dir() -> str:
    """Get configuration directory (creates if not exists)"""
    base_dir = get_base_dir()
    config_dir = os.path.join(base_dir, "data")
    
    try:
        os.makedirs(config_dir, exist_ok=True)
        if sys.platform == "win32":
            try:
                ctypes.windll.kernel32.SetFileAttributesW(config_dir, 0x02)
            except AttributeError:
                pass
            except OSError:
                pass
    except PermissionError as e:
        print(f"[Config] Permission error creating {config_dir}: {e}")
        config_dir = os.path.join(tempfile.gettempdir(), "securepasspro")
        os.makedirs(config_dir, exist_ok=True)
        print(f"[Config] Using fallback temp dir: {config_dir}")
    except OSError as e:
        print(f"[Config] OS error creating {config_dir}: {e}")
        config_dir = os.path.join(tempfile.gettempdir(), "securepasspro")
        os.makedirs(config_dir, exist_ok=True)
        print(f"[Config] Using fallback temp dir: {config_dir}")
    
    return config_dir


def get_config_file() -> str:
    """Get config.json file path"""
    return os.path.join(get_config_dir(), "config.json")


def get_db_file() -> str:
    """Get passwords.db file path"""
    return os.path.join(get_config_dir(), "passwords.db")


def get_salt_file() -> str:
    """Get db.salt file path"""
    return os.path.join(get_config_dir(), "db.salt")


def get_master_file() -> str:
    """Get master.key file path"""
    return os.path.join(get_config_dir(), "master.key")


def get_uuid_file() -> str:
    """Get machine.id file path"""
    return os.path.join(get_config_dir(), "machine.id")


def hide_dir(path: str) -> None:
    """Hide directory on Windows"""
    if sys.platform == "win32":
        try:
            ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
        except AttributeError:
            pass
        except OSError:
            pass