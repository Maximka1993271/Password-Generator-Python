"""
Path management for SecurePassPro
Centralized portable path logic for EXE and script modes
FIXED: Добавлена поддержка roaming/local appdata, portable mode, безопасные временные пути
"""
import os
import sys
import ctypes
import tempfile
import platform
import time
import shutil
from typing import Optional, Dict, List, Tuple
from enum import Enum

# НЕ импортируем logger здесь, чтобы избежать циклического импорта
# Будем использовать простой print для ошибок на этом этапе


class PathMode(Enum):
    """Режим работы с путями"""
    PORTABLE = "portable"      # Переносимый режим (все данные в папке с программой)
    LOCAL = "local"            # Локальные данные (AppData/Local)
    ROAMING = "roaming"        # Роуминговые данные (AppData/Roaming)


class PathManager:
    """Centralized path management with fallback support"""
    
    _instance = None
    _base_dir: Optional[str] = None
    _config_dir: Optional[str] = None
    _logs_dir: Optional[str] = None
    _data_dir: Optional[str] = None
    _cache_dir: Optional[str] = None
    _temp_dir: Optional[str] = None
    _backup_dir: Optional[str] = None
    _mode: PathMode = PathMode.PORTABLE
    _portable_flag_file: str = "PORTABLE.txt"
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._detect_mode()
        return cls._instance
    
    def _detect_mode(self) -> None:
        """
        Определяет режим работы:
        - PORTABLE: если есть файл PORTABLE.txt в корне или в папке data
        - LOCAL: по умолчанию на Windows
        - ROAMING: если указано в конфиге (будет загружено позже)
        """
        base_dir = self.get_base_dir()
        
        # Проверяем наличие файла PORTABLE.txt
        portable_file = os.path.join(base_dir, self._portable_flag_file)
        if os.path.exists(portable_file):
            self._mode = PathMode.PORTABLE
            print(f"[Paths] Portable mode detected via {self._portable_flag_file}")
            return
        
        # Проверяем наличие папки data в корне (признак portable режима)
        data_dir = os.path.join(base_dir, "data")
        if os.path.exists(data_dir) and os.path.isdir(data_dir):
            # Проверяем, можем ли мы писать в эту папку
            if self._is_writable(data_dir):
                self._mode = PathMode.PORTABLE
                print("[Paths] Portable mode detected (data directory exists)")
                return
        
        # По умолчанию используем локальный режим
        self._mode = PathMode.LOCAL
        print(f"[Paths] Using {self._mode.value} mode")
    
    def set_mode(self, mode: PathMode) -> None:
        """Устанавливает режим работы (требует перезапуска для применения)"""
        if mode in [PathMode.LOCAL, PathMode.ROAMING, PathMode.PORTABLE]:
            self._mode = mode
            # Сбрасываем кэшированные пути
            self._config_dir = None
            self._logs_dir = None
            self._data_dir = None
            self._cache_dir = None
            self._temp_dir = None
            self._backup_dir = None
            print(f"[Paths] Mode changed to {mode.value} (restart may be required)")
    
    def get_mode(self) -> PathMode:
        """Возвращает текущий режим работы"""
        return self._mode
    
    def create_portable_flag(self) -> bool:
        """Создаёт файл PORTABLE.txt для включения portable режима"""
        try:
            flag_path = os.path.join(self.get_base_dir(), self._portable_flag_file)
            with open(flag_path, 'w') as f:
                f.write("# Secure Pass Pro - Portable Mode\n")
                f.write("# This file enables portable mode (all data stored in the application directory)\n")
            print(f"[Paths] Portable flag created: {flag_path}")
            return True
        except (OSError, IOError, PermissionError) as e:
            print(f"[Paths] Failed to create portable flag: {e}")
            return False
    
    def remove_portable_flag(self) -> bool:
        """Удаляет файл PORTABLE.txt для отключения portable режима"""
        try:
            flag_path = os.path.join(self.get_base_dir(), self._portable_flag_file)
            if os.path.exists(flag_path):
                os.remove(flag_path)
                print(f"[Paths] Portable flag removed: {flag_path}")
            return True
        except (OSError, IOError, PermissionError) as e:
            print(f"[Paths] Failed to remove portable flag: {e}")
            return False
    
    def is_portable(self) -> bool:
        """Проверяет, включён ли portable режим"""
        return self._mode == PathMode.PORTABLE
    
    @classmethod
    def get_base_dir(cls) -> str:
        """Get base directory (works for EXE and script)"""
        if cls._base_dir is not None:
            return cls._base_dir
        
        if getattr(sys, 'frozen', False):
            cls._base_dir = os.path.dirname(sys.executable)
        else:
            cls._base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        return cls._base_dir
    
    def _get_portable_config_dir(self) -> str:
        """Получает путь для portable режима"""
        return os.path.join(self.get_base_dir(), "data")
    
    def _get_local_config_dir(self) -> str:
        """Получает путь для локального режима (Windows AppData/Local)"""
        system = platform.system()
        
        if system == "Windows":
            local_appdata = os.environ.get('LOCALAPPDATA', '')
            if local_appdata:
                return os.path.join(local_appdata, "SecurePassPro")
            else:
                return os.path.join(tempfile.gettempdir(), "securepasspro")
        
        elif system == "Darwin":  # macOS
            home = os.path.expanduser("~")
            return os.path.join(home, "Library", "Application Support", "SecurePassPro")
        
        else:  # Linux and others
            home = os.path.expanduser("~")
            return os.path.join(home, ".local", "share", "securepasspro")
    
    def _get_roaming_config_dir(self) -> str:
        """Получает путь для роумингового режима (Windows AppData/Roaming)"""
        system = platform.system()
        
        if system == "Windows":
            appdata = os.environ.get('APPDATA', '')
            if appdata:
                return os.path.join(appdata, "SecurePassPro")
            else:
                return self._get_local_config_dir()
        
        elif system == "Darwin":  # macOS
            home = os.path.expanduser("~")
            return os.path.join(home, "Library", "Application Support", "SecurePassPro")
        
        else:  # Linux
            home = os.path.expanduser("~")
            return os.path.join(home, ".config", "securepasspro")
    
    def get_config_dir(self) -> str:
        """
        Get configuration directory (creates if not exists)
        Uses OS-appropriate locations with fallback
        """
        if self._config_dir is not None:
            return self._config_dir
        
        # Выбираем директорию в зависимости от режима
        if self._mode == PathMode.PORTABLE:
            config_dir = self._get_portable_config_dir()
        elif self._mode == PathMode.ROAMING:
            config_dir = self._get_roaming_config_dir()
        else:  # LOCAL
            config_dir = self._get_local_config_dir()
        
        # Проверяем возможность записи
        if not self._is_writable(config_dir):
            # Fallback к portable режиму
            fallback_dir = self._get_portable_config_dir()
            if self._is_writable(fallback_dir):
                print(f"[Paths] Fallback to portable mode: {fallback_dir}")
                self._mode = PathMode.PORTABLE
                config_dir = fallback_dir
            else:
                # Последний fallback: temp directory
                config_dir = os.path.join(tempfile.gettempdir(), "securepasspro")
                print(f"[Paths] Using temp directory as fallback: {config_dir}")
        
        self._config_dir = config_dir
        self._ensure_dir(config_dir)
        self._hide_dir(config_dir)
        
        return self._config_dir
    
    def get_data_dir(self) -> str:
        """Get data directory (for user data)"""
        if self._data_dir is not None:
            return self._data_dir
        
        self._data_dir = self.get_config_dir()
        return self._data_dir
    
    def get_cache_dir(self) -> str:
        """Get cache directory"""
        if self._cache_dir is not None:
            return self._cache_dir
        
        if self._mode == PathMode.PORTABLE:
            self._cache_dir = os.path.join(self.get_config_dir(), "cache")
        else:
            system = platform.system()
            
            if system == "Windows":
                local_appdata = os.environ.get('LOCALAPPDATA', '')
                if local_appdata:
                    self._cache_dir = os.path.join(local_appdata, "SecurePassPro", "Cache")
                else:
                    self._cache_dir = os.path.join(self.get_config_dir(), "cache")
            
            elif system == "Darwin":  # macOS
                home = os.path.expanduser("~")
                self._cache_dir = os.path.join(home, "Library", "Caches", "SecurePassPro")
            
            else:  # Linux
                home = os.path.expanduser("~")
                self._cache_dir = os.path.join(home, ".cache", "securepasspro")
        
        self._ensure_dir(self._cache_dir)
        return self._cache_dir
    
    def get_logs_dir(self) -> str:
        """Get logs directory path"""
        if self._logs_dir is not None:
            return self._logs_dir
        
        if self._mode == PathMode.PORTABLE:
            self._logs_dir = os.path.join(self.get_base_dir(), "logs")
        else:
            self._logs_dir = os.path.join(self.get_cache_dir(), "logs")
        
        self._ensure_dir(self._logs_dir)
        return self._logs_dir
    
    def get_temp_dir(self) -> str:
        """Get temporary directory for the app with cleanup support"""
        if self._temp_dir is not None:
            return self._temp_dir
        
        if self._mode == PathMode.PORTABLE:
            self._temp_dir = os.path.join(self.get_config_dir(), "temp")
        else:
            # Используем системную temp директорию с подпапкой приложения
            system_temp = tempfile.gettempdir()
            self._temp_dir = os.path.join(system_temp, "securepasspro")
        
        self._ensure_dir(self._temp_dir)
        
        # Очищаем старые временные файлы (при запуске)
        self._cleanup_old_temp_files()
        
        return self._temp_dir
    
    def get_backup_dir(self) -> str:
        """Get backup directory"""
        if self._backup_dir is not None:
            return self._backup_dir
        
        self._backup_dir = os.path.join(self.get_config_dir(), "backups")
        self._ensure_dir(self._backup_dir)
        return self._backup_dir
    
    def get_config_file(self) -> str:
        """Get config.json file path"""
        return os.path.join(self.get_config_dir(), "config.json")
    
    def get_db_file(self) -> str:
        """Get passwords.db file path"""
        return os.path.join(self.get_data_dir(), "passwords.db")
    
    def get_salt_file(self) -> str:
        """Get db.salt file path"""
        return os.path.join(self.get_data_dir(), "db.salt")
    
    def get_master_file(self) -> str:
        """Get master.key file path"""
        return os.path.join(self.get_data_dir(), "master.key")
    
    def get_uuid_file(self) -> str:
        """Get machine.id file path"""
        return os.path.join(self.get_data_dir(), "machine.id")
    
    def get_key_version_file(self) -> str:
        """Get key.version file path"""
        return os.path.join(self.get_data_dir(), "key.version")
    
    def get_sqlcipher_salt_file(self) -> str:
        """Get sqlcipher.salt file path"""
        return os.path.join(self.get_data_dir(), "sqlcipher.salt")
    
    def get_lockout_file(self) -> str:
        """Get lockout.json file path"""
        return os.path.join(self.get_data_dir(), "lockout.json")
    
    def get_audit_file(self) -> str:
        """Get auth_audit.json file path"""
        return os.path.join(self.get_data_dir(), "auth_audit.json")
    
    @staticmethod
    def _is_writable(path: str) -> bool:
        """Check if directory is writable"""
        try:
            if not os.path.exists(path):
                os.makedirs(path, exist_ok=True)
            test_file = os.path.join(path, ".write_test")
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
            return True
        except (PermissionError, OSError, IOError) as e:
            return False
    
    @staticmethod
    def _ensure_dir(path: str) -> None:
        """Ensure directory exists"""
        try:
            os.makedirs(path, exist_ok=True)
        except (PermissionError, OSError) as e:
            # Не используем logger здесь из-за циклического импорта
            print(f"[Paths] Failed to create directory {path}: {e}")
    
    @staticmethod
    def _hide_dir(path: str) -> None:
        """Hide directory on Windows"""
        if platform.system() == "Windows":
            try:
                ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
            except (AttributeError, OSError, TypeError) as e:
                pass
    
    def _cleanup_old_temp_files(self, max_age_hours: int = 24) -> int:
        """Clean up old temporary files"""
        temp_dir = self.get_temp_dir()
        if not os.path.exists(temp_dir):
            return 0
        
        deleted = 0
        current_time = time.time()
        max_age_seconds = max_age_hours * 3600
        
        try:
            for filename in os.listdir(temp_dir):
                file_path = os.path.join(temp_dir, filename)
                try:
                    if os.path.isfile(file_path):
                        file_age = current_time - os.path.getmtime(file_path)
                        if file_age > max_age_seconds:
                            # Перезаписываем перед удалением для безопасности
                            try:
                                size = os.path.getsize(file_path)
                                if 0 < size < 1024 * 1024:  # Только файлы до 1MB
                                    with open(file_path, 'wb') as f:
                                        f.write(os.urandom(size))
                                        f.flush()
                            except (OSError, IOError, PermissionError):
                                pass
                            os.remove(file_path)
                            deleted += 1
                except (OSError, IOError, PermissionError, ValueError):
                    continue
        except (OSError, IOError, PermissionError) as e:
            print(f"[Paths] Temp cleanup error: {e}")
        
        if deleted > 0:
            print(f"[Paths] Cleaned up {deleted} old temp files")
        
        return deleted
    
    def cleanup_temp_files(self, max_age_hours: int = 24) -> int:
        """Public method to clean up temporary files"""
        return self._cleanup_old_temp_files(max_age_hours)
    
    def get_all_paths(self) -> Dict[str, str]:
        """Get all important paths for debugging"""
        return {
            "mode": self._mode.value,
            "base_dir": self.get_base_dir(),
            "config_dir": self.get_config_dir(),
            "data_dir": self.get_data_dir(),
            "cache_dir": self.get_cache_dir(),
            "logs_dir": self.get_logs_dir(),
            "backup_dir": self.get_backup_dir(),
            "temp_dir": self.get_temp_dir(),
            "config_file": self.get_config_file(),
            "db_file": self.get_db_file(),
            "master_file": self.get_master_file(),
            "lockout_file": self.get_lockout_file(),
        }
    
    def migrate_from_old_location(self, old_path: str) -> bool:
        """
        Миграция данных из старой локации в новую.
        
        Args:
            old_path: Старый путь к папке данных
        
        Returns:
            True если миграция успешна
        """
        if not os.path.exists(old_path):
            return False
        
        new_path = self.get_config_dir()
        if old_path == new_path:
            return True
        
        try:
            # Копируем все файлы из старой локации
            for item in os.listdir(old_path):
                old_item = os.path.join(old_path, item)
                new_item = os.path.join(new_path, item)
                
                if os.path.isfile(old_item) and not os.path.exists(new_item):
                    shutil.copy2(old_item, new_item)
                    print(f"[Paths] Migrated: {item}")
            
            print(f"[Paths] Migration completed from {old_path} to {new_path}")
            return True
            
        except (OSError, IOError, PermissionError, shutil.Error) as e:
            print(f"[Paths] Migration failed: {e}")
            return False


# ==================== ОБРАТНАЯ СОВМЕСТИМОСТЬ ====================

_path_manager = PathManager()


def get_base_dir() -> str:
    return _path_manager.get_base_dir()


def get_config_dir() -> str:
    return _path_manager.get_config_dir()


def get_data_dir() -> str:
    return _path_manager.get_data_dir()


def get_cache_dir() -> str:
    return _path_manager.get_cache_dir()


def get_logs_dir() -> str:
    return _path_manager.get_logs_dir()


def get_backup_dir() -> str:
    return _path_manager.get_backup_dir()


def get_temp_dir() -> str:
    return _path_manager.get_temp_dir()


def get_config_file() -> str:
    return _path_manager.get_config_file()


def get_db_file() -> str:
    return _path_manager.get_db_file()


def get_salt_file() -> str:
    return _path_manager.get_salt_file()


def get_master_file() -> str:
    return _path_manager.get_master_file()


def get_uuid_file() -> str:
    return _path_manager.get_uuid_file()


def get_key_version_file() -> str:
    return _path_manager.get_key_version_file()


def get_sqlcipher_salt_file() -> str:
    return _path_manager.get_sqlcipher_salt_file()


def get_lockout_file() -> str:
    return _path_manager.get_lockout_file()


def get_audit_file() -> str:
    return _path_manager.get_audit_file()


def hide_dir(path: str) -> None:
    _path_manager._hide_dir(path)


def ensure_dir(path: str) -> None:
    _path_manager._ensure_dir(path)


def cleanup_temp_files(max_age_hours: int = 24) -> int:
    return _path_manager.cleanup_temp_files(max_age_hours)


def get_all_paths() -> Dict[str, str]:
    return _path_manager.get_all_paths()


def is_portable() -> bool:
    """Проверяет, включён ли portable режим"""
    return _path_manager.is_portable()


def set_portable_mode(enabled: bool) -> bool:
    """
    Включает/выключает portable режим.
    
    Args:
        enabled: True для включения portable режима
    
    Returns:
        True если операция успешна
    """
    if enabled:
        return _path_manager.create_portable_flag()
    else:
        return _path_manager.remove_portable_flag()


def get_path_mode() -> str:
    """Возвращает текущий режим работы с путями"""
    return _path_manager.get_mode().value


def migrate_from_old_location(old_path: str) -> bool:
    """Миграция данных из старой локации"""
    return _path_manager.migrate_from_old_location(old_path)


# Экспорт
__all__ = [
    'get_base_dir',
    'get_config_dir',
    'get_data_dir',
    'get_cache_dir',
    'get_logs_dir',
    'get_backup_dir',
    'get_temp_dir',
    'get_config_file',
    'get_db_file',
    'get_salt_file',
    'get_master_file',
    'get_uuid_file',
    'get_key_version_file',
    'get_sqlcipher_salt_file',
    'get_lockout_file',
    'get_audit_file',
    'hide_dir',
    'ensure_dir',
    'cleanup_temp_files',
    'get_all_paths',
    'is_portable',
    'set_portable_mode',
    'get_path_mode',
    'migrate_from_old_location',
    'PathManager',
    'PathMode',
]