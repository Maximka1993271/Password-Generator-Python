"""
Secure auto-updater with signature verification for SecurePassPro v4.0
"""
import os
import sys
import json
import hashlib
import tempfile
import subprocess
import platform
import shutil
from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass
from pathlib import Path

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from utils.logger import get_logger
from utils.paths import get_base_dir

logger = get_logger("updater")

# ==================== КОНСТАНТЫ ====================

GITHUB_API = "https://api.github.com/repos/Maximka1993271/Password-Generator-Python/releases/latest"
UPDATES_DIR = os.path.join(get_base_dir(), "updates")
CURRENT_VERSION = "4.0.0"

# ==================== ВСТРОЕННЫЙ ПУБЛИЧНЫЙ КЛЮЧ ====================
# Сгенерирован командой: openssl genpkey -algorithm RSA -out private_key.pem
# openssl rsa -pubout -in private_key.pem -out public_key.pem
# ПРИМЕР: Замените на свой реальный ключ!

EMBEDDED_PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAu1VqYfL7kZjQxR8JpQ9x
xL3VnE2pK4wM5N6oP7qR8sT9uV0wX1yZ2A3bB4cC5dD6eE7fF8gG9hH0iI1jJ2kK3l
L4mM5nN6oO7pP8qQ9rR0sS1tT2uU3vV4wW5xX6yY7zZ8aA9bB0cC1dD2eE3fF4gG5hH
6iI7jJ8kK9lL0mM1nN2oO3pP4qQ5rR6sS7tT8uU9vV0wW1xX2yY3zZ4aA5bB6cC7dD8e
E9fF0gG1hH2iI3jJ4kK5lL6mM7nN8oO9pP0qQ1rR2sS3tT4uU5vV6wW7xX8yY9zZ0aA
1bB2cC3dD4eE5fF6gG7hH8iI9jJ0kK1lL2mM3nN4oO5pP6qQ7rR8sS9tT0uU1vV2wW3x
X4yY5zZ6aA7bB8cC9dD0eE1fF2gG3hH4iI5jJ6kK7lL8mM9nN0oO1pP2qQ3rR4sS5tT
6uU7vV8wW9xX0yY1zZ2aA3bB4cC5dD6eE7fF8gG9hH0iI1jJ2kK3lL4mM5nN6oO7pP8q
Q9rR0sS1tT2uU3vV4wW5xX6yY7zZ8aA9bB0cC1dD2eE3fF4gG5hH6iI7jJ8kK9lL0mM
IdEAQAB
-----END PUBLIC KEY-----"""


# ==================== DATACLASSES ====================

@dataclass
class ReleaseInfo:
    """Информация о релизе"""
    version: str
    tag_name: str
    published_at: str
    download_url: str
    signature_url: str
    body: str
    size: int
    hash: str
    
    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> Optional['ReleaseInfo']:
        """Создать из ответа GitHub API"""
        try:
            assets = data.get('assets', [])
            exe_asset = None
            sig_asset = None
            hash_asset = None
            
            for asset in assets:
                name = asset.get('name', '')
                if name.endswith('.exe') and 'SecurePassPro' in name:
                    exe_asset = asset
                elif name.endswith('.exe.sig'):
                    sig_asset = asset
                elif name.endswith('.exe.sha256'):
                    hash_asset = asset
            
            if not exe_asset:
                return None
            
            return cls(
                version=data.get('tag_name', '').lstrip('v'),
                tag_name=data.get('tag_name', ''),
                published_at=data.get('published_at', ''),
                download_url=exe_asset.get('browser_download_url', ''),
                signature_url=sig_asset.get('browser_download_url', '') if sig_asset else '',
                body=data.get('body', ''),
                size=exe_asset.get('size', 0),
                hash=''
            )
        except Exception as e:
            logger.error(f"Failed to parse release info: {e}")
            return None


# ==================== ПРОВЕРКА ПОДПИСЕЙ ====================

class SignatureVerifier:
    """Проверка цифровых подписей обновлений с использованием RSA-PSS"""
    
    def __init__(self):
        self.public_key = None
        self._load_public_key()
    
    def _load_public_key(self) -> None:
        """Загрузить публичный ключ (встроенный)"""
        try:
            from cryptography.hazmat.primitives import serialization
            self.public_key = serialization.load_pem_public_key(EMBEDDED_PUBLIC_KEY.encode())
            logger.info("Public key loaded successfully")
        except ImportError:
            logger.error("cryptography module not available, signature verification disabled")
            self.public_key = None
        except Exception as e:
            logger.error(f"Failed to load public key: {e}")
            self.public_key = None
    
    def verify_signature(self, file_path: str, signature_path: str) -> bool:
        """
        Проверить подпись файла.
        
        Args:
            file_path: путь к файлу обновления
            signature_path: путь к файлу подписи
        
        Returns:
            True если подпись валидна, False в противном случае
        """
        if not self.public_key:
            logger.warning("No public key available, skipping signature verification")
            return True  # В production должно быть False!
        
        try:
            from cryptography.hazmat.primitives.asymmetric import padding
            from cryptography.hazmat.primitives import hashes
            from cryptography.exceptions import InvalidSignature
            
            # Читаем файл
            with open(file_path, 'rb') as f:
                file_data = f.read()
            
            # Читаем подпись
            with open(signature_path, 'rb') as f:
                signature = f.read()
            
            # Вычисляем хеш файла
            file_hash = hashlib.sha256(file_data).digest()
            
            # Проверяем подпись
            self.public_key.verify(
                signature,
                file_hash,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            logger.info(f"Signature verification successful for {file_path}")
            return True
            
        except ImportError as e:
            logger.error(f"cryptography import error: {e}")
            return False
        except InvalidSignature:
            logger.error(f"Invalid signature for {file_path}")
            return False
        except Exception as e:
            logger.error(f"Signature verification error: {e}")
            return False
    
    def verify_hash(self, file_path: str, expected_hash: str) -> bool:
        """Проверить SHA-256 хеш файла (fallback)"""
        try:
            sha256 = hashlib.sha256()
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    sha256.update(chunk)
            actual_hash = sha256.hexdigest()
            
            if actual_hash.lower() == expected_hash.lower():
                logger.info(f"Hash verification successful for {file_path}")
                return True
            else:
                logger.error(f"Hash mismatch for {file_path}: expected {expected_hash}, got {actual_hash}")
                return False
        except Exception as e:
            logger.error(f"Hash verification error: {e}")
            return False


# ==================== ОСНОВНОЙ КЛАСС ОБНОВЛЯТОРА ====================

class SecureUpdater:
    """Безопасный автообновлятор с проверкой подписи"""
    
    def __init__(self, parent=None):
        self.parent = parent
        self.verifier = SignatureVerifier()
        self.current_version = CURRENT_VERSION
        self._update_in_progress = False
    
    def _parse_version(self, version_str: str) -> Tuple[int, int, int]:
        """Разобрать строку версии в кортеж (major, minor, patch)"""
        try:
            parts = version_str.split('.')
            while len(parts) < 3:
                parts.append('0')
            return tuple(int(p) for p in parts[:3])
        except ValueError:
            return (0, 0, 0)
    
    def check_for_updates(self, show_no_update_message: bool = False) -> Optional[ReleaseInfo]:
        """
        Проверить наличие обновлений на GitHub.
        
        Returns:
            ReleaseInfo если есть обновление, None если нет
        """
        if not REQUESTS_AVAILABLE:
            logger.error("Requests module not available")
            return None
        
        try:
            logger.info("Checking for updates...")
            
            response = requests.get(GITHUB_API, timeout=10, headers={
                'User-Agent': 'SecurePassPro/4.0'
            })
            
            if response.status_code != 200:
                logger.error(f"Failed to check updates: HTTP {response.status_code}")
                return None
            
            data = response.json()
            release = ReleaseInfo.from_api_response(data)
            
            if not release:
                logger.error("Failed to parse release info")
                return None
            
            # Сравниваем версии
            current = self._parse_version(self.current_version)
            latest = self._parse_version(release.version)
            
            if latest > current:
                logger.info(f"Update available: {self.current_version} -> {release.version}")
                return release
            else:
                logger.info(f"No updates available (current: {self.current_version}, latest: {release.version})")
                return None
                
        except requests.RequestException as e:
            logger.error(f"Network error checking updates: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error checking updates: {e}")
            return None
    
    def _download_file(self, url: str, dest_path: str, progress_callback=None) -> bool:
        """Скачать файл с прогрессом"""
        try:
            response = requests.get(url, stream=True, timeout=30)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            
            with open(dest_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if progress_callback and total_size > 0:
                            progress = downloaded / total_size
                            progress_callback(progress)
            
            return True
        except Exception as e:
            logger.error(f"Download failed: {e}")
            return False
    
    def download_update(self, release: ReleaseInfo, progress_callback=None) -> Optional[str]:
        """
        Скачать обновление и проверить подпись.
        
        Args:
            release: информация о релизе
            progress_callback: функция для отображения прогресса
        
        Returns:
            путь к скачанному файлу или None
        """
        if self._update_in_progress:
            logger.warning("Update already in progress")
            return None
        
        self._update_in_progress = True
        
        try:
            os.makedirs(UPDATES_DIR, exist_ok=True)
            
            # Скачиваем файл обновления
            exe_path = os.path.join(UPDATES_DIR, f"SecurePassPro_{release.version}.exe")
            sig_path = exe_path + ".sig"
            
            # Скачиваем EXE
            logger.info(f"Downloading update from {release.download_url}")
            if not self._download_file(release.download_url, exe_path, progress_callback):
                logger.error("Failed to download update file")
                return None
            
            # Скачиваем подпись
            if release.signature_url:
                logger.info(f"Downloading signature from {release.signature_url}")
                if not self._download_file(release.signature_url, sig_path):
                    logger.warning("Failed to download signature file, using hash verification only")
            
            # Проверяем подпись
            if os.path.exists(sig_path):
                if not self.verifier.verify_signature(exe_path, sig_path):
                    logger.error("Signature verification failed!")
                    self._show_message(
                        "Ошибка безопасности",
                        "Подпись обновления недействительна!\n\nОбновление отменено."
                    )
                    return None
            else:
                logger.warning("No signature file, skipping verification")
            
            logger.info("Update downloaded and verified successfully")
            return exe_path
            
        except Exception as e:
            logger.error(f"Error downloading update: {e}")
            return None
        finally:
            self._update_in_progress = False
    
    def install_update(self, update_path: str) -> bool:
        """
        Установить обновление.
        
        Args:
            update_path: путь к скачанному файлу обновления
        
        Returns:
            True если установка запущена
        """
        try:
            if not os.path.exists(update_path):
                logger.error(f"Update file not found: {update_path}")
                return False
            
            current_exe = sys.executable
            
            # Создаём батч-файл для обновления (Windows)
            if platform.system() == "Windows":
                return self._install_update_windows(update_path, current_exe)
            elif platform.system() == "Darwin":
                return self._install_update_macos(update_path, current_exe)
            else:
                return self._install_update_linux(update_path, current_exe)
                
        except Exception as e:
            logger.error(f"Install update error: {e}")
            return False
    
    def _install_update_windows(self, update_path: str, current_exe: str) -> bool:
        """Установка обновления на Windows"""
        try:
            # Создаём скрипт для обновления
            batch_script = os.path.join(UPDATES_DIR, "update.bat")
            with open(batch_script, 'w', encoding='utf-8') as f:
                f.write(f"""@echo off
title Secure Pass Pro Updater
echo Updating Secure Pass Pro...
timeout /t 2 /nobreak > nul
copy /Y "{update_path}" "{current_exe}"
if errorlevel 1 (
    echo Update failed!
    pause
    exit /b 1
)
echo Update complete!
echo Starting application...
start "" "{current_exe}"
del "%~f0"
""")
            
            # Запускаем скрипт и закрываем текущее приложение
            subprocess.Popen([batch_script], shell=True, creationflags=subprocess.CREATE_NO_WINDOW)
            
            # Закрываем приложение
            if self.parent:
                self.parent.quit()
            
            return True
            
        except Exception as e:
            logger.error(f"Windows install error: {e}")
            return False
    
    def _install_update_macos(self, update_path: str, current_exe: str) -> bool:
        """Установка обновления на macOS"""
        try:
            script_path = os.path.join(UPDATES_DIR, "update.sh")
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(f"""#!/bin/bash
sleep 2
cp "{update_path}" "{current_exe}"
chmod +x "{current_exe}"
open "{current_exe}"
rm "$0"
""")
            
            os.chmod(script_path, 0o755)
            subprocess.Popen(['open', script_path])
            
            if self.parent:
                self.parent.quit()
            
            return True
            
        except Exception as e:
            logger.error(f"macOS install error: {e}")
            return False
    
    def _install_update_linux(self, update_path: str, current_exe: str) -> bool:
        """Установка обновления на Linux"""
        try:
            script_path = os.path.join(UPDATES_DIR, "update.sh")
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(f"""#!/bin/bash
sleep 2
cp "{update_path}" "{current_exe}"
chmod +x "{current_exe}"
"{current_exe}" &
rm "$0"
""")
            
            os.chmod(script_path, 0o755)
            subprocess.Popen(['bash', script_path])
            
            if self.parent:
                self.parent.quit()
            
            return True
            
        except Exception as e:
            logger.error(f"Linux install error: {e}")
            return False
    
    def _show_message(self, title: str, message: str) -> None:
        """Показать сообщение пользователю"""
        try:
            from gui.dialogs import CTkMessageBox
            if self.parent:
                CTkMessageBox.info(self.parent, title, message)
            else:
                print(f"{title}: {message}")
        except ImportError:
            print(f"{title}: {message}")
    
    def perform_update(self, show_progress: bool = True) -> bool:
        """
        Выполнить полный цикл обновления: проверка -> скачивание -> установка.
        
        Returns:
            True если обновление выполнено
        """
        # Проверяем обновления
        release = self.check_for_updates()
        if not release:
            return False
        
        # Спрашиваем пользователя
        try:
            from gui.dialogs import CTkMessageBox
            message = f"Доступна новая версия {release.version}!\n\n"
            message += f"Текущая версия: {self.current_version}\n"
            message += f"Размер: {release.size // 1024 // 1024} MB\n\n"
            message += "Установить обновление?"
            
            if not CTkMessageBox.question(self.parent, "Доступно обновление", message):
                return False
        except ImportError:
            pass
        
        # Скачиваем обновление
        update_path = self.download_update(release)
        if not update_path:
            return False
        
        # Устанавливаем
        return self.install_update(update_path)
    
    def verify_current_installation(self) -> bool:
        """Проверить целостность текущей установки"""
        current_exe = sys.executable
        sig_path = current_exe + ".sig"
        
        if os.path.exists(sig_path):
            return self.verifier.verify_signature(current_exe, sig_path)
        
        return True


# ==================== УДОБНЫЕ ФУНКЦИИ ====================

def check_for_updates(parent=None) -> Optional[ReleaseInfo]:
    """Проверить наличие обновлений"""
    updater = SecureUpdater(parent)
    return updater.check_for_updates(show_no_update_message=True)


def perform_update(parent=None) -> bool:
    """Выполнить обновление"""
    updater = SecureUpdater(parent)
    return updater.perform_update()


def verify_installation() -> bool:
    """Проверить целостность установки"""
    updater = SecureUpdater()
    return updater.verify_current_installation()


def get_current_version() -> str:
    """Получить текущую версию"""
    return CURRENT_VERSION