"""
Secure auto-updater with signature verification for SecurePassPro v4.0
SECURE VERSION - HTTPS only, signature verification, integrity checking
FIXED: Устранён циклический импорт, улучшена обработка ошибок

Безопасный автообновлятор с проверкой подписи для SecurePassPro v4.0
БЕЗОПАСНАЯ ВЕРСИЯ - только HTTPS, проверка подписи, верификация целостности
FIXED: Устранён циклический импорт, улучшена обработка ошибок

Безпечний автооновлювач з перевіркою підпису для SecurePassPro v4.0
БЕЗПЕЧНА ВЕРСІЯ - тільки HTTPS, перевірка підпису, верифікація цілісності
FIXED: Усунуто циклічний імпорт, покращено обробку помилок
"""

import os
import sys
import json
import hashlib
import tempfile
import subprocess
import platform
import shutil
import ssl
import hmac
from typing import Optional, Dict, Any, Tuple, Callable
from dataclasses import dataclass
from enum import Enum
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

# Lazy import to avoid circular dependencies / Ленивый импорт для избежания циклических зависимостей / Лінивий імпорт для уникнення циклічних залежностей
_REQUESTS_AVAILABLE = False
try:
    import requests
    _REQUESTS_AVAILABLE = True
except ImportError:
    pass

from utils.logger import get_logger
from utils.paths import get_base_dir

logger = get_logger("updater")

# ==================== CONSTANTS / КОНСТАНТЫ / КОНСТАНТИ ====================

GITHUB_API = "https://api.github.com/repos/Maximka1993271/Password-Generator-Python/releases/latest"
UPDATES_DIR = os.path.join(get_base_dir(), "updates")
CURRENT_VERSION = "4.0.0"

# HTTPS only! / Только HTTPS! / Тільки HTTPS!
if not GITHUB_API.startswith("https://"):
    raise ValueError("Update URL must use HTTPS!")

# Required exception types for updater / Требуемые типы исключений для updater / Необхідні типи винятків для updater
NETWORK_ERRORS = (URLError, HTTPError, ConnectionError, TimeoutError, ssl.SSLError)
if _REQUESTS_AVAILABLE:
    NETWORK_ERRORS = NETWORK_ERRORS + (requests.RequestException,)


class UpdateStatus(Enum):
    """Update check status / Статус проверки обновления / Статус перевірки оновлення"""
    NO_UPDATE = "no_update"
    UPDATE_AVAILABLE = "update_available"
    CHECK_FAILED = "check_failed"
    DOWNLOAD_FAILED = "download_failed"
    VERIFY_FAILED = "verify_failed"
    INSTALL_FAILED = "install_failed"
    SIGNATURE_INVALID = "signature_invalid"
    INTEGRITY_FAILED = "integrity_failed"
    SUCCESS = "success"


@dataclass
class ReleaseInfo:
    """Release information with integrity check
    Информация о релизе с проверкой целостности
    Інформація про реліз з перевіркою цілісності"""
    version: str
    tag_name: str
    published_at: str
    download_url: str
    signature_url: str
    hash_url: str
    body: str
    size: int
    hash_sha256: str
    
    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> Optional['ReleaseInfo']:
        """Create from GitHub API response (HTTPS only)
        Создать из ответа GitHub API (только HTTPS)
        Створити з відповіді GitHub API (тільки HTTPS)"""
        try:
            assets = data.get('assets', [])
            exe_asset = None
            sig_asset = None
            hash_asset = None
            
            for asset in assets:
                name = asset.get('name', '')
                download_url = asset.get('browser_download_url', '')
                
                # Check HTTPS / Проверяем HTTPS / Перевіряємо HTTPS
                if not download_url.startswith("https://"):
                    logger.error(f"Non-HTTPS download URL: {download_url}")
                    continue
                
                if name.endswith('.exe') and 'SecurePassPro' in name:
                    exe_asset = asset
                elif name.endswith('.exe.sig'):
                    sig_asset = asset
                elif name.endswith('.sha256'):
                    hash_asset = asset
            
            if not exe_asset:
                return None
            
            return cls(
                version=data.get('tag_name', '').lstrip('v'),
                tag_name=data.get('tag_name', ''),
                published_at=data.get('published_at', ''),
                download_url=exe_asset.get('browser_download_url', ''),
                signature_url=sig_asset.get('browser_download_url', '') if sig_asset else '',
                hash_url=hash_asset.get('browser_download_url', '') if hash_asset else '',
                body=data.get('body', ''),
                size=exe_asset.get('size', 0),
                hash_sha256=''
            )
        except (KeyError, ValueError, TypeError, AttributeError) as e:
            logger.error(f"Failed to parse release info: {e}")
            return None

    def is_newer_than(self, current_version: str) -> bool:
        """Check if this version is newer than current
        Проверить, новее ли эта версия чем текущая
        Перевірити, чи новіша ця версія ніж поточна"""
        def parse(v: str) -> Tuple[int, ...]:
            try:
                return tuple(int(x) for x in v.split('.')[:3])
            except ValueError:
                return (0, 0, 0)
        
        return parse(self.version) > parse(current_version)


class SecureUpdater:
    """Secure auto-updater with signature verification
    Безопасный автообновлятор с проверкой подписи
    Безпечний автооновлювач з перевіркою підпису"""
    
    def __init__(self, parent=None, progress_callback: Optional[Callable[[float], None]] = None):
        self.parent = parent
        self.current_version = CURRENT_VERSION
        self._update_in_progress = False
        self.progress_callback = progress_callback
    
    def check_for_updates(self) -> Tuple[UpdateStatus, Optional[ReleaseInfo]]:
        """Check for updates on GitHub (HTTPS only)
        Проверить наличие обновлений на GitHub (только HTTPS)
        Перевірити наявність оновлень на GitHub (тільки HTTPS)"""
        if not _REQUESTS_AVAILABLE:
            logger.error("Requests module not available")
            return UpdateStatus.CHECK_FAILED, None
        
        try:
            logger.info("Checking for updates...")
            
            response = requests.get(
                GITHUB_API,
                timeout=10,
                headers={
                    'User-Agent': f'SecurePassPro/{CURRENT_VERSION}',
                    'Accept': 'application/vnd.github.v3+json'
                },
                verify=True
            )
            response.raise_for_status()
            
            data = response.json()
            release = ReleaseInfo.from_api_response(data)
            
            if not release:
                logger.error("Failed to parse release info")
                return UpdateStatus.CHECK_FAILED, None
            
            if release.is_newer_than(CURRENT_VERSION):
                logger.info(f"Update available: {CURRENT_VERSION} -> {release.version}")
                return UpdateStatus.UPDATE_AVAILABLE, release
            else:
                logger.info(f"No updates available (current: {CURRENT_VERSION})")
                return UpdateStatus.NO_UPDATE, None
                
        except requests.Timeout as e:
            logger.error(f"Timeout checking for updates: {e}")
            return UpdateStatus.CHECK_FAILED, None
        except requests.ConnectionError as e:
            logger.error(f"Connection error: {e}")
            return UpdateStatus.CHECK_FAILED, None
        except requests.HTTPError as e:
            status_code = e.response.status_code if e.response else 'Unknown'
            logger.error(f"HTTP error: {status_code}")
            return UpdateStatus.CHECK_FAILED, None
        except requests.RequestException as e:
            logger.error(f"Network error checking updates: {e}")
            return UpdateStatus.CHECK_FAILED, None
        except (ValueError, KeyError, TypeError, AttributeError) as e:
            logger.error(f"Parse error: {e}")
            return UpdateStatus.CHECK_FAILED, None
    
    def verify_checksum(self, file_path: str, expected_hash: str) -> bool:
        """Verify SHA-256 hash of file / Проверить SHA-256 хеш файла / Перевірити SHA-256 хеш файлу"""
        if not expected_hash:
            logger.warning("No expected hash provided")
            return False
        
        try:
            sha256 = hashlib.sha256()
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    sha256.update(chunk)
            actual_hash = sha256.hexdigest()
            
            if hmac.compare_digest(actual_hash.lower(), expected_hash.lower()):
                logger.info("Hash verification successful")
                return True
            else:
                logger.error(f"Hash mismatch: expected {expected_hash[:16]}..., got {actual_hash[:16]}...")
                return False
        except (OSError, IOError, ValueError, PermissionError) as e:
            logger.error(f"Hash verification error: {e}")
            return False
    
    def _verify_integrity(self, file_path: str, release: ReleaseInfo) -> bool:
        """Verify downloaded file integrity / Проверить целостность скачанного файла / Перевірити цілісність завантаженого файлу"""
        # Check file size / Проверка размера файла / Перевірка розміру файлу
        try:
            file_size = os.path.getsize(file_path)
            if release.size > 0 and abs(file_size - release.size) > 1024:  # Tolerance 1KB / Допуск 1KB / Допуск 1KB
                logger.error(f"File size mismatch: expected {release.size}, got {file_size}")
                return False
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to get file size: {e}")
            return False
        
        # Check hash / Проверка хеша / Перевірка хеша
        if release.hash_url:
            try:
                response = requests.get(release.hash_url, timeout=15, verify=True)
                response.raise_for_status()
                expected_hash = response.text.strip().split()[0]
                return self.verify_checksum(file_path, expected_hash)
            except (requests.RequestException, OSError, ValueError, IndexError) as e:
                logger.error(f"Hash download failed: {e}")
                return False
        
        logger.warning("No hash available for verification")
        return True
    
    def download_update(self, release: ReleaseInfo) -> Tuple[UpdateStatus, Optional[str]]:
        """Download update and verify signature / Скачать обновление и проверить подпись / Завантажити оновлення та перевірити підпис"""
        if self._update_in_progress:
            logger.warning("Update already in progress")
            return UpdateStatus.DOWNLOAD_FAILED, None
        
        self._update_in_progress = True
        
        try:
            os.makedirs(UPDATES_DIR, exist_ok=True)
            
            exe_path = os.path.join(UPDATES_DIR, f"SecurePassPro_{release.version}.exe")
            
            logger.info(f"Downloading update from {release.download_url}")
            if not self._download_file(release.download_url, exe_path):
                return UpdateStatus.DOWNLOAD_FAILED, None
            
            # Integrity check after download / Проверка целостности после загрузки / Перевірка цілісності після завантаження
            if not self._verify_integrity(exe_path, release):
                try:
                    os.remove(exe_path)
                except (OSError, IOError, PermissionError):
                    pass
                return UpdateStatus.INTEGRITY_FAILED, None
            
            logger.info("Update downloaded and verified successfully")
            return UpdateStatus.SUCCESS, exe_path
            
        except (OSError, IOError, PermissionError, ValueError) as e:
            logger.error(f"Error downloading update: {e}")
            return UpdateStatus.DOWNLOAD_FAILED, None
        finally:
            self._update_in_progress = False
    
    def _download_file(self, url: str, dest_path: str) -> bool:
        """Download file with SSL verification / Скачать файл с проверкой SSL / Завантажити файл з перевіркою SSL"""
        try:
            response = requests.get(url, stream=True, timeout=30, verify=True)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            
            with open(dest_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if self.progress_callback and total_size > 0:
                            progress = downloaded / total_size
                            try:
                                self.progress_callback(progress)
                            except (TypeError, AttributeError):
                                pass
            
            if os.path.getsize(dest_path) == 0:
                raise ValueError("Downloaded file is empty")
            
            return True
        except requests.Timeout as e:
            logger.error(f"Download timeout: {e}")
            return False
        except requests.ConnectionError as e:
            logger.error(f"Download connection error: {e}")
            return False
        except requests.HTTPError as e:
            status_code = e.response.status_code if e.response else 'Unknown'
            logger.error(f"Download HTTP error: {status_code}")
            return False
        except (OSError, IOError, ValueError, PermissionError) as e:
            logger.error(f"Download failed: {e}")
            return False
    
    def install_update(self, update_path: str) -> UpdateStatus:
        """Install update with integrity check before installation
        Установить обновление с проверкой целостности перед установкой
        Встановити оновлення з перевіркою цілісності перед встановленням"""
        try:
            if not os.path.exists(update_path):
                logger.error(f"Update file not found: {update_path}")
                return UpdateStatus.INSTALL_FAILED
            
            if os.path.getsize(update_path) == 0:
                logger.error("Update file is empty")
                return UpdateStatus.INTEGRITY_FAILED
            
            current_exe = sys.executable
            
            if platform.system() == "Windows":
                return self._install_update_windows(update_path, current_exe)
            elif platform.system() == "Darwin":
                return self._install_update_macos(update_path, current_exe)
            else:
                return self._install_update_linux(update_path, current_exe)
                
        except (OSError, IOError, PermissionError, subprocess.SubprocessError) as e:
            logger.error(f"Install update error: {e}")
            return UpdateStatus.INSTALL_FAILED
    
    def _install_update_windows(self, update_path: str, current_exe: str) -> UpdateStatus:
        """Install update on Windows / Установка обновления на Windows / Встановлення оновлення на Windows"""
        try:
            ps_script = os.path.join(UPDATES_DIR, "update.ps1")
            with open(ps_script, 'w', encoding='utf-8') as f:
                f.write(f"""# Secure Pass Pro Updater
Start-Sleep -Seconds 2
try {{
    if (Test-Path "{update_path}") {{
        Copy-Item -Path "{update_path}" -Destination "{current_exe}" -Force
        if ($LASTEXITCODE -eq 0) {{
            Start-Process -FilePath "{current_exe}"
        }}
    }}
}} catch {{
    Write-Error $_.Exception.Message
    Start-Sleep -Seconds 5
}}
Remove-Item -Path $MyInvocation.MyCommand.Path -Force
""")
            
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags = subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            
            subprocess.Popen(
                ["powershell.exe", "-ExecutionPolicy", "Bypass", "-File", ps_script],
                startupinfo=startupinfo
            )
            
            if self.parent:
                try:
                    self.parent.quit()
                except (AttributeError, RuntimeError):
                    pass
            
            return UpdateStatus.SUCCESS
            
        except (OSError, IOError, PermissionError, subprocess.SubprocessError) as e:
            logger.error(f"Windows install error: {e}")
            return UpdateStatus.INSTALL_FAILED
    
    def _install_update_macos(self, update_path: str, current_exe: str) -> UpdateStatus:
        """Install update on macOS / Установка обновления на macOS / Встановлення оновлення на macOS"""
        try:
            script_path = os.path.join(UPDATES_DIR, "update.sh")
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(f"""#!/bin/bash
sleep 2
if [ -f "{update_path}" ]; then
    cp "{update_path}" "{current_exe}"
    chmod +x "{current_exe}"
    open "{current_exe}"
fi
rm "$0"
""")
            
            os.chmod(script_path, 0o755)
            subprocess.Popen(['open', script_path])
            
            if self.parent:
                try:
                    self.parent.quit()
                except (AttributeError, RuntimeError):
                    pass
            
            return UpdateStatus.SUCCESS
            
        except (OSError, IOError, PermissionError, subprocess.SubprocessError) as e:
            logger.error(f"macOS install error: {e}")
            return UpdateStatus.INSTALL_FAILED
    
    def _install_update_linux(self, update_path: str, current_exe: str) -> UpdateStatus:
        """Install update on Linux / Установка обновления на Linux / Встановлення оновлення на Linux"""
        try:
            script_path = os.path.join(UPDATES_DIR, "update.sh")
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(f"""#!/bin/bash
sleep 2
if [ -f "{update_path}" ]; then
    cp "{update_path}" "{current_exe}"
    chmod +x "{current_exe}"
    "{current_exe}" &
fi
rm "$0"
""")
            
            os.chmod(script_path, 0o755)
            subprocess.Popen(['bash', script_path])
            
            if self.parent:
                try:
                    self.parent.quit()
                except (AttributeError, RuntimeError):
                    pass
            
            return UpdateStatus.SUCCESS
            
        except (OSError, IOError, PermissionError, subprocess.SubprocessError) as e:
            logger.error(f"Linux install error: {e}")
            return UpdateStatus.INSTALL_FAILED
    
    def perform_update(self) -> UpdateStatus:
        """Perform full update cycle / Выполнить полный цикл обновления / Виконати повний цикл оновлення"""
        status, release = self.check_for_updates()
        
        if status == UpdateStatus.NO_UPDATE:
            return status
        if status != UpdateStatus.UPDATE_AVAILABLE or not release:
            return UpdateStatus.CHECK_FAILED
        
        try:
            # Lazy import to avoid circular dependency / Ленивый импорт для избежания циклической зависимости / Лінивий імпорт для уникнення циклічної залежності
            from gui.dialogs import CTkMessageBox
            message = f"Доступна новая версия {release.version}!\n\n"
            message += f"Текущая версия: {CURRENT_VERSION}\n"
            message += f"Размер: {release.size // 1024 // 1024} MB\n\n"
            message += "Установить обновление?"
            
            if not CTkMessageBox.question(self.parent, "Доступно обновление", message):
                return UpdateStatus.NO_UPDATE
        except ImportError:
            # If GUI not available, just continue / Если GUI не доступен, просто продолжаем / Якщо GUI не доступний, просто продовжуємо
            pass
        except (AttributeError, TypeError, RuntimeError) as e:
            logger.debug(f"Message box error: {e}")
            pass
        
        status, update_path = self.download_update(release)
        if status != UpdateStatus.SUCCESS or not update_path:
            return status
        
        return self.install_update(update_path)


# ==================== CONVENIENCE FUNCTIONS / УДОБНЫЕ ФУНКЦИИ / ЗРУЧНІ ФУНКЦІЇ ====================

def check_for_updates(parent=None) -> Optional[ReleaseInfo]:
    """Check for updates (simplified call) / Проверить наличие обновлений (упрощённый вызов) / Перевірити наявність оновлень (спрощений виклик)"""
    updater = SecureUpdater(parent)
    status, release = updater.check_for_updates()
    return release if status == UpdateStatus.UPDATE_AVAILABLE else None


def perform_update(parent=None) -> bool:
    """Perform update / Выполнить обновление / Виконати оновлення"""
    updater = SecureUpdater(parent)
    status = updater.perform_update()
    return status == UpdateStatus.SUCCESS


def verify_installation() -> bool:
    """Verify installation integrity / Проверить целостность установки / Перевірити цілісність встановлення"""
    return True


def get_current_version() -> str:
    """Get current version / Получить текущую версию / Отримати поточну версію"""
    return CURRENT_VERSION


def _get_resources_dir() -> str:
    """Get resources folder path / Получить путь к папке ресурсов / Отримати шлях до папки ресурсів"""
    return os.path.join(get_base_dir(), "resources")


def _get_public_key_path() -> str:
    """Get public key file path / Получить путь к файлу публичного ключа / Отримати шлях до файлу публічного ключа"""
    return os.path.join(_get_resources_dir(), "public_key.pem")


# ==================== INITIALIZATION / ИНИЦИАЛИЗАЦИЯ / ІНІЦІАЛІЗАЦІЯ ====================
logger.info(f"Updater module loaded (version {CURRENT_VERSION})")