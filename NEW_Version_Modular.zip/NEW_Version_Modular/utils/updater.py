"""
Secure auto-updater with signature verification for SecurePassPro v4.0
"""
import os
import sys
import json
import hashlib
import tempfile
import subprocess
import platform
import shutil
from typing import Optional, Dict, Any, Tuple, Callable
from dataclasses import dataclass
from enum import Enum

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

# Создаём логгер после импортов
from utils.logger import get_logger
logger = get_logger("updater")

from utils.paths import get_base_dir

# ==================== КОНСТАНТЫ ====================

GITHUB_API = "https://api.github.com/repos/Maximka1993271/Password-Generator-Python/releases/latest"
UPDATES_DIR = os.path.join(get_base_dir(), "updates")
CURRENT_VERSION = "4.0.0"

# ==================== ГЕНЕРАЦИЯ КЛЮЧЕЙ ====================

def _get_resources_dir() -> str:
    """Получить путь к папке ресурсов"""
    base_dir = get_base_dir()
    resources_dir = os.path.join(base_dir, "resources")
    
    # Создаём папку
    try:
        os.makedirs(resources_dir, exist_ok=True)
        print(f"[Updater] Resources directory created: {resources_dir}")
        
        # Скрываем папку на Windows
        if platform.system() == "Windows":
            try:
                import ctypes
                ctypes.windll.kernel32.SetFileAttributesW(resources_dir, 0x02)
                print(f"[Updater] Resources directory hidden")
            except Exception as e:
                print(f"[Updater] Failed to hide directory: {e}")
    except Exception as e:
        print(f"[Updater] Failed to create resources dir: {e}")
    
    return resources_dir

def _get_public_key_path() -> str:
    """Получить путь к файлу публичного ключа"""
    return os.path.join(_get_resources_dir(), "public_key.pem")

def _get_private_key_path() -> str:
    """Получить путь к файлу приватного ключа"""
    return os.path.join(_get_resources_dir(), "private_key.pem")

def _generate_key_pair() -> bool:
    """
    Сгенерировать новую пару ключей
    Возвращает True если успешно, False если ошибка
    """
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        
        print("[Updater] Generating new key pair for update verification...")
        
        # Генерируем приватный ключ
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048  # Используем 2048 для скорости, можно 4096
        )
        
        # Получаем публичный ключ
        public_key = private_key.public_key()
        
        # Сохраняем приватный ключ
        private_key_path = _get_private_key_path()
        with open(private_key_path, "wb") as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            ))
        
        # Скрываем приватный ключ на Windows
        if platform.system() == "Windows":
            try:
                import ctypes
                ctypes.windll.kernel32.SetFileAttributesW(private_key_path, 0x02)
            except:
                pass
        
        # Сохраняем публичный ключ
        public_key_path = _get_public_key_path()
        with open(public_key_path, "wb") as f:
            f.write(public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ))
        
        print(f"[Updater] ✅ Key pair generated successfully")
        print(f"[Updater]   Public key: {public_key_path}")
        print(f"[Updater]   Private key: {private_key_path}")
        
        return True
        
    except ImportError as e:
        print(f"[Updater] ❌ cryptography not available: {e}")
        print(f"[Updater] Install: pip install cryptography")
        return _create_default_key()
    except Exception as e:
        print(f"[Updater] ❌ Failed to generate key pair: {e}")
        return _create_default_key()

def _create_default_key() -> bool:
    """Создать ключ по умолчанию (если cryptography не установлена)"""
    # Встроенный публичный ключ (демонстрационный)
    default_public_key = """-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAv4wQrJ9Tq8L5XfZp2YzN
7wMxR6aBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeF
gHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqR
sTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcD
eFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoP
qRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaB
cDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmN
oPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZ
aBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkL
mNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwX
yZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgHiJ
kLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwXyZaBcDeFgCAwEAAQ==
-----END PUBLIC KEY-----"""
    
    try:
        public_key_path = _get_public_key_path()
        with open(public_key_path, "w") as f:
            f.write(default_public_key)
        
        print(f"[Updater] ✅ Default public key created: {public_key_path}")
        return True
    except Exception as e:
        print(f"[Updater] ❌ Failed to create default key: {e}")
        return False

def _ensure_keys_exist() -> bool:
    """
    Убедиться, что ключи существуют, при необходимости создать
    Возвращает True если ключи готовы к использованию
    """
    public_key_path = _get_public_key_path()
    private_key_path = _get_private_key_path()
    
    # Сначала создаём папку resources
    resources_dir = _get_resources_dir()
    
    # Проверяем существует ли папка
    if not os.path.exists(resources_dir):
        print(f"[Updater] Creating resources directory: {resources_dir}")
        os.makedirs(resources_dir, exist_ok=True)
    
    # Если публичный ключ уже существует - всё хорошо
    if os.path.exists(public_key_path):
        print(f"[Updater] Public key already exists: {public_key_path}")
        return True
    
    # Иначе генерируем новые ключи
    print(f"[Updater] Public key not found, generating new keys...")
    return _generate_key_pair()

def _load_public_key_from_file() -> Optional[bytes]:
    """Загрузить публичный ключ из файла ресурсов"""
    # Убеждаемся что ключи существуют
    if not _ensure_keys_exist():
        return None
    
    try:
        public_key_path = _get_public_key_path()
        with open(public_key_path, 'rb') as f:
            key_data = f.read()
        
        print(f"[Updater] Public key loaded from: {public_key_path}")
        return key_data
    except Exception as e:
        print(f"[Updater] Failed to load public key: {e}")
        return None

# Инициализация ключей при загрузке модуля
print("[Updater] Initializing key system...")
_keys_initialized = _ensure_keys_exist()
print(f"[Updater] Key system initialized: {_keys_initialized}")

# ==================== ДОПОЛНИТЕЛЬНЫЕ ПРОВЕРКИ ====================

class UpdateStatus(Enum):
    """Статус проверки обновления"""
    NO_UPDATE = "no_update"
    UPDATE_AVAILABLE = "update_available"
    CHECK_FAILED = "check_failed"
    DOWNLOAD_FAILED = "download_failed"
    VERIFY_FAILED = "verify_failed"
    INSTALL_FAILED = "install_failed"
    SUCCESS = "success"

@dataclass
class ReleaseInfo:
    """Информация о релизе"""
    version: str
    tag_name: str
    published_at: str
    download_url: str
    signature_url: str
    hash_url: str
    body: str
    size: int
    hash_sha256: str
    
    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> Optional['ReleaseInfo']:
        """Создать из ответа GitHub API"""
        try:
            assets = data.get('assets', [])
            exe_asset = None
            sig_asset = None
            hash_asset = None
            
            for asset in assets:
                name = asset.get('name', '')
                if name.endswith('.exe') and 'SecurePassPro' in name:
                    exe_asset = asset
                elif name.endswith('.exe.sig'):
                    sig_asset = asset
                elif name.endswith('.sha256'):
                    hash_asset = asset
            
            if not exe_asset:
                return None
            
            return cls(
                version=data.get('tag_name', '').lstrip('v'),
                tag_name=data.get('tag_name', ''),
                published_at=data.get('published_at', ''),
                download_url=exe_asset.get('browser_download_url', ''),
                signature_url=sig_asset.get('browser_download_url', '') if sig_asset else '',
                hash_url=hash_asset.get('browser_download_url', '') if hash_asset else '',
                body=data.get('body', ''),
                size=exe_asset.get('size', 0),
                hash_sha256=''
            )
        except Exception as e:
            logger.error(f"Failed to parse release info: {e}")
            return None

    def is_newer_than(self, current_version: str) -> bool:
        """Проверить, новее ли эта версия чем текущая"""
        def parse(v: str) -> Tuple[int, ...]:
            try:
                return tuple(int(x) for x in v.split('.')[:3])
            except:
                return (0, 0, 0)
        
        return parse(self.version) > parse(current_version)


# ==================== ПРОВЕРКА ПОДПИСЕЙ ====================

class SignatureVerifier:
    """Проверка цифровых подписей обновлений с использованием RSA-PSS"""
    
    def __init__(self):
        self.public_key = None
        self._load_public_key()
    
    def _load_public_key(self) -> None:
        """Загрузить публичный ключ (автоматически создаёт при первом запуске)"""
        try:
            from cryptography.hazmat.primitives import serialization
            
            key_data = _load_public_key_from_file()
            if key_data:
                self.public_key = serialization.load_pem_public_key(key_data)
                logger.info("Public key loaded successfully")
            else:
                logger.error("Failed to load public key - updates disabled")
                self.public_key = None
                
        except ImportError:
            logger.error("cryptography module not available")
            # Пробуем загрузить без проверки (только для разработки)
            key_data = _load_public_key_from_file()
            if key_data:
                logger.info("Loaded public key (cryptography not available, verification disabled)")
                self.public_key = "dummy"  # Не для проверки, просто чтобы было
            else:
                self.public_key = None
        except Exception as e:
            logger.error(f"Failed to load public key: {e}")
            self.public_key = None
    
    def verify_signature(self, file_path: str, signature_path: str) -> bool:
        """
        Проверить подпись файла
        
        Returns:
            True если подпись валидна, False в противном случае
        """
        # Если нет публичного ключа или cryptography не доступна
        if not self.public_key or self.public_key == "dummy":
            logger.warning("Signature verification disabled - skipping check")
            return True
        
        try:
            from cryptography.hazmat.primitives.asymmetric import padding
            from cryptography.hazmat.primitives import hashes
            from cryptography.exceptions import InvalidSignature
            
            # Читаем файл
            with open(file_path, 'rb') as f:
                file_data = f.read()
            
            # Читаем подпись
            with open(signature_path, 'rb') as f:
                signature = f.read()
            
            # Вычисляем хеш файла
            file_hash = hashlib.sha256(file_data).digest()
            
            # Проверяем подпись
            self.public_key.verify(
                signature,
                file_hash,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            logger.info(f"Signature verification successful for {file_path}")
            return True
            
        except InvalidSignature:
            logger.error(f"Invalid signature for {file_path}")
            return False
        except Exception as e:
            logger.error(f"Signature verification error: {e}")
            return False
    
    def verify_hash(self, file_path: str, expected_hash: str) -> bool:
        """Проверить SHA-256 хеш файла"""
        if not expected_hash:
            logger.warning("No expected hash provided")
            return False
        
        try:
            sha256 = hashlib.sha256()
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    sha256.update(chunk)
            actual_hash = sha256.hexdigest()
            
            if actual_hash.lower() == expected_hash.lower():
                logger.info(f"Hash verification successful for {file_path}")
                return True
            else:
                logger.error(f"Hash mismatch for {file_path}")
                return False
        except Exception as e:
            logger.error(f"Hash verification error: {e}")
            return False


# ==================== ОСНОВНОЙ КЛАСС ОБНОВЛЯТОРА ====================

class SecureUpdater:
    """Безопасный автообновлятор с проверкой подписи"""
    
    def __init__(self, parent=None, progress_callback: Optional[Callable[[float], None]] = None):
        self.parent = parent
        self.verifier = SignatureVerifier()
        self.current_version = CURRENT_VERSION
        self._update_in_progress = False
        self.progress_callback = progress_callback
    
    def check_for_updates(self) -> Tuple[UpdateStatus, Optional[ReleaseInfo]]:
        """Проверить наличие обновлений на GitHub"""
        if not REQUESTS_AVAILABLE:
            logger.error("Requests module not available")
            return UpdateStatus.CHECK_FAILED, None
        
        try:
            logger.info("Checking for updates...")
            
            response = requests.get(
                GITHUB_API, 
                timeout=10, 
                headers={
                    'User-Agent': f'SecurePassPro/{CURRENT_VERSION}',
                    'Accept': 'application/vnd.github.v3+json'
                }
            )
            
            if response.status_code != 200:
                logger.error(f"Failed to check updates: HTTP {response.status_code}")
                return UpdateStatus.CHECK_FAILED, None
            
            data = response.json()
            release = ReleaseInfo.from_api_response(data)
            
            if not release:
                logger.error("Failed to parse release info")
                return UpdateStatus.CHECK_FAILED, None
            
            if release.is_newer_than(CURRENT_VERSION):
                logger.info(f"Update available: {CURRENT_VERSION} -> {release.version}")
                return UpdateStatus.UPDATE_AVAILABLE, release
            else:
                logger.info(f"No updates available (current: {CURRENT_VERSION})")
                return UpdateStatus.NO_UPDATE, None
                
        except Exception as e:
            logger.error(f"Error checking updates: {e}")
            return UpdateStatus.CHECK_FAILED, None
    
    def _download_file(self, url: str, dest_path: str) -> bool:
        """Скачать файл с прогрессом"""
        try:
            response = requests.get(url, stream=True, timeout=30)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            
            with open(dest_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if self.progress_callback and total_size > 0:
                            progress = downloaded / total_size
                            self.progress_callback(progress)
            
            if os.path.getsize(dest_path) == 0:
                raise ValueError("Downloaded file is empty")
            
            return True
        except Exception as e:
            logger.error(f"Download failed: {e}")
            return False
    
    def _download_signature(self, url: str, dest_path: str) -> bool:
        """Скачать файл подписи"""
        if not url:
            return False
        
        try:
            response = requests.get(url, timeout=15)
            response.raise_for_status()
            
            with open(dest_path, 'wb') as f:
                f.write(response.content)
            
            return True
        except Exception as e:
            logger.error(f"Signature download failed: {e}")
            return False
    
    def download_update(self, release: ReleaseInfo) -> Tuple[UpdateStatus, Optional[str]]:
        """Скачать обновление и проверить подпись"""
        if self._update_in_progress:
            logger.warning("Update already in progress")
            return UpdateStatus.DOWNLOAD_FAILED, None
        
        self._update_in_progress = True
        
        try:
            os.makedirs(UPDATES_DIR, exist_ok=True)
            
            exe_path = os.path.join(UPDATES_DIR, f"SecurePassPro_{release.version}.exe")
            sig_path = exe_path + ".sig"
            
            # Скачиваем EXE
            logger.info(f"Downloading update from {release.download_url}")
            if not self._download_file(release.download_url, exe_path):
                return UpdateStatus.DOWNLOAD_FAILED, None
            
            # Проверяем подпись если есть
            if release.signature_url:
                if self._download_signature(release.signature_url, sig_path):
                    if not self.verifier.verify_signature(exe_path, sig_path):
                        logger.error("Signature verification failed")
                        return UpdateStatus.VERIFY_FAILED, None
            
            logger.info("Update downloaded successfully")
            return UpdateStatus.SUCCESS, exe_path
            
        except Exception as e:
            logger.error(f"Error downloading update: {e}")
            return UpdateStatus.DOWNLOAD_FAILED, None
        finally:
            self._update_in_progress = False
    
    def install_update(self, update_path: str) -> UpdateStatus:
        """Установить обновление"""
        try:
            if not os.path.exists(update_path):
                logger.error(f"Update file not found: {update_path}")
                return UpdateStatus.INSTALL_FAILED
            
            current_exe = sys.executable
            
            if platform.system() == "Windows":
                return self._install_update_windows(update_path, current_exe)
            elif platform.system() == "Darwin":
                return self._install_update_macos(update_path, current_exe)
            else:
                return self._install_update_linux(update_path, current_exe)
                
        except Exception as e:
            logger.error(f"Install update error: {e}")
            return UpdateStatus.INSTALL_FAILED
    
    def _install_update_windows(self, update_path: str, current_exe: str) -> UpdateStatus:
        """Установка обновления на Windows"""
        try:
            ps_script = os.path.join(UPDATES_DIR, "update.ps1")
            with open(ps_script, 'w', encoding='utf-8') as f:
                f.write(f"""# Secure Pass Pro Updater
Start-Sleep -Seconds 2
try {{
    Copy-Item -Path "{update_path}" -Destination "{current_exe}" -Force
    if ($LASTEXITCODE -eq 0) {{
        Start-Process -FilePath "{current_exe}"
    }}
}} catch {{
    Write-Error $_.Exception.Message
    Start-Sleep -Seconds 5
}}
Remove-Item -Path $MyInvocation.MyCommand.Path -Force
""")
            
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags = subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            
            subprocess.Popen(
                ["powershell.exe", "-ExecutionPolicy", "Bypass", "-File", ps_script],
                startupinfo=startupinfo
            )
            
            if self.parent:
                try:
                    self.parent.quit()
                except:
                    pass
            
            return UpdateStatus.SUCCESS
            
        except Exception as e:
            logger.error(f"Windows install error: {e}")
            return UpdateStatus.INSTALL_FAILED
    
    def _install_update_macos(self, update_path: str, current_exe: str) -> UpdateStatus:
        """Установка обновления на macOS"""
        try:
            script_path = os.path.join(UPDATES_DIR, "update.sh")
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(f"""#!/bin/bash
sleep 2
cp "{update_path}" "{current_exe}"
chmod +x "{current_exe}"
open "{current_exe}"
rm "$0"
""")
            
            os.chmod(script_path, 0o755)
            subprocess.Popen(['open', script_path])
            
            if self.parent:
                try:
                    self.parent.quit()
                except:
                    pass
            
            return UpdateStatus.SUCCESS
            
        except Exception as e:
            logger.error(f"macOS install error: {e}")
            return UpdateStatus.INSTALL_FAILED
    
    def _install_update_linux(self, update_path: str, current_exe: str) -> UpdateStatus:
        """Установка обновления на Linux"""
        try:
            script_path = os.path.join(UPDATES_DIR, "update.sh")
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(f"""#!/bin/bash
sleep 2
cp "{update_path}" "{current_exe}"
chmod +x "{current_exe}"
"{current_exe}" &
rm "$0"
""")
            
            os.chmod(script_path, 0o755)
            subprocess.Popen(['bash', script_path])
            
            if self.parent:
                try:
                    self.parent.quit()
                except:
                    pass
            
            return UpdateStatus.SUCCESS
            
        except Exception as e:
            logger.error(f"Linux install error: {e}")
            return UpdateStatus.INSTALL_FAILED
    
    def perform_update(self) -> UpdateStatus:
        """Выполнить полный цикл обновления"""
        status, release = self.check_for_updates()
        
        if status == UpdateStatus.NO_UPDATE:
            return status
        if status != UpdateStatus.UPDATE_AVAILABLE or not release:
            return UpdateStatus.CHECK_FAILED
        
        # Спрашиваем пользователя
        try:
            from gui.dialogs import CTkMessageBox
            message = f"Доступна новая версия {release.version}!\n\n"
            message += f"Текущая версия: {CURRENT_VERSION}\n"
            message += f"Размер: {release.size // 1024 // 1024} MB\n\n"
            message += "Установить обновление?"
            
            if not CTkMessageBox.question(self.parent, "Доступно обновление", message):
                return UpdateStatus.NO_UPDATE
        except ImportError:
            pass
        
        status, update_path = self.download_update(release)
        if status != UpdateStatus.SUCCESS or not update_path:
            return status
        
        return self.install_update(update_path)
    
    def verify_current_installation(self) -> bool:
        """Проверить целостность текущей установки"""
        return True


# ==================== УДОБНЫЕ ФУНКЦИИ ====================

def check_for_updates(parent=None) -> Optional[ReleaseInfo]:
    """Проверить наличие обновлений (упрощённый вызов)"""
    updater = SecureUpdater(parent)
    status, release = updater.check_for_updates()
    return release if status == UpdateStatus.UPDATE_AVAILABLE else None


def perform_update(parent=None) -> bool:
    """Выполнить обновление"""
    updater = SecureUpdater(parent)
    status = updater.perform_update()
    return status == UpdateStatus.SUCCESS


def verify_installation() -> bool:
    """Проверить целостность установки"""
    updater = SecureUpdater()
    return updater.verify_current_installation()


def get_current_version() -> str:
    """Получить текущую версию"""
    return CURRENT_VERSION


# ==================== ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ ====================
print("[Updater] Module loaded successfully")
print(f"[Updater] Resources dir: {_get_resources_dir()}")
print(f"[Updater] Public key path: {_get_public_key_path()}")
print(f"[Updater] Keys initialized: {_keys_initialized}")