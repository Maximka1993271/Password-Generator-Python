"""
Program integrity checker for SecurePassPro
Performs integrity verification at startup and runtime

Проверка целостности программы для SecurePassPro
Выполняет проверку целостности при запуске и во время работы

Перевірка цілісності програми для SecurePassPro
Виконує перевірку цілісності при запуску та під час роботи
"""
import os
import sys
import hashlib
import json
import platform
from typing import Dict, List, Tuple, Optional
from datetime import datetime
from utils.logger import get_logger
from utils.paths import get_base_dir, get_config_dir

logger = get_logger("integrity_check")

# Integrity file with hashes / Файл с хешами для проверки / Файл з хешами для перевірки
INTEGRITY_FILE = os.path.join(get_base_dir(), "integrity.json")
BACKUP_INTEGRITY_FILE = os.path.join(get_config_dir(), "integrity_backup.json")

# Critical files to check (relative to project root)
# Критические файлы для проверки (относительно корня проекта)
# Критичні файли для перевірки (відносно кореня проекту)
CRITICAL_FILES = [
    ("main.py", True),  # File that must exist / Файл, обязательно должен существовать / Файл, обов'язково повинен існувати
    ("__main__.py", False),  # Optional / Опционально / Опціонально
    ("core/generator.py", True),
    ("core/__init__.py", True),
    ("security/master.py", True),
    ("security/encryption.py", True),
    ("security/__init__.py", True),
    ("storage/database.py", True),
    ("storage/config.py", True),
    ("gui/main_window.py", True),
    ("gui/__init__.py", True),
    ("utils/secure_memory.py", True),
    ("utils/logger.py", True),
    ("utils/paths.py", True),
]


class IntegrityChecker:
    """Program file integrity checker
    Проверка целостности файлов программы
    Перевірка цілісності файлів програми"""

    _instance = None
    _hashes: Dict[str, str] = {}
    _verified = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @classmethod
    def _get_file_hash(cls, file_path: str) -> Optional[str]:
        """Calculate SHA-256 hash of a file
        Вычисляет SHA-256 хеш файла
        Обчислює SHA-256 хеш файлу"""
        if not os.path.exists(file_path):
            return None

        try:
            sha256 = hashlib.sha256()
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    sha256.update(chunk)
            return sha256.hexdigest()
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to hash {file_path}: {e}")
            return None
        except (ValueError, TypeError) as e:
            logger.error(f"Hash computation error for {file_path}: {e}")
            return None

    @classmethod
    def _get_absolute_path(cls, rel_path: str) -> str:
        """Get absolute path relative to project root
        Получает абсолютный путь относительно корня проекта
        Отримує абсолютний шлях відносно кореня проекту"""
        base_dir = get_base_dir()
        return os.path.join(base_dir, rel_path.replace('/', os.sep))

    @classmethod
    def generate_integrity_file(cls) -> bool:
        """Generate file with hashes of all critical files
        Генерирует файл с хешами всех критических файлов
        Генерує файл з хешами всіх критичних файлів"""
        hashes = {}

        for file_path, required in CRITICAL_FILES:
            abs_path = cls._get_absolute_path(file_path)
            file_hash = cls._get_file_hash(abs_path)

            if file_hash:
                hashes[file_path] = file_hash
                logger.debug(f"Hash for {file_path}: {file_hash[:16]}...")
            elif required:
                logger.error(f"Required file not found: {file_path}")
                return False

        try:
            integrity_data = {
                "generated": datetime.now().isoformat(),
                "platform": platform.platform(),
                "python_version": sys.version,
                "files": hashes
            }

            with open(INTEGRITY_FILE, 'w', encoding='utf-8') as f:
                json.dump(integrity_data, f, indent=2, ensure_ascii=False)

            # Create backup / Создаём резервную копию / Створюємо резервну копію
            with open(BACKUP_INTEGRITY_FILE, 'w', encoding='utf-8') as f:
                json.dump(integrity_data, f, indent=2, ensure_ascii=False)

            logger.info(f"Integrity file generated: {INTEGRITY_FILE}")
            return True

        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to generate integrity file: {e}")
            return False
        except TypeError as e:
            logger.error(f"JSON serialization error: {e}")
            return False

    @classmethod
    def _load_integrity_data(cls) -> Optional[Dict]:
        """Load integrity data from file / Загружает данные целостности из файла / Завантажує дані цілісності з файлу"""
        # Try main file / Пробуем основной файл / Пробуємо основний файл
        if os.path.exists(INTEGRITY_FILE):
            try:
                with open(INTEGRITY_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError as e:
                logger.warning(f"Failed to parse integrity file: {e}")
            except (OSError, IOError, PermissionError) as e:
                logger.warning(f"Failed to load integrity file: {e}")

        # Try backup file / Пробуем резервный файл / Пробуємо резервний файл
        if os.path.exists(BACKUP_INTEGRITY_FILE):
            try:
                with open(BACKUP_INTEGRITY_FILE, 'r', encoding='utf-8') as f:
                    logger.info("Using backup integrity file")
                    return json.load(f)
            except json.JSONDecodeError as e:
                logger.warning(f"Failed to parse backup integrity file: {e}")
            except (OSError, IOError, PermissionError) as e:
                logger.warning(f"Failed to load backup integrity file: {e}")

        return None

    @classmethod
    def verify_integrity(cls, auto_repair: bool = True) -> Tuple[bool, List[str]]:
        """
        Verify program integrity.
        
        Проверяет целостность программы.
        Перевіряє цілісність програми.
        
        Args:
            auto_repair: Automatically regenerate integrity file
                         Автоматически перегенерировать файл целостности
                         Автоматично перегенерувати файл цілісності

        Returns:
            (is_valid, list_of_errors) - status and list of errors
            (is_valid, list_of_errors) - статус и список ошибок
            (is_valid, list_of_errors) - статус та список помилок
        """
        errors = []

        # Load saved hashes / Загружаем сохранённые хеши / Завантажуємо збережені хеші
        integrity_data = cls._load_integrity_data()

        if not integrity_data:
            if auto_repair:
                logger.warning("Integrity file missing, generating...")
                if cls.generate_integrity_file():
                    integrity_data = cls._load_integrity_data()
                else:
                    errors.append("Failed to generate integrity file")
                    return False, errors
            else:
                errors.append("Integrity file not found")
                return False, errors

        saved_hashes = integrity_data.get("files", {})
        if not isinstance(saved_hashes, dict):
            errors.append("Invalid integrity file format")
            return False, errors

        # Check each file / Проверяем каждый файл / Перевіряємо кожен файл
        for file_path, required in CRITICAL_FILES:
            abs_path = cls._get_absolute_path(file_path)
            current_hash = cls._get_file_hash(abs_path)
            expected_hash = saved_hashes.get(file_path)

            if current_hash is None:
                if required:
                    errors.append(f"Missing required file: {file_path}")
                continue

            if expected_hash is None:
                errors.append(f"New file not in integrity database: {file_path}")
                continue

            if current_hash != expected_hash:
                errors.append(f"File modified: {file_path}")
                logger.warning(f"Hash mismatch for {file_path}")

        if errors:
            logger.warning(f"Integrity check failed with {len(errors)} errors")
            for error in errors[:5]:  # Log first 5 errors / Логируем первые 5 ошибок / Логуємо перші 5 помилок
                logger.debug(f"  - {error}")
        else:
            logger.info("Integrity check passed")
            cls._verified = True

        return len(errors) == 0, errors

    @classmethod
    def is_verified(cls) -> bool:
        """Return status of last check / Возвращает статус последней проверки / Повертає статус останньої перевірки"""
        return cls._verified

    @classmethod
    def get_file_status(cls) -> Dict[str, Dict]:
        """
        Get status of each file.
        Returns a dictionary with information about each file.
        
        Получает статус каждого файла.
        Возвращает словарь с информацией о каждом файле.
        
        Отримує статус кожного файлу.
        Повертає словник з інформацією про кожен файл.
        """
        status = {}

        integrity_data = cls._load_integrity_data()
        saved_hashes = integrity_data.get("files", {}) if integrity_data and isinstance(integrity_data, dict) else {}

        for file_path, required in CRITICAL_FILES:
            abs_path = cls._get_absolute_path(file_path)
            current_hash = cls._get_file_hash(abs_path)
            expected_hash = saved_hashes.get(file_path)

            status[file_path] = {
                "exists": current_hash is not None,
                "required": required,
                "modified": current_hash is not None and expected_hash is not None and current_hash != expected_hash,
                "in_database": expected_hash is not None
            }

        return status

    @classmethod
    def update_integrity(cls) -> bool:
        """Update integrity file (after program update)
        Обновляет файл целостности (после обновления программы)
        Оновлює файл цілісності (після оновлення програми)"""
        logger.info("Updating integrity database...")
        return cls.generate_integrity_file()


def verify_program_integrity() -> bool:
    """
    Quick program integrity check.
    Returns True if check passed.
    
    Быстрая проверка целостности программы.
    Возвращает True если проверка пройдена.
    
    Швидка перевірка цілісності програми.
    Повертає True якщо перевірку пройдено.
    """
    is_valid, errors = IntegrityChecker.verify_integrity(auto_repair=True)

    if not is_valid:
        logger.error(f"Program integrity check failed with {len(errors)} errors")
        for error in errors[:3]:
            logger.error(f"  - {error}")

    return is_valid


def get_integrity_status() -> Dict:
    """
    Get detailed integrity status.
    Used for display in UI.
    
    Получает детальный статус целостности.
    Используется для отображения в UI.
    
    Отримує детальний статус цілісності.
    Використовується для відображення в UI.
    """
    is_valid, errors = IntegrityChecker.verify_integrity(auto_repair=False)

    return {
        "is_valid": is_valid,
        "errors": errors,
        "file_status": IntegrityChecker.get_file_status(),
        "last_verified": IntegrityChecker.is_verified()
    }


def repair_integrity() -> bool:
    """Attempt to repair integrity (regenerate file)
    Пытается восстановить целостность (перегенерирует файл)
    Намагається відновити цілісність (перегенерує файл)"""
    logger.info("Attempting to repair integrity...")
    return IntegrityChecker.generate_integrity_file()


def init_integrity_check() -> None:
    """Initialize integrity check (at startup)
    Инициализация проверки целостности (при запуске)
    Ініціалізація перевірки цілісності (при запуску)"""
    if not os.path.exists(INTEGRITY_FILE):
        logger.info("First run - generating integrity file")
        IntegrityChecker.generate_integrity_file()
    else:
        # Background check (non-critical) / Фоновая проверка (не критично) / Фонова перевірка (не критично)
        try:
            is_valid, errors = IntegrityChecker.verify_integrity(auto_repair=False)
            if not is_valid:
                logger.warning("Integrity check found issues")
        except (OSError, IOError, json.JSONDecodeError) as e:
            logger.debug(f"Background integrity check failed: {e}")


__all__ = [
    'IntegrityChecker',
    'verify_program_integrity',
    'get_integrity_status',
    'repair_integrity',
    'init_integrity_check'
]