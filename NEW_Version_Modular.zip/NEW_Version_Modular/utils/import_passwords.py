"""
Password import utilities for CSV, JSON, KeePass XML, Bitwarden, 1Password, 1PUX
FIXED: Added CSV sanitization, malformed row recovery, duplicate detection, encoding fallback

Утилиты импорта паролей из CSV, JSON, KeePass XML, Bitwarden, 1Password, 1PUX
FIXED: Добавлены CSV sanitization, malformed row recovery, duplicate detection, encoding fallback

Утиліти імпорту паролів з CSV, JSON, KeePass XML, Bitwarden, 1Password, 1PUX
FIXED: Додано CSV sanitization, malformed row recovery, duplicate detection, encoding fallback
"""
import json
import csv
import xml.etree.ElementTree as ET
import os
import datetime
import zipfile
import tempfile
import shutil
import re
import hashlib
from typing import List, Dict, Any, Optional, Tuple, Set
from tkinter import filedialog
from utils.logger import get_logger

logger = get_logger("import_passwords")

# Maximum import file size (50 MB) / Максимальный размер файла для импорта (50 MB) / Максимальний розмір файлу для імпорту (50 MB)
MAX_FILE_SIZE = 50 * 1024 * 1024

# Allowed characters for passwords (for sanitization)
# Допустимые символы для паролей (для санитизации)
# Допустимі символи для паролів (для санітизації)
SAFE_PASSWORD_CHARS = re.compile(r'[^\x20-\x7E\u0400-\u04FF\u00A0-\u00FF]')

# Maximum password length / Максимальная длина пароля / Максимальна довжина пароля
MAX_PASSWORD_LENGTH = 1000

# Maximum label length / Максимальная длина метки / Максимальна довжина мітки
MAX_LABEL_LENGTH = 200

# CSV delimiter detection sample size / Размер выборки для определения разделителя CSV / Розмір вибірки для визначення розділювача CSV
CSV_SAMPLE_SIZE = 4096


class ImportError(Exception):
    """Exception for import errors / Исключение для ошибок импорта / Виняток для помилок імпорту"""
    pass


class InvalidFileFormatError(ImportError):
    """Exception for invalid file format / Исключение для неверного формата файла / Виняток для невірного формату файлу"""
    pass


class MalformedFileError(ImportError):
    """Exception for corrupted file / Исключение для повреждённого файла / Виняток для пошкодженого файлу"""
    pass


class FileTooLargeError(ImportError):
    """Exception for file too large / Исключение для слишком большого файла / Виняток для надто великого файлу"""
    pass


class UnsupportedEncodingError(ImportError):
    """Exception for unsupported encoding / Исключение для неподдерживаемой кодировки / Виняток для непідтримуваного кодування"""
    pass


def sanitize_csv_value(value: str, max_length: int = MAX_LABEL_LENGTH) -> str:
    """
    Sanitize CSV value from dangerous characters.
    
    Очищает значение из CSV от опасных символов.
    Очищує значення з CSV від небезпечних символів.
    
    Args:
        value: Original value / Исходное значение / Вихідне значення
        max_length: Maximum length / Максимальная длина / Максимальна довжина
    
    Returns:
        Sanitized value / Очищенное значение / Очищене значення
    """
    if not value:
        return ""
    
    # Convert to string if not already / Конвертируем в строку если не строка / Конвертуємо в рядок якщо не рядок
    value_str = str(value)
    
    # Remove non-printable characters (except spaces, tabs, newlines)
    # Удаляем непечатаемые символы (кроме пробелов, табуляции, перевода строки)
    # Видаляємо недруковані символи (крім пробілів, табуляції, переводу рядка)
    sanitized = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', value_str)
    
    # Remove Unicode control characters / Удаляем управляющие символы Unicode / Видаляємо керуючі символи Unicode
    sanitized = re.sub(r'[\u200B-\u200D\uFEFF]', '', sanitized)
    
    # Limit length / Ограничиваем длину / Обмежуємо довжину
    if len(sanitized) > max_length:
        sanitized = sanitized[:max_length]
    
    return sanitized.strip()


def sanitize_password(password: str, max_length: int = MAX_PASSWORD_LENGTH) -> str:
    """
    Sanitize password, preserving allowed characters.
    
    Очищает пароль, сохраняя допустимые символы.
    Очищує пароль, зберігаючи допустимі символи.
    
    Args:
        password: Original password / Исходный пароль / Вихідний пароль
        max_length: Maximum length / Максимальная длина / Максимальна довжина
    
    Returns:
        Sanitized password / Очищенный пароль / Очищений пароль
    """
    if not password:
        return ""
    
    # Convert to string / Конвертируем в строку / Конвертуємо в рядок
    password_str = str(password)
    
    # Remove dangerous characters / Удаляем опасные символы / Видаляємо небезпечні символи
    sanitized = SAFE_PASSWORD_CHARS.sub('', password_str)
    
    # Remove control characters / Удаляем управляющие символы / Видаляємо керуючі символи
    sanitized = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', sanitized)
    
    # Limit length / Ограничиваем длину / Обмежуємо довжину
    if len(sanitized) > max_length:
        sanitized = sanitized[:max_length]
        logger.warning(f"Password truncated to {max_length} characters")
    
    return sanitized


def detect_encoding(file_path: str, encodings: List[str] = None) -> Tuple[str, str]:
    """
    Detect file encoding with comprehensive fallback.
    
    Определяет кодировку файла с комплексным fallback.
    Визначає кодування файлу з комплексним fallback.
    
    Args:
        file_path: Path to file / Путь к файлу / Шлях до файлу
        encodings: List of encodings to check / Список кодировок для проверки / Список кодувань для перевірки
    
    Returns:
        (encoding, content) - encoding and content
        (encoding, content) - кодировка и содержимое
        (encoding, content) - кодування та вміст
    
    Raises:
        UnsupportedEncodingError: If no encoding works / Если ни одна кодировка не подошла / Якщо жодне кодування не підійшло
    """
    if encodings is None:
        encodings = ['utf-8-sig', 'utf-8', 'cp1251', 'latin-1', 'cp866', 'koi8-r', 'iso-8859-1']
    
    # Try to read as binary first for BOM detection / Сначала пробуем прочитать как бинарный для обнаружения BOM / Спочатку пробуємо прочитати як бінарний для виявлення BOM
    try:
        with open(file_path, 'rb') as f:
            raw = f.read(4)
            if raw.startswith(b'\xef\xbb\xbf'):
                encodings.insert(0, 'utf-8-sig')
            elif raw.startswith(b'\xff\xfe'):
                encodings.insert(0, 'utf-16-le')
            elif raw.startswith(b'\xfe\xff'):
                encodings.insert(0, 'utf-16-be')
    except (OSError, IOError, PermissionError) as e:
        logger.debug(f"BOM detection failed: {e}")
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
                # Check that content is not empty and seems valid
                # Проверяем, что содержимое не пустое и выглядит валидным
                # Перевіряємо, що вміст не порожній і виглядає дійсним
                if content and len(content) > 0:
                    # Additional sanity check - should contain at least some letters
                    # Дополнительная проверка - должно содержать хотя бы несколько букв
                    # Додаткова перевірка - повинно містити хоча б кілька літер
                    if re.search(r'[a-zA-Zа-яА-Я]', content):
                        logger.debug(f"Successfully detected encoding: {encoding}")
                        return encoding, content
        except (UnicodeDecodeError, UnicodeError, OSError, IOError) as e:
            logger.debug(f"Encoding {encoding} failed: {e}")
            continue
    
    raise UnsupportedEncodingError(f"Cannot detect file encoding for {file_path}")


def detect_csv_delimiter(content: str) -> str:
    """
    Detect CSV delimiter from content sample.
    
    Определяет разделитель CSV из образца содержимого.
    Визначає розділювач CSV зі зразка вмісту.
    
    Args:
        content: CSV content / Содержимое CSV / Вміст CSV
    
    Returns:
        Detected delimiter / Определённый разделитель / Визначений розділювач
    """
    sample = content[:CSV_SAMPLE_SIZE]
    
    # Count occurrences of possible delimiters / Считаем вхождения возможных разделителей / Рахуємо входження можливих розділювачів
    delimiters = [',', ';', '\t', '|']
    counts = {}
    
    for delim in delimiters:
        counts[delim] = sample.count(delim)
    
    # Return the most common delimiter / Возвращаем самый частый разделитель / Повертаємо найчастіший розділювач
    if counts:
        max_delim = max(counts, key=lambda k: counts[k])
        if counts[max_delim] > 0:
            return max_delim
    
    return ','  # Default to comma / По умолчанию запятая / За замовчуванням кома


def is_duplicate_password(password: str, existing_passwords: Set[str]) -> bool:
    """
    Check if password is a duplicate.
    
    Проверяет, является ли пароль дубликатом.
    Перевіряє, чи є пароль дублікатом.
    
    Args:
        password: Password to check / Пароль для проверки / Пароль для перевірки
        existing_passwords: Set of existing passwords / Множество существующих паролей / Множина існуючих паролів
    
    Returns:
        True if duplicate / True если дубликат / True якщо дублікат
    """
    return password in existing_passwords


def safe_xml_parse(file_path: str) -> ET.Element:
    """
    Safely parse XML file with protection against malicious content.
    
    Безопасно парсит XML файл с защитой от вредоносного содержимого.
    Безпечно парсить XML файл із захистом від шкідливого вмісту.
    
    Args:
        file_path: Path to XML file / Путь к XML файлу / Шлях до XML файлу
    
    Returns:
        Root element / Корневой элемент / Кореневий елемент
    """
    try:
        # Disable external entity processing for security
        # Отключаем обработку внешних сущностей для безопасности
        # Вимкаємо обробку зовнішніх сутностей для безпеки
        parser = ET.XMLParser()
        parser.entity = {}  # Disable entity resolution
        
        tree = ET.parse(file_path, parser=parser)
        root = tree.getroot()
        
        if root is None:
            raise MalformedFileError("XML file has no root element")
        
        return root
    except ET.ParseError as e:
        logger.error(f"XML parse error: {e}")
        raise InvalidFileFormatError(f"Invalid XML format: {e}")
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"XML file read error: {e}")
        raise ImportError(f"Cannot read XML file: {e}")


class PasswordImporter:
    """Import passwords from various formats
    Импорт паролей из различных форматов
    Імпорт паролів з різних форматів"""
    
    _imported_hashes: Set[str] = set()
    
    @classmethod
    def reset_duplicate_tracking(cls) -> None:
        """Reset duplicate tracking / Сбрасывает отслеживание дубликатов / Скидає відстеження дублікатів"""
        cls._imported_hashes.clear()
    
    @classmethod
    def _get_password_hash(cls, password: str) -> str:
        """Return password hash for duplicate tracking
        Возвращает хеш пароля для отслеживания дубликатов
        Повертає хеш пароля для відстеження дублікатів"""
        return hashlib.sha256(password.encode('utf-8')).hexdigest()[:16]
    
    @classmethod
    def _check_and_add_duplicate(cls, password: str) -> bool:
        """
        Check and add password to duplicate tracking.
        
        Проверяет и добавляет пароль в отслеживание дубликатов.
        Перевіряє та додає пароль у відстеження дублікатів.
        
        Returns:
            True if duplicate, False if new / True если дубликат, False если новый / True якщо дублікат, False якщо новий
        """
        pwd_hash = cls._get_password_hash(password)
        if pwd_hash in cls._imported_hashes:
            return True
        cls._imported_hashes.add(pwd_hash)
        return False

    @staticmethod
    def import_from_json(file_path: str) -> List[Dict[str, Any]]:
        """Import from JSON format (Secure Pass Pro) with corruption check
        Импорт из JSON формата (Secure Pass Pro) с проверкой на повреждения
        Імпорт з JSON формату (Secure Pass Pro) з перевіркою на пошкодження"""
        # Check file size / Проверка размера файла / Перевірка розміру файлу
        try:
            file_size = os.path.getsize(file_path)
            if file_size > MAX_FILE_SIZE:
                raise FileTooLargeError(f"File too large: {file_size} bytes (max: {MAX_FILE_SIZE})")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to check file size: {e}")
            raise ImportError(f"Cannot read file: {e}")
        
        try:
            encoding, content = detect_encoding(file_path)
            logger.debug(f"Detected encoding: {encoding}")
            
            # Check for BOM / Проверка на BOM / Перевірка на BOM
            if content.startswith('\ufeff'):
                content = content[1:]
            
            # Check for corruption / Проверка на повреждения / Перевірка на пошкодження
            if not content or not content.strip():
                raise MalformedFileError("Empty file")
            
            # Check for truncation / Проверка на усечение / Перевірка на усічення
            if content.rstrip().endswith(',') or content.rstrip().endswith('\\'):
                raise MalformedFileError("File appears truncated")
            
            data = json.loads(content)
            passwords = []
            
            if isinstance(data, list):
                for i, item in enumerate(data):
                    try:
                        if not isinstance(item, dict):
                            logger.warning(f"Skipping non-dictionary item at index {i}")
                            continue
                        
                        label = item.get('label', item.get('name', ''))
                        password = item.get('password', item.get('pwd', ''))
                        created = item.get('created', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                        notes = item.get('notes', '')[:500] if item.get('notes') else ''
                        
                        if password and password.strip():
                            # Sanitization / Санитизация / Санітизація
                            label = sanitize_csv_value(label, MAX_LABEL_LENGTH)
                            password = sanitize_password(password)
                            
                            passwords.append({
                                'label': label if label else f"Imported_{i+1}",
                                'password': password,
                                'created': created,
                                'notes': notes
                            })
                    except (KeyError, ValueError, TypeError) as e:
                        logger.warning(f"Error processing item {i}: {e}")
                        continue
                        
            elif isinstance(data, dict):
                items = data.get('passwords', data.get('items', []))
                if not isinstance(items, list):
                    raise InvalidFileFormatError("Invalid JSON structure: 'passwords' or 'items' must be a list")
                
                for i, item in enumerate(items):
                    try:
                        if not isinstance(item, dict):
                            continue
                        
                        label = item.get('label', item.get('name', ''))
                        password = item.get('password', item.get('pwd', ''))
                        created = item.get('created', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                        notes = item.get('notes', '')[:500] if item.get('notes') else ''
                        
                        if password and password.strip():
                            label = sanitize_csv_value(label, MAX_LABEL_LENGTH)
                            password = sanitize_password(password)
                            
                            passwords.append({
                                'label': label if label else f"Imported_{i+1}",
                                'password': password,
                                'created': created,
                                'notes': notes
                            })
                    except (KeyError, ValueError, TypeError) as e:
                        logger.warning(f"Error processing item {i}: {e}")
                        continue
            else:
                raise InvalidFileFormatError(f"Unexpected JSON type: {type(data).__name__}")
            
            logger.info(f"Imported {len(passwords)} passwords from JSON")
            return passwords
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            raise InvalidFileFormatError(f"Invalid JSON format: {e}")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"File read error: {e}")
            raise ImportError(f"Cannot read file: {e}")
        except MalformedFileError:
            raise
        except InvalidFileFormatError:
            raise
        except UnsupportedEncodingError as e:
            logger.error(f"Encoding error: {e}")
            raise ImportError(f"Cannot detect file encoding: {e}")

    @staticmethod
    def import_from_csv(file_path: str) -> List[Dict[str, Any]]:
        """Import from CSV format (Excel, Google Sheets) with sanitization
        Импорт из CSV формата (Excel, Google Sheets) с санитизацией
        Імпорт з CSV формату (Excel, Google Sheets) з санітизацією"""
        # Check file size / Проверка размера файла / Перевірка розміру файлу
        try:
            if os.path.getsize(file_path) > MAX_FILE_SIZE:
                raise FileTooLargeError(f"File too large: {os.path.getsize(file_path)} bytes")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to check file size: {e}")
            raise ImportError(f"Cannot read file: {e}")
        
        # Detect encoding / Определяем кодировку / Визначаємо кодування
        try:
            encoding, content = detect_encoding(file_path)
            logger.debug(f"Detected encoding: {encoding}")
        except UnsupportedEncodingError as e:
            logger.error(f"Encoding detection failed: {e}")
            raise ImportError(f"Cannot detect file encoding: {e}")
        
        passwords = []
        line_number = 0
        
        try:
            from io import StringIO
            f = StringIO(content)
            
            # Detect delimiter / Определяем разделитель / Визначаємо розділювач
            delimiter = detect_csv_delimiter(content)
            logger.debug(f"Detected CSV delimiter: '{delimiter}'")
            
            reader = csv.DictReader(f, delimiter=delimiter)
            fieldnames = reader.fieldnames or []
            
            if not fieldnames:
                raise InvalidFileFormatError("CSV file has no headers")
            
            # Determine columns / Определяем колонки / Визначаємо колонки
            label_col = None
            pwd_col = None
            date_col = None
            notes_col = None
            
            for col in fieldnames:
                col_lower = col.lower().strip()
                if 'label' in col_lower or 'name' in col_lower or 'title' in col_lower or 'site' in col_lower:
                    label_col = col
                elif 'password' in col_lower or 'pwd' in col_lower or 'pass' in col_lower:
                    pwd_col = col
                elif 'created' in col_lower or 'date' in col_lower or 'time' in col_lower:
                    date_col = col
                elif 'notes' in col_lower or 'comment' in col_lower or 'description' in col_lower:
                    notes_col = col
            
            # Fallback: take first columns / Fallback: берём первые колонки / Fallback: беремо перші колонки
            if label_col is None and len(fieldnames) > 0:
                label_col = fieldnames[0]
                logger.debug(f"Using first column as label: {label_col}")
            if pwd_col is None and len(fieldnames) > 1:
                pwd_col = fieldnames[1]
                logger.debug(f"Using second column as password: {pwd_col}")
            
            if pwd_col is None:
                raise InvalidFileFormatError("Cannot find password column in CSV")
            
            for row in reader:
                line_number += 1
                try:
                    # Extract values with malformed row recovery
                    # Извлекаем значения с восстановлением повреждённых строк
                    # Витягуємо значення з відновленням пошкоджених рядків
                    label = row.get(label_col, '') if label_col else ''
                    password = row.get(pwd_col, '') if pwd_col else ''
                    created = row.get(date_col, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) if date_col else datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    notes = row.get(notes_col, '')[:500] if notes_col else ''
                    
                    # Skip empty password rows / Пропускаем строки с пустым паролем / Пропускаємо рядки з порожнім паролем
                    if not password or not password.strip():
                        continue
                    
                    # Sanitization / Санитизация / Санітизація
                    label = sanitize_csv_value(label, MAX_LABEL_LENGTH)
                    password = sanitize_password(password)
                    
                    passwords.append({
                        'label': label if label.strip() else f"Imported_{line_number}",
                        'password': password,
                        'created': created[:19] if len(created) > 19 else created,
                        'notes': notes
                    })
                except (KeyError, ValueError, TypeError, AttributeError) as e:
                    logger.warning(f"Error processing CSV line {line_number}: {e}")
                    continue
            
            logger.info(f"Imported {len(passwords)} passwords from CSV (encoding: {encoding})")
            return passwords
            
        except csv.Error as e:
            logger.error(f"CSV parse error at line {line_number}: {e}")
            raise InvalidFileFormatError(f"CSV parsing error: {e}")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"File read error: {e}")
            raise ImportError(f"Cannot read file: {e}")

    @staticmethod
    def import_from_keepass_xml(file_path: str) -> List[Dict[str, Any]]:
        """Import from KeePass XML format with safe parsing
        Импорт из KeePass XML формата с безопасным парсингом
        Імпорт з KeePass XML формату з безпечним парсингом"""
        try:
            if os.path.getsize(file_path) > MAX_FILE_SIZE:
                raise FileTooLargeError(f"File too large: {os.path.getsize(file_path)} bytes")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to check file size: {e}")
            raise ImportError(f"Cannot read file: {e}")
        
        try:
            # Safe XML parsing / Безопасный парсинг XML / Безпечний парсинг XML
            root = safe_xml_parse(file_path)
            
            passwords = []
            
            # Find entry elements / Ищем элементы entry / Шукаємо елементи entry
            entries = root.findall('.//Entry') or root.findall('.//entry')
            
            for i, entry in enumerate(entries):
                try:
                    title_elem = entry.find('.//Title') or entry.find('.//title')
                    password_elem = entry.find('.//Password') or entry.find('.//password')
                    username_elem = entry.find('.//UserName') or entry.find('.//username')
                    url_elem = entry.find('.//URL') or entry.find('.//url')
                    notes_elem = entry.find('.//Notes') or entry.find('.//notes')
                    
                    title = title_elem.text if title_elem is not None else ''
                    password = password_elem.text if password_elem is not None else ''
                    username = username_elem.text if username_elem is not None else ''
                    url = url_elem.text if url_elem is not None else ''
                    notes = notes_elem.text if notes_elem is not None else ''
                    
                    if password and password.strip():
                        # Sanitization / Санитизация / Санітизація
                        password = sanitize_password(password)
                        label = sanitize_csv_value(title, MAX_LABEL_LENGTH) if title else f"KeePass_{i+1}"
                        
                        if username:
                            label += f" ({sanitize_csv_value(username, 50)})"
                        if url:
                            label += f" - {url[:100]}"
                        
                        passwords.append({
                            'label': label[:MAX_LABEL_LENGTH],
                            'password': password,
                            'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            'notes': notes[:500] if notes else ''
                        })
                except (AttributeError, ValueError, TypeError) as e:
                    logger.warning(f"Error processing KeePass entry {i}: {e}")
                    continue
            
            logger.info(f"Imported {len(passwords)} passwords from KeePass XML")
            return passwords
            
        except ET.ParseError as e:
            logger.error(f"XML parse error: {e}")
            raise InvalidFileFormatError(f"Invalid XML format: {e}")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"File read error: {e}")
            raise ImportError(f"Cannot read file: {e}")

    @staticmethod
    def import_from_bitwarden_json(file_path: str) -> List[Dict[str, Any]]:
        """Import from Bitwarden JSON format / Импорт из Bitwarden JSON формата / Імпорт з Bitwarden JSON формату"""
        try:
            if os.path.getsize(file_path) > MAX_FILE_SIZE:
                raise FileTooLargeError(f"File too large: {os.path.getsize(file_path)} bytes")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to check file size: {e}")
            raise ImportError(f"Cannot read file: {e}")
        
        try:
            encoding, content = detect_encoding(file_path)
            logger.debug(f"Detected encoding: {encoding}")
            
            # Check for BOM / Проверка на BOM / Перевірка на BOM
            if content.startswith('\ufeff'):
                content = content[1:]
            
            data = json.loads(content)
            passwords = []
            
            items = data.get('items', [])
            if not isinstance(items, list):
                raise InvalidFileFormatError("Bitwarden JSON: 'items' must be a list")
            
            for item in items:
                try:
                    login = item.get('login', {})
                    password = login.get('password', '')
                    
                    if password and password.strip():
                        password = sanitize_password(password)
                        name = item.get('name', '')
                        username = login.get('username', '')
                        
                        label = sanitize_csv_value(name, MAX_LABEL_LENGTH) if name else "Bitwarden"
                        if username:
                            label += f" ({sanitize_csv_value(username, 50)})"
                        
                        passwords.append({
                            'label': label[:MAX_LABEL_LENGTH],
                            'password': password,
                            'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            'notes': ''
                        })
                except (KeyError, ValueError, TypeError) as e:
                    logger.warning(f"Error processing Bitwarden item: {e}")
                    continue
            
            logger.info(f"Imported {len(passwords)} passwords from Bitwarden JSON")
            return passwords
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            raise InvalidFileFormatError(f"Invalid JSON format: {e}")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"File read error: {e}")
            raise ImportError(f"Cannot read file: {e}")
        except UnsupportedEncodingError as e:
            logger.error(f"Encoding error: {e}")
            raise ImportError(f"Cannot detect file encoding: {e}")

    @staticmethod
    def import_from_1password_csv(file_path: str) -> List[Dict[str, Any]]:
        """Import from 1Password CSV format / Импорт из 1Password CSV формата / Імпорт з 1Password CSV формату"""
        try:
            if os.path.getsize(file_path) > MAX_FILE_SIZE:
                raise FileTooLargeError(f"File too large: {os.path.getsize(file_path)} bytes")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to check file size: {e}")
            raise ImportError(f"Cannot read file: {e}")
        
        try:
            encoding, content = detect_encoding(file_path, ['utf-8-sig', 'utf-8', 'cp1251'])
            logger.debug(f"Detected encoding: {encoding}")
            
            passwords = []
            line_number = 0
            
            from io import StringIO
            f = StringIO(content)
            reader = csv.DictReader(f)
            
            for row in reader:
                line_number += 1
                try:
                    title = row.get('title', row.get('Title', ''))
                    password = row.get('password', row.get('Password', ''))
                    username = row.get('username', row.get('Username', ''))
                    url = row.get('url', row.get('URL', ''))
                    
                    if password and password.strip():
                        password = sanitize_password(password)
                        label = sanitize_csv_value(title, MAX_LABEL_LENGTH) if title else f"1Password_{line_number}"
                        
                        if username:
                            label += f" ({sanitize_csv_value(username, 50)})"
                        if url:
                            label += f" - {url[:100]}"
                        
                        passwords.append({
                            'label': label[:MAX_LABEL_LENGTH],
                            'password': password,
                            'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            'notes': ''
                        })
                except (KeyError, ValueError, TypeError) as e:
                    logger.warning(f"Error processing 1Password line {line_number}: {e}")
                    continue
            
            logger.info(f"Imported {len(passwords)} passwords from 1Password CSV")
            return passwords
            
        except csv.Error as e:
            logger.error(f"CSV parse error at line {line_number}: {e}")
            raise InvalidFileFormatError(f"CSV parsing error: {e}")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"File read error: {e}")
            raise ImportError(f"Cannot read file: {e}")
        except UnsupportedEncodingError as e:
            logger.error(f"Encoding error: {e}")
            raise ImportError(f"Cannot detect file encoding: {e}")

    @staticmethod
    def import_from_1pux(file_path: str) -> List[Dict[str, Any]]:
        """Import from 1PUX (1Password Unified Export) format
        Импорт из 1PUX (1Password Unified Export) формата
        Імпорт з 1PUX (1Password Unified Export) формату"""
        temp_dir = None
        
        try:
            if os.path.getsize(file_path) > MAX_FILE_SIZE:
                raise FileTooLargeError(f"File too large: {os.path.getsize(file_path)} bytes")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to check file size: {e}")
            raise ImportError(f"Cannot read file: {e}")
        
        try:
            passwords = []
            
            # 1PUX can be either a zip archive or regular JSON
            # 1PUX может быть как zip архивом, так и обычным JSON
            # 1PUX може бути як zip архівом, так і звичайним JSON
            if zipfile.is_zipfile(file_path):
                temp_dir = tempfile.mkdtemp()
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    zip_ref.extractall(temp_dir)
                
                # Find export.data or .json file / Ищем export.data или .json файл / Шукаємо export.data або .json файл
                export_file = os.path.join(temp_dir, 'export.data')
                if not os.path.exists(export_file):
                    for f in os.listdir(temp_dir):
                        if f.endswith('.json'):
                            export_file = os.path.join(temp_dir, f)
                            break
                
                if not os.path.exists(export_file):
                    raise InvalidFileFormatError("Cannot find export.data or .json in 1PUX archive")
                
                encoding, content = detect_encoding(export_file)
                data = json.loads(content)
            else:
                encoding, content = detect_encoding(file_path)
                if content.startswith('\ufeff'):
                    content = content[1:]
                data = json.loads(content)
            
            logger.debug(f"1PUX detected encoding: {encoding}")
            
            items = data.get('items', [])
            if not isinstance(items, list):
                raise InvalidFileFormatError("1PUX: 'items' must be a list")
            
            for item in items:
                try:
                    title = item.get('title', '')
                    
                    password = ''
                    username = ''
                    url = ''
                    notes = ''
                    
                    fields = item.get('fields', [])
                    if isinstance(fields, list):
                        for field in fields:
                            field_type = field.get('type', '')
                            value = field.get('value', '')
                            purpose = field.get('purpose', '')
                            
                            if field_type == 'PASSWORD' or purpose == 'PASSWORD':
                                password = value
                            elif field_type == 'USERNAME' or purpose == 'USERNAME':
                                username = value
                            elif field_type == 'URL' or purpose == 'URL':
                                url = value
                            elif field_type == 'NOTES' or purpose == 'NOTES':
                                notes = value
                    
                    if not password:
                        details = item.get('details', {})
                        if isinstance(details, dict):
                            password = details.get('password', '')
                            if not password:
                                password = details.get('passphrase', '')
                            if not password:
                                login_details = details.get('login', {})
                                password = login_details.get('password', '')
                    
                    if password and password.strip():
                        password = sanitize_password(password)
                        label = sanitize_csv_value(title, MAX_LABEL_LENGTH) if title else "1Password_import"
                        
                        if username:
                            label += f" ({sanitize_csv_value(username, 50)})"
                        if url:
                            label += f" - {url[:100]}"
                        
                        passwords.append({
                            'label': label[:MAX_LABEL_LENGTH],
                            'password': password,
                            'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            'notes': notes[:500] if notes else ''
                        })
                except (KeyError, ValueError, TypeError, AttributeError) as e:
                    logger.warning(f"Error processing 1PUX item: {e}")
                    continue
            
            logger.info(f"Imported {len(passwords)} passwords from 1PUX")
            return passwords
            
        except zipfile.BadZipFile:
            # Not a zip archive, try as JSON / Не zip архив, пробуем как JSON / Не zip архів, пробуємо як JSON
            try:
                encoding, content = detect_encoding(file_path)
                if content.startswith('\ufeff'):
                    content = content[1:]
                data = json.loads(content)
                
                passwords = []
                items = data.get('items', [])
                for item in items:
                    try:
                        title = item.get('title', '')
                        password = ''
                        username = ''
                        url = ''
                        
                        fields = item.get('fields', [])
                        for field in fields:
                            field_type = field.get('type', '')
                            value = field.get('value', '')
                            if field_type == 'PASSWORD':
                                password = value
                            elif field_type == 'USERNAME':
                                username = value
                            elif field_type == 'URL':
                                url = value
                        
                        if not password:
                            details = item.get('details', {})
                            password = details.get('password', '')
                            if not password:
                                login_details = details.get('login', {})
                                password = login_details.get('password', '')
                        
                        if password and password.strip():
                            password = sanitize_password(password)
                            label = sanitize_csv_value(title, MAX_LABEL_LENGTH) if title else "1Password_import"
                            
                            if username:
                                label += f" ({sanitize_csv_value(username, 50)})"
                            if url:
                                label += f" - {url[:100]}"
                            
                            passwords.append({
                                'label': label[:MAX_LABEL_LENGTH],
                                'password': password,
                                'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                'notes': ''
                            })
                    except (KeyError, ValueError, TypeError) as e:
                        continue
                
                return passwords
            except json.JSONDecodeError as e:
                raise InvalidFileFormatError(f"Invalid 1PUX/JSON format: {e}")
        except json.JSONDecodeError as e:
            logger.error(f"1PUX JSON decode error: {e}")
            raise InvalidFileFormatError(f"Invalid 1PUX format: {e}")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"1PUX file read error: {e}")
            raise ImportError(f"Cannot read file: {e}")
        except UnsupportedEncodingError as e:
            logger.error(f"Encoding error: {e}")
            raise ImportError(f"Cannot detect file encoding: {e}")
        finally:
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, ignore_errors=True)

    @classmethod
    def import_all(cls, parent, lang: str = "RU") -> None:
        """Dialog for format selection and import - with 1PUX support and duplicate checking
        Диалог выбора формата и импорт - с поддержкой 1PUX и проверкой дубликатов
        Діалог вибору формату та імпорт - з підтримкою 1PUX та перевіркою дублікатів"""
        from storage.database import PasswordDB
        from gui.dialogs import CTkMessageBox
        import customtkinter as ctk
        import tkinter as tk
        from localization.lang import LANGUAGES
        
        # Reset duplicate tracking / Сбрасываем отслеживание дубликатов / Скидаємо відстеження дублікатів
        cls.reset_duplicate_tracking()

        L = LANGUAGES.get(lang, LANGUAGES["RU"])

        # Create window / Создаём окно / Створюємо вікно
        win = ctk.CTkToplevel(parent)
        win.title(L.get("import_title", "Import Passwords"))
        win.geometry("500x650")
        win.resizable(False, False)
        win.transient(parent)
        win.grab_set()
        win.attributes("-topmost", True)

        # Center window / Центрируем окно / Центруємо вікно
        try:
            win.update_idletasks()
            parent_x = parent.winfo_x()
            parent_y = parent.winfo_y()
            parent_width = parent.winfo_width()
            parent_height = parent.winfo_height()
            x = parent_x + (parent_width - 500) // 2
            y = parent_y + (parent_height - 650) // 2
            win.geometry(f"500x650+{x}+{y}")
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Center window error: {e}")
            win.geometry("500x650")

        main_frame = ctk.CTkFrame(win, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=25, pady=20)

        # Header / Заголовок / Заголовок
        try:
            title_label = ctk.CTkLabel(main_frame, text=L.get("import_title", "Import Passwords"),
                                       font=("Segoe UI", 22, "bold"))
            title_label.pack(pady=(0, 10))
        except (tk.TclError, KeyError, TypeError) as e:
            logger.debug(f"Title error: {e}")

        # Separator / Разделитель / Розділювач
        separator = ctk.CTkFrame(main_frame, height=2, fg_color="#2d6a4f")
        separator.pack(fill="x", pady=(0, 15))

        # Import format / Формат импорта / Формат імпорту
        try:
            format_label = ctk.CTkLabel(main_frame, text=L.get("import_format", "Import format:"),
                                       font=("Segoe UI", 15, "bold"))
            format_label.pack(pady=(0, 10))
        except (tk.TclError, KeyError, TypeError) as e:
            logger.debug(f"Format label error: {e}")

        format_var = tk.StringVar(value="json")

        formats_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        formats_frame.pack(pady=(0, 15))

        formats = [
            ("json", "JSON (Secure Pass Pro)"),
            ("csv", "CSV (Excel / Google Sheets)"),
            ("keepass", "KeePass XML"),
            ("bitwarden", "Bitwarden JSON"),
            ("onepassword", "1Password CSV"),
            ("1pux", "1PUX (1Password Unified Export)")
        ]

        for fmt, text in formats:
            try:
                rb = ctk.CTkRadioButton(formats_frame, text=text, variable=format_var,
                                        value=fmt, font=("Segoe UI", 12))
                rb.pack(anchor="center", pady=4)
            except (tk.TclError, AttributeError, TypeError) as e:
                logger.debug(f"Radio button error for {fmt}: {e}")

        # Separator / Разделитель / Розділювач
        separator2 = ctk.CTkFrame(main_frame, height=1, fg_color="#333333")
        separator2.pack(fill="x", pady=(10, 15))

        # Warning / Предупреждение / Попередження
        warning_frame = ctk.CTkFrame(main_frame, fg_color="#3a2a0a", corner_radius=10)
        warning_frame.pack(fill="x", pady=(0, 20))

        try:
            warning_label = ctk.CTkLabel(warning_frame,
                                        text=L.get("import_warning", "Import only from trusted sources!"),
                                        font=("Segoe UI", 11), text_color="#FFA500")
            warning_label.pack(pady=12, padx=15)
        except (tk.TclError, KeyError, TypeError) as e:
            logger.debug(f"Warning label error: {e}")

        # Checkbox for skipping duplicates / Чекбокс для пропуска дубликатов / Чекбокс для пропуску дублікатів
        skip_duplicates_var = tk.BooleanVar(value=True)
        try:
            skip_duplicates_cb = ctk.CTkCheckBox(
                main_frame,
                text=L.get("skip_duplicates", "Skip duplicate passwords"),
                variable=skip_duplicates_var,
                font=("Segoe UI", 12)
            )
            skip_duplicates_cb.pack(pady=(0, 15))
        except (tk.TclError, KeyError, TypeError) as e:
            logger.debug(f"Skip duplicates checkbox error: {e}")

        # Buttons frame / Фрейм для кнопок / Фрейм для кнопок
        buttons_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        buttons_frame.pack(fill="x", pady=(10, 0))

        def do_import():
            fmt = format_var.get()
            extensions = {
                "json": ("JSON files", "*.json"),
                "csv": ("CSV files", "*.csv"),
                "keepass": ("KeePass XML", "*.xml"),
                "bitwarden": ("Bitwarden JSON", "*.json"),
                "onepassword": ("1Password CSV", "*.csv"),
                "1pux": ("1PUX files", "*.1pux")
            }

            path = filedialog.askopenfilename(
                title="Select file to import",
                filetypes=[(extensions[fmt][0], extensions[fmt][1]), ("All files", "*.*")]
            )

            if path:
                try:
                    if fmt == "json":
                        passwords = cls.import_from_json(path)
                    elif fmt == "csv":
                        passwords = cls.import_from_csv(path)
                    elif fmt == "keepass":
                        passwords = cls.import_from_keepass_xml(path)
                    elif fmt == "bitwarden":
                        passwords = cls.import_from_bitwarden_json(path)
                    elif fmt == "onepassword":
                        passwords = cls.import_from_1password_csv(path)
                    elif fmt == "1pux":
                        passwords = cls.import_from_1pux(path)
                    else:
                        passwords = []

                    if not passwords:
                        CTkMessageBox.warning(win, L.get("import_title", "Import"),
                                             L.get("import_no_passwords", "No passwords found in file!"))
                        return

                    # Duplicate filtering / Фильтрация дубликатов / Фільтрація дублікатів
                    skip_duplicates = skip_duplicates_var.get()
                    filtered_passwords = []
                    duplicates_count = 0
                    
                    for pwd in passwords:
                        if skip_duplicates and cls._check_and_add_duplicate(pwd['password']):
                            duplicates_count += 1
                            logger.debug(f"Duplicate password skipped: {pwd['label']}")
                        else:
                            filtered_passwords.append(pwd)
                    
                    if duplicates_count > 0:
                        logger.info(f"Skipped {duplicates_count} duplicate passwords")

                    # Show preview / Показываем предпросмотр / Показуємо попередній перегляд
                    preview_lines = []
                    for p in filtered_passwords[:10]:
                        preview_lines.append(f"- {p['label'][:50]}")
                    preview = "\n".join(preview_lines)
                    if len(filtered_passwords) > 10:
                        preview += f"\n... and {len(filtered_passwords) - 10} more"
                    
                    if duplicates_count > 0:
                        preview += f"\n\nSkipped duplicates: {duplicates_count}"

                    if not CTkMessageBox.question(win, L.get("import_title", "Import"),
                        f"{L.get('import_found', 'Passwords found')}: {len(filtered_passwords)}\n\n{preview}\n\n{L.get('import_confirm', 'Import?')}"):
                        return

                    # Import / Импортируем / Імпортуємо
                    imported = 0
                    failed = 0
                    for pwd in filtered_passwords:
                        try:
                            PasswordDB.save(pwd['label'], pwd['password'], pwd.get('notes', ''))
                            imported += 1
                        except (OSError, IOError, sqlite3.Error, ValueError) as e:
                            logger.error(f"Import save error: {e}")
                            failed += 1

                    win.destroy()

                    result_msg = L.get("import_success", "Imported: {0}").format(imported)
                    if failed > 0:
                        result_msg += f"\nFailed to import: {failed}"
                    if duplicates_count > 0:
                        result_msg += f"\nSkipped duplicates: {duplicates_count}"

                    CTkMessageBox.info(parent, L.get("import_title", "Import"), result_msg)

                    # Refresh database window / Обновляем окно БД / Оновлюємо вікно БД
                    if hasattr(parent, '_refresh_db_window'):
                        parent._refresh_db_window()
                    elif hasattr(parent, 'refresh'):
                        parent.refresh()
                    elif hasattr(parent, 'parent') and hasattr(parent.parent, '_refresh_db_window'):
                        parent.parent._refresh_db_window()

                except FileTooLargeError as e:
                    logger.error(f"File too large: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('import_error', 'Import error')}:\n{L.get('err_file_too_large', 'File too large')}")
                except InvalidFileFormatError as e:
                    logger.error(f"Invalid format: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('import_error', 'Import error')}:\n{L.get('err_invalid_format', 'Invalid file format')}")
                except MalformedFileError as e:
                    logger.error(f"Malformed file: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('import_error', 'Import error')}:\n{L.get('err_malformed', 'File corrupted')}")
                except UnsupportedEncodingError as e:
                    logger.error(f"Unsupported encoding: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('import_error', 'Import error')}:\n{L.get('err_encoding', 'Unsupported file encoding')}")
                except ImportError as e:
                    logger.error(f"Import error: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('import_error', 'Import error')}:\n{str(e)}")
                except (ValueError, TypeError, AttributeError) as e:
                    logger.error(f"Import error: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('import_error', 'Import error')}:\n{str(e)}")
                except sqlite3.Error as e:
                    logger.error(f"Database error during import: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('err_database', 'Database error')}:\n{str(e)}")

        # Buttons / Кнопки / Кнопки
        button_container = ctk.CTkFrame(buttons_frame, fg_color="transparent")
        button_container.pack(expand=True)

        try:
            import_btn = ctk.CTkButton(button_container, text=L.get("ok", "Import"),
                                      command=do_import, width=160, height=40,
                                      fg_color="#2d6a4f", hover_color="#40916c",
                                      corner_radius=20, font=("Segoe UI", 14, "bold"))
            import_btn.pack(side="left", padx=(0, 20))
        except (tk.TclError, KeyError, TypeError) as e:
            logger.debug(f"Import button error: {e}")

        try:
            cancel_btn = ctk.CTkButton(button_container, text=L.get("cancel", "Cancel"),
                                      command=win.destroy, width=160, height=40,
                                      fg_color="#8b0000", hover_color="#cc0000",
                                      corner_radius=20, font=("Segoe UI", 14, "bold"))
            cancel_btn.pack(side="left")
        except (tk.TclError, KeyError, TypeError) as e:
            logger.debug(f"Cancel button error: {e}")

        win.after(100, lambda: win.attributes("-topmost", False))