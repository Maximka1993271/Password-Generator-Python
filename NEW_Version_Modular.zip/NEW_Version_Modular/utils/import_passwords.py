"""
Password import utilities for CSV, JSON, KeePass XML, Bitwarden, 1Password, 1PUX
"""
import json
import csv
import xml.etree.ElementTree as ET
import os
import datetime
import zipfile
import tempfile
from typing import List, Dict, Any, Optional
from tkinter import filedialog
from utils.logger import get_logger

logger = get_logger("import_passwords")


class PasswordImporter:
    """Импорт паролей из различных форматов"""

    @staticmethod
    def import_from_json(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из JSON формата (Secure Pass Pro)"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            passwords = []

            if isinstance(data, list):
                for i, item in enumerate(data):
                    label = item.get('label', item.get('name', ''))
                    password = item.get('password', item.get('pwd', ''))
                    created = item.get('created', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                    if password:
                        passwords.append({
                            'label': label[:100] if label else f"Imported_{i+1}",
                            'password': password,
                            'created': created
                        })
            elif isinstance(data, dict):
                items = data.get('passwords', data.get('items', []))
                for i, item in enumerate(items):
                    label = item.get('label', item.get('name', ''))
                    password = item.get('password', item.get('pwd', ''))
                    created = item.get('created', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                    if password:
                        passwords.append({
                            'label': label[:100] if label else f"Imported_{i+1}",
                            'password': password,
                            'created': created
                        })

            return passwords
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            raise ValueError(f"Неверный формат JSON: {e}")
        except (OSError, IOError) as e:
            logger.error(f"File read error: {e}")
            raise ValueError(f"Ошибка чтения файла: {e}")

    @staticmethod
    def import_from_csv(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из CSV формата (Excel, Google Sheets)"""
        try:
            passwords = []

            with open(file_path, 'r', encoding='utf-8-sig') as f:
                sample = f.read(1024)
                f.seek(0)

                delimiter = ','
                if ';' in sample and ',' not in sample:
                    delimiter = ';'
                elif '\t' in sample:
                    delimiter = '\t'

                reader = csv.DictReader(f, delimiter=delimiter)
                fieldnames = reader.fieldnames or []

                label_col = None
                pwd_col = None
                date_col = None

                for col in fieldnames:
                    col_lower = col.lower()
                    if 'label' in col_lower or 'name' in col_lower or 'title' in col_lower or 'site' in col_lower:
                        label_col = col
                    elif 'password' in col_lower or 'pwd' in col_lower or 'pass' in col_lower:
                        pwd_col = col
                    elif 'created' in col_lower or 'date' in col_lower or 'time' in col_lower:
                        date_col = col

                if label_col is None and len(fieldnames) > 0:
                    label_col = fieldnames[0]
                if pwd_col is None and len(fieldnames) > 1:
                    pwd_col = fieldnames[1]

                for i, row in enumerate(reader):
                    label = row.get(label_col, '') if label_col else ''
                    password = row.get(pwd_col, '') if pwd_col else ''
                    created = row.get(date_col, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) if date_col else datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                    if password and password.strip():
                        passwords.append({
                            'label': label.strip()[:100] if label.strip() else f"Imported_{i+1}",
                            'password': password.strip(),
                            'created': created
                        })

            return passwords
        except csv.Error as e:
            logger.error(f"CSV parse error: {e}")
            raise ValueError(f"Ошибка парсинга CSV: {e}")
        except (OSError, IOError) as e:
            logger.error(f"File read error: {e}")
            raise ValueError(f"Ошибка чтения файла: {e}")

    @staticmethod
    def import_from_keepass_xml(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из KeePass XML формата"""
        try:
            tree = ET.parse(file_path)
            root = tree.getroot()

            passwords = []

            entries = root.findall('.//Entry') or root.findall('.//entry')

            for i, entry in enumerate(entries):
                title_elem = entry.find('.//Title') or entry.find('.//title')
                password_elem = entry.find('.//Password') or entry.find('.//password')
                username_elem = entry.find('.//UserName') or entry.find('.//username')
                url_elem = entry.find('.//URL') or entry.find('.//url')

                title = title_elem.text if title_elem is not None else ''
                password = password_elem.text if password_elem is not None else ''
                username = username_elem.text if username_elem is not None else ''
                url = url_elem.text if url_elem is not None else ''

                if password and password.strip():
                    label = title if title else f"KeePass_{i+1}"
                    if username:
                        label += f" ({username})"
                    if url:
                        label += f" - {url}"

                    passwords.append({
                        'label': label[:100],
                        'password': password,
                        'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    })

            return passwords
        except ET.ParseError as e:
            logger.error(f"XML parse error: {e}")
            raise ValueError(f"Ошибка парсинга XML: {e}")
        except (OSError, IOError) as e:
            logger.error(f"File read error: {e}")
            raise ValueError(f"Ошибка чтения файла: {e}")

    @staticmethod
    def import_from_bitwarden_json(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из Bitwarden JSON формата"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            passwords = []

            items = data.get('items', [])
            for item in items:
                login = item.get('login', {})
                password = login.get('password', '')

                if password and password.strip():
                    name = item.get('name', '')
                    username = login.get('username', '')

                    label = name if name else "Bitwarden"
                    if username:
                        label += f" ({username})"

                    passwords.append({
                        'label': label[:100],
                        'password': password,
                        'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    })

            return passwords
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            raise ValueError(f"Неверный формат JSON: {e}")
        except (OSError, IOError) as e:
            logger.error(f"File read error: {e}")
            raise ValueError(f"Ошибка чтения файла: {e}")

    @staticmethod
    def import_from_1password_csv(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из 1Password CSV формата"""
        try:
            passwords = []

            with open(file_path, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)

                for i, row in enumerate(reader):
                    title = row.get('title', row.get('Title', ''))
                    password = row.get('password', row.get('Password', ''))
                    username = row.get('username', row.get('Username', ''))
                    url = row.get('url', row.get('URL', ''))

                    if password and password.strip():
                        label = title if title else f"1Password_{i+1}"
                        if username:
                            label += f" ({username})"
                        if url:
                            label += f" - {url}"

                        passwords.append({
                            'label': label[:100],
                            'password': password,
                            'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        })

            return passwords
        except csv.Error as e:
            logger.error(f"CSV parse error: {e}")
            raise ValueError(f"Ошибка парсинга CSV: {e}")
        except (OSError, IOError) as e:
            logger.error(f"File read error: {e}")
            raise ValueError(f"Ошибка чтения файла: {e}")

    @staticmethod
    def import_from_1pux(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из 1PUX (1Password Unified Export) формата"""
        try:
            passwords = []
            temp_dir = None

            # 1PUX может быть как zip архивом, так и обычным JSON
            if zipfile.is_zipfile(file_path):
                # Это zip архив
                temp_dir = tempfile.mkdtemp()
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    zip_ref.extractall(temp_dir)

                # Ищем файл export.data
                export_file = os.path.join(temp_dir, 'export.data')
                if not os.path.exists(export_file):
                    # Ищем любой .json файл
                    for f in os.listdir(temp_dir):
                        if f.endswith('.json'):
                            export_file = os.path.join(temp_dir, f)
                            break

                with open(export_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                # Удаляем временную папку
                import shutil
                shutil.rmtree(temp_dir, ignore_errors=True)
            else:
                # Обычный JSON файл
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)

            # Парсим 1PUX структуру
            items = data.get('items', [])
            for item in items:
                # Получаем название
                title = item.get('title', '')

                # Получаем поля
                fields = item.get('fields', [])
                password = ''
                username = ''
                url = ''

                for field in fields:
                    field_type = field.get('type', '')
                    value = field.get('value', '')
                    purpose = field.get('purpose', '')

                    if field_type == 'PASSWORD' or purpose == 'PASSWORD':
                        password = value
                    elif field_type == 'USERNAME' or purpose == 'USERNAME':
                        username = value
                    elif field_type == 'URL' or purpose == 'URL':
                        url = value
                    elif field_type == 'EMAIL':
                        if not username:
                            username = value

                # Также проверяем секции
                sections = item.get('sections', [])
                for section in sections:
                    section_fields = section.get('fields', [])
                    for field in section_fields:
                        field_type = field.get('type', '')
                        value = field.get('value', '')
                        if field_type == 'PASSWORD' and not password:
                            password = value
                        elif field_type == 'USERNAME' and not username:
                            username = value

                # Если пароль найден в других местах
                if not password:
                    # Проверяем details
                    details = item.get('details', {})
                    password = details.get('password', '')
                    if not password:
                        password = details.get('passphrase', '')
                    if not password:
                        login_details = details.get('login', {})
                        password = login_details.get('password', '')

                if password and password.strip():
                    label = title if title else "1Password_import"
                    if username:
                        label += f" ({username})"
                    if url:
                        label += f" - {url}"

                    passwords.append({
                        'label': label[:100],
                        'password': password,
                        'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    })

            return passwords
        except zipfile.BadZipFile:
            # Не zip архив, пробуем как JSON
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                passwords = []
                items = data.get('items', [])
                for item in items:
                    title = item.get('title', '')

                    # Ищем пароль в разных местах
                    password = ''
                    username = ''
                    url = ''

                    fields = item.get('fields', [])
                    for field in fields:
                        field_type = field.get('type', '')
                        value = field.get('value', '')
                        if field_type == 'PASSWORD':
                            password = value
                        elif field_type == 'USERNAME':
                            username = value
                        elif field_type == 'URL':
                            url = value

                    if not password:
                        details = item.get('details', {})
                        password = details.get('password', '')
                        if not password:
                            login_details = details.get('login', {})
                            password = login_details.get('password', '')

                    if password and password.strip():
                        label = title if title else "1Password_import"
                        if username:
                            label += f" ({username})"
                        if url:
                            label += f" - {url}"

                        passwords.append({
                            'label': label[:100],
                            'password': password,
                            'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        })

                return passwords
            except json.JSONDecodeError:
                raise ValueError("Неверный формат 1PUX файла")
        except json.JSONDecodeError as e:
            logger.error(f"1PUX JSON decode error: {e}")
            raise ValueError(f"Неверный формат 1PUX: {e}")
        except (OSError, IOError) as e:
            logger.error(f"1PUX file read error: {e}")
            raise ValueError(f"Ошибка чтения файла: {e}")
        finally:
            if temp_dir and os.path.exists(temp_dir):
                import shutil
                shutil.rmtree(temp_dir, ignore_errors=True)

    @staticmethod
    def import_all(parent, lang: str = "RU") -> None:
        """Диалог выбора формата и импорт - с поддержкой 1PUX"""
        from storage.database import PasswordDB
        from gui.dialogs import CTkMessageBox
        import customtkinter as ctk
        import tkinter as tk
        from localization.lang import LANGUAGES

        L = LANGUAGES.get(lang, LANGUAGES["RU"])

        # Создаём окно
        win = ctk.CTkToplevel(parent)
        win.title(L.get("import_title", "Импорт паролей"))
        win.geometry("500x580")
        win.resizable(False, False)
        win.transient(parent)
        win.grab_set()
        win.attributes("-topmost", True)

        # Центрируем окно
        win.update_idletasks()
        parent_x = parent.winfo_x()
        parent_y = parent.winfo_y()
        parent_width = parent.winfo_width()
        parent_height = parent.winfo_height()
        x = parent_x + (parent_width - 500) // 2
        y = parent_y + (parent_height - 580) // 2
        win.geometry(f"500x580+{x}+{y}")

        main_frame = ctk.CTkFrame(win, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=25, pady=20)

        # Заголовок
        title_label = ctk.CTkLabel(main_frame, text="📥 " + L.get("import_title", "Импорт паролей"),
                                   font=("Segoe UI", 22, "bold"))
        title_label.pack(pady=(0, 10))

        # Разделитель
        separator = ctk.CTkFrame(main_frame, height=2, fg_color="#2d6a4f")
        separator.pack(fill="x", pady=(0, 15))

        # Формат импорта
        format_label = ctk.CTkLabel(main_frame, text=L.get("import_format", "Формат импорта:"),
                                   font=("Segoe UI", 15, "bold"))
        format_label.pack(pady=(0, 10))

        format_var = tk.StringVar(value="json")

        formats_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        formats_frame.pack(pady=(0, 15))

        formats = [
            ("json", "📄 JSON (Secure Pass Pro)"),
            ("csv", "📊 CSV (Excel / Google Sheets)"),
            ("keepass", "🔑 KeePass XML"),
            ("bitwarden", "🔒 Bitwarden JSON"),
            ("onepassword", "🔐 1Password CSV"),
            ("1pux", "📦 1PUX (1Password Unified Export)")
        ]

        for fmt, text in formats:
            rb = ctk.CTkRadioButton(formats_frame, text=text, variable=format_var,
                                    value=fmt, font=("Segoe UI", 12))
            rb.pack(anchor="center", pady=4)

        # Разделитель
        separator2 = ctk.CTkFrame(main_frame, height=1, fg_color="#333333")
        separator2.pack(fill="x", pady=(10, 15))

        # Предупреждение
        warning_frame = ctk.CTkFrame(main_frame, fg_color="#3a2a0a", corner_radius=10)
        warning_frame.pack(fill="x", pady=(0, 20))

        warning_label = ctk.CTkLabel(warning_frame,
                                    text="⚠️ " + L.get("import_warning", "Импортируйте только из доверенных источников!"),
                                    font=("Segoe UI", 11), text_color="#FFA500")
        warning_label.pack(pady=12, padx=15)

        # Фрейм для кнопок
        buttons_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        buttons_frame.pack(fill="x", pady=(10, 0))

        def do_import():
            fmt = format_var.get()
            extensions = {
                "json": ("JSON files", "*.json"),
                "csv": ("CSV files", "*.csv"),
                "keepass": ("KeePass XML", "*.xml"),
                "bitwarden": ("Bitwarden JSON", "*.json"),
                "onepassword": ("1Password CSV", "*.csv"),
                "1pux": ("1PUX files", "*.1pux")
            }

            path = filedialog.askopenfilename(
                title="Выберите файл для импорта",
                filetypes=[(extensions[fmt][0], extensions[fmt][1]), ("All files", "*.*")]
            )

            if path:
                try:
                    if fmt == "json":
                        passwords = PasswordImporter.import_from_json(path)
                    elif fmt == "csv":
                        passwords = PasswordImporter.import_from_csv(path)
                    elif fmt == "keepass":
                        passwords = PasswordImporter.import_from_keepass_xml(path)
                    elif fmt == "bitwarden":
                        passwords = PasswordImporter.import_from_bitwarden_json(path)
                    elif fmt == "onepassword":
                        passwords = PasswordImporter.import_from_1password_csv(path)
                    elif fmt == "1pux":
                        passwords = PasswordImporter.import_from_1pux(path)
                    else:
                        passwords = []

                    if not passwords:
                        CTkMessageBox.warning(win, L.get("import_title", "Импорт"),
                                             L.get("import_no_passwords", "Не найдено паролей в файле!"))
                        return

                    # Показываем предпросмотр
                    preview_lines = []
                    for p in passwords[:10]:
                        preview_lines.append(f"• {p['label'][:50]}")
                    preview = "\n".join(preview_lines)
                    if len(passwords) > 10:
                        preview += f"\n... и ещё {len(passwords) - 10}"

                    if not CTkMessageBox.question(win, L.get("import_title", "Импорт"),
                        f"{L.get('import_found', 'Найдено паролей')}: {len(passwords)}\n\n{preview}\n\n{L.get('import_confirm', 'Импортировать?')}"):
                        return

                    # Импортируем
                    imported = 0
                    failed = 0
                    for pwd in passwords:
                        try:
                            PasswordDB.save(pwd['label'], pwd['password'])
                            imported += 1
                        except Exception as e:
                            logger.error(f"Import save error: {e}")
                            failed += 1

                    win.destroy()

                    result_msg = L.get("import_success", "✅ Импортировано: {0}").format(imported)
                    if failed > 0:
                        result_msg += f"\n⚠️ Не удалось импортировать: {failed}"

                    CTkMessageBox.info(parent, L.get("import_title", "Импорт"), result_msg)

                    # Обновляем окно БД
                    if hasattr(parent, '_refresh_db_window'):
                        parent._refresh_db_window()
                    elif hasattr(parent, 'refresh'):
                        parent.refresh()
                    elif hasattr(parent, 'parent') and hasattr(parent.parent, '_refresh_db_window'):
                        parent.parent._refresh_db_window()

                except ValueError as e:
                    logger.error(f"Import value error: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       L.get("import_error", "Ошибка импорта: {0}").format(str(e)))
                except Exception as e:
                    logger.error(f"Import error: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       L.get("import_error", "Ошибка импорта: {0}").format(str(e)))

        # Кнопки
        button_container = ctk.CTkFrame(buttons_frame, fg_color="transparent")
        button_container.pack(expand=True)

        import_btn = ctk.CTkButton(button_container, text="📥 " + L.get("ok", "Импорт"),
                                  command=do_import, width=160, height=40,
                                  fg_color="#2d6a4f", hover_color="#40916c",
                                  corner_radius=20, font=("Segoe UI", 14, "bold"))
        import_btn.pack(side="left", padx=(0, 20))

        cancel_btn = ctk.CTkButton(button_container, text=L.get("cancel", "Отмена"),
                                  command=win.destroy, width=160, height=40,
                                  fg_color="#8b0000", hover_color="#cc0000",
                                  corner_radius=20, font=("Segoe UI", 14, "bold"))
        cancel_btn.pack(side="left")

        win.after(100, lambda: win.attributes("-topmost", False))
