"""
Password import utilities for CSV, JSON, KeePass XML, Bitwarden, 1Password, 1PUX
FIXED: Добавлены CSV sanitization, malformed row recovery, duplicate detection, encoding fallback
"""
import json
import csv
import xml.etree.ElementTree as ET
import os
import datetime
import zipfile
import tempfile
import shutil
import re
from typing import List, Dict, Any, Optional, Tuple, Set
from tkinter import filedialog
from utils.logger import get_logger

logger = get_logger("import_passwords")

# Максимальный размер файла для импорта (50 MB)
MAX_FILE_SIZE = 50 * 1024 * 1024

# Допустимые символы для паролей (для санитизации)
SAFE_PASSWORD_CHARS = re.compile(r'[^\x20-\x7E\u0400-\u04FF]')


class ImportError(Exception):
    """Исключение для ошибок импорта"""
    pass


class InvalidFileFormatError(ImportError):
    """Исключение для неверного формата файла"""
    pass


class MalformedFileError(ImportError):
    """Исключение для повреждённого файла"""
    pass


class FileTooLargeError(ImportError):
    """Исключение для слишком большого файла"""
    pass


def sanitize_csv_value(value: str, max_length: int = 100) -> str:
    """
    Очищает значение из CSV от опасных символов.
    
    Args:
        value: Исходное значение
        max_length: Максимальная длина
    
    Returns:
        Очищенное значение
    """
    if not value:
        return ""
    
    # Удаляем непечатаемые символы (кроме пробелов, табуляции, перевода строки)
    sanitized = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', str(value))
    
    # Ограничиваем длину
    if len(sanitized) > max_length:
        sanitized = sanitized[:max_length]
    
    return sanitized.strip()


def sanitize_password(password: str, max_length: int = 1000) -> str:
    """
    Очищает пароль, сохраняя допустимые символы.
    
    Args:
        password: Исходный пароль
        max_length: Максимальная длина
    
    Returns:
        Очищенный пароль
    """
    if not password:
        return ""
    
    # Удаляем непечатаемые символы
    sanitized = SAFE_PASSWORD_CHARS.sub('', str(password))
    
    # Ограничиваем длину
    if len(sanitized) > max_length:
        sanitized = sanitized[:max_length]
        logger.warning(f"Password truncated to {max_length} characters")
    
    return sanitized


def detect_encoding(file_path: str, encodings: List[str] = None) -> Tuple[str, Optional[str]]:
    """
    Определяет кодировку файла.
    
    Args:
        file_path: Путь к файлу
        encodings: Список кодировок для проверки
    
    Returns:
        (encoding, content) - кодировка и содержимое или None при ошибке
    """
    if encodings is None:
        encodings = ['utf-8-sig', 'utf-8', 'cp1251', 'latin-1', 'cp866', 'koi8-r']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
                # Проверяем, что файл не пустой
                if content.strip():
                    return encoding, content
        except (UnicodeDecodeError, UnicodeError, OSError, IOError) as e:
            logger.debug(f"Encoding {encoding} failed: {e}")
            continue
    
    return None, None


def is_duplicate_password(password: str, existing_passwords: Set[str]) -> bool:
    """
    Проверяет, является ли пароль дубликатом.
    
    Args:
        password: Пароль для проверки
        existing_passwords: Множество существующих паролей
    
    Returns:
        True если дубликат
    """
    return password in existing_passwords


class PasswordImporter:
    """Импорт паролей из различных форматов"""
    
    _imported_hashes: Set[str] = set()
    
    @classmethod
    def reset_duplicate_tracking(cls) -> None:
        """Сбрасывает отслеживание дубликатов"""
        cls._imported_hashes.clear()
    
    @classmethod
    def _get_password_hash(cls, password: str) -> str:
        """Возвращает хеш пароля для отслеживания дубликатов"""
        import hashlib
        return hashlib.sha256(password.encode('utf-8')).hexdigest()[:16]
    
    @classmethod
    def _check_and_add_duplicate(cls, password: str) -> bool:
        """
        Проверяет и добавляет пароль в отслеживание дубликатов.
        
        Returns:
            True если дубликат, False если новый
        """
        pwd_hash = cls._get_password_hash(password)
        if pwd_hash in cls._imported_hashes:
            return True
        cls._imported_hashes.add(pwd_hash)
        return False

    @staticmethod
    def import_from_json(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из JSON формата (Secure Pass Pro) с проверкой на повреждения"""
        # Проверка размера файла
        try:
            if os.path.getsize(file_path) > MAX_FILE_SIZE:
                raise FileTooLargeError(f"File too large: {os.path.getsize(file_path)} bytes (max: {MAX_FILE_SIZE})")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to check file size: {e}")
            raise ImportError(f"Cannot read file: {e}")
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Проверка на BOM
            if content.startswith('\ufeff'):
                content = content[1:]
            
            # Проверка на повреждения
            if not content or not content.strip():
                raise MalformedFileError("Empty file")
            
            # Проверка на усечение
            if content.rstrip().endswith(',') or content.rstrip().endswith('\\'):
                raise MalformedFileError("File appears truncated")
            
            data = json.loads(content)
            passwords = []
            
            if isinstance(data, list):
                for i, item in enumerate(data):
                    try:
                        if not isinstance(item, dict):
                            logger.warning(f"Skipping non-dictionary item at index {i}")
                            continue
                        
                        label = item.get('label', item.get('name', ''))
                        password = item.get('password', item.get('pwd', ''))
                        created = item.get('created', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                        
                        if password and password.strip():
                            # Санитизация
                            label = sanitize_csv_value(label, 100)
                            password = sanitize_password(password)
                            
                            passwords.append({
                                'label': label if label else f"Imported_{i+1}",
                                'password': password,
                                'created': created
                            })
                    except (KeyError, ValueError, TypeError) as e:
                        logger.warning(f"Error processing item {i}: {e}")
                        continue
                        
            elif isinstance(data, dict):
                items = data.get('passwords', data.get('items', []))
                if not isinstance(items, list):
                    raise InvalidFileFormatError("Invalid JSON structure: 'passwords' or 'items' must be a list")
                
                for i, item in enumerate(items):
                    try:
                        if not isinstance(item, dict):
                            continue
                        
                        label = item.get('label', item.get('name', ''))
                        password = item.get('password', item.get('pwd', ''))
                        created = item.get('created', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                        
                        if password and password.strip():
                            label = sanitize_csv_value(label, 100)
                            password = sanitize_password(password)
                            
                            passwords.append({
                                'label': label if label else f"Imported_{i+1}",
                                'password': password,
                                'created': created
                            })
                    except (KeyError, ValueError, TypeError) as e:
                        logger.warning(f"Error processing item {i}: {e}")
                        continue
            else:
                raise InvalidFileFormatError(f"Unexpected JSON type: {type(data).__name__}")
            
            logger.info(f"Imported {len(passwords)} passwords from JSON")
            return passwords
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            raise InvalidFileFormatError(f"Invalid JSON format: {e}")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"File read error: {e}")
            raise ImportError(f"Cannot read file: {e}")
        except MalformedFileError:
            raise
        except InvalidFileFormatError:
            raise

    @staticmethod
    def import_from_csv(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из CSV формата (Excel, Google Sheets) с санитизацией"""
        # Проверка размера файла
        try:
            if os.path.getsize(file_path) > MAX_FILE_SIZE:
                raise FileTooLargeError(f"File too large: {os.path.getsize(file_path)} bytes")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to check file size: {e}")
            raise ImportError(f"Cannot read file: {e}")
        
        # Определяем кодировку
        encoding, content = detect_encoding(file_path)
        if encoding is None:
            raise ImportError("Cannot detect file encoding")
        
        passwords = []
        line_number = 0
        
        try:
            # Используем StringIO для работы с уже прочитанным содержимым
            from io import StringIO
            f = StringIO(content)
            
            # Определяем разделитель
            sample = content[:1024]
            delimiter = ','
            if ';' in sample and ',' not in sample:
                delimiter = ';'
            elif '\t' in sample:
                delimiter = '\t'
            
            reader = csv.DictReader(f, delimiter=delimiter)
            fieldnames = reader.fieldnames or []
            
            if not fieldnames:
                raise InvalidFileFormatError("CSV file has no headers")
            
            # Определяем колонки
            label_col = None
            pwd_col = None
            date_col = None
            
            for col in fieldnames:
                col_lower = col.lower().strip()
                if 'label' in col_lower or 'name' in col_lower or 'title' in col_lower or 'site' in col_lower:
                    label_col = col
                elif 'password' in col_lower or 'pwd' in col_lower or 'pass' in col_lower:
                    pwd_col = col
                elif 'created' in col_lower or 'date' in col_lower or 'time' in col_lower:
                    date_col = col
            
            # Fallback: берём первые колонки
            if label_col is None and len(fieldnames) > 0:
                label_col = fieldnames[0]
                logger.debug(f"Using first column as label: {label_col}")
            if pwd_col is None and len(fieldnames) > 1:
                pwd_col = fieldnames[1]
                logger.debug(f"Using second column as password: {pwd_col}")
            
            if pwd_col is None:
                raise InvalidFileFormatError("Cannot find password column in CSV")
            
            for row in reader:
                line_number += 1
                try:
                    # Извлекаем значения
                    label = row.get(label_col, '') if label_col else ''
                    password = row.get(pwd_col, '') if pwd_col else ''
                    created = row.get(date_col, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) if date_col else datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    
                    # Санитизация
                    label = sanitize_csv_value(label, 100)
                    password = sanitize_password(password)
                    
                    if password and password.strip():
                        passwords.append({
                            'label': label if label.strip() else f"Imported_{line_number}",
                            'password': password,
                            'created': created[:19] if len(created) > 19 else created
                        })
                except (KeyError, ValueError, TypeError) as e:
                    logger.warning(f"Error processing CSV line {line_number}: {e}")
                    continue
            
            logger.info(f"Imported {len(passwords)} passwords from CSV (encoding: {encoding})")
            return passwords
            
        except csv.Error as e:
            logger.error(f"CSV parse error at line {line_number}: {e}")
            raise InvalidFileFormatError(f"CSV parsing error: {e}")
        except (OSError, IOError) as e:
            logger.error(f"File read error: {e}")
            raise ImportError(f"Cannot read file: {e}")

    @staticmethod
    def import_from_keepass_xml(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из KeePass XML формата с безопасным парсингом"""
        try:
            if os.path.getsize(file_path) > MAX_FILE_SIZE:
                raise FileTooLargeError(f"File too large: {os.path.getsize(file_path)} bytes")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to check file size: {e}")
            raise ImportError(f"Cannot read file: {e}")
        
        try:
            # Безопасный парсинг XML
            tree = ET.parse(file_path)
            root = tree.getroot()
            
            passwords = []
            
            # Ищем элементы entry
            entries = root.findall('.//Entry') or root.findall('.//entry')
            
            for i, entry in enumerate(entries):
                try:
                    title_elem = entry.find('.//Title') or entry.find('.//title')
                    password_elem = entry.find('.//Password') or entry.find('.//password')
                    username_elem = entry.find('.//UserName') or entry.find('.//username')
                    url_elem = entry.find('.//URL') or entry.find('.//url')
                    
                    title = title_elem.text if title_elem is not None else ''
                    password = password_elem.text if password_elem is not None else ''
                    username = username_elem.text if username_elem is not None else ''
                    url = url_elem.text if url_elem is not None else ''
                    
                    if password and password.strip():
                        # Санитизация
                        password = sanitize_password(password)
                        label = sanitize_csv_value(title, 100) if title else f"KeePass_{i+1}"
                        
                        if username:
                            label += f" ({sanitize_csv_value(username, 50)})"
                        if url:
                            label += f" - {sanitize_csv_value(url, 100)[:100]}"
                        
                        passwords.append({
                            'label': label[:100],
                            'password': password,
                            'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        })
                except (AttributeError, ValueError, TypeError) as e:
                    logger.warning(f"Error processing KeePass entry {i}: {e}")
                    continue
            
            logger.info(f"Imported {len(passwords)} passwords from KeePass XML")
            return passwords
            
        except ET.ParseError as e:
            logger.error(f"XML parse error: {e}")
            raise InvalidFileFormatError(f"Invalid XML format: {e}")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"File read error: {e}")
            raise ImportError(f"Cannot read file: {e}")

    @staticmethod
    def import_from_bitwarden_json(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из Bitwarden JSON формата"""
        try:
            if os.path.getsize(file_path) > MAX_FILE_SIZE:
                raise FileTooLargeError(f"File too large: {os.path.getsize(file_path)} bytes")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to check file size: {e}")
            raise ImportError(f"Cannot read file: {e}")
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Проверка на BOM
            if content.startswith('\ufeff'):
                content = content[1:]
            
            data = json.loads(content)
            passwords = []
            
            items = data.get('items', [])
            if not isinstance(items, list):
                raise InvalidFileFormatError("Bitwarden JSON: 'items' must be a list")
            
            for item in items:
                try:
                    login = item.get('login', {})
                    password = login.get('password', '')
                    
                    if password and password.strip():
                        password = sanitize_password(password)
                        name = item.get('name', '')
                        username = login.get('username', '')
                        
                        label = sanitize_csv_value(name, 100) if name else "Bitwarden"
                        if username:
                            label += f" ({sanitize_csv_value(username, 50)})"
                        
                        passwords.append({
                            'label': label[:100],
                            'password': password,
                            'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        })
                except (KeyError, ValueError, TypeError) as e:
                    logger.warning(f"Error processing Bitwarden item: {e}")
                    continue
            
            logger.info(f"Imported {len(passwords)} passwords from Bitwarden JSON")
            return passwords
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            raise InvalidFileFormatError(f"Invalid JSON format: {e}")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"File read error: {e}")
            raise ImportError(f"Cannot read file: {e}")

    @staticmethod
    def import_from_1password_csv(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из 1Password CSV формата"""
        try:
            if os.path.getsize(file_path) > MAX_FILE_SIZE:
                raise FileTooLargeError(f"File too large: {os.path.getsize(file_path)} bytes")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to check file size: {e}")
            raise ImportError(f"Cannot read file: {e}")
        
        encoding, content = detect_encoding(file_path, ['utf-8-sig', 'utf-8', 'cp1251'])
        if encoding is None:
            raise ImportError("Cannot detect file encoding")
        
        passwords = []
        line_number = 0
        
        try:
            from io import StringIO
            f = StringIO(content)
            reader = csv.DictReader(f)
            
            for row in reader:
                line_number += 1
                try:
                    title = row.get('title', row.get('Title', ''))
                    password = row.get('password', row.get('Password', ''))
                    username = row.get('username', row.get('Username', ''))
                    url = row.get('url', row.get('URL', ''))
                    
                    if password and password.strip():
                        password = sanitize_password(password)
                        label = sanitize_csv_value(title, 100) if title else f"1Password_{line_number}"
                        
                        if username:
                            label += f" ({sanitize_csv_value(username, 50)})"
                        if url:
                            label += f" - {sanitize_csv_value(url, 100)[:100]}"
                        
                        passwords.append({
                            'label': label[:100],
                            'password': password,
                            'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        })
                except (KeyError, ValueError, TypeError) as e:
                    logger.warning(f"Error processing 1Password line {line_number}: {e}")
                    continue
            
            logger.info(f"Imported {len(passwords)} passwords from 1Password CSV")
            return passwords
            
        except csv.Error as e:
            logger.error(f"CSV parse error at line {line_number}: {e}")
            raise InvalidFileFormatError(f"CSV parsing error: {e}")
        except (OSError, IOError) as e:
            logger.error(f"File read error: {e}")
            raise ImportError(f"Cannot read file: {e}")

    @staticmethod
    def import_from_1pux(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из 1PUX (1Password Unified Export) формата"""
        temp_dir = None
        
        try:
            if os.path.getsize(file_path) > MAX_FILE_SIZE:
                raise FileTooLargeError(f"File too large: {os.path.getsize(file_path)} bytes")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Failed to check file size: {e}")
            raise ImportError(f"Cannot read file: {e}")
        
        try:
            passwords = []
            
            # 1PUX может быть как zip архивом, так и обычным JSON
            if zipfile.is_zipfile(file_path):
                temp_dir = tempfile.mkdtemp()
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    zip_ref.extractall(temp_dir)
                
                export_file = os.path.join(temp_dir, 'export.data')
                if not os.path.exists(export_file):
                    for f in os.listdir(temp_dir):
                        if f.endswith('.json'):
                            export_file = os.path.join(temp_dir, f)
                            break
                
                if not os.path.exists(export_file):
                    raise InvalidFileFormatError("Cannot find export.data in 1PUX archive")
                
                with open(export_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            else:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    if content.startswith('\ufeff'):
                        content = content[1:]
                    data = json.load(content)
            
            items = data.get('items', [])
            if not isinstance(items, list):
                raise InvalidFileFormatError("1PUX: 'items' must be a list")
            
            for item in items:
                try:
                    title = item.get('title', '')
                    
                    password = ''
                    username = ''
                    url = ''
                    
                    fields = item.get('fields', [])
                    if isinstance(fields, list):
                        for field in fields:
                            field_type = field.get('type', '')
                            value = field.get('value', '')
                            purpose = field.get('purpose', '')
                            
                            if field_type == 'PASSWORD' or purpose == 'PASSWORD':
                                password = value
                            elif field_type == 'USERNAME' or purpose == 'USERNAME':
                                username = value
                            elif field_type == 'URL' or purpose == 'URL':
                                url = value
                    
                    if not password:
                        details = item.get('details', {})
                        if isinstance(details, dict):
                            password = details.get('password', '')
                            if not password:
                                password = details.get('passphrase', '')
                            if not password:
                                login_details = details.get('login', {})
                                password = login_details.get('password', '')
                    
                    if password and password.strip():
                        password = sanitize_password(password)
                        label = sanitize_csv_value(title, 100) if title else "1Password_import"
                        
                        if username:
                            label += f" ({sanitize_csv_value(username, 50)})"
                        if url:
                            label += f" - {sanitize_csv_value(url, 100)[:100]}"
                        
                        passwords.append({
                            'label': label[:100],
                            'password': password,
                            'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        })
                except (KeyError, ValueError, TypeError, AttributeError) as e:
                    logger.warning(f"Error processing 1PUX item: {e}")
                    continue
            
            logger.info(f"Imported {len(passwords)} passwords from 1PUX")
            return passwords
            
        except zipfile.BadZipFile:
            # Не zip архив, пробуем как JSON
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    if content.startswith('\ufeff'):
                        content = content[1:]
                    data = json.loads(content)
                
                passwords = []
                items = data.get('items', [])
                for item in items:
                    try:
                        title = item.get('title', '')
                        password = ''
                        username = ''
                        url = ''
                        
                        fields = item.get('fields', [])
                        for field in fields:
                            field_type = field.get('type', '')
                            value = field.get('value', '')
                            if field_type == 'PASSWORD':
                                password = value
                            elif field_type == 'USERNAME':
                                username = value
                            elif field_type == 'URL':
                                url = value
                        
                        if not password:
                            details = item.get('details', {})
                            password = details.get('password', '')
                            if not password:
                                login_details = details.get('login', {})
                                password = login_details.get('password', '')
                        
                        if password and password.strip():
                            password = sanitize_password(password)
                            label = sanitize_csv_value(title, 100) if title else "1Password_import"
                            
                            if username:
                                label += f" ({sanitize_csv_value(username, 50)})"
                            if url:
                                label += f" - {sanitize_csv_value(url, 100)[:100]}"
                            
                            passwords.append({
                                'label': label[:100],
                                'password': password,
                                'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                            })
                    except (KeyError, ValueError, TypeError) as e:
                        continue
                
                return passwords
            except json.JSONDecodeError as e:
                raise InvalidFileFormatError(f"Invalid 1PUX/JSON format: {e}")
        except json.JSONDecodeError as e:
            logger.error(f"1PUX JSON decode error: {e}")
            raise InvalidFileFormatError(f"Invalid 1PUX format: {e}")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"1PUX file read error: {e}")
            raise ImportError(f"Cannot read file: {e}")
        finally:
            if temp_dir and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir, ignore_errors=True)

    @classmethod
    def import_all(cls, parent, lang: str = "RU") -> None:
        """Диалог выбора формата и импорт - с поддержкой 1PUX и проверкой дубликатов"""
        from storage.database import PasswordDB
        from gui.dialogs import CTkMessageBox
        import customtkinter as ctk
        import tkinter as tk
        from localization.lang import LANGUAGES
        
        # Сбрасываем отслеживание дубликатов
        cls.reset_duplicate_tracking()

        L = LANGUAGES.get(lang, LANGUAGES["RU"])

        # Создаём окно
        win = ctk.CTkToplevel(parent)
        win.title(L.get("import_title", "Import Passwords"))
        win.geometry("500x620")
        win.resizable(False, False)
        win.transient(parent)
        win.grab_set()
        win.attributes("-topmost", True)

        # Центрируем окно
        try:
            win.update_idletasks()
            parent_x = parent.winfo_x()
            parent_y = parent.winfo_y()
            parent_width = parent.winfo_width()
            parent_height = parent.winfo_height()
            x = parent_x + (parent_width - 500) // 2
            y = parent_y + (parent_height - 620) // 2
            win.geometry(f"500x620+{x}+{y}")
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Center window error: {e}")
            win.geometry("500x620")

        main_frame = ctk.CTkFrame(win, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=25, pady=20)

        # Заголовок
        try:
            title_label = ctk.CTkLabel(main_frame, text=L.get("import_title", "Import Passwords"),
                                       font=("Segoe UI", 22, "bold"))
            title_label.pack(pady=(0, 10))
        except (tk.TclError, KeyError) as e:
            logger.debug(f"Title error: {e}")

        # Разделитель
        separator = ctk.CTkFrame(main_frame, height=2, fg_color="#2d6a4f")
        separator.pack(fill="x", pady=(0, 15))

        # Формат импорта
        try:
            format_label = ctk.CTkLabel(main_frame, text=L.get("import_format", "Import format:"),
                                       font=("Segoe UI", 15, "bold"))
            format_label.pack(pady=(0, 10))
        except (tk.TclError, KeyError) as e:
            logger.debug(f"Format label error: {e}")

        format_var = tk.StringVar(value="json")

        formats_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        formats_frame.pack(pady=(0, 15))

        formats = [
            ("json", "JSON (Secure Pass Pro)"),
            ("csv", "CSV (Excel / Google Sheets)"),
            ("keepass", "KeePass XML"),
            ("bitwarden", "Bitwarden JSON"),
            ("onepassword", "1Password CSV"),
            ("1pux", "1PUX (1Password Unified Export)")
        ]

        for fmt, text in formats:
            try:
                rb = ctk.CTkRadioButton(formats_frame, text=text, variable=format_var,
                                        value=fmt, font=("Segoe UI", 12))
                rb.pack(anchor="center", pady=4)
            except (tk.TclError, AttributeError) as e:
                logger.debug(f"Radio button error for {fmt}: {e}")

        # Разделитель
        separator2 = ctk.CTkFrame(main_frame, height=1, fg_color="#333333")
        separator2.pack(fill="x", pady=(10, 15))

        # Предупреждение
        warning_frame = ctk.CTkFrame(main_frame, fg_color="#3a2a0a", corner_radius=10)
        warning_frame.pack(fill="x", pady=(0, 20))

        try:
            warning_label = ctk.CTkLabel(warning_frame,
                                        text=L.get("import_warning", "Import only from trusted sources!"),
                                        font=("Segoe UI", 11), text_color="#FFA500")
            warning_label.pack(pady=12, padx=15)
        except (tk.TclError, KeyError) as e:
            logger.debug(f"Warning label error: {e}")

        # Чекбокс для пропуска дубликатов
        skip_duplicates_var = tk.BooleanVar(value=True)
        try:
            skip_duplicates_cb = ctk.CTkCheckBox(
                main_frame,
                text=L.get("skip_duplicates", "Skip duplicate passwords"),
                variable=skip_duplicates_var,
                font=("Segoe UI", 12)
            )
            skip_duplicates_cb.pack(pady=(0, 15))
        except (tk.TclError, KeyError) as e:
            logger.debug(f"Skip duplicates checkbox error: {e}")

        # Фрейм для кнопок
        buttons_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        buttons_frame.pack(fill="x", pady=(10, 0))

        def do_import():
            fmt = format_var.get()
            extensions = {
                "json": ("JSON files", "*.json"),
                "csv": ("CSV files", "*.csv"),
                "keepass": ("KeePass XML", "*.xml"),
                "bitwarden": ("Bitwarden JSON", "*.json"),
                "onepassword": ("1Password CSV", "*.csv"),
                "1pux": ("1PUX files", "*.1pux")
            }

            path = filedialog.askopenfilename(
                title="Select file to import",
                filetypes=[(extensions[fmt][0], extensions[fmt][1]), ("All files", "*.*")]
            )

            if path:
                try:
                    if fmt == "json":
                        passwords = cls.import_from_json(path)
                    elif fmt == "csv":
                        passwords = cls.import_from_csv(path)
                    elif fmt == "keepass":
                        passwords = cls.import_from_keepass_xml(path)
                    elif fmt == "bitwarden":
                        passwords = cls.import_from_bitwarden_json(path)
                    elif fmt == "onepassword":
                        passwords = cls.import_from_1password_csv(path)
                    elif fmt == "1pux":
                        passwords = cls.import_from_1pux(path)
                    else:
                        passwords = []

                    if not passwords:
                        CTkMessageBox.warning(win, L.get("import_title", "Import"),
                                             L.get("import_no_passwords", "No passwords found in file!"))
                        return

                    # Фильтрация дубликатов
                    skip_duplicates = skip_duplicates_var.get()
                    filtered_passwords = []
                    duplicates_count = 0
                    
                    for pwd in passwords:
                        if skip_duplicates and cls._check_and_add_duplicate(pwd['password']):
                            duplicates_count += 1
                            logger.debug(f"Duplicate password skipped: {pwd['label']}")
                        else:
                            filtered_passwords.append(pwd)
                    
                    if duplicates_count > 0:
                        logger.info(f"Skipped {duplicates_count} duplicate passwords")

                    # Показываем предпросмотр
                    preview_lines = []
                    for p in filtered_passwords[:10]:
                        preview_lines.append(f"- {p['label'][:50]}")
                    preview = "\n".join(preview_lines)
                    if len(filtered_passwords) > 10:
                        preview += f"\n... and {len(filtered_passwords) - 10} more"
                    
                    if duplicates_count > 0:
                        preview += f"\n\nSkipped duplicates: {duplicates_count}"

                    if not CTkMessageBox.question(win, L.get("import_title", "Import"),
                        f"{L.get('import_found', 'Passwords found')}: {len(filtered_passwords)}\n\n{preview}\n\n{L.get('import_confirm', 'Import?')}"):
                        return

                    # Импортируем
                    imported = 0
                    failed = 0
                    for pwd in filtered_passwords:
                        try:
                            PasswordDB.save(pwd['label'], pwd['password'])
                            imported += 1
                        except Exception as e:
                            logger.error(f"Import save error: {e}")
                            failed += 1

                    win.destroy()

                    result_msg = L.get("import_success", "Imported: {0}").format(imported)
                    if failed > 0:
                        result_msg += f"\nFailed to import: {failed}"
                    if duplicates_count > 0:
                        result_msg += f"\nSkipped duplicates: {duplicates_count}"

                    CTkMessageBox.info(parent, L.get("import_title", "Import"), result_msg)

                    # Обновляем окно БД
                    if hasattr(parent, '_refresh_db_window'):
                        parent._refresh_db_window()
                    elif hasattr(parent, 'refresh'):
                        parent.refresh()
                    elif hasattr(parent, 'parent') and hasattr(parent.parent, '_refresh_db_window'):
                        parent.parent._refresh_db_window()

                except FileTooLargeError as e:
                    logger.error(f"File too large: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('import_error', 'Import error')}:\nFile too large: {e}")
                except InvalidFileFormatError as e:
                    logger.error(f"Invalid format: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('import_error', 'Import error')}:\nInvalid file format: {e}")
                except MalformedFileError as e:
                    logger.error(f"Malformed file: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('import_error', 'Import error')}:\nFile corrupted: {e}")
                except ImportError as e:
                    logger.error(f"Import error: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('import_error', 'Import error')}:\n{str(e)}")
                except (ValueError, TypeError, AttributeError) as e:
                    logger.error(f"Import error: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('import_error', 'Import error')}:\n{str(e)}")

        # Кнопки
        button_container = ctk.CTkFrame(buttons_frame, fg_color="transparent")
        button_container.pack(expand=True)

        try:
            import_btn = ctk.CTkButton(button_container, text=L.get("ok", "Import"),
                                      command=do_import, width=160, height=40,
                                      fg_color="#2d6a4f", hover_color="#40916c",
                                      corner_radius=20, font=("Segoe UI", 14, "bold"))
            import_btn.pack(side="left", padx=(0, 20))
        except (tk.TclError, KeyError) as e:
            logger.debug(f"Import button error: {e}")

        try:
            cancel_btn = ctk.CTkButton(button_container, text=L.get("cancel", "Cancel"),
                                      command=win.destroy, width=160, height=40,
                                      fg_color="#8b0000", hover_color="#cc0000",
                                      corner_radius=20, font=("Segoe UI", 14, "bold"))
            cancel_btn.pack(side="left")
        except (tk.TclError, KeyError) as e:
            logger.debug(f"Cancel button error: {e}")

        win.after(100, lambda: win.attributes("-topmost", False))