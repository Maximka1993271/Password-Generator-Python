# utils/secure_memory.py
"""
Secure memory management for Python
Безопасная работа с чувствительными данными в памяти
"""
import os
import sys
import ctypes
import gc
import platform
from typing import Optional, Union
from utils.logger import get_logger

logger = get_logger("secure_memory")


def secure_zero_memory(buffer: Union[bytearray, memoryview, ctypes.Array]) -> None:
    """Безопасно обнуляет буфер памяти"""
    if buffer is None:
        return
    try:
        if isinstance(buffer, memoryview):
            buffer = buffer.tobytes()
        if isinstance(buffer, (bytes, bytearray)):
            length = len(buffer)
            addr = ctypes.addressof(ctypes.c_char.from_buffer(buffer))
            ctypes.memset(addr, 0, length)
            ctypes.memset(addr, 0, length)  # Двойной вызов для надёжности
        else:
            length = ctypes.sizeof(buffer)
            ctypes.memset(ctypes.addressof(buffer), 0, length)
    except Exception as e:
        logger.debug(f"Secure zero memory failed: {e}")


def secure_zero_string(s: str) -> None:
    """Пытается безопасно обнулить строку"""
    if not s:
        return
    if s.startswith(('[encrypted', 'enc1:', 'enc2:', 'enc3:')):
        return
    try:
        ba = bytearray(s.encode('utf-8'))
        secure_zero_memory(ba)
        gc.collect()
    except Exception as e:
        logger.debug(f"String clearing failed: {e}")


class SecureBytes:
    """Безопасное хранилище байтов"""
    
    def __init__(self, data: Optional[Union[str, bytes, bytearray]] = None):
        self._data: Optional[bytearray] = None
        if data is not None:
            self.set(data)
    
    def set(self, data: Union[str, bytes, bytearray]) -> None:
        self.clear()
        if isinstance(data, str):
            self._data = bytearray(data.encode('utf-8'))
        elif isinstance(data, bytes):
            self._data = bytearray(data)
        elif isinstance(data, bytearray):
            self._data = bytearray(data)
    
    def get(self) -> Optional[bytes]:
        if self._data is None:
            return None
        return bytes(self._data)
    
    def get_string(self) -> Optional[str]:
        if self._data is None:
            return None
        return self._data.decode('utf-8')
    
    def clear(self) -> None:
        if self._data:
            secure_zero_memory(self._data)
            self._data = None
        gc.collect()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.clear()
    
    def __del__(self):
        self.clear()


class SecurePassword(SecureBytes):
    """Специализированный класс для безопасного хранения паролей"""
    
    def __init__(self, password: Optional[Union[str, bytes, bytearray]] = None):
        super().__init__(password)
        self._copy_count = 0
    
    def get_string(self) -> Optional[str]:
        self._copy_count += 1
        return super().get_string()
    
    def verify(self, other: Union[str, bytes, 'SecurePassword']) -> bool:
        import secrets
        if isinstance(other, SecurePassword):
            other_data = other._data
        elif isinstance(other, str):
            other_data = bytearray(other.encode('utf-8'))
        elif isinstance(other, bytes):
            other_data = bytearray(other)
        else:
            return False
        if self._data is None or other_data is None:
            return False
        if len(self._data) != len(other_data):
            return False
        return secrets.compare_digest(self._data, other_data)
    
    def clear(self) -> None:
        if self._data:
            for _ in range(3):
                secure_zero_memory(self._data)
            self._data = None
        self._copy_count = 0
        gc.collect()


class MemoryGuard:
    """Контекстный менеджер для защиты памяти"""
    
    def __init__(self):
        self.sensitive_data = []
    
    def register(self, data: SecureBytes):
        self.sensitive_data.append(data)
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        for data in self.sensitive_data:
            if data:
                data.clear()
        gc.collect()


def init_secure_memory() -> None:
    """Инициализация системы безопасной памяти"""
    logger.info("Secure memory system initialized")


init_secure_memory()