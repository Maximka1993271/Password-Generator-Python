# utils/secure_memory.py
"""
Secure memory management for Python
Безопасная работа с чувствительными данными в памяти

Secure memory management for Python
Безопасная работа с чувствительными данными в памяти
Безпечна робота з чутливими даними в пам'яті
"""
import os
import sys
import ctypes
import gc
import platform
import time
import threading
from typing import Optional, Union, Any
from utils.logger import get_logger

logger = get_logger("secure_memory")


# ==================== LOW-LEVEL CLEARING FUNCTIONS / НИЗКОУРОВНЕВЫЕ ФУНКЦИИ ОЧИСТКИ / НИЗЬКОРІВНЕВІ ФУНКЦІЇ ОЧИЩЕННЯ ====================

def secure_zero_memory(buffer: Union[bytearray, memoryview, ctypes.Array]) -> None:
    """Safely zero out a memory buffer
    Безопасно обнуляет буфер памяти
    Безпечно обнуляє буфер пам'яті"""
    if buffer is None:
        return
    
    # Multiple passes for security / Множественные проходы для безопасности / Множинні проходи для безпеки
    passes = 3
    
    try:
        for _ in range(passes):
            if isinstance(buffer, memoryview):
                # Convert to bytes for zeroing / Конвертируем для обнуления / Конвертуємо для обнулення
                buffer_bytes = buffer.tobytes()
                if isinstance(buffer_bytes, (bytes, bytearray)):
                    length = len(buffer_bytes)
                    addr = ctypes.addressof(ctypes.c_char.from_buffer(buffer_bytes))
                    ctypes.memset(addr, 0, length)
            elif isinstance(buffer, (bytes, bytearray)):
                length = len(buffer)
                addr = ctypes.addressof(ctypes.c_char.from_buffer(buffer))
                ctypes.memset(addr, 0, length)
            elif hasattr(buffer, '__len__') and hasattr(buffer, '__getitem__'):
                # Fallback for array-like objects / Fallback для массивоподобных объектов / Fallback для масивоподібних об'єктів
                for i in range(len(buffer)):
                    try:
                        buffer[i] = 0
                    except (TypeError, ValueError, IndexError):
                        pass
            else:
                # Try direct ctypes approach / Прямой подход ctypes / Прямий підхід ctypes
                try:
                    length = ctypes.sizeof(buffer)
                    addr = ctypes.addressof(buffer)
                    ctypes.memset(addr, 0, length)
                except (TypeError, AttributeError, ValueError):
                    pass
    except (TypeError, AttributeError, ValueError, OSError, BufferError) as e:
        logger.debug(f"Secure zero memory failed: {e}")
        # Last resort fallback / Последнее средство / Останній засіб
        try:
            for i in range(len(buffer)):
                try:
                    buffer[i] = 0
                except (TypeError, ValueError, IndexError):
                    pass
        except (TypeError, ValueError, AttributeError) as e2:
            logger.debug(f"Fallback zeroing failed: {e2}")


def secure_zero_string(s: str) -> None:
    """Attempt to safely zero out a string
    Пытается безопасно обнулить строку
    Намагається безпечно обнулити рядок"""
    if not s:
        return
    # Do not attempt to clear encrypted data / Не пытаемся очистить зашифрованные данные / Не намагаємося очистити зашифровані дані
    if s.startswith(('[encrypted', 'enc1:', 'enc2:', 'enc3:', '[FILTERED]')):
        return
    
    # Check string length to avoid large allocations
    # Проверяем длину строки, чтобы избежать больших выделений
    # Перевіряємо довжину рядка, щоб уникнути великих виділень
    max_string_length = 10000
    if len(s) > max_string_length:
        logger.debug(f"String too long for secure zeroing: {len(s)} chars")
        return
    
    try:
        ba = bytearray(s.encode('utf-8'))
        secure_zero_memory(ba)
        # Force garbage collection / Принудительный сбор мусора / Примусове збирання сміття
        gc.collect()
        # Additional pass for interned strings / Дополнительный проход для интернированных строк / Додатковий прохід для інтернованих рядків
        try:
            import sys
            if sys.intern(s) is s:
                # String is interned, try to clear reference
                # Строка интернирована, пытаемся очистить ссылку
                # Рядок інтернований, намагаємося очистити посилання
                pass
        except (AttributeError, TypeError):
            pass
    except (UnicodeEncodeError, TypeError, MemoryError, ValueError, OSError) as e:
        logger.debug(f"String clearing failed: {e}")


def secure_zero_dict(data: dict) -> None:
    """Safely clear all values in a dictionary
    Безопасно очищает все значения в словаре
    Безпечно очищає всі значення у словнику"""
    if not data:
        return
    
    try:
        for key in list(data.keys()):
            try:
                value = data[key]
                if isinstance(value, str):
                    secure_zero_string(value)
                elif isinstance(value, (bytes, bytearray)):
                    secure_zero_memory(value)
                elif hasattr(value, 'clear'):
                    try:
                        value.clear()
                    except (AttributeError, RuntimeError):
                        pass
                data[key] = None
            except (KeyError, RuntimeError, AttributeError, TypeError) as e:
                logger.debug(f"Dict value clearing error: {e}")
        data.clear()
    except (RuntimeError, AttributeError, TypeError) as e:
        logger.debug(f"Dict clearing error: {e}")


# ==================== SECURE STORAGE CLASSES / КЛАССЫ БЕЗОПАСНОГО ХРАНЕНИЯ / КЛАСИ БЕЗПЕЧНОГО ЗБЕРІГАННЯ ====================

class SecureBytes:
    """Secure byte storage with automatic clearing
    Безопасное хранилище байтов с автоматической очисткой
    Безпечне сховище байтів з автоматичним очищенням"""
    
    __slots__ = ('_data', '_cleared', '_creation_time')
    
    def __init__(self, data: Optional[Union[str, bytes, bytearray]] = None):
        self._data: Optional[bytearray] = None
        self._cleared = False
        self._creation_time = time.time()
        if data is not None:
            self.set(data)
    
    def set(self, data: Union[str, bytes, bytearray]) -> None:
        """Set data with clearing of previous data
        Устанавливает данные с очисткой предыдущих
        Встановлює дані з очищенням попередніх"""
        self.clear()
        try:
            if isinstance(data, str):
                self._data = bytearray(data.encode('utf-8'))
            elif isinstance(data, bytes):
                self._data = bytearray(data)
            elif isinstance(data, bytearray):
                self._data = bytearray(data)
            else:
                raise TypeError(f"Unsupported data type: {type(data).__name__}")
            self._cleared = False
        except (UnicodeEncodeError, TypeError, MemoryError, ValueError) as e:
            logger.error(f"Failed to set secure data: {e}")
            self._data = None
            self._cleared = True
    
    def get(self) -> Optional[bytes]:
        """Return a copy of the data (without clearing)
        Возвращает копию данных (без очистки)
        Повертає копію даних (без очищення)"""
        if self._data is None or self._cleared:
            return None
        try:
            return bytes(self._data)
        except (TypeError, MemoryError, ValueError) as e:
            logger.debug(f"Failed to get secure data: {e}")
            return None
    
    def get_string(self) -> Optional[str]:
        """Return a string (without clearing)
        Возвращает строку (без очистки)
        Повертає рядок (без очищення)"""
        data = self.get()
        if data is None:
            return None
        try:
            return data.decode('utf-8')
        except (UnicodeDecodeError, ValueError) as e:
            logger.debug(f"Failed to decode secure data: {e}")
            return None
    
    def clear(self) -> None:
        """Clear data from memory / Очищает данные из памяти / Очищує дані з пам'яті"""
        if self._data:
            try:
                secure_zero_memory(self._data)
                # Additional pass for safety / Дополнительный проход для безопасности / Додатковий прохід для безпеки
                secure_zero_memory(self._data)
                self._data = None
            except (TypeError, ValueError, AttributeError, OSError) as e:
                logger.debug(f"SecureBytes clear error: {e}")
                self._data = None
        self._cleared = True
        try:
            gc.collect()
        except (RuntimeError, ImportError) as e:
            logger.debug(f"GC collect error: {e}")
    
    def is_cleared(self) -> bool:
        """Check if data has been cleared / Проверяет, очищены ли данные / Перевіряє, чи очищено дані"""
        return self._cleared
    
    def get_age(self) -> float:
        """Get age of object in seconds / Возвращает возраст объекта в секундах / Повертає вік об'єкта в секундах"""
        return time.time() - self._creation_time
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.clear()
    
    def __del__(self):
        self.clear()


class SecurePassword(SecureBytes):
    """Specialized class for secure password storage
    Специализированный класс для безопасного хранения паролей
    Спеціалізований клас для безпечного зберігання паролів"""
    
    __slots__ = ('_copy_count', '_max_access_warning', '_access_times')
    
    def __init__(self, password: Optional[Union[str, bytes, bytearray]] = None):
        super().__init__(password)
        self._copy_count = 0
        self._max_access_warning = 100
        self._access_times: list = []
    
    def get_string(self) -> Optional[str]:
        """Return password string (with access tracking)
        Возвращает строку пароля (с отслеживанием доступа)
        Повертає рядок пароля (з відстеженням доступу)"""
        self._copy_count += 1
        self._access_times.append(time.time())
        
        # Clean old access times / Очищаем старые времена доступа / Очищуємо старі часи доступу
        try:
            current_time = time.time()
            self._access_times = [t for t in self._access_times if current_time - t < 60]
        except (ValueError, TypeError, RuntimeError) as e:
            logger.debug(f"Access times cleanup error: {e}")
        
        # Warning on frequent access / Предупреждение при частом доступе / Попередження при частому доступі
        if self._copy_count > self._max_access_warning:
            logger.warning(f"SecurePassword accessed {self._copy_count} times")
        
        return super().get_string()
    
    def verify(self, other: Union[str, bytes, 'SecurePassword']) -> bool:
        """Secure password comparison (resistant to timing attacks)
        Безопасное сравнение паролей (устойчивое к timing attack)
        Безпечне порівняння паролів (стійке до timing attack)"""
        import secrets
        
        if self._data is None or self._cleared:
            return False
        
        other_data = None
        try:
            if isinstance(other, SecurePassword):
                other_data = other._data
            elif isinstance(other, str):
                other_data = bytearray(other.encode('utf-8'))
            elif isinstance(other, bytes):
                other_data = bytearray(other)
            else:
                raise TypeError(f"Unsupported comparison type: {type(other).__name__}")
        except (TypeError, ValueError, UnicodeEncodeError) as e:
            logger.debug(f"Comparison type error: {e}")
            return False
        
        if other_data is None:
            return False
        
        if len(self._data) != len(other_data):
            # Clear temporary data / Очищаем временные данные / Очищуємо тимчасові дані
            if other_data is not other._data:
                try:
                    secure_zero_memory(other_data)
                except (TypeError, ValueError, AttributeError):
                    pass
            return False
        
        try:
            # Use secrets.compare_digest for protection against timing attacks
            # Используем secrets.compare_digest для защиты от timing attack
            # Використовуємо secrets.compare_digest для захисту від timing attack
            result = secrets.compare_digest(self._data, other_data)
        except (TypeError, ValueError) as e:
            logger.debug(f"Compare digest error: {e}")
            result = False
        finally:
            # Clear temporary data / Очищаем временные данные / Очищуємо тимчасові дані
            if other_data is not getattr(other, '_data', None):
                try:
                    secure_zero_memory(other_data)
                except (TypeError, ValueError, AttributeError):
                    pass
        
        return result
    
    def get_access_count(self) -> int:
        """Return number of accesses to the password
        Возвращает количество обращений к паролю
        Повертає кількість звернень до пароля"""
        return self._copy_count
    
    def get_access_frequency(self) -> float:
        """Get access frequency (accesses per minute)
        Получить частоту доступа (доступов в минуту)
        Отримати частоту доступу (доступів за хвилину)"""
        if not self._access_times:
            return 0.0
        try:
            oldest = min(self._access_times)
            newest = max(self._access_times)
            duration = newest - oldest
            if duration <= 0:
                return float(self._copy_count)
            return self._copy_count / (duration / 60.0)
        except (ValueError, TypeError, RuntimeError) as e:
            logger.debug(f"Frequency calculation error: {e}")
            return float(self._copy_count)
    
    def clear(self) -> None:
        """Clear password from memory / Очищает пароль из памяти / Очищує пароль з пам'яті"""
        super().clear()
        self._copy_count = 0
        self._access_times = []
    
    def __str__(self) -> str:
        return "<SecurePassword>"
    
    def __repr__(self) -> str:
        return f"<SecurePassword length={len(self._data) if self._data else 0}>"


class MemoryGuard:
    """Context manager for memory protection with memory pressure handling
    Контекстный менеджер для защиты памяти с обработкой давления памяти
    Контекстний менеджер для захисту пам'яті з обробкою тиску пам'яті"""
    
    __slots__ = ('sensitive_data', '_pressure_callback')
    
    def __init__(self, pressure_callback=None):
        self.sensitive_data = []
        self._pressure_callback = pressure_callback
        
        # Register memory pressure callback if available
        # Регистрируем callback давления памяти если доступен
        # Реєструємо callback тиску пам'яті якщо доступний
        if pressure_callback is None:
            try:
                import gc
                self._pressure_callback = self._handle_memory_pressure
            except ImportError:
                pass
    
    def register(self, data: SecureBytes) -> None:
        """Register data for automatic clearing
        Регистрирует данные для автоматической очистки
        Реєструє дані для автоматичного очищення"""
        if data not in self.sensitive_data:
            self.sensitive_data.append(data)
    
    def _handle_memory_pressure(self) -> None:
        """Handle memory pressure by clearing old data
        Обрабатывает давление памяти очисткой старых данных
        Обробляє тиск пам'яті очищенням старих даних"""
        try:
            current_time = time.time()
            # Clear data older than 5 minutes
            # Очищаем данные старше 5 минут
            # Очищуємо дані старші 5 хвилин
            for data in self.sensitive_data[:]:
                try:
                    if hasattr(data, 'get_age') and data.get_age() > 300:
                        data.clear()
                        if data in self.sensitive_data:
                            self.sensitive_data.remove(data)
                except (AttributeError, RuntimeError, TypeError) as e:
                    logger.debug(f"Memory pressure cleanup error: {e}")
        except (RuntimeError, AttributeError, TypeError) as e:
            logger.debug(f"Memory pressure handler error: {e}")
    
    def clear(self) -> None:
        """Clear all registered data / Очищает все зарегистрированные данные / Очищує всі зареєстровані дані"""
        for data in self.sensitive_data:
            try:
                data.clear()
            except (AttributeError, RuntimeError, TypeError) as e:
                logger.debug(f"Data clear error: {e}")
        self.sensitive_data.clear()
        try:
            gc.collect()
        except (RuntimeError, ImportError) as e:
            logger.debug(f"GC collect error: {e}")
    
    def clear_by_age(self, max_age_seconds: int = 300) -> int:
        """Clear data older than specified age
        Очищает данные старше указанного возраста
        Очищує дані старші зазначеного віку"""
        cleared_count = 0
        current_time = time.time()
        
        for data in self.sensitive_data[:]:
            try:
                if hasattr(data, 'get_age') and data.get_age() > max_age_seconds:
                    data.clear()
                    if data in self.sensitive_data:
                        self.sensitive_data.remove(data)
                    cleared_count += 1
            except (AttributeError, RuntimeError, TypeError) as e:
                logger.debug(f"Age-based clear error: {e}")
        
        if cleared_count > 0:
            try:
                gc.collect()
            except (RuntimeError, ImportError):
                pass
        
        return cleared_count
    
    def get_registered_count(self) -> int:
        """Get number of registered sensitive objects
        Получить количество зарегистрированных чувствительных объектов
        Отримати кількість зареєстрованих чутливих об'єктів"""
        return len(self.sensitive_data)
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.clear()


# ==================== MEMORY PRESSURE MONITORING / МОНИТОРИНГ ДАВЛЕНИЯ ПАМЯТИ / МОНІТОРИНГ ТИСКУ ПАМ'ЯТІ ====================

_memory_pressure_monitor: Optional[threading.Thread] = None
_memory_pressure_stop = False


def _monitor_memory_pressure(guard: MemoryGuard, interval: int = 60) -> None:
    """Background thread for memory pressure monitoring
    Фоновый поток для мониторинга давления памяти
    Фоновий потік для моніторингу тиску пам'яті"""
    global _memory_pressure_stop
    
    while not _memory_pressure_stop:
        try:
            time.sleep(interval)
            if hasattr(guard, 'clear_by_age'):
                guard.clear_by_age(300)  # Clear data older than 5 minutes
        except (RuntimeError, OSError, AttributeError, TypeError) as e:
            logger.debug(f"Memory pressure monitor error: {e}")


def start_memory_pressure_monitoring(guard: MemoryGuard, interval: int = 60) -> None:
    """Start background memory pressure monitoring
    Запустить фоновый мониторинг давления памяти
    Запустити фоновий моніторинг тиску пам'яті"""
    global _memory_pressure_monitor, _memory_pressure_stop
    
    if _memory_pressure_monitor is not None and _memory_pressure_monitor.is_alive():
        return
    
    _memory_pressure_stop = False
    _memory_pressure_monitor = threading.Thread(
        target=_monitor_memory_pressure,
        args=(guard, interval),
        daemon=True
    )
    try:
        _memory_pressure_monitor.start()
        logger.info(f"Memory pressure monitoring started (interval: {interval}s)")
    except (RuntimeError, threading.ThreadError) as e:
        logger.debug(f"Failed to start memory pressure monitor: {e}")


def stop_memory_pressure_monitoring() -> None:
    """Stop background memory pressure monitoring
    Остановить фоновый мониторинг давления памяти
    Зупинити фоновий моніторинг тиску пам'яті"""
    global _memory_pressure_monitor, _memory_pressure_stop
    
    _memory_pressure_stop = True
    if _memory_pressure_monitor and _memory_pressure_monitor.is_alive():
        try:
            _memory_pressure_monitor.join(timeout=2.0)
        except (RuntimeError, threading.ThreadError) as e:
            logger.debug(f"Memory pressure monitor join error: {e}")
    _memory_pressure_monitor = None
    logger.info("Memory pressure monitoring stopped")


# ==================== HELPER FUNCTIONS / ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ / ДОПОМІЖНІ ФУНКЦІЇ ====================

def wipe_variable(var: Any) -> None:
    """Attempt to safely delete a variable and clear its data
    Пытается безопасно удалить переменную и очистить её данные
    Намагається безпечно видалити змінну та очистити її дані"""
    if var is None:
        return
    
    try:
        if isinstance(var, str):
            secure_zero_string(var)
        elif isinstance(var, (bytes, bytearray)):
            secure_zero_memory(var)
        elif isinstance(var, dict):
            secure_zero_dict(var)
        elif isinstance(var, list):
            try:
                for i, item in enumerate(var):
                    if isinstance(item, str):
                        secure_zero_string(item)
                    elif isinstance(item, (bytes, bytearray)):
                        secure_zero_memory(item)
                    var[i] = None
                var.clear()
            except (TypeError, RuntimeError, AttributeError) as e:
                logger.debug(f"List clearing error: {e}")
        elif hasattr(var, 'clear'):
            try:
                var.clear()
            except (AttributeError, RuntimeError) as e:
                logger.debug(f"Object clear error: {e}")
    except (TypeError, ValueError, AttributeError, RuntimeError, OSError) as e:
        logger.debug(f"Variable wiping failed: {e}")
    finally:
        try:
            del var
        except (NameError, ReferenceError):
            pass


def is_memory_secure() -> bool:
    """Check if secure memory mechanisms are available
    Проверяет, доступны ли механизмы безопасной памяти
    Перевіряє, чи доступні механізми безпечної пам'яті"""
    try:
        test_buffer = bytearray(10)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(test_buffer)), 0, 10)
        return True
    except (TypeError, AttributeError, OSError, ValueError, BufferError) as e:
        logger.debug(f"Memory security check failed: {e}")
        return False


def get_memory_usage() -> Optional[int]:
    """Get current memory usage of the process in bytes
    Получить текущее использование памяти процессом в байтах
    Отримати поточне використання пам'яті процесом у байтах"""
    try:
        import psutil
        process = psutil.Process()
        return process.memory_info().rss
    except ImportError:
        pass
    except (OSError, AttributeError, ValueError, RuntimeError) as e:
        logger.debug(f"Memory usage check failed: {e}")
    return None


def force_memory_cleanup() -> None:
    """Force memory cleanup including garbage collection
    Принудительная очистка памяти включая сборщик мусора
    Примусове очищення пам'яті включаючи збирач сміття"""
    try:
        gc.collect()
        gc.collect()  # Double collect for safety / Двойной сбор для безопасности / Подвійний збір для безпеки
    except (RuntimeError, ImportError) as e:
        logger.debug(f"GC collect error: {e}")


# ==================== INITIALIZATION / ИНИЦИАЛИЗАЦИЯ / ІНІЦІАЛІЗАЦІЯ ====================

def init_secure_memory() -> None:
    """Initialize the secure memory system
    Инициализация системы безопасной памяти
    Ініціалізація системи безпечної пам'яті"""
    if not is_memory_secure():
        logger.warning("Secure memory fallback mode active - some protections may be limited")
    else:
        logger.info("Secure memory system initialized")
    
    # Force initial cleanup / Принудительная начальная очистка / Примусове початкове очищення
    force_memory_cleanup()


# Initialize on module import / Выполняем инициализацию при импорте модуля / Виконуємо ініціалізацію при імпорті модуля
init_secure_memory()


# Export main classes and functions / Экспортируем основные классы и функции / Експортуємо основні класи та функції
__all__ = [
    'secure_zero_memory',
    'secure_zero_string',
    'secure_zero_dict',
    'SecureBytes',
    'SecurePassword',
    'MemoryGuard',
    'wipe_variable',
    'is_memory_secure',
    'init_secure_memory',
    'start_memory_pressure_monitoring',
    'stop_memory_pressure_monitoring',
    'get_memory_usage',
    'force_memory_cleanup',
]