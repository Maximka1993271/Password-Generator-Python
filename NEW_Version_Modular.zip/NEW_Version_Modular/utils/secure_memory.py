# utils/secure_memory.py
"""
Secure memory management for Python
Безопасная работа с чувствительными данными в памяти

Secure memory management for Python
Безопасная работа с чувствительными данными в памяти
Безпечна робота з чутливими даними в пам'яті
"""
import os
import sys
import ctypes
import gc
import platform
import time
import threading
from typing import Optional, Union, Any
from utils.logger import get_logger

logger = get_logger("secure_memory")


# ==================== LOW-LEVEL CLEARING FUNCTIONS / НИЗКОУРОВНЕВЫЕ ФУНКЦИИ ОЧИСТКИ / НИЗЬКОРІВНЕВІ ФУНКЦІЇ ОЧИЩЕННЯ ====================

def secure_zero_memory(buffer: Union[bytearray, memoryview, ctypes.Array]) -> None:
    """Safely zero out a memory buffer
    Безопасно обнуляет буфер памяти
    Безпечно обнуляє буфер пам'яті"""
    if buffer is None:
        return
    try:
        if isinstance(buffer, memoryview):
            buffer = buffer.tobytes()
        if isinstance(buffer, (bytes, bytearray)):
            length = len(buffer)
            addr = ctypes.addressof(ctypes.c_char.from_buffer(buffer))
            ctypes.memset(addr, 0, length)
        else:
            length = ctypes.sizeof(buffer)
            addr = ctypes.addressof(buffer)
            ctypes.memset(addr, 0, length)
    except Exception as e:
        logger.debug(f"Secure zero memory failed: {e}")


def secure_zero_string(s: str) -> None:
    """Attempt to safely zero out a string
    Пытается безопасно обнулить строку
    Намагається безпечно обнулити рядок"""
    if not s:
        return
    # Do not attempt to clear encrypted data / Не пытаемся очистить зашифрованные данные / Не намагаємося очистити зашифровані дані
    if s.startswith(('[encrypted', 'enc1:', 'enc2:', 'enc3:', '[FILTERED]')):
        return
    try:
        ba = bytearray(s.encode('utf-8'))
        secure_zero_memory(ba)
        gc.collect()
    except Exception as e:
        logger.debug(f"String clearing failed: {e}")


# ==================== SECURE STORAGE CLASSES / КЛАССЫ БЕЗОПАСНОГО ХРАНЕНИЯ / КЛАСИ БЕЗПЕЧНОГО ЗБЕРІГАННЯ ====================

class SecureBytes:
    """Secure byte storage with automatic clearing
    Безопасное хранилище байтов с автоматической очисткой
    Безпечне сховище байтів з автоматичним очищенням"""
    
    __slots__ = ('_data', '_cleared')
    
    def __init__(self, data: Optional[Union[str, bytes, bytearray]] = None):
        self._data: Optional[bytearray] = None
        self._cleared = False
        if data is not None:
            self.set(data)
    
    def set(self, data: Union[str, bytes, bytearray]) -> None:
        """Set data with clearing of previous data
        Устанавливает данные с очисткой предыдущих
        Встановлює дані з очищенням попередніх"""
        self.clear()
        if isinstance(data, str):
            self._data = bytearray(data.encode('utf-8'))
        elif isinstance(data, bytes):
            self._data = bytearray(data)
        elif isinstance(data, bytearray):
            self._data = bytearray(data)
        self._cleared = False
    
    def get(self) -> Optional[bytes]:
        """Return a copy of the data (without clearing)
        Возвращает копию данных (без очистки)
        Повертає копію даних (без очищення)"""
        if self._data is None or self._cleared:
            return None
        return bytes(self._data)
    
    def get_string(self) -> Optional[str]:
        """Return a string (without clearing)
        Возвращает строку (без очистки)
        Повертає рядок (без очищення)"""
        data = self.get()
        if data is None:
            return None
        try:
            return data.decode('utf-8')
        except UnicodeDecodeError:
            return None
    
    def clear(self) -> None:
        """Clear data from memory / Очищает данные из памяти / Очищує дані з пам'яті"""
        if self._data:
            secure_zero_memory(self._data)
            self._data = None
        self._cleared = True
        gc.collect()
    
    def is_cleared(self) -> bool:
        """Check if data has been cleared / Проверяет, очищены ли данные / Перевіряє, чи очищено дані"""
        return self._cleared
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.clear()
    
    def __del__(self):
        self.clear()


class SecurePassword(SecureBytes):
    """Specialized class for secure password storage
    Специализированный класс для безопасного хранения паролей
    Спеціалізований клас для безпечного зберігання паролів"""
    
    __slots__ = ('_copy_count',)
    
    def __init__(self, password: Optional[Union[str, bytes, bytearray]] = None):
        super().__init__(password)
        self._copy_count = 0
    
    def get_string(self) -> Optional[str]:
        """Return password string (with access tracking)
        Возвращает строку пароля (с отслеживанием доступа)
        Повертає рядок пароля (з відстеженням доступу)"""
        self._copy_count += 1
        # Warning on frequent access (but not blocking) / Предупреждение при частом доступе (но не блокируем) / Попередження при частому доступі (але не блокуємо)
        if self._copy_count > 100:
            logger.warning(f"SecurePassword accessed {self._copy_count} times")
        return super().get_string()
    
    def verify(self, other: Union[str, bytes, 'SecurePassword']) -> bool:
        """Secure password comparison (resistant to timing attacks)
        Безопасное сравнение паролей (устойчивое к timing attack)
        Безпечне порівняння паролів (стійке до timing attack)"""
        import secrets
        
        if self._data is None or self._cleared:
            return False
        
        if isinstance(other, SecurePassword):
            other_data = other._data
        elif isinstance(other, str):
            other_data = bytearray(other.encode('utf-8'))
        elif isinstance(other, bytes):
            other_data = bytearray(other)
        else:
            return False
        
        if other_data is None:
            return False
        
        if len(self._data) != len(other_data):
            return False
        
        # Use secrets.compare_digest for protection against timing attacks
        # Используем secrets.compare_digest для защиты от timing attack
        # Використовуємо secrets.compare_digest для захисту від timing attack
        result = secrets.compare_digest(self._data, other_data)
        
        # Clear temporary data / Очищаем временные данные / Очищуємо тимчасові дані
        if other_data is not other._data:
            secure_zero_memory(other_data)
        
        return result
    
    def get_access_count(self) -> int:
        """Return number of accesses to the password
        Возвращает количество обращений к паролю
        Повертає кількість звернень до пароля"""
        return self._copy_count
    
    def clear(self) -> None:
        """Clear password from memory / Очищает пароль из памяти / Очищує пароль з пам'яті"""
        super().clear()
        self._copy_count = 0
    
    def __str__(self) -> str:
        return "<SecurePassword>"
    
    def __repr__(self) -> str:
        return f"<SecurePassword length={len(self._data) if self._data else 0}>"


class MemoryGuard:
    """Context manager for memory protection
    Контекстный менеджер для защиты памяти
    Контекстний менеджер для захисту пам'яті"""
    
    __slots__ = ('sensitive_data',)
    
    def __init__(self):
        self.sensitive_data = []
    
    def register(self, data: SecureBytes) -> None:
        """Register data for automatic clearing
        Регистрирует данные для автоматической очистки
        Реєструє дані для автоматичного очищення"""
        if data not in self.sensitive_data:
            self.sensitive_data.append(data)
    
    def clear(self) -> None:
        """Clear all registered data / Очищает все зарегистрированные данные / Очищує всі зареєстровані дані"""
        for data in self.sensitive_data:
            try:
                data.clear()
            except Exception:
                pass
        self.sensitive_data.clear()
        gc.collect()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.clear()


# ==================== HELPER FUNCTIONS / ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ / ДОПОМІЖНІ ФУНКЦІЇ ====================

def wipe_variable(var: Any) -> None:
    """Attempt to safely delete a variable and clear its data
    Пытается безопасно удалить переменную и очистить её данные
    Намагається безпечно видалити змінну та очистити її дані"""
    if var is None:
        return
    
    try:
        if isinstance(var, str):
            secure_zero_string(var)
        elif isinstance(var, (bytes, bytearray)):
            secure_zero_memory(var)
        elif hasattr(var, 'clear'):
            var.clear()
    except Exception as e:
        logger.debug(f"Variable wiping failed: {e}")
    finally:
        del var


def is_memory_secure() -> bool:
    """Check if secure memory mechanisms are available
    Проверяет, доступны ли механизмы безопасной памяти
    Перевіряє, чи доступні механізми безпечної пам'яті"""
    try:
        test_buffer = bytearray(10)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(test_buffer)), 0, 10)
        return True
    except Exception:
        return False


# ==================== INITIALIZATION / ИНИЦИАЛИЗАЦИЯ / ІНІЦІАЛІЗАЦІЯ ====================

def init_secure_memory() -> None:
    """Initialize the secure memory system
    Инициализация системы безопасной памяти
    Ініціалізація системи безпечної пам'яті"""
    if not is_memory_secure():
        logger.warning("Secure memory fallback mode active - some protections may be limited")
    else:
        logger.info("Secure memory system initialized")


# Initialize on module import / Выполняем инициализацию при импорте модуля / Виконуємо ініціалізацію при імпорті модуля
init_secure_memory()


# Export main classes and functions / Экспортируем основные классы и функции / Експортуємо основні класи та функції
__all__ = [
    'secure_zero_memory',
    'secure_zero_string',
    'SecureBytes',
    'SecurePassword',
    'MemoryGuard',
    'wipe_variable',
    'is_memory_secure',
    'init_secure_memory',
]