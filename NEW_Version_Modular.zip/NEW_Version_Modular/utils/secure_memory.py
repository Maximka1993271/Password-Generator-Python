# utils/secure_memory.py
"""
Secure memory management for Python
Безопасная работа с чувствительными данными в памяти
"""
import os
import sys
import ctypes
import gc
import platform
import time
import threading
from typing import Optional, Union, Any
from utils.logger import get_logger

logger = get_logger("secure_memory")


# ==================== НИЗКОУРОВНЕВЫЕ ФУНКЦИИ ОЧИСТКИ ====================

def secure_zero_memory(buffer: Union[bytearray, memoryview, ctypes.Array]) -> None:
    """Безопасно обнуляет буфер памяти"""
    if buffer is None:
        return
    try:
        if isinstance(buffer, memoryview):
            buffer = buffer.tobytes()
        if isinstance(buffer, (bytes, bytearray)):
            length = len(buffer)
            addr = ctypes.addressof(ctypes.c_char.from_buffer(buffer))
            ctypes.memset(addr, 0, length)
        else:
            length = ctypes.sizeof(buffer)
            addr = ctypes.addressof(buffer)
            ctypes.memset(addr, 0, length)
    except Exception as e:
        logger.debug(f"Secure zero memory failed: {e}")


def secure_zero_string(s: str) -> None:
    """Пытается безопасно обнулить строку"""
    if not s:
        return
    # Не пытаемся очистить зашифрованные данные
    if s.startswith(('[encrypted', 'enc1:', 'enc2:', 'enc3:', '[FILTERED]')):
        return
    try:
        ba = bytearray(s.encode('utf-8'))
        secure_zero_memory(ba)
        gc.collect()
    except Exception as e:
        logger.debug(f"String clearing failed: {e}")


# ==================== КЛАССЫ БЕЗОПАСНОГО ХРАНЕНИЯ ====================

class SecureBytes:
    """Безопасное хранилище байтов с автоматической очисткой"""
    
    __slots__ = ('_data', '_cleared')
    
    def __init__(self, data: Optional[Union[str, bytes, bytearray]] = None):
        self._data: Optional[bytearray] = None
        self._cleared = False
        if data is not None:
            self.set(data)
    
    def set(self, data: Union[str, bytes, bytearray]) -> None:
        """Устанавливает данные с очисткой предыдущих"""
        self.clear()
        if isinstance(data, str):
            self._data = bytearray(data.encode('utf-8'))
        elif isinstance(data, bytes):
            self._data = bytearray(data)
        elif isinstance(data, bytearray):
            self._data = bytearray(data)
        self._cleared = False
    
    def get(self) -> Optional[bytes]:
        """Возвращает копию данных (без очистки)"""
        if self._data is None or self._cleared:
            return None
        return bytes(self._data)
    
    def get_string(self) -> Optional[str]:
        """Возвращает строку (без очистки)"""
        data = self.get()
        if data is None:
            return None
        try:
            return data.decode('utf-8')
        except UnicodeDecodeError:
            return None
    
    def clear(self) -> None:
        """Очищает данные из памяти"""
        if self._data:
            secure_zero_memory(self._data)
            self._data = None
        self._cleared = True
        gc.collect()
    
    def is_cleared(self) -> bool:
        """Проверяет, очищены ли данные"""
        return self._cleared
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.clear()
    
    def __del__(self):
        self.clear()


class SecurePassword(SecureBytes):
    """Специализированный класс для безопасного хранения паролей"""
    
    __slots__ = ('_copy_count',)
    
    def __init__(self, password: Optional[Union[str, bytes, bytearray]] = None):
        super().__init__(password)
        self._copy_count = 0
    
    def get_string(self) -> Optional[str]:
        """Возвращает строку пароля (с отслеживанием доступа)"""
        self._copy_count += 1
        # Предупреждение при частом доступе (но не блокируем)
        if self._copy_count > 100:
            logger.warning(f"SecurePassword accessed {self._copy_count} times")
        return super().get_string()
    
    def verify(self, other: Union[str, bytes, 'SecurePassword']) -> bool:
        """Безопасное сравнение паролей (устойчивое к timing attack)"""
        import secrets
        
        if self._data is None or self._cleared:
            return False
        
        if isinstance(other, SecurePassword):
            other_data = other._data
        elif isinstance(other, str):
            other_data = bytearray(other.encode('utf-8'))
        elif isinstance(other, bytes):
            other_data = bytearray(other)
        else:
            return False
        
        if other_data is None:
            return False
        
        if len(self._data) != len(other_data):
            return False
        
        # Используем secrets.compare_digest для защиты от timing attack
        result = secrets.compare_digest(self._data, other_data)
        
        # Очищаем временные данные
        if other_data is not other._data:
            secure_zero_memory(other_data)
        
        return result
    
    def get_access_count(self) -> int:
        """Возвращает количество обращений к паролю"""
        return self._copy_count
    
    def clear(self) -> None:
        """Очищает пароль из памяти"""
        super().clear()
        self._copy_count = 0
    
    def __str__(self) -> str:
        return "<SecurePassword>"
    
    def __repr__(self) -> str:
        return f"<SecurePassword length={len(self._data) if self._data else 0}>"


class MemoryGuard:
    """Контекстный менеджер для защиты памяти"""
    
    __slots__ = ('sensitive_data',)
    
    def __init__(self):
        self.sensitive_data = []
    
    def register(self, data: SecureBytes) -> None:
        """Регистрирует данные для автоматической очистки"""
        if data not in self.sensitive_data:
            self.sensitive_data.append(data)
    
    def clear(self) -> None:
        """Очищает все зарегистрированные данные"""
        for data in self.sensitive_data:
            try:
                data.clear()
            except Exception:
                pass
        self.sensitive_data.clear()
        gc.collect()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.clear()


# ==================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ====================

def wipe_variable(var: Any) -> None:
    """Пытается безопасно удалить переменную и очистить её данные"""
    if var is None:
        return
    
    try:
        if isinstance(var, str):
            secure_zero_string(var)
        elif isinstance(var, (bytes, bytearray)):
            secure_zero_memory(var)
        elif hasattr(var, 'clear'):
            var.clear()
    except Exception as e:
        logger.debug(f"Variable wiping failed: {e}")
    finally:
        del var


def is_memory_secure() -> bool:
    """Проверяет, доступны ли механизмы безопасной памяти"""
    try:
        test_buffer = bytearray(10)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(test_buffer)), 0, 10)
        return True
    except Exception:
        return False


# ==================== ИНИЦИАЛИЗАЦИЯ ====================

def init_secure_memory() -> None:
    """Инициализация системы безопасной памяти"""
    if not is_memory_secure():
        logger.warning("Secure memory fallback mode active - some protections may be limited")
    else:
        logger.info("Secure memory system initialized")


# Выполняем инициализацию при импорте модуля
init_secure_memory()


# Экспортируем основные классы и функции
__all__ = [
    'secure_zero_memory',
    'secure_zero_string',
    'SecureBytes',
    'SecurePassword',
    'MemoryGuard',
    'wipe_variable',
    'is_memory_secure',
    'init_secure_memory',
]