"""
Utils module - helper functions
"""
from utils.helpers import (
    get_global_radius, set_global_radius, center_screen,
    get_resource_path, play_sound, is_windows, is_macos, is_linux,
    apply_window_rounding, set_window_icon
)
from utils.paths import (
    get_base_dir, get_config_dir, get_config_file, get_db_file,
    get_salt_file, get_master_file, get_uuid_file, get_logs_dir, hide_dir
)
from utils.logger import get_logger, log_exception, log_crash_report, SecureLogger

__all__ = [
    'get_global_radius', 'set_global_radius', 'center_screen',
    'get_resource_path', 'play_sound', 'is_windows', 'is_macos', 'is_linux',
    'apply_window_rounding', 'set_window_icon',
    'get_base_dir', 'get_config_dir', 'get_config_file', 'get_db_file',
    'get_salt_file', 'get_master_file', 'get_uuid_file', 'get_logs_dir', 'hide_dir',
    'get_logger', 'log_exception', 'log_crash_report', 'SecureLogger'
]
