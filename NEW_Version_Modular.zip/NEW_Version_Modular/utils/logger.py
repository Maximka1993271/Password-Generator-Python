"""
Logging subsystem for SecurePassPro with sensitive data filtering
"""
import os
import sys
import logging
import logging.handlers
import re
from datetime import datetime
from typing import Optional


class SensitiveDataFilter(logging.Filter):
    """Фильтр для удаления конфиденциальных данных из логов"""
    
    # Паттерны для поиска конфиденциальных данных
    PATTERNS = [
        # Мастер-пароль
        (r'(master["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
        # Пароль
        (r'(password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
        # Ключ
        (r'(key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
        # Секрет
        (r'(secret["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
        # Токен
        (r'(token["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
        # Длинные base64 строки (потенциальные ключи)
        (r'([A-Za-z0-9+/]{40,})', '[BASE64-FILTERED]'),
        # Длинные хэши
        (r'([A-Fa-f0-9]{64,})', '[HASH-FILTERED]'),
        # Приватные ключи
        (r'(-----BEGIN[^-]+PRIVATE KEY-----.*?-----END[^-]+PRIVATE KEY-----)', '[PRIVATE KEY FILTERED]'),
    ]
    
    def filter(self, record):
        """Фильтрация сообщения лога"""
        if hasattr(record, 'msg') and isinstance(record.msg, str):
            filtered_msg = record.msg
            for pattern, replacement in self.PATTERNS:
                filtered_msg = re.sub(pattern, replacement, filtered_msg, flags=re.IGNORECASE | re.DOTALL)
            record.msg = filtered_msg
        return True


class SecureLogger:
    """Centralized logging with rotation and crash reporting"""
    
    _instance = None
    _initialized = False
    
    LOG_DIR = "logs"
    MAX_LOG_SIZE = 5 * 1024 * 1024  # 5 MB
    BACKUP_COUNT = 5
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._setup_logging()
        self._initialized = True
    
    def _get_log_path(self) -> str:
        """Get log file path relative to executable"""
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        log_dir = os.path.join(base_dir, self.LOG_DIR)
        try:
            os.makedirs(log_dir, exist_ok=True)
        except (PermissionError, OSError):
            log_dir = os.path.join(tempfile.gettempdir(), "securepasspro_logs")
            os.makedirs(log_dir, exist_ok=True)
        
        # Hide log directory on Windows
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.kernel32.SetFileAttributesW(log_dir, 0x02)
            except Exception:
                pass
        
        return os.path.join(log_dir, "securepasspro.log")
    
    def _setup_logging(self):
        """Setup logging with rotation and sensitive data filtering"""
        log_path = self._get_log_path()
        
        # Create formatter (без sensitive данных в формате)
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # File handler with rotation
        try:
            file_handler = logging.handlers.RotatingFileHandler(
                log_path,
                maxBytes=self.MAX_LOG_SIZE,
                backupCount=self.BACKUP_COUNT,
                encoding='utf-8'
            )
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(formatter)
            file_handler.addFilter(SensitiveDataFilter())
        except (PermissionError, OSError) as e:
            print(f"[Logger] Cannot create log file: {e}")
            return
        
        # Console handler (only for development)
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        console_handler.addFilter(SensitiveDataFilter())
        
        # Configure root logger
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.DEBUG)
        root_logger.addHandler(file_handler)
        
        # Add console handler only in development mode
        if not getattr(sys, 'frozen', False):
            root_logger.addHandler(console_handler)
        
        # Log startup (без sensitive данных)
        logging.info("=" * 50)
        logging.info("Secure Pass Pro v4.0 starting")
        logging.info(f"Log file: {log_path}")
        logging.info(f"Python version: {sys.version}")
        logging.info(f"Platform: {sys.platform}")
        logging.info("=" * 50)
    
    def get_logger(self, name: str) -> logging.Logger:
        """Get logger for specific module"""
        return logging.getLogger(name)


def get_logger(name: str) -> logging.Logger:
    """Convenience function to get logger"""
    return SecureLogger().get_logger(name)


def log_exception(logger: logging.Logger, e: Exception, context: str = "") -> None:
    """Log exception with full traceback (без sensitive данных)"""
    import traceback
    # Не логируем сам пароль или ключ, только тип ошибки
    logger.error(f"Exception in {context}: {type(e).__name__}: {str(e)[:100]}")
    logger.debug(traceback.format_exc())


def log_crash_report(error: Exception, context: dict = None) -> None:
    """Create crash report file (без sensitive данных)"""
    import tempfile
    try:
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        crash_dir = os.path.join(base_dir, "logs")
        try:
            os.makedirs(crash_dir, exist_ok=True)
        except (PermissionError, OSError):
            crash_dir = tempfile.gettempdir()
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        crash_file = os.path.join(crash_dir, f"crash_{timestamp}.log")
        
        import traceback
        with open(crash_file, 'w', encoding='utf-8') as f:
            f.write("=" * 60 + "\n")
            f.write("SECURE PASS PRO - CRASH REPORT\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"Time: {datetime.now().isoformat()}\n")
            f.write(f"Python: {sys.version}\n")
            f.write(f"Platform: {sys.platform}\n\n")
            
            # Не пишем пароли в crash report!
            if context:
                f.write("CONTEXT (без sensitive данных):\n")
                for key, value in context.items():
                    if key.lower() not in ['password', 'master', 'key', 'secret', 'token']:
                        f.write(f"  {key}: {value}\n")
                f.write("\n")
            
            f.write("ERROR:\n")
            f.write(f"  {type(error).__name__}: {error}\n\n")
            
            f.write("TRACEBACK:\n")
            f.write(traceback.format_exc())
            f.write("\n")
            f.write("=" * 60 + "\n")
        
        logging.error(f"Crash report saved to: {crash_file}")
        
    except Exception as e:
        logging.error(f"Failed to create crash report: {e}")