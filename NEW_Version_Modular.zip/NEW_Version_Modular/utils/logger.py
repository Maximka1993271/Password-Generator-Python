"""
Logging subsystem for SecurePassPro
"""
import os
import sys
import logging
import logging.handlers
from datetime import datetime
from pathlib import Path
from typing import Optional


class SecureLogger:
    """Centralized logging with rotation and crash reporting"""
    
    _instance = None
    _initialized = False
    
    LOG_DIR = "logs"
    MAX_LOG_SIZE = 5 * 1024 * 1024  # 5 MB
    BACKUP_COUNT = 5
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._setup_logging()
        self._initialized = True
    
    def _get_log_path(self) -> str:
        """Get log file path relative to executable"""
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        log_dir = os.path.join(base_dir, self.LOG_DIR)
        os.makedirs(log_dir, exist_ok=True)
        
        # Hide log directory on Windows
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.kernel32.SetFileAttributesW(log_dir, 0x02)
            except Exception:
                pass
        
        return os.path.join(log_dir, "securepasspro.log")
    
    def _setup_logging(self):
        """Setup logging with rotation"""
        log_path = self._get_log_path()
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # File handler with rotation
        file_handler = logging.handlers.RotatingFileHandler(
            log_path,
            maxBytes=self.MAX_LOG_SIZE,
            backupCount=self.BACKUP_COUNT,
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        
        # Console handler (only for development)
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        
        # Configure root logger
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.DEBUG)
        root_logger.addHandler(file_handler)
        
        # Add console handler only in development mode
        if not getattr(sys, 'frozen', False):
            root_logger.addHandler(console_handler)
        
        # Log startup
        logging.info("=" * 50)
        logging.info("Secure Pass Pro v4.0 starting")
        logging.info(f"Log file: {log_path}")
        logging.info(f"Python version: {sys.version}")
        logging.info(f"Platform: {sys.platform}")
        logging.info("=" * 50)
    
    def get_logger(self, name: str) -> logging.Logger:
        """Get logger for specific module"""
        return logging.getLogger(name)


def get_logger(name: str) -> logging.Logger:
    """Convenience function to get logger"""
    return SecureLogger().get_logger(name)


def log_exception(logger: logging.Logger, e: Exception, context: str = "") -> None:
    """Log exception with full traceback"""
    import traceback
    logger.error(f"Exception in {context}: {type(e).__name__}: {e}")
    logger.debug(traceback.format_exc())


def log_crash_report(error: Exception, context: dict = None) -> None:
    """Create crash report file"""
    try:
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        crash_dir = os.path.join(base_dir, "logs")
        os.makedirs(crash_dir, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        crash_file = os.path.join(crash_dir, f"crash_{timestamp}.log")
        
        import traceback
        with open(crash_file, 'w', encoding='utf-8') as f:
            f.write("=" * 60 + "\n")
            f.write("SECURE PASS PRO - CRASH REPORT\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"Time: {datetime.now().isoformat()}\n")
            f.write(f"Python: {sys.version}\n")
            f.write(f"Platform: {sys.platform}\n")
            f.write(f"Executable: {sys.executable}\n\n")
            
            if context:
                f.write("CONTEXT:\n")
                for key, value in context.items():
                    f.write(f"  {key}: {value}\n")
                f.write("\n")
            
            f.write("ERROR:\n")
            f.write(f"  {type(error).__name__}: {error}\n\n")
            
            f.write("TRACEBACK:\n")
            f.write(traceback.format_exc())
            f.write("\n")
            
            f.write("=" * 60 + "\n")
        
        logging.error(f"Crash report saved to: {crash_file}")
        
    except Exception as e:
        logging.error(f"Failed to create crash report: {e}")