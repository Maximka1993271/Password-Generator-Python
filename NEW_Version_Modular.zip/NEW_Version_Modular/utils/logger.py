"""
Logging subsystem for SecurePassPro with sensitive data filtering
"""
import os
import sys
import logging
import logging.handlers
import re
import tempfile
from datetime import datetime
from typing import Optional, List, Pattern, Dict, Any, Union

# ==================== ПАТТЕРНЫ ДЛЯ ФИЛЬТРАЦИИ ====================

# Паттерны для поиска конфиденциальных данных
SENSITIVE_PATTERNS: List[tuple] = [
    # Мастер-пароль
    (r'(master["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[MASTER_PASSWORD_FILTERED]\3'),
    (r'(master_password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[MASTER_PASSWORD_FILTERED]\3'),
    (r'(master_pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[MASTER_PASSWORD_FILTERED]\3'),
    
    # Пароль (общий)
    (r'(password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(pass["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(new_pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(new_password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(old_password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(test_pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[TEST_PASSWORD_FILTERED]\3'),
    (r'(test_password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[TEST_PASSWORD_FILTERED]\3'),
    
    # Ключи шифрования
    (r'(key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[KEY_FILTERED]\3'),
    (r'(encryption_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[ENCRYPTION_KEY_FILTERED]\3'),
    (r'(private_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PRIVATE_KEY_FILTERED]\3'),
    (r'(secret_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[SECRET_KEY_FILTERED]\3'),
    (r'(api_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[API_KEY_FILTERED]\3'),
    (r'(token["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[TOKEN_FILTERED]\3'),
    (r'(_sqlcipher_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[SQLCIPHER_KEY_FILTERED]\3'),
    
    # Секреты
    (r'(secret["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[SECRET_FILTERED]\3'),
    
    # Соль
    (r'(salt["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[SALT_FILTERED]\3'),
    
    # Длинные base64 строки
    (r'([A-Za-z0-9+/]{40,})', '[BASE64_DATA_FILTERED]'),
    
    # Длинные хэши
    (r'([A-Fa-f0-9]{64,})', '[HASH_DATA_FILTERED]'),
    
    # Приватные ключи PEM
    (r'(-----BEGIN[^-]+PRIVATE KEY-----.*?-----END[^-]+PRIVATE KEY-----)', '[PRIVATE_KEY_BLOCK_FILTERED]'),
    (r'(-----BEGIN[^-]+RSA PRIVATE KEY-----.*?-----END[^-]+RSA PRIVATE KEY-----)', '[RSA_KEY_BLOCK_FILTERED]'),
    
    # Данные для входа
    (r'(login["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[LOGIN_FILTERED]\3'),
    (r'(username["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[USERNAME_FILTERED]\3'),
    (r'(user["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[USERNAME_FILTERED]\3'),
    (r'(email["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[EMAIL_FILTERED]\3'),
    
    # Расшифрованный контент
    (r'(decrypted["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[DECRYPTED_FILTERED]\3'),
    (r'(plaintext["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PLAINTEXT_FILTERED]\3'),
    
    # Токены авторизации
    (r'(Bearer\s+)([A-Za-z0-9\-_]+)', r'\1[BEARER_TOKEN_FILTERED]'),
    (r'(Authorization["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[AUTH_TOKEN_FILTERED]\3'),
    
    # Данные кредитных карт
    (r'\b(?:\d[ -]*?){13,16}\b', '[CREDIT_CARD_FILTERED]'),
    
    # IP адреса
    (r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', '[IP_ADDRESS_FILTERED]'),
]


class SensitiveDataFilter(logging.Filter):
    """Фильтр для удаления конфиденциальных данных из логов"""
    
    _compiled_patterns: List[tuple] = None
    _max_string_length = 2000
    
    @classmethod
    def _get_patterns(cls) -> List[tuple]:
        if cls._compiled_patterns is None:
            cls._compiled_patterns = []
            for pattern, replacement in SENSITIVE_PATTERNS:
                try:
                    cls._compiled_patterns.append((
                        re.compile(pattern, re.IGNORECASE | re.DOTALL),
                        replacement
                    ))
                except re.error as e:
                    print(f"[Logger] Invalid regex pattern: {e}")
        return cls._compiled_patterns
    
    def _filter_string(self, text: str) -> str:
        if not text or len(text) < 4:
            return text
        
        if len(text) > self._max_string_length:
            text = text[:self._max_string_length] + "...[TRUNCATED]"
        
        result = text
        for pattern, replacement in self._get_patterns():
            try:
                result = pattern.sub(replacement, result)
            except Exception:
                continue
        return result
    
    def _filter_traceback(self, text: str) -> str:
        if not text:
            return text
        
        lines = text.split('\n')
        filtered_lines = []
        
        for line in lines:
            skip = False
            dangerous_patterns = [
                r'password\s*=',
                r'pwd\s*=',
                r'master\s*=',
                r'key\s*=',
                r'secret\s*=',
                r'token\s*=',
                r'decrypt',
                r'plaintext',
            ]
            for pattern in dangerous_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    skip = True
                    filtered_lines.append('[SENSITIVE_LINE_REMOVED]')
                    break
            
            if not skip:
                filtered_lines.append(self._filter_string(line))
        
        return '\n'.join(filtered_lines)
    
    def filter(self, record: logging.LogRecord) -> bool:
        if hasattr(record, 'msg') and record.msg:
            if isinstance(record.msg, str):
                if 'Traceback' in record.msg or 'File "' in record.msg:
                    record.msg = self._filter_traceback(record.msg)
                else:
                    record.msg = self._filter_string(record.msg)
            elif isinstance(record.msg, Exception):
                record.msg = type(record.msg).__name__
        
        return True


class SensitiveDataFormatter(logging.Formatter):
    def __init__(self, fmt=None, datefmt=None, style='%'):
        super().__init__(fmt, datefmt, style)
        self.filter_obj = SensitiveDataFilter()
    
    def format(self, record: logging.LogRecord) -> str:
        self.filter_obj.filter(record)
        return super().format(record)


class SecureLogger:
    _instance = None
    _initialized = False
    
    LOG_DIR = "logs"
    MAX_LOG_SIZE = 5 * 1024 * 1024
    BACKUP_COUNT = 5
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._setup_logging()
        self._initialized = True
    
    def _get_log_path(self) -> str:
        # Ленивый импорт для избежания циклического импорта
        from utils.paths import get_logs_dir
        log_dir = get_logs_dir()
        
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.kernel32.SetFileAttributesW(log_dir, 0x02)
            except Exception:
                pass
        
        return os.path.join(log_dir, "securepasspro.log")
    
    def _setup_logging(self) -> None:
        log_path = self._get_log_path()
        
        formatter = SensitiveDataFormatter(
            '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        try:
            file_handler = logging.handlers.RotatingFileHandler(
                log_path,
                maxBytes=self.MAX_LOG_SIZE,
                backupCount=self.BACKUP_COUNT,
                encoding='utf-8'
            )
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(formatter)
            
        except (PermissionError, OSError) as e:
            temp_log = os.path.join(tempfile.gettempdir(), "securepasspro.log")
            try:
                file_handler = logging.handlers.RotatingFileHandler(
                    temp_log,
                    maxBytes=self.MAX_LOG_SIZE,
                    backupCount=self.BACKUP_COUNT,
                    encoding='utf-8'
                )
                file_handler.setLevel(logging.DEBUG)
                file_handler.setFormatter(formatter)
                print(f"[Logger] Using fallback log: {temp_log}")
            except Exception as e2:
                print(f"[Logger] Cannot create log file: {e2}")
                return
        
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)
        console_handler.setFormatter(formatter)
        
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.DEBUG)
        
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)
        
        root_logger.addHandler(file_handler)
        
        if not getattr(sys, 'frozen', False):
            root_logger.addHandler(console_handler)
        
        logging.info("=" * 50)
        logging.info("Secure Pass Pro v4.0 starting")
        logging.info(f"Log file: {log_path}")
        logging.info(f"Python version: {sys.version}")
        logging.info(f"Platform: {sys.platform}")
        logging.info(f"Frozen: {getattr(sys, 'frozen', False)}")
        logging.info("=" * 50)
    
    def get_logger(self, name: str) -> logging.Logger:
        return logging.getLogger(name)


def get_logger(name: str) -> logging.Logger:
    return SecureLogger().get_logger(name)


def log_exception(logger: logging.Logger, e: Exception, context: str = "") -> None:
    import traceback
    error_msg = str(e)
    filter_obj = SensitiveDataFilter()
    filtered_msg = filter_obj._filter_string(error_msg[:500])
    logger.error(f"Exception in {context}: {type(e).__name__}: {filtered_msg}")
    tb = traceback.format_exc()
    filtered_tb = filter_obj._filter_traceback(tb)
    logger.debug(filtered_tb[:2000])


def log_crash_report(error: Exception, context: dict = None) -> None:
    from utils.paths import get_logs_dir
    
    try:
        crash_dir = get_logs_dir()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        crash_file = os.path.join(crash_dir, f"crash_{timestamp}.log")
        
        import traceback
        filter_obj = SensitiveDataFilter()
        
        with open(crash_file, 'w', encoding='utf-8') as f:
            f.write("=" * 60 + "\n")
            f.write("SECURE PASS PRO - CRASH REPORT\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"Time: {datetime.now().isoformat()}\n")
            f.write(f"Python: {sys.version}\n")
            f.write(f"Platform: {sys.platform}\n\n")
            
            if context:
                f.write("CONTEXT:\n")
                sensitive_keys = ['password', 'master', 'key', 'secret', 'token', 
                                  'pwd', 'pass', 'decrypted', 'plaintext', 'salt']
                for key, value in context.items():
                    if key.lower() not in sensitive_keys:
                        if isinstance(value, str):
                            value = filter_obj._filter_string(value[:200])
                        f.write(f"  {key}: {value}\n")
                f.write("\n")
            
            f.write("ERROR:\n")
            error_msg = str(error)[:500]
            filtered_error = filter_obj._filter_string(error_msg)
            f.write(f"  {type(error).__name__}: {filtered_error}\n\n")
            
            f.write("TRACEBACK:\n")
            tb = traceback.format_exc()
            filtered_tb = filter_obj._filter_traceback(tb)
            if len(filtered_tb) > 5000:
                filtered_tb = filtered_tb[:5000] + "\n... [TRUNCATED]"
            f.write(filtered_tb)
            f.write("\n")
            f.write("=" * 60 + "\n")
        
        logging.error(f"Crash report saved to: {crash_file}")
        
    except Exception as e:
        logging.error(f"Failed to create crash report: {e}")


def is_sensitive_string(text: str) -> bool:
    if not text or len(text) < 4:
        return False
    
    for pattern, _ in SENSITIVE_PATTERNS:
        try:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        except re.error:
            continue
    
    return False


def redact_sensitive(text: str) -> str:
    if not text:
        return text
    
    filter_obj = SensitiveDataFilter()
    return filter_obj._filter_string(text)


def sanitize_log_message(message: str) -> str:
    if not message:
        return message
    
    message = re.sub(r'(password|pwd|pass)[\s]*[:=][\s]*["\']?[^"\'\s]{2,}["\']?', 
                     r'\1=[REDACTED]', message, flags=re.IGNORECASE)
    message = re.sub(r'(key|secret|token)[\s]*[:=][\s]*["\']?[^"\'\s]{4,}["\']?', 
                     r'\1=[REDACTED]', message, flags=re.IGNORECASE)
    message = re.sub(r'master[\s]*[:=][\s]*["\']?[^"\'\s]{2,}["\']?', 
                     r'master=[REDACTED]', message, flags=re.IGNORECASE)
    
    return message


__all__ = [
    'get_logger',
    'log_exception',
    'log_crash_report',
    'is_sensitive_string',
    'redact_sensitive',
    'sanitize_log_message',
    'SecureLogger',
    'SensitiveDataFilter',
    'SensitiveDataFormatter',
]