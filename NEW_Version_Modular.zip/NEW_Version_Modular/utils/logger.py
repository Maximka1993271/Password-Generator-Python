"""
Logging subsystem for SecurePassPro with sensitive data filtering
"""
import os
import sys
import logging
import logging.handlers
import re
import tempfile
from datetime import datetime
from typing import Optional, List, Pattern, Dict, Any, Union
from utils.paths import get_logs_dir

# ==================== PATTERNS FOR SENSITIVE DATA ====================

# Паттерны для поиска конфиденциальных данных
SENSITIVE_PATTERNS: List[tuple] = [
    # Мастер-пароль
    (r'(master["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(master_password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(master_pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Пароль
    (r'(password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(pass["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(new_pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Ключи шифрования
    (r'(key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(encryption_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(private_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(secret_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(api_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(token["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(_sqlcipher_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Секреты
    (r'(secret["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Соль
    (r'(salt["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Длинные base64 строки
    (r'([A-Za-z0-9+/]{40,})', '[BASE64-FILTERED]'),
    
    # Длинные хэши (64+ символов)
    (r'([A-Fa-f0-9]{64,})', '[HASH-FILTERED]'),
    
    # Приватные ключи PEM
    (r'(-----BEGIN[^-]+PRIVATE KEY-----.*?-----END[^-]+PRIVATE KEY-----)', '[PRIVATE KEY FILTERED]'),
    (r'(-----BEGIN[^-]+RSA PRIVATE KEY-----.*?-----END[^-]+RSA PRIVATE KEY-----)', '[RSA KEY FILTERED]'),
    
    # Данные для входа
    (r'(login["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(username["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(user["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(email["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Расшифрованный контент
    (r'(decrypted["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(plaintext["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Переменные в traceback
    (r'([a-zA-Z_][a-zA-Z0-9_]*\s*=\s*["\'])([^"\']{4,})(["\'])', r'\1[FILTERED]\3'),
]


class SensitiveDataFilter(logging.Filter):
    """Фильтр для удаления конфиденциальных данных из логов"""
    
    _compiled_patterns: List[Pattern] = None
    _max_string_length = 1000  # Максимальная длина строки для обработки
    
    @classmethod
    def _get_patterns(cls) -> List[tuple]:
        """Ленивая компиляция паттернов"""
        if cls._compiled_patterns is None:
            cls._compiled_patterns = []
            for pattern, replacement in SENSITIVE_PATTERNS:
                try:
                    cls._compiled_patterns.append((
                        re.compile(pattern, re.IGNORECASE | re.DOTALL),
                        replacement
                    ))
                except re.error as e:
                    print(f"[Logger] Invalid regex pattern: {e}")
        return cls._compiled_patterns
    
    def _filter_string(self, text: str) -> str:
        """Фильтрует отдельную строку"""
        if not text or len(text) < 4:
            return text
        
        # Ограничиваем длину для производительности
        if len(text) > self._max_string_length:
            text = text[:self._max_string_length] + "...[TRUNCATED]"
        
        result = text
        for pattern, replacement in self._get_patterns():
            try:
                result = pattern.sub(replacement, result)
            except Exception:
                continue
        return result
    
    def _filter_dict(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Фильтрует словарь аргументов"""
        filtered = {}
        for key, value in args.items():
            if isinstance(value, str):
                filtered[key] = self._filter_string(value)
            elif isinstance(value, dict):
                filtered[key] = self._filter_dict(value)
            elif isinstance(value, (list, tuple)):
                filtered[key] = self._filter_sequence(value)
            elif isinstance(value, Exception):
                filtered[key] = type(value).__name__
            else:
                filtered[key] = value
        return filtered
    
    def _filter_sequence(self, args: Union[List, tuple]) -> Union[List, tuple]:
        """Фильтрует список или кортеж аргументов"""
        filtered = []
        for arg in args:
            if isinstance(arg, str):
                filtered.append(self._filter_string(arg))
            elif isinstance(arg, dict):
                filtered.append(self._filter_dict(arg))
            elif isinstance(arg, (list, tuple)):
                filtered.append(self._filter_sequence(arg))
            elif isinstance(arg, Exception):
                filtered.append(type(arg).__name__)
            else:
                filtered.append(arg)
        return tuple(filtered) if isinstance(args, tuple) else filtered
    
    def _filter_traceback(self, text: str) -> str:
        """Специальная фильтрация для traceback"""
        if not text:
            return text
        
        # Удаляем строки с потенциальными паролями
        lines = text.split('\n')
        filtered_lines = []
        
        for line in lines:
            # Пропускаем строки с подозрительными переменными
            skip = False
            dangerous_patterns = [
                r'password\s*=',
                r'pwd\s*=',
                r'master\s*=',
                r'key\s*=',
                r'secret\s*=',
                r'token\s*=',
            ]
            for pattern in dangerous_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    skip = True
                    filtered_lines.append('[SENSITIVE LINE REMOVED]')
                    break
            
            if not skip:
                # Фильтруем остальные строки
                filtered_lines.append(self._filter_string(line))
        
        return '\n'.join(filtered_lines)
    
    def filter(self, record: logging.LogRecord) -> bool:
        """
        Фильтрация сообщения лога и аргументов.
        Защищает от утечек через traceback и исключения.
        """
        # Фильтруем само сообщение
        if hasattr(record, 'msg') and record.msg:
            if isinstance(record.msg, str):
                # Проверяем на traceback
                if 'Traceback' in record.msg or 'File "' in record.msg:
                    record.msg = self._filter_traceback(record.msg)
                else:
                    record.msg = self._filter_string(record.msg)
            elif isinstance(record.msg, Exception):
                record.msg = type(record.msg).__name__
        
        # Фильтруем аргументы (важно для traceback и исключений!)
        if hasattr(record, 'args') and record.args:
            if isinstance(record.args, dict):
                record.args = self._filter_dict(record.args)
            elif isinstance(record.args, (tuple, list)):
                record.args = self._filter_sequence(record.args)
        
        # Фильтруем имя модуля (может содержать sensitive данные)
        if hasattr(record, 'name') and record.name:
            record.name = self._filter_string(record.name)
        
        # Фильтруем путь к файлу (может содержать sensitive данные)
        if hasattr(record, 'pathname') and record.pathname:
            record.pathname = self._filter_string(record.pathname)
        
        # Фильтруем имя функции
        if hasattr(record, 'funcName') and record.funcName:
            record.funcName = self._filter_string(record.funcName)
        
        # Фильтруем строку в файле
        if hasattr(record, 'lineno') and record.lineno:
            pass  # Число не фильтруем
        
        return True


class SensitiveDataFormatter(logging.Formatter):
    """Форматтер с дополнительной фильтрацией"""
    
    def __init__(self, fmt=None, datefmt=None, style='%'):
        super().__init__(fmt, datefmt, style)
        self.filter_obj = SensitiveDataFilter()
    
    def format(self, record: logging.LogRecord) -> str:
        # Применяем фильтрацию
        self.filter_obj.filter(record)
        return super().format(record)


class SecureLogger:
    """Centralized logging with rotation and crash reporting"""
    
    _instance = None
    _initialized = False
    
    LOG_DIR = "logs"
    MAX_LOG_SIZE = 5 * 1024 * 1024
    BACKUP_COUNT = 5
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._setup_logging()
        self._initialized = True
    
    def _get_log_path(self) -> str:
        """Get log file path"""
        log_dir = get_logs_dir()
        
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.kernel32.SetFileAttributesW(log_dir, 0x02)
            except Exception:
                pass
        
        return os.path.join(log_dir, "securepasspro.log")
    
    def _setup_logging(self) -> None:
        """Setup logging with rotation and sensitive data filtering"""
        log_path = self._get_log_path()
        
        # Используем безопасный форматтер
        formatter = SensitiveDataFormatter(
            '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        try:
            file_handler = logging.handlers.RotatingFileHandler(
                log_path,
                maxBytes=self.MAX_LOG_SIZE,
                backupCount=self.BACKUP_COUNT,
                encoding='utf-8'
            )
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(formatter)
            
        except (PermissionError, OSError) as e:
            temp_log = os.path.join(tempfile.gettempdir(), "securepasspro.log")
            try:
                file_handler = logging.handlers.RotatingFileHandler(
                    temp_log,
                    maxBytes=self.MAX_LOG_SIZE,
                    backupCount=self.BACKUP_COUNT,
                    encoding='utf-8'
                )
                file_handler.setLevel(logging.DEBUG)
                file_handler.setFormatter(formatter)
                print(f"[Logger] Using fallback log: {temp_log}")
            except Exception as e2:
                print(f"[Logger] Cannot create log file: {e2}")
                return
        
        # Консольный обработчик только для разработки
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.DEBUG)
        
        # Очищаем старые обработчики
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)
        
        root_logger.addHandler(file_handler)
        
        # Добавляем консоль только в режиме разработки
        if not getattr(sys, 'frozen', False):
            root_logger.addHandler(console_handler)
        
        logging.info("=" * 50)
        logging.info("Secure Pass Pro v4.0 starting")
        logging.info(f"Log file: {log_path}")
        logging.info(f"Python version: {sys.version}")
        logging.info(f"Platform: {sys.platform}")
        logging.info(f"Frozen: {getattr(sys, 'frozen', False)}")
        logging.info("=" * 50)
    
    def get_logger(self, name: str) -> logging.Logger:
        """Get logger with sensitive data filtering"""
        return logging.getLogger(name)


def get_logger(name: str) -> logging.Logger:
    """Convenience function to get logger with sensitive data filtering"""
    return SecureLogger().get_logger(name)


def log_exception(logger: logging.Logger, e: Exception, context: str = "") -> None:
    """Log exception with full traceback (без sensitive данных)"""
    import traceback
    error_msg = str(e)
    # Фильтруем сообщение об ошибке
    filter_obj = SensitiveDataFilter()
    filtered_msg = filter_obj._filter_string(error_msg[:200])
    logger.error(f"Exception in {context}: {type(e).__name__}: {filtered_msg}")
    # Логируем traceback на уровне DEBUG
    tb = traceback.format_exc()
    filtered_tb = filter_obj._filter_traceback(tb)
    logger.debug(filtered_tb)


def log_crash_report(error: Exception, context: dict = None) -> None:
    """Create crash report file (без sensitive данных)"""
    try:
        crash_dir = get_logs_dir()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        crash_file = os.path.join(crash_dir, f"crash_{timestamp}.log")
        
        import traceback
        filter_obj = SensitiveDataFilter()
        
        with open(crash_file, 'w', encoding='utf-8') as f:
            f.write("=" * 60 + "\n")
            f.write("SECURE PASS PRO - CRASH REPORT\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"Time: {datetime.now().isoformat()}\n")
            f.write(f"Python: {sys.version}\n")
            f.write(f"Platform: {sys.platform}\n\n")
            
            if context:
                f.write("CONTEXT:\n")
                sensitive_keys = ['password', 'master', 'key', 'secret', 'token', 'pwd', 'pass', 'decrypted', 'plaintext']
                for key, value in context.items():
                    if key.lower() not in sensitive_keys:
                        # Фильтруем значение
                        if isinstance(value, str):
                            value = filter_obj._filter_string(value)
                        f.write(f"  {key}: {value}\n")
                f.write("\n")
            
            f.write("ERROR:\n")
            error_msg = str(error)[:200]
            filtered_error = filter_obj._filter_string(error_msg)
            f.write(f"  {type(error).__name__}: {filtered_error}\n\n")
            
            f.write("TRACEBACK:\n")
            tb = traceback.format_exc()
            filtered_tb = filter_obj._filter_traceback(tb)
            f.write(filtered_tb)
            f.write("\n")
            f.write("=" * 60 + "\n")
        
        logging.error(f"Crash report saved to: {crash_file}")
        
    except Exception as e:
        logging.error(f"Failed to create crash report: {e}")


def is_sensitive_string(text: str) -> bool:
    """Check if a string contains sensitive data patterns"""
    if not text or len(text) < 4:
        return False
    
    for pattern, _ in SENSITIVE_PATTERNS:
        try:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        except re.error:
            continue
    
    return False


def redact_sensitive(text: str) -> str:
    """Redact sensitive data from a string"""
    if not text:
        return text
    
    filter_obj = SensitiveDataFilter()
    return filter_obj._filter_string(text)


# Экспортируем основные функции
__all__ = [
    'get_logger',
    'log_exception',
    'log_crash_report',
    'is_sensitive_string',
    'redact_sensitive',
    'SecureLogger',
    'SensitiveDataFilter',
    'SensitiveDataFormatter'
]