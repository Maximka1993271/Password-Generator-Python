"""
Logging subsystem for SecurePassPro with sensitive data filtering
FIXED: Полная фильтрация конфиденциальных данных, JSON logs, structured logging
FIXED: Устранён циклический импорт путей
"""
import os
import sys
import logging
import logging.handlers
import re
import tempfile
import json
from datetime import datetime
from typing import Optional, List, Pattern, Dict, Any, Union
from enum import Enum

# ==================== ПАТТЕРНЫ ДЛЯ ФИЛЬТРАЦИИ ====================

# Паттерны для поиска конфиденциальных данных
SENSITIVE_PATTERNS: List[tuple] = [
    # Мастер-пароль
    (r'(master["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[MASTER_PASSWORD_FILTERED]\3'),
    (r'(master_password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[MASTER_PASSWORD_FILTERED]\3'),
    (r'(master_pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[MASTER_PASSWORD_FILTERED]\3'),
    
    # Пароль (общий)
    (r'(password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(pass["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(new_pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(new_password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(old_password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    
    # Ключи шифрования
    (r'(key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[KEY_FILTERED]\3'),
    (r'(encryption_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[ENCRYPTION_KEY_FILTERED]\3'),
    (r'(private_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PRIVATE_KEY_FILTERED]\3'),
    (r'(secret_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[SECRET_KEY_FILTERED]\3'),
    (r'(api_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[API_KEY_FILTERED]\3'),
    (r'(token["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[TOKEN_FILTERED]\3'),
    (r'(_sqlcipher_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[SQLCIPHER_KEY_FILTERED]\3'),
    
    # TOTP секреты
    (r'(totp_secret["\s]*[:=][\s]*["\']?)([A-Z2-7]{10,})(["\']?)', r'\1[TOTP_SECRET_FILTERED]\3'),
    (r'(2fa_secret["\s]*[:=][\s]*["\']?)([A-Z2-7]{10,})(["\']?)', r'\1[TOTP_SECRET_FILTERED]\3'),
    (r'(backup_code["\s]*[:=][\s]*["\']?)([A-Z0-9\-]{8,})(["\']?)', r'\1[BACKUP_CODE_FILTERED]\3'),
    
    # Секреты
    (r'(secret["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[SECRET_FILTERED]\3'),
    
    # Соль
    (r'(salt["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[SALT_FILTERED]\3'),
    
    # Длинные base64 строки
    (r'([A-Za-z0-9+/]{40,})', '[BASE64_DATA_FILTERED]'),
    
    # Длинные хэши
    (r'([A-Fa-f0-9]{64,})', '[HASH_DATA_FILTERED]'),
    
    # Приватные ключи PEM
    (r'(-----BEGIN[^-]+PRIVATE KEY-----.*?-----END[^-]+PRIVATE KEY-----)', '[PRIVATE_KEY_BLOCK_FILTERED]'),
    (r'(-----BEGIN[^-]+RSA PRIVATE KEY-----.*?-----END[^-]+RSA PRIVATE KEY-----)', '[RSA_KEY_BLOCK_FILTERED]'),
    
    # Данные для входа
    (r'(login["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[LOGIN_FILTERED]\3'),
    (r'(username["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[USERNAME_FILTERED]\3'),
    (r'(user["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[USERNAME_FILTERED]\3'),
    (r'(email["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[EMAIL_FILTERED]\3'),
    
    # Расшифрованный контент
    (r'(decrypted["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[DECRYPTED_FILTERED]\3'),
    (r'(plaintext["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PLAINTEXT_FILTERED]\3'),
    
    # Токены авторизации
    (r'(Bearer\s+)([A-Za-z0-9\-_]+)', r'\1[BEARER_TOKEN_FILTERED]'),
    (r'(Authorization["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[AUTH_TOKEN_FILTERED]\3'),
    
    # Данные кредитных карт
    (r'\b(?:\d[ -]*?){13,16}\b', '[CREDIT_CARD_FILTERED]'),
    
    # Сессионные ID
    (r'(session["\s]*[:=][\s]*["\']?)([a-f0-9]{32,})(["\']?)', r'\1[SESSION_ID_FILTERED]\3'),
    (r'(session_id["\s]*[:=][\s]*["\']?)([a-f0-9]{32,})(["\']?)', r'\1[SESSION_ID_FILTERED]\3'),
]


class LogLevel(Enum):
    """Уровни логирования"""
    DEBUG = logging.DEBUG
    INFO = logging.INFO
    WARNING = logging.WARNING
    ERROR = logging.ERROR
    CRITICAL = logging.CRITICAL


class SensitiveDataFilter(logging.Filter):
    """Фильтр для удаления конфиденциальных данных из логов"""
    
    _compiled_patterns: List[tuple] = None
    _max_string_length = 2000
    
    @classmethod
    def _get_patterns(cls) -> List[tuple]:
        if cls._compiled_patterns is None:
            cls._compiled_patterns = []
            for pattern, replacement in SENSITIVE_PATTERNS:
                try:
                    cls._compiled_patterns.append((
                        re.compile(pattern, re.IGNORECASE | re.DOTALL),
                        replacement
                    ))
                except re.error as e:
                    print(f"[Logger] Invalid regex pattern: {e}")
        return cls._compiled_patterns
    
    def _filter_string(self, text: str) -> str:
        if not text or len(text) < 4:
            return text
        
        if len(text) > self._max_string_length:
            text = text[:self._max_string_length] + "...[TRUNCATED]"
        
        result = text
        for pattern, replacement in self._get_patterns():
            try:
                result = pattern.sub(replacement, result)
            except (re.error, TypeError, AttributeError) as e:
                continue
        return result
    
    def _filter_traceback(self, text: str) -> str:
        if not text:
            return text
        
        lines = text.split('\n')
        filtered_lines = []
        
        for line in lines:
            skip = False
            dangerous_patterns = [
                r'password\s*=',
                r'pwd\s*=',
                r'master\s*=',
                r'key\s*=',
                r'secret\s*=',
                r'token\s*=',
                r'decrypt',
                r'plaintext',
                r'totp',
                r'2fa',
            ]
            for pattern in dangerous_patterns:
                try:
                    if re.search(pattern, line, re.IGNORECASE):
                        skip = True
                        filtered_lines.append('[SENSITIVE_LINE_REMOVED]')
                        break
                except re.error:
                    continue
            
            if not skip:
                filtered_lines.append(self._filter_string(line))
        
        return '\n'.join(filtered_lines)
    
    def filter(self, record: logging.LogRecord) -> bool:
        if hasattr(record, 'msg') and record.msg:
            if isinstance(record.msg, str):
                if 'Traceback' in record.msg or 'File "' in record.msg:
                    record.msg = self._filter_traceback(record.msg)
                else:
                    record.msg = self._filter_string(record.msg)
            elif isinstance(record.msg, Exception):
                record.msg = type(record.msg).__name__
        
        # Фильтрация аргументов
        if hasattr(record, 'args') and record.args:
            try:
                filtered_args = []
                for arg in record.args:
                    if isinstance(arg, str):
                        filtered_args.append(self._filter_string(arg))
                    else:
                        filtered_args.append(arg)
                record.args = tuple(filtered_args)
            except (TypeError, AttributeError):
                pass
        
        return True


class SensitiveDataFormatter(logging.Formatter):
    def __init__(self, fmt=None, datefmt=None, style='%'):
        super().__init__(fmt, datefmt, style)
        self.filter_obj = SensitiveDataFilter()
    
    def format(self, record: logging.LogRecord) -> str:
        try:
            self.filter_obj.filter(record)
            return super().format(record)
        except (TypeError, ValueError, AttributeError) as e:
            return f"[FORMATTER_ERROR: {e}]"


class JSONFormatter(logging.Formatter):
    """JSON форматер для структурированных логов"""
    
    def __init__(self, include_extra: bool = True):
        super().__init__()
        self.include_extra = include_extra
        self.filter_obj = SensitiveDataFilter()
    
    def format(self, record: logging.LogRecord) -> str:
        try:
            log_entry = {
                "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S.%fZ"),
                "level": record.levelname,
                "logger": record.name,
                "message": record.getMessage(),
                "module": record.module,
                "function": record.funcName,
                "line": record.lineno,
            }
            
            # Фильтрация сообщения
            if "message" in log_entry:
                log_entry["message"] = self.filter_obj._filter_string(log_entry["message"])
            
            if self.include_extra and hasattr(record, 'extra'):
                extra = getattr(record, 'extra', {})
                if isinstance(extra, dict):
                    filtered_extra = {}
                    for key, value in extra.items():
                        if isinstance(value, str):
                            filtered_extra[key] = self.filter_obj._filter_string(value)
                        else:
                            filtered_extra[key] = value
                    log_entry["extra"] = filtered_extra
            
            if hasattr(record, 'exc_info') and record.exc_info:
                import traceback
                tb = traceback.format_exception(*record.exc_info)
                log_entry["exception"] = self.filter_obj._filter_traceback(''.join(tb))
            
            return json.dumps(log_entry, ensure_ascii=False)
        except (TypeError, ValueError, AttributeError) as e:
            return f'{{"error": "JSON formatting failed: {e}"}}'


class SecureLogger:
    _instance = None
    _initialized = False
    
    LOG_DIR = "logs"
    MAX_LOG_SIZE = 5 * 1024 * 1024
    BACKUP_COUNT = 5
    
    # Режимы логирования
    _json_mode = False
    _debug_mode = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._setup_logging()
        self._initialized = True
    
    @classmethod
    def set_json_mode(cls, enabled: bool) -> None:
        """Включить/выключить JSON формат логов"""
        cls._json_mode = enabled
        if cls._instance:
            cls._instance._reconfigure_handlers()
    
    @classmethod
    def set_debug_mode(cls, enabled: bool) -> None:
        """Включить/выключить DEBUG уровень"""
        cls._debug_mode = enabled
        if cls._instance:
            cls._instance._reconfigure_handlers()
    
    def _reconfigure_handlers(self) -> None:
        """Перенастраивает обработчики при изменении режима"""
        root_logger = logging.getLogger()
        for handler in root_logger.handlers:
            if isinstance(handler, logging.Handler):
                if self._json_mode and isinstance(handler, logging.handlers.RotatingFileHandler):
                    handler.setFormatter(JSONFormatter())
                elif not self._json_mode and isinstance(handler, logging.handlers.RotatingFileHandler):
                    handler.setFormatter(SensitiveDataFormatter(
                        '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S'
                    ))
                
                if self._debug_mode:
                    handler.setLevel(logging.DEBUG)
                else:
                    handler.setLevel(logging.INFO)
    
    def _get_log_path(self) -> str:
        """Получить путь к лог-файлу без циклического импорта"""
        # Определяем базовую директорию вручную
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        log_dir = os.path.join(base_dir, "logs")
        
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.kernel32.SetFileAttributesW(log_dir, 0x02)
            except (ImportError, AttributeError, OSError) as e:
                pass
        
        return os.path.join(log_dir, "securepasspro.log")
    
    def _setup_logging(self) -> None:
        log_path = self._get_log_path()
        
        try:
            file_handler = logging.handlers.RotatingFileHandler(
                log_path,
                maxBytes=self.MAX_LOG_SIZE,
                backupCount=self.BACKUP_COUNT,
                encoding='utf-8'
            )
            
            if self._json_mode:
                file_handler.setFormatter(JSONFormatter())
            else:
                file_handler.setFormatter(SensitiveDataFormatter(
                    '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S'
                ))
            
            file_handler.setLevel(logging.DEBUG if self._debug_mode else logging.INFO)
            
        except (PermissionError, OSError, IOError) as e:
            temp_log = os.path.join(tempfile.gettempdir(), "securepasspro.log")
            try:
                file_handler = logging.handlers.RotatingFileHandler(
                    temp_log,
                    maxBytes=self.MAX_LOG_SIZE,
                    backupCount=self.BACKUP_COUNT,
                    encoding='utf-8'
                )
                file_handler.setFormatter(SensitiveDataFormatter(
                    '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S'
                ))
                file_handler.setLevel(logging.DEBUG if self._debug_mode else logging.INFO)
                print(f"[Logger] Using fallback log: {temp_log}")
            except (PermissionError, OSError, IOError) as e2:
                print(f"[Logger] Cannot create log file: {e2}")
                return
        
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)
        console_handler.setFormatter(SensitiveDataFormatter(
            '%(levelname)s | %(name)s | %(message)s'
        ))
        
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.DEBUG if self._debug_mode else logging.INFO)
        
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)
        
        root_logger.addHandler(file_handler)
        
        if not getattr(sys, 'frozen', False):
            root_logger.addHandler(console_handler)
        
        # Начальная запись в лог
        logging.info("=" * 50)
        logging.info("Secure Pass Pro v4.0 starting")
        logging.info(f"Log file: {log_path}")
        logging.info(f"JSON mode: {self._json_mode}")
        logging.info(f"Debug mode: {self._debug_mode}")
        logging.info(f"Python version: {sys.version}")
        logging.info(f"Platform: {sys.platform}")
        logging.info(f"Frozen: {getattr(sys, 'frozen', False)}")
        logging.info("=" * 50)
    
    def get_logger(self, name: str) -> logging.Logger:
        return logging.getLogger(name)


# Глобальный экземпляр логгера
_logger_instance = None


def get_logger(name: str) -> logging.Logger:
    """Возвращает настроенный логгер"""
    global _logger_instance
    if _logger_instance is None:
        _logger_instance = SecureLogger()
    return _logger_instance.get_logger(name)


def log_exception(logger: logging.Logger, e: Exception, context: str = "") -> None:
    """Логирует исключение с фильтрацией"""
    import traceback
    error_msg = str(e)
    filter_obj = SensitiveDataFilter()
    filtered_msg = filter_obj._filter_string(error_msg[:500])
    logger.error(f"Exception in {context}: {type(e).__name__}: {filtered_msg}")
    tb = traceback.format_exc()
    filtered_tb = filter_obj._filter_traceback(tb)
    logger.debug(filtered_tb[:2000])


def log_crash_report(error: Exception, context: dict = None) -> None:
    """Создаёт отчёт о краше"""
    # Определяем папку логов вручную
    if getattr(sys, 'frozen', False):
        base_dir = os.path.dirname(sys.executable)
    else:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    crash_dir = os.path.join(base_dir, "logs")
    
    try:
        os.makedirs(crash_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        crash_file = os.path.join(crash_dir, f"crash_{timestamp}.log")
        
        import traceback
        filter_obj = SensitiveDataFilter()
        
        with open(crash_file, 'w', encoding='utf-8') as f:
            f.write("=" * 60 + "\n")
            f.write("SECURE PASS PRO - CRASH REPORT\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"Time: {datetime.now().isoformat()}\n")
            f.write(f"Python: {sys.version}\n")
            f.write(f"Platform: {sys.platform}\n\n")
            
            if context:
                f.write("CONTEXT:\n")
                sensitive_keys = ['password', 'master', 'key', 'secret', 'token', 
                                  'pwd', 'pass', 'decrypted', 'plaintext', 'salt',
                                  'totp', '2fa', 'backup_code']
                for key, value in context.items():
                    if key.lower() not in sensitive_keys:
                        if isinstance(value, str):
                            value = filter_obj._filter_string(value[:200])
                        f.write(f"  {key}: {value}\n")
                f.write("\n")
            
            f.write("ERROR:\n")
            error_msg = str(error)[:500]
            filtered_error = filter_obj._filter_string(error_msg)
            f.write(f"  {type(error).__name__}: {filtered_error}\n\n")
            
            f.write("TRACEBACK:\n")
            tb = traceback.format_exc()
            filtered_tb = filter_obj._filter_traceback(tb)
            if len(filtered_tb) > 5000:
                filtered_tb = filtered_tb[:5000] + "\n... [TRUNCATED]"
            f.write(filtered_tb)
            f.write("\n")
            f.write("=" * 60 + "\n")
        
        # Логируем через стандартный логгер
        try:
            logging.error(f"Crash report saved to: {crash_file}")
        except (NameError, RuntimeError):
            print(f"Crash report saved to: {crash_file}")
        
    except (OSError, IOError, PermissionError) as e:
        try:
            logging.error(f"Failed to create crash report: {e}")
        except (NameError, RuntimeError):
            print(f"Failed to create crash report: {e}")


def is_sensitive_string(text: str) -> bool:
    """Проверяет, содержит ли строка чувствительные данные"""
    if not text or len(text) < 4:
        return False
    
    for pattern, _ in SENSITIVE_PATTERNS:
        try:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        except re.error:
            continue
    
    return False


def redact_sensitive(text: str) -> str:
    """Удаляет чувствительные данные из строки"""
    if not text:
        return text
    
    filter_obj = SensitiveDataFilter()
    return filter_obj._filter_string(text)


def sanitize_log_message(message: str) -> str:
    """Очищает сообщение лога от чувствительных данных"""
    if not message:
        return message
    
    try:
        message = re.sub(r'(password|pwd|pass)[\s]*[:=][\s]*["\']?[^"\'\s]{2,}["\']?', 
                         r'\1=[REDACTED]', message, flags=re.IGNORECASE)
        message = re.sub(r'(key|secret|token)[\s]*[:=][\s]*["\']?[^"\'\s]{4,}["\']?', 
                         r'\1=[REDACTED]', message, flags=re.IGNORECASE)
        message = re.sub(r'master[\s]*[:=][\s]*["\']?[^"\'\s]{2,}["\']?', 
                         r'master=[REDACTED]', message, flags=re.IGNORECASE)
        message = re.sub(r'(totp|2fa)[\s]*[:=][\s]*["\']?[A-Z2-7]{10,}["\']?', 
                         r'\1=[REDACTED]', message, flags=re.IGNORECASE)
    except re.error as e:
        pass
    
    return message


def enable_json_logs() -> None:
    """Включает JSON формат логов"""
    SecureLogger.set_json_mode(True)


def enable_debug_logs() -> None:
    """Включает DEBUG уровень логов"""
    SecureLogger.set_debug_mode(True)


def disable_json_logs() -> None:
    """Выключает JSON формат логов"""
    SecureLogger.set_json_mode(False)


def disable_debug_logs() -> None:
    """Выключает DEBUG уровень логов"""
    SecureLogger.set_debug_mode(False)


def get_log_level() -> LogLevel:
    """Возвращает текущий уровень логирования"""
    root_logger = logging.getLogger()
    level = root_logger.getEffectiveLevel()
    for lvl in LogLevel:
        if lvl.value == level:
            return lvl
    return LogLevel.INFO


__all__ = [
    'get_logger',
    'log_exception',
    'log_crash_report',
    'is_sensitive_string',
    'redact_sensitive',
    'sanitize_log_message',
    'SecureLogger',
    'SensitiveDataFilter',
    'SensitiveDataFormatter',
    'JSONFormatter',
    'LogLevel',
    'enable_json_logs',
    'enable_debug_logs',
    'disable_json_logs',
    'disable_debug_logs',
    'get_log_level',
]