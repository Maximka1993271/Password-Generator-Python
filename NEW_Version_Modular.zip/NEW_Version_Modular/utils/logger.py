"""
Logging subsystem for SecurePassPro with sensitive data filtering
"""
import os
import sys
import logging
import logging.handlers
import re
import tempfile
from datetime import datetime
from typing import Optional, List, Pattern
from utils.paths import get_logs_dir

# ==================== PATTERNS FOR SENSITIVE DATA ====================

# Паттерны для поиска конфиденциальных данных
SENSITIVE_PATTERNS: List[tuple] = [
    # Мастер-пароль
    (r'(master["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(master_password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(master_pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Пароль
    (r'(password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(pass["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Ключи шифрования
    (r'(key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(encryption_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(private_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(secret_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(api_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(token["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Секреты
    (r'(secret["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Соль
    (r'(salt["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Длинные base64 строки
    (r'([A-Za-z0-9+/]{40,})', '[BASE64-FILTERED]'),
    
    # Длинные хэши (64+ символов)
    (r'([A-Fa-f0-9]{64,})', '[HASH-FILTERED]'),
    
    # Приватные ключи PEM
    (r'(-----BEGIN[^-]+PRIVATE KEY-----.*?-----END[^-]+PRIVATE KEY-----)', '[PRIVATE KEY FILTERED]'),
    (r'(-----BEGIN[^-]+RSA PRIVATE KEY-----.*?-----END[^-]+RSA PRIVATE KEY-----)', '[RSA KEY FILTERED]'),
    
    # Данные для входа
    (r'(login["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(username["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(user["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(email["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    
    # Расшифрованный контент
    (r'(decrypted["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
    (r'(plaintext["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[FILTERED]\3'),
]


class SensitiveDataFilter(logging.Filter):
    """Фильтр для удаления конфиденциальных данных из логов"""
    
    _compiled_patterns: List[Pattern] = None
    
    @classmethod
    def _get_patterns(cls) -> List[tuple]:
        """Ленивая компиляция паттернов"""
        if cls._compiled_patterns is None:
            cls._compiled_patterns = []
            for pattern, replacement in SENSITIVE_PATTERNS:
                try:
                    cls._compiled_patterns.append((
                        re.compile(pattern, re.IGNORECASE | re.DOTALL),
                        replacement
                    ))
                except re.error as e:
                    print(f"[Logger] Invalid regex pattern: {e}")
        return cls._compiled_patterns
    
    def filter(self, record: logging.LogRecord) -> bool:
        """Фильтрация сообщения лога"""
        if not hasattr(record, 'msg') or not isinstance(record.msg, str):
            return True
        
        filtered_msg = record.msg
        
        for pattern, replacement in self._get_patterns():
            try:
                filtered_msg = pattern.sub(replacement, filtered_msg)
            except Exception:
                continue
        
        record.msg = filtered_msg
        
        # Также фильтруем аргументы
        if hasattr(record, 'args') and record.args:
            if isinstance(record.args, dict):
                filtered_args = {}
                for k, v in record.args.items():
                    if isinstance(v, str) and len(v) > 4:
                        is_sensitive = False
                        for pattern, _ in self._get_patterns():
                            if pattern.search(v):
                                is_sensitive = True
                                break
                        filtered_args[k] = "[FILTERED]" if is_sensitive else v
                    else:
                        filtered_args[k] = v
                record.args = filtered_args
            elif isinstance(record.args, (tuple, list)):
                filtered_args = []
                for arg in record.args:
                    if isinstance(arg, str) and len(arg) > 4:
                        is_sensitive = False
                        for pattern, _ in self._get_patterns():
                            if pattern.search(arg):
                                is_sensitive = True
                                break
                        filtered_args.append("[FILTERED]" if is_sensitive else arg)
                    else:
                        filtered_args.append(arg)
                record.args = tuple(filtered_args) if isinstance(record.args, tuple) else filtered_args
        
        return True


class SecureLogger:
    """Centralized logging with rotation and crash reporting"""
    
    _instance = None
    _initialized = False
    
    LOG_DIR = "logs"
    MAX_LOG_SIZE = 5 * 1024 * 1024
    BACKUP_COUNT = 5
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._setup_logging()
        self._initialized = True
    
    def _get_log_path(self) -> str:
        """Get log file path"""
        log_dir = get_logs_dir()
        
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.kernel32.SetFileAttributesW(log_dir, 0x02)
            except Exception:
                pass
        
        return os.path.join(log_dir, "securepasspro.log")
    
    def _setup_logging(self) -> None:
        """Setup logging with rotation and sensitive data filtering"""
        log_path = self._get_log_path()
        
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        try:
            file_handler = logging.handlers.RotatingFileHandler(
                log_path,
                maxBytes=self.MAX_LOG_SIZE,
                backupCount=self.BACKUP_COUNT,
                encoding='utf-8'
            )
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(formatter)
            file_handler.addFilter(SensitiveDataFilter())
        except (PermissionError, OSError) as e:
            temp_log = os.path.join(tempfile.gettempdir(), "securepasspro.log")
            try:
                file_handler = logging.handlers.RotatingFileHandler(
                    temp_log,
                    maxBytes=self.MAX_LOG_SIZE,
                    backupCount=self.BACKUP_COUNT,
                    encoding='utf-8'
                )
                file_handler.setLevel(logging.DEBUG)
                file_handler.setFormatter(formatter)
                file_handler.addFilter(SensitiveDataFilter())
                print(f"[Logger] Using fallback log: {temp_log}")
            except Exception as e2:
                print(f"[Logger] Cannot create log file: {e2}")
                return
        
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        console_handler.addFilter(SensitiveDataFilter())
        
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.DEBUG)
        
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)
        
        root_logger.addHandler(file_handler)
        
        if not getattr(sys, 'frozen', False):
            root_logger.addHandler(console_handler)
        
        logging.info("=" * 50)
        logging.info("Secure Pass Pro v4.0 starting")
        logging.info(f"Log file: {log_path}")
        logging.info(f"Python version: {sys.version}")
        logging.info(f"Platform: {sys.platform}")
        logging.info("=" * 50)
    
    def get_logger(self, name: str) -> logging.Logger:
        return logging.getLogger(name)


def get_logger(name: str) -> logging.Logger:
    """Convenience function to get logger with sensitive data filtering"""
    return SecureLogger().get_logger(name)


def log_exception(logger: logging.Logger, e: Exception, context: str = "") -> None:
    """Log exception with full traceback (без sensitive данных)"""
    import traceback
    error_msg = str(e)
    logger.error(f"Exception in {context}: {type(e).__name__}: {error_msg[:200]}")
    logger.debug(traceback.format_exc())


def log_crash_report(error: Exception, context: dict = None) -> None:
    """Create crash report file (без sensitive данных)"""
    try:
        crash_dir = get_logs_dir()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        crash_file = os.path.join(crash_dir, f"crash_{timestamp}.log")
        
        import traceback
        
        with open(crash_file, 'w', encoding='utf-8') as f:
            f.write("=" * 60 + "\n")
            f.write("SECURE PASS PRO - CRASH REPORT\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"Time: {datetime.now().isoformat()}\n")
            f.write(f"Python: {sys.version}\n")
            f.write(f"Platform: {sys.platform}\n\n")
            
            if context:
                f.write("CONTEXT:\n")
                sensitive_keys = ['password', 'master', 'key', 'secret', 'token', 'pwd', 'pass', 'decrypted', 'plaintext']
                for key, value in context.items():
                    if key.lower() not in sensitive_keys:
                        f.write(f"  {key}: {value}\n")
                f.write("\n")
            
            f.write("ERROR:\n")
            f.write(f"  {type(error).__name__}: {str(error)[:200]}\n\n")
            
            f.write("TRACEBACK:\n")
            f.write(traceback.format_exc())
            f.write("\n")
            f.write("=" * 60 + "\n")
        
        logging.error(f"Crash report saved to: {crash_file}")
        
    except Exception as e:
        logging.error(f"Failed to create crash report: {e}")


def is_sensitive_string(text: str) -> bool:
    """Check if a string contains sensitive data patterns"""
    if not text or len(text) < 4:
        return False
    
    for pattern, _ in SENSITIVE_PATTERNS:
        try:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        except re.error:
            continue
    
    return False


def redact_sensitive(text: str) -> str:
    """Redact sensitive data from a string"""
    if not text:
        return text
    
    result = text
    for pattern, replacement in SENSITIVE_PATTERNS:
        try:
            result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
        except re.error:
            continue
    
    return result