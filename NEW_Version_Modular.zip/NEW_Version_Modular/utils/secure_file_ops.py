"""
Secure file operations with atomic replace support for all platforms
"""
import os
import sys
import shutil
import platform
import ctypes
import tempfile
from typing import Optional
from utils.logger import get_logger

logger = get_logger("secure_file_ops")

# Константы для Windows MoveFileEx
if platform.system() == "Windows":
    MOVEFILE_REPLACE_EXISTING = 0x00000001
    MOVEFILE_WRITE_THROUGH = 0x00000008
    MOVEFILE_COPY_ALLOWED = 0x00000002
    MOVEFILE_DELAY_UNTIL_REBOOT = 0x00000004


def secure_replace(src: str, dst: str, retry_count: int = 3) -> bool:
    """
    Атомарная замена файла с поддержкой всех платформ.
    
    Args:
        src: исходный файл (временный)
        dst: целевой файл
        retry_count: количество попыток при ошибке
    
    Returns:
        True если успешно, False если ошибка
    """
    if not os.path.exists(src):
        logger.error(f"Source file does not exist: {src}")
        return False
    
    for attempt in range(retry_count):
        try:
            if platform.system() == "Windows":
                return _secure_replace_windows(src, dst)
            else:
                return _secure_replace_unix(src, dst)
        except Exception as e:
            logger.warning(f"Replace attempt {attempt + 1}/{retry_count} failed: {e}")
            if attempt == retry_count - 1:
                logger.error(f"Failed to replace file after {retry_count} attempts: {src} -> {dst}")
                return False
    
    return False


def _secure_replace_windows(src: str, dst: str) -> bool:
    """
    Атомарная замена на Windows через MoveFileEx.
    Поддерживает跨卷 перемещение.
    """
    try:
        # Пытаемся использовать MoveFileEx с флагами
        result = ctypes.windll.kernel32.MoveFileExW(
            src, 
            dst, 
            MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH
        )
        
        if result:
            logger.debug(f"MoveFileEx succeeded: {src} -> {dst}")
            return True
        
        # Если MoveFileEx не сработал (разные тома), используем копирование
        logger.debug(f"MoveFileEx failed, falling back to copy+delete")
        return _secure_replace_fallback(src, dst)
        
    except Exception as e:
        logger.debug(f"MoveFileEx exception: {e}, using fallback")
        return _secure_replace_fallback(src, dst)


def _secure_replace_unix(src: str, dst: str) -> bool:
    """
    Атомарная замена на Unix-системах через os.replace.
    """
    try:
        # На Unix os.replace обычно атомарный
        os.replace(src, dst)
        logger.debug(f"os.replace succeeded: {src} -> {dst}")
        return True
    except OSError as e:
        # Если ошибка (разные файловые системы), используем fallback
        logger.debug(f"os.replace failed (likely cross-device): {e}")
        return _secure_replace_fallback(src, dst)


def _secure_replace_fallback(src: str, dst: str) -> bool:
    """
    Fallback механизм: копирование + удаление.
    Не атомарный, но работает на любых файловых системах.
    """
    try:
        # Сначала создаём резервную копию если целевой файл существует
        backup = None
        if os.path.exists(dst):
            backup = dst + ".backup"
            try:
                shutil.copy2(dst, backup)
                logger.debug(f"Backup created: {backup}")
            except Exception as e:
                logger.warning(f"Failed to create backup: {e}")
        
        # Копируем исходный файл в целевой
        shutil.copy2(src, dst)
        
        # Проверяем, что файл записался корректно
        if os.path.exists(dst) and os.path.getsize(dst) == os.path.getsize(src):
            # Удаляем исходный файл
            os.remove(src)
            
            # Удаляем резервную копию если была
            if backup and os.path.exists(backup):
                try:
                    os.remove(backup)
                except:
                    pass
            
            logger.debug(f"Fallback replace succeeded: {src} -> {dst}")
            return True
        else:
            # Восстанавливаем из резервной копии
            if backup and os.path.exists(backup):
                shutil.copy2(backup, dst)
                os.remove(backup)
            logger.error("Fallback replace failed - file size mismatch")
            return False
            
    except Exception as e:
        logger.error(f"Fallback replace failed: {e}")
        return False


def secure_write(file_path: str, content: bytes, make_hidden: bool = True) -> bool:
    """
    Безопасная запись файла с атомарной заменой.
    
    Args:
        file_path: путь к файлу
        content: содержимое в байтах
        make_hidden: сделать файл скрытым на Windows
    
    Returns:
        True если успешно
    """
    directory = os.path.dirname(os.path.abspath(file_path)) or "."
    os.makedirs(directory, exist_ok=True)
    
    # Создаём временный файл в той же директории (гарантирует тот же том)
    fd, tmp_path = tempfile.mkstemp(prefix=".tmp-", dir=directory, suffix=".tmp")
    
    try:
        # Записываем во временный файл
        with os.fdopen(fd, "wb") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())  # Принудительная запись на диск
        
        # Проверяем, что запись прошла успешно
        if os.path.getsize(tmp_path) != len(content):
            raise IOError(f"Written size mismatch: expected {len(content)}, got {os.path.getsize(tmp_path)}")
        
        # Атомарно заменяем целевой файл
        if not secure_replace(tmp_path, file_path):
            raise IOError("Atomic replace failed")
        
        # Скрываем файл на Windows если нужно
        if make_hidden and platform.system() == "Windows":
            try:
                ctypes.windll.kernel32.SetFileAttributesW(file_path, 0x02)
            except Exception as e:
                logger.debug(f"Failed to hide file: {e}")
        
        logger.debug(f"Secure write succeeded: {file_path}")
        return True
        
    except Exception as e:
        logger.error(f"Secure write failed for {file_path}: {e}")
        try:
            os.remove(tmp_path)
        except:
            pass
        return False


def secure_read(file_path: str) -> Optional[bytes]:
    """
    Безопасное чтение файла с проверкой целостности.
    
    Returns:
        Содержимое файла или None при ошибке
    """
    try:
        if not os.path.exists(file_path):
            logger.warning(f"File not found: {file_path}")
            return None
        
        with open(file_path, 'rb') as f:
            content = f.read()
        
        # Базовая проверка - файл не пустой (если не должен быть)
        if len(content) == 0:
            logger.warning(f"File is empty: {file_path}")
        
        return content
        
    except Exception as e:
        logger.error(f"Failed to read {file_path}: {e}")
        return None


def secure_copy(src: str, dst: str, overwrite: bool = True) -> bool:
    """
    Безопасное копирование файла с атомарной записью.
    """
    try:
        content = secure_read(src)
        if content is None:
            return False
        
        return secure_write(dst, content)
        
    except Exception as e:
        logger.error(f"Secure copy failed: {src} -> {dst}, error: {e}")
        return False


def secure_delete(file_path: str, secure: bool = True) -> bool:
    """
    Безопасное удаление файла.
    Если secure=True, перезаписывает содержимое перед удалением.
    """
    try:
        if not os.path.exists(file_path):
            return True
        
        if secure:
            # Перезаписываем файл случайными данными перед удалением
            size = os.path.getsize(file_path)
            if size > 0 and size < 1024 * 1024 * 10:  # Только для файлов до 10MB
                try:
                    with open(file_path, 'wb') as f:
                        # Перезаписываем 3 раза для безопасности
                        for _ in range(3):
                            f.write(os.urandom(size))
                            f.flush()
                            os.fsync(f.fileno())
                            f.seek(0)
                except Exception as e:
                    logger.debug(f"Secure overwrite failed: {e}")
        
        os.remove(file_path)
        logger.debug(f"Deleted: {file_path}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to delete {file_path}: {e}")
        return False