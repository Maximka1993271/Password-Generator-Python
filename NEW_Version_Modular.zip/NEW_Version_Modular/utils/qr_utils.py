"""
QR code utilities for 2FA setup and display
FIXED: Убраны broad exceptions, добавлена безопасная обработка изображений, очистка временных файлов
"""
import os
import tempfile
import atexit
from io import BytesIO
from typing import Optional, List

from PIL import Image, ImageDraw
from utils.logger import get_logger

logger = get_logger("qr_utils")

# Проверяем наличие qrcode (опционально)
QRCODE_AVAILABLE = False
try:
    import qrcode
    QRCODE_AVAILABLE = True
    logger.info("qrcode module available - QR codes will be shown")
except ImportError as e:
    logger.warning(f"qrcode module not available - using text fallback for 2FA setup: {e}")

# Список временных файлов для очистки
_temp_qr_files: List[str] = []


def _cleanup_temp_files() -> None:
    """Очищает все временные QR-файлы при завершении"""
    global _temp_qr_files
    for file_path in _temp_qr_files[:]:
        try:
            if os.path.exists(file_path):
                # Перезаписываем перед удалением
                try:
                    size = os.path.getsize(file_path)
                    if 0 < size < 1024 * 1024:
                        with open(file_path, 'wb') as f:
                            f.write(os.urandom(size))
                            f.flush()
                except (OSError, IOError, PermissionError):
                    pass
                os.remove(file_path)
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"Failed to cleanup temp QR file {file_path}: {e}")
    _temp_qr_files.clear()


# Регистрируем очистку при завершении
atexit.register(_cleanup_temp_files)


def _register_temp_file(file_path: str) -> None:
    """Регистрирует временный файл для очистки"""
    if file_path not in _temp_qr_files:
        _temp_qr_files.append(file_path)


class QRUtils:
    """Утилиты для создания и отображения QR кодов для 2FA (с fallback)"""
    
    @staticmethod
    def is_available() -> bool:
        """Проверяет, доступен ли модуль qrcode"""
        return QRCODE_AVAILABLE
    
    @staticmethod
    def generate_qr_image(data: str, size: int = 280) -> Optional[Image.Image]:
        """
        Генерирует QR код из данных (или текстовое изображение-заглушку).
        
        Args:
            data: Данные для QR кода (обычно provisioning URI)
            size: Размер выходного изображения в пикселях
        
        Returns:
            PIL Image объект или None при ошибке
        """
        try:
            if QRCODE_AVAILABLE:
                # Создаём настоящий QR код
                qr = qrcode.QRCode(
                    version=5,
                    error_correction=qrcode.constants.ERROR_CORRECT_M,
                    box_size=10,
                    border=2,
                )
                qr.add_data(data)
                qr.make(fit=True)
                img = qr.make_image(fill_color="black", back_color="white")
                img = img.resize((size, size), Image.Resampling.LANCZOS)
                logger.debug(f"QR image generated, size={size}x{size}")
                return img
            else:
                # Создаём изображение-заглушку с текстом и инструкцией
                img = Image.new('RGB', (size, size), color='white')
                draw = ImageDraw.Draw(img)
                
                # Рисуем рамку
                draw.rectangle([2, 2, size-3, size-3], outline='black', width=2)
                
                # Заголовок
                draw.text((size//2 - 100, 30), "QR CODE NOT AVAILABLE", fill='black')
                draw.text((size//2 - 80, 55), "Install qrcode module:", fill='black')
                draw.text((size//2 - 100, 80), "pip install qrcode[pil]", fill='black')
                
                # Разделитель
                draw.line([(40, 110), (size-40, 110)], fill='black', width=1)
                
                # Инструкция
                draw.text((size//2 - 100, 130), "MANUAL SETUP:", fill='black')
                draw.text((size//2 - 100, 155), "Open Google Authenticator or", fill='black')
                draw.text((size//2 - 100, 175), "other TOTP app and enter this code:", fill='black')
                
                return img
                
        except ImportError as e:
            logger.error(f"Failed to import QR modules: {e}")
            return None
        except (ValueError, AttributeError, OSError, TypeError) as e:
            logger.error(f"Failed to generate QR image: {e}")
            return None
    
    @staticmethod
    def qr_image_to_ctk(image: Image.Image) -> Optional['ctk.CTkImage']:
        """
        Конвертирует PIL Image в CTkImage для использования в customtkinter.
        
        Args:
            image: PIL Image объект
        
        Returns:
            CTkImage объект или None при ошибке
        """
        try:
            import customtkinter as ctk
            
            ctk_image = ctk.CTkImage(
                light_image=image,
                dark_image=image,
                size=(image.width, image.height)
            )
            return ctk_image
            
        except ImportError as e:
            logger.error(f"customtkinter not available: {e}")
            return None
        except (AttributeError, TypeError, ValueError) as e:
            logger.error(f"Failed to convert image: {e}")
            return None
    
    @staticmethod
    def save_qr_temp(image: Image.Image) -> Optional[str]:
        """
        Сохраняет QR изображение во временный файл и возвращает путь.
        Файл будет автоматически удалён при завершении.
        
        Args:
            image: PIL Image объект
        
        Returns:
            Путь к временному файлу или None при ошибке
        """
        try:
            fd, temp_path = tempfile.mkstemp(suffix='.png', prefix='qr_')
            os.close(fd)
            
            image.save(temp_path, 'PNG')
            _register_temp_file(temp_path)
            logger.debug(f"QR image saved to temp file: {temp_path}")
            return temp_path
            
        except (OSError, IOError, PermissionError, AttributeError) as e:
            logger.error(f"Failed to save QR temp file: {e}")
            return None
    
    @staticmethod
    def cleanup_temp_qr_files() -> None:
        """Принудительно очищает все временные QR-файлы"""
        _cleanup_temp_files()
    
    @staticmethod
    def show_qr_window(parent, provisioning_uri: str, secret: str, 
                       lang: str = "RU", title: str = "2FA Setup") -> None:
        """
        Показывает окно с QR кодом для настройки 2FA.
        
        Args:
            parent: Родительское окно
            provisioning_uri: URI для QR кода
            secret: Секретный ключ (отображается текстом)
            lang: Язык интерфейса
            title: Заголовок окна
        """
        try:
            import customtkinter as ctk
            from localization.lang import LANGUAGES
            
            L = LANGUAGES.get(lang, LANGUAGES["RU"])
            
            # Создаём окно
            window = ctk.CTkToplevel(parent)
            window.title(title)
            window.geometry("480x650")
            window.resizable(False, False)
            window.transient(parent)
            window.grab_set()
            window.attributes("-topmost", True)
            
            # Центрируем окно
            try:
                window.update_idletasks()
                parent_x = parent.winfo_x()
                parent_y = parent.winfo_y()
                parent_width = parent.winfo_width()
                parent_height = parent.winfo_height()
                x = parent_x + (parent_width - 480) // 2
                y = parent_y + (parent_height - 650) // 2
                if x < 0:
                    x = 10
                if y < 30:
                    y = 30
                window.geometry(f"480x650+{x}+{y}")
            except (tk.TclError, AttributeError) as e:
                logger.debug(f"Window centering error: {e}")
                window.geometry("480x650")
            
            # Основной фрейм
            main_frame = ctk.CTkFrame(window, fg_color="transparent")
            main_frame.pack(fill="both", expand=True, padx=20, pady=20)
            
            # Заголовок
            try:
                ctk.CTkLabel(
                    main_frame,
                    text=L.get("2fa_setup_title", "Two-Factor Authentication Setup"),
                    font=("Segoe UI", 18, "bold")
                ).pack(pady=(0, 10))
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Title label error: {e}")
            
            # Пояснение
            try:
                ctk.CTkLabel(
                    main_frame,
                    text=L.get("2fa_scan_qr", "Scan this QR code with Google Authenticator, Authy, or any other TOTP app:"),
                    wraplength=400,
                    justify="center",
                    font=("Segoe UI", 12)
                ).pack(pady=(0, 15))
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Instruction label error: {e}")
            
            # QR код (или заглушка)
            try:
                img = QRUtils.generate_qr_image(provisioning_uri, size=250)
                if img:
                    ctk_img = QRUtils.qr_image_to_ctk(img)
                    if ctk_img:
                        qr_label = ctk.CTkLabel(main_frame, image=ctk_img, text="")
                        qr_label.image = ctk_img
                        qr_label.pack(pady=10)
            except (ValueError, AttributeError, OSError) as e:
                logger.error(f"QR image display error: {e}")
            
            # Секретный ключ (показываем всегда)
            try:
                ctk.CTkLabel(
                    main_frame,
                    text=L.get("2fa_or_enter_manually", "Or enter this code manually:"),
                    font=("Segoe UI", 11),
                    text_color="gray"
                ).pack(pady=(10, 5))
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Manual entry label error: {e}")
            
            secret_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
            secret_frame.pack(pady=5)
            
            # Показываем секрет с группировкой для удобства
            try:
                formatted_secret = ' '.join([secret[i:i+4] for i in range(0, len(secret), 4)])
                secret_label = ctk.CTkLabel(
                    secret_frame,
                    text=formatted_secret,
                    font=("Consolas", 14, "bold"),
                    fg_color=("#2b2b2b" if ctk.get_appearance_mode() == "Dark" else "#e0e0e0"),
                    corner_radius=8,
                    padx=15,
                    pady=8
                )
                secret_label.pack()
            except (ValueError, AttributeError, tk.TclError) as e:
                logger.debug(f"Secret label error: {e}")
                # Fallback: показываем без форматирования
                ctk.CTkLabel(
                    secret_frame,
                    text=secret,
                    font=("Consolas", 12),
                    fg_color=("#2b2b2b" if ctk.get_appearance_mode() == "Dark" else "#e0e0e0"),
                    corner_radius=8,
                    padx=15,
                    pady=8
                ).pack()
            
            # Кнопка копирования секрета
            def copy_secret():
                try:
                    window.clipboard_clear()
                    window.clipboard_append(secret)
                    copy_btn.configure(text=L.get("copied", "Copied!"))
                    window.after(2000, lambda: copy_btn.configure(text=L.get("copy", "Copy")))
                except (tk.TclError, AttributeError) as e:
                    logger.debug(f"Copy secret error: {e}")
            
            try:
                copy_btn = ctk.CTkButton(
                    secret_frame,
                    text=L.get("copy", "Copy"),
                    command=copy_secret,
                    width=100,
                    height=30,
                    fg_color="#2d6a4f",
                    corner_radius=15
                )
                copy_btn.pack(pady=5)
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Copy button error: {e}")
            
            # Предупреждение о резервных кодах
            try:
                ctk.CTkLabel(
                    main_frame,
                    text=L.get("2fa_backup_warning", "Save backup codes! They are required to recover access."),
                    font=("Segoe UI", 11),
                    text_color="#FFA500"
                ).pack(pady=(10, 5))
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Warning label error: {e}")
            
            # Кнопка закрытия
            try:
                ctk.CTkButton(
                    main_frame,
                    text=L.get("close", "Close"),
                    command=window.destroy,
                    width=120,
                    height=35,
                    fg_color="#8b0000",
                    corner_radius=15
                ).pack(pady=15)
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Close button error: {e}")
            
            window.after(100, lambda: QRUtils._set_topmost_false(window))
            
        except ImportError as e:
            logger.error(f"Failed to import GUI modules for QR window: {e}")
            from gui.dialogs import CTkMessageBox
            from localization.lang import LANGUAGES
            L = LANGUAGES.get(lang, LANGUAGES["RU"])
            CTkMessageBox.error(parent, title, f"{L.get('err_title', 'Error')}: {str(e)}")
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.error(f"Failed to show QR window: {e}")
            from gui.dialogs import CTkMessageBox
            from localization.lang import LANGUAGES
            L = LANGUAGES.get(lang, LANGUAGES["RU"])
            CTkMessageBox.error(parent, title, f"{L.get('err_title', 'Error')}: {str(e)}")
    
    @staticmethod
    def _set_topmost_false(window) -> None:
        """Безопасно снимает флаг topmost"""
        try:
            window.attributes("-topmost", False)
        except (tk.TclError, AttributeError):
            pass
    
    @staticmethod
    def verify_2fa_code(parent, lang: str = "RU", title: str = "2FA Verification") -> Optional[str]:
        """
        Показывает диалог для ввода 2FA кода.
        
        Args:
            parent: Родительское окно
            lang: Язык интерфейса
            title: Заголовок окна
        
        Returns:
            Введённый код или None при отмене
        """
        try:
            import customtkinter as ctk
            from localization.lang import LANGUAGES
            
            L = LANGUAGES.get(lang, LANGUAGES["RU"])
            
            result = {"code": None}
            
            dialog = ctk.CTkToplevel(parent)
            dialog.title(title)
            dialog.geometry("400x300")
            dialog.resizable(False, False)
            dialog.transient(parent)
            dialog.grab_set()
            dialog.attributes("-topmost", True)
            
            # Центрируем
            try:
                dialog.update_idletasks()
                parent_x = parent.winfo_x()
                parent_y = parent.winfo_y()
                parent_width = parent.winfo_width()
                parent_height = parent.winfo_height()
                x = parent_x + (parent_width - 400) // 2
                y = parent_y + (parent_height - 300) // 2
                dialog.geometry(f"400x300+{x}+{y}")
            except (tk.TclError, AttributeError) as e:
                logger.debug(f"Center dialog error: {e}")
                dialog.geometry("400x300")
            
            # Определяем цвета
            try:
                theme = "dark" if ctk.get_appearance_mode() == "Dark" else "light"
            except (AttributeError, tk.TclError):
                theme = "dark"
            
            if theme == "light":
                bg_color = "#F3F3F3"
                fg_color = "#000000"
                entry_bg = "#FFFFFF"
            else:
                bg_color = "#1d1e1e"
                fg_color = "#FFFFFF"
                entry_bg = "#2b2b2b"
            
            dialog.configure(fg_color=bg_color)
            
            main_frame = ctk.CTkFrame(dialog, fg_color="transparent")
            main_frame.pack(fill="both", expand=True, padx=20, pady=20)
            
            # Иконка
            try:
                ctk.CTkLabel(
                    main_frame,
                    text="",
                    font=("Segoe UI", 36),
                    text_color="#4EC9B0"
                ).pack(pady=(0, 10))
            except (tk.TclError, AttributeError) as e:
                logger.debug(f"Icon label error: {e}")
            
            # Текст
            try:
                ctk.CTkLabel(
                    main_frame,
                    text=L.get("2fa_enter_code", "Enter verification code:"),
                    font=("Segoe UI", 14, "bold"),
                    text_color=fg_color
                ).pack(pady=(0, 15))
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Prompt label error: {e}")
            
            # Поле ввода
            entry = ctk.CTkEntry(
                main_frame,
                width=200,
                height=45,
                font=("Consolas", 20, "bold"),
                justify="center",
                fg_color=entry_bg,
                text_color=fg_color
            )
            entry.pack(pady=(0, 15))
            entry.focus_set()
            
            # Статус
            status_label = ctk.CTkLabel(
                main_frame,
                text="",
                font=("Segoe UI", 11),
                text_color="#E24B4A"
            )
            status_label.pack()
            
            def on_verify():
                try:
                    code = entry.get().strip()
                    if len(code) == 6 and code.isdigit():
                        result["code"] = code
                        dialog.destroy()
                    else:
                        try:
                            status_label.configure(text=L.get("2fa_invalid_code", "Please enter a valid 6-digit code"))
                        except (tk.TclError, KeyError):
                            pass
                        entry.delete(0, "end")
                        entry.focus_set()
                except (tk.TclError, AttributeError) as e:
                    logger.debug(f"Verify function error: {e}")
            
            def on_cancel():
                dialog.destroy()
            
            # Кнопки
            btn_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
            btn_frame.pack(pady=10)
            
            try:
                ctk.CTkButton(
                    btn_frame,
                    text=L.get("ok", "Verify"),
                    command=on_verify,
                    width=110,
                    height=35,
                    fg_color="#2d6a4f",
                    corner_radius=17
                ).pack(side="left", padx=10)
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Verify button error: {e}")
            
            try:
                ctk.CTkButton(
                    btn_frame,
                    text=L.get("cancel", "Cancel"),
                    command=on_cancel,
                    width=110,
                    height=35,
                    fg_color="#8b0000",
                    corner_radius=17
                ).pack(side="left", padx=10)
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Cancel button error: {e}")
            
            entry.bind("<Return>", lambda e: on_verify())
            entry.bind("<Escape>", lambda e: on_cancel())
            
            dialog.after(100, lambda: QRUtils._set_topmost_false(dialog))
            
            parent.wait_window(dialog)
            
            return result["code"]
            
        except ImportError as e:
            logger.error(f"Failed to import GUI modules for verification: {e}")
            return None
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.error(f"Failed to show verification dialog: {e}")
            return None


__all__ = ['QRUtils', 'QRCODE_AVAILABLE', 'cleanup_temp_qr_files']