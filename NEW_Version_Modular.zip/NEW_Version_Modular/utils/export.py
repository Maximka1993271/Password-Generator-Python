"""
Data export utilities for JSON, CSV, HTML with encryption support

Утилиты экспорта данных в JSON, CSV, HTML с поддержкой шифрования
Утиліти експорту даних у JSON, CSV, HTML з підтримкою шифрування
"""
import json
import csv
import os
import datetime
import tkinter as tk
import tempfile
import shutil
import re
import hashlib
import hmac
import secrets
from typing import List, Dict, Any, Optional, Tuple
from tkinter import filedialog
from utils.logger import get_logger

# Try to import cryptography for export encryption / Попытка импорта криптографии для шифрования экспорта / Спроба імпорту криптографії для шифрування експорту
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

logger = get_logger("export")

# Maximum export file size / Максимальный размер файла экспорта / Максимальний розмір файлу експорту
MAX_EXPORT_SIZE = 50 * 1024 * 1024  # 50 MB

# Maximum password length for encryption / Максимальная длина пароля для шифрования / Максимальна довжина пароля для шифрування
MAX_ENCRYPT_PASSWORD_LENGTH = 128

# Minimum password length for encryption / Минимальная длина пароля для шифрования / Мінімальна довжина пароля для шифрування
MIN_ENCRYPT_PASSWORD_LENGTH = 8


class ExportError(Exception):
    """Exception for export errors / Исключение для ошибок экспорта / Виняток для помилок експорту"""
    pass


class EncryptionError(ExportError):
    """Exception for encryption errors / Исключение для ошибок шифрования / Виняток для помилок шифрування"""
    pass


class ValidationError(ExportError):
    """Exception for validation errors / Исключение для ошибок валидации / Виняток для помилок валідації"""
    pass


def sanitize_export_data(data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Sanitize data before export (remove sensitive patterns, limit size).
    
    Очищает данные перед экспортом (удаляет чувствительные паттерны, ограничивает размер).
    Очищує дані перед експортом (видаляє чутливі патерни, обмежує розмір).
    
    Args:
        data: Raw export data / Исходные данные для экспорта / Вихідні дані для експорту
    
    Returns:
        Sanitized data / Очищенные данные / Очищені дані
    """
    sanitized = []
    
    for item in data:
        sanitized_item = {}
        for key, value in item.items():
            if value is None:
                sanitized_item[key] = ""
            elif isinstance(value, str):
                # Remove control characters / Удаляем управляющие символы / Видаляємо керуючі символи
                cleaned = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', value)
                # Limit length / Ограничиваем длину / Обмежуємо довжину
                if len(cleaned) > 10000:
                    cleaned = cleaned[:10000] + "...[TRUNCATED]"
                sanitized_item[key] = cleaned
            else:
                sanitized_item[key] = value
        sanitized.append(sanitized_item)
    
    return sanitized


def validate_export_password(password: str) -> Tuple[bool, str]:
    """
    Validate encryption password strength.
    
    Проверяет надёжность пароля для шифрования.
    Перевіряє надійність пароля для шифрування.
    
    Args:
        password: Password to validate / Пароль для проверки / Пароль для перевірки
    
    Returns:
        (is_valid, error_message) / (is_valid, error_message) / (is_valid, error_message)
    """
    if not password:
        return False, "Password cannot be empty"
    
    if len(password) < MIN_ENCRYPT_PASSWORD_LENGTH:
        return False, f"Password must be at least {MIN_ENCRYPT_PASSWORD_LENGTH} characters"
    
    if len(password) > MAX_ENCRYPT_PASSWORD_LENGTH:
        return False, f"Password must be at most {MAX_ENCRYPT_PASSWORD_LENGTH} characters"
    
    return True, ""


def encrypt_export_file(data: bytes, password: str) -> bytes:
    """
    Encrypt exported data with password.
    
    Зашифровать экспортированные данные паролем.
    Зашифрувати експортовані дані паролем.
    
    Args:
        data: Data to encrypt / Данные для шифрования / Дані для шифрування
        password: Encryption password / Пароль для шифрования / Пароль для шифрування
    
    Returns:
        Encrypted data with salt and nonce / Зашифрованные данные с солью и nonce / Зашифровані дані з сіллю та nonce
    
    Raises:
        EncryptionError: If encryption fails / Если шифрование не удалось / Якщо шифрування не вдалося
    """
    if not CRYPTO_AVAILABLE:
        raise EncryptionError("Cryptography module not available for encryption")
    
    is_valid, error = validate_export_password(password)
    if not is_valid:
        raise EncryptionError(f"Invalid encryption password: {error}")
    
    try:
        # Generate random salt and nonce / Генерируем случайную соль и nonce / Генеруємо випадкову сіль та nonce
        salt = os.urandom(16)
        nonce = os.urandom(12)
        
        # Derive key from password with many iterations / Получаем ключ из пароля с большим количеством итерацій / Отримуємо ключ з пароля з великою кількістю ітерацій
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=600000,  # High iteration count for security
        )
        key = kdf.derive(password.encode('utf-8'))
        
        # Encrypt with AES-GCM / Шифруем с AES-GCM / Шифруємо з AES-GCM
        aesgcm = AESGCM(key)
        ciphertext = aesgcm.encrypt(nonce, data, None)
        
        # Format: salt(16) + nonce(12) + ciphertext
        # Формат: salt(16) + nonce(12) + ciphertext
        # Формат: salt(16) + nonce(12) + ciphertext
        result = salt + nonce + ciphertext
        
        # Securely clear sensitive data / Безопасно очищаем чувствительные данные / Безпечно очищуємо чутливі дані
        key = None
        kdf = None
        
        return result
        
    except (ValueError, TypeError, MemoryError, RuntimeError) as e:
        logger.error(f"Encryption error: {e}")
        raise EncryptionError(f"Failed to encrypt export: {e}")


def verify_export_integrity(file_path: str, expected_size: Optional[int] = None) -> bool:
    """
    Verify exported file integrity.
    
    Проверяет целостность экспортированного файла.
    Перевіряє цілісність експортованого файлу.
    
    Args:
        file_path: Path to exported file / Путь к экспортированному файлу / Шлях до експортованого файлу
        expected_size: Expected file size (optional) / Ожидаемый размер файла (опционально) / Очікуваний розмір файлу (опціонально)
    
    Returns:
        True if file is valid / True если файл валиден / True якщо файл дійсний
    """
    try:
        if not os.path.exists(file_path):
            logger.error(f"Export file not found: {file_path}")
            return False
        
        size = os.path.getsize(file_path)
        if size == 0:
            logger.error("Export file is empty")
            return False
        
        if expected_size and abs(size - expected_size) > 1024:  # 1KB tolerance
            logger.warning(f"File size mismatch: expected {expected_size}, got {size}")
            # Not failing, just warning
        
        return True
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Integrity check failed: {e}")
        return False


class DataExporter:
    """Data export to JSON, CSV, HTML with advanced features
    Экспорт данных в JSON, CSV, HTML с расширенными возможностями
    Експорт даних у JSON, CSV, HTML з розширеними можливостями"""

    @staticmethod
    def export_json(data: List[Dict[str, Any]], file_path: str,
                    fields: List[str] = None, encrypt: bool = False,
                    password: str = None) -> bool:
        """Export to JSON with field selection and encryption
        Экспорт в JSON с выбором полей и шифрованием
        Експорт у JSON з вибором полів та шифруванням"""
        try:
            # Sanitize data / Очищаем данные / Очищуємо дані
            export_data = sanitize_export_data(data)
            
            # Filter fields / Фильтруем поля / Фільтруємо поля
            filtered_data = []
            for item in export_data:
                if fields:
                    filtered_item = {k: v for k, v in item.items() if k in fields}
                else:
                    filtered_item = item.copy()
                # Remove None values / Удаляем None значения / Видаляємо None значення
                filtered_item = {k: v for k, v in filtered_item.items() if v is not None}
                filtered_data.append(filtered_item)
            
            # Create export wrapper / Создаём обёртку для экспорта / Створюємо обгортку для експорту
            export_wrapper = {
                "export_date": datetime.datetime.now().isoformat(),
                "app": "Secure Pass Pro v4.0",
                "count": len(data),
                "fields": fields if fields else list(data[0].keys()) if data else [],
                "passwords": filtered_data
            }
            
            json_data = json.dumps(export_wrapper, indent=2, ensure_ascii=False).encode('utf-8')
            
            # Encrypt if requested / Шифруем если нужно / Шифруємо якщо потрібно
            if encrypt and password:
                json_data = encrypt_export_file(json_data, password)
                file_path = file_path.replace('.json', '.enc.json')
            
            # Write to temp file first for safety / Сначала пишем во временный файл для безопасности / Спочатку пишемо у тимчасовий файл для безпеки
            temp_fd, temp_path = tempfile.mkstemp(suffix='.tmp', prefix='export_')
            os.close(temp_fd)
            
            try:
                with open(temp_path, 'wb') as f:
                    f.write(json_data)
                    f.flush()
                    os.fsync(f.fileno())
                
                # Move to final destination / Перемещаем в конечное место / Переміщуємо в кінцеве місце
                shutil.move(temp_path, file_path)
                
                # Verify integrity / Проверяем целостность / Перевіряємо цілісність
                if not verify_export_integrity(file_path, len(json_data)):
                    raise ExportError("Export file integrity check failed")
                
                logger.info(f"JSON export successful: {file_path}")
                return True
            finally:
                if os.path.exists(temp_path):
                    try:
                        os.remove(temp_path)
                    except (OSError, IOError, PermissionError):
                        pass
                        
        except (OSError, IOError, TypeError, json.JSONDecodeError, shutil.Error) as e:
            logger.error(f"JSON export error: {e}")
            return False
        except EncryptionError as e:
            logger.error(f"Encryption error during JSON export: {e}")
            return False
        except ExportError as e:
            logger.error(f"Export error: {e}")
            return False

    @staticmethod
    def export_csv(data: List[Dict[str, Any]], file_path: str,
                   fields: List[str] = None, encoding: str = 'utf-8-sig') -> bool:
        """Export to CSV with field selection and encoding
        Экспорт в CSV с выбором полей и кодировки
        Експорт у CSV з вибором полів та кодування"""
        try:
            if not data:
                logger.warning("No data to export to CSV")
                return False

            # Sanitize data / Очищаем данные / Очищуємо дані
            export_data = sanitize_export_data(data)
            
            if fields is None:
                fields = ['id', 'label', 'password', 'created', 'notes']
            
            # Filter existing fields / Фильтруем существующие поля / Фільтруємо існуючі поля
            existing_fields = [f for f in fields if f in export_data[0] or f == 'id']
            
            # Write to temp file first / Сначала пишем во временный файл / Спочатку пишемо у тимчасовий файл
            temp_fd, temp_path = tempfile.mkstemp(suffix='.tmp', prefix='export_')
            os.close(temp_fd)
            
            try:
                with open(temp_path, 'w', encoding=encoding, newline='') as f:
                    writer = csv.DictWriter(f, fieldnames=existing_fields)
                    writer.writeheader()
                    for row in export_data:
                        filtered_row = {k: row.get(k, '') for k in existing_fields}
                        filtered_row = {k: (v if v is not None else '') for k, v in filtered_row.items()}
                        writer.writerow(filtered_row)
                
                # Move to final destination / Перемещаем в конечное место / Переміщуємо в кінцеве місце
                shutil.move(temp_path, file_path)
                
                # Verify integrity / Проверяем целостность / Перевіряємо цілісність
                if not verify_export_integrity(file_path):
                    raise ExportError("Export file integrity check failed")
                
                logger.info(f"CSV export successful: {file_path}")
                return True
            finally:
                if os.path.exists(temp_path):
                    try:
                        os.remove(temp_path)
                    except (OSError, IOError, PermissionError):
                        pass
                        
        except (OSError, IOError, csv.Error, shutil.Error) as e:
            logger.error(f"CSV export error: {e}")
            return False
        except ExportError as e:
            logger.error(f"Export error: {e}")
            return False

    @staticmethod
    def export_html(data: List[Dict[str, Any]], file_path: str, lang: str = "RU",
                    fields: List[str] = None) -> bool:
        """Export to HTML with interactive search, sorting, highlighting and printing
        Экспорт в HTML с интерактивным поиском, сортировкой, подсветкой и печатью
        Експорт у HTML з інтерактивним пошуком, сортуванням, підсвіткою та друком"""
        try:
            from localization.lang import LANGUAGES
            
            # Sanitize data / Очищаем данные / Очищуємо дані
            export_data = sanitize_export_data(data)
            
            L = LANGUAGES.get(lang, LANGUAGES["RU"])
            now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # Get translated phrase "No label" from language dictionary
            no_label_text = L.get("db_no_label", "No label")

            if fields is None:
                fields = ['id', 'label', 'password', 'created', 'notes']

            # Table headers / Заголовки таблицы / Заголовки таблиці
            headers = {
                'id': '#',
                'label': L.get('db_edit_label', 'Label'),
                'password': L.get('pdf_pass', 'Password'),
                'created': L.get('pdf_date', 'Date'),
                'notes': L.get('db_notes', 'Notes')
            }

            rows = ""
            for i, row in enumerate(export_data, 1):
                row_html = "<tr>"
                for field in fields:
                    raw_value = row.get(field, '')
                    if raw_value is None:
                        raw_value = ''
                    
                    if field == 'id':
                        value = str(i)
                    else:
                        value = str(raw_value)
                    
                    # For label field, replace empty values with translated version
                    if field == "label":
                        if not value or value.strip() == "" or value in ["Без метки", "No label", "Без мітки"]:
                            value = no_label_text
                        
                    escaped_value = value.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
                    
                    if field == "password":
                        row_html += f'<td class="password-cell" data-field="{field}" data-value="{escaped_value}"><span class="password" title="{L.get("db_copy", "Copy")}">{escaped_value}</span></td>'
                    elif field == "label":
                        row_html += f'<td class="label-cell" data-field="{field}" data-value="{escaped_value}"><strong>{escaped_value}</strong></td>'
                    elif field == "created":
                        row_html += f'<td class="date-cell" data-field="{field}" data-value="{escaped_value}">{escaped_value}</td>'
                    else:
                        row_html += f'<td class="{field}-cell" data-field="{field}" data-value="{escaped_value}">{escaped_value}</td>'
                row_html += "</tr>"
                rows += row_html

            header_html = ""
            for index, field in enumerate(fields):
                header_text = headers.get(field, field.capitalize())
                header_html += f'<th onclick="sortTable({index})" title="{L.get("export_sort_title", "Sort by")} {header_text}">{header_text}<span class="sort-icon"></span></th>'

            # Write to temp file first / Сначала пишем во временный файл / Спочатку пишемо у тимчасовий файл
            temp_fd, temp_path = tempfile.mkstemp(suffix='.tmp', prefix='export_')
            os.close(temp_fd)
            
            try:
                with open(temp_path, 'w', encoding='utf-8') as f:
                    f.write(DataExporter._generate_html_content(
                        lang, L, now, no_label_text, fields, headers, rows, header_html, len(export_data)
                    ))
                
                # Move to final destination / Перемещаем в конечное место / Переміщуємо в кінцеве місце
                shutil.move(temp_path, file_path)
                
                # Verify integrity / Проверяем целостность / Перевіряємо цілісність
                if not verify_export_integrity(file_path):
                    raise ExportError("Export file integrity check failed")
                
                logger.info(f"HTML export successful: {file_path}")
                return True
            finally:
                if os.path.exists(temp_path):
                    try:
                        os.remove(temp_path)
                    except (OSError, IOError, PermissionError):
                        pass
                        
        except (OSError, IOError, shutil.Error) as e:
            logger.error(f"HTML export error: {e}")
            return False
        except ExportError as e:
            logger.error(f"Export error: {e}")
            return False
    
    @staticmethod
    def _generate_html_content(lang: str, L, now: str, no_label_text: str,
                                fields: List[str], headers: Dict[str, str],
                                rows: str, header_html: str, data_count: int) -> str:
        """Generate HTML content (helper method) / Генерация HTML содержимого (вспомогательный метод) / Генерація HTML вмісту (допоміжний метод)"""
        
        # Texts for different languages
        texts = {
            'search_placeholder': {
                'RU': "Поиск по названию метки, значению пароля или дате создания...",
                'EN': "Search by label, password or date...",
                'UA': "Пошук за назвою мітки, значенням пароля або датою створення..."
            },
            'reset_btn': {'RU': "Сбросить", 'EN': "Reset", 'UA': "Скинути"},
            'print_btn': {'RU': "Печать отчёта", 'EN': "Print report", 'UA': "Друк звіту"},
            'copy_hint': {
                'RU': "Нажмите на пароль для копирования в буфер обмена",
                'EN': "Click on password to copy to clipboard",
                'UA': "Натисніть на пароль для копіювання в буфер обміну"
            },
            'copied_toast': {
                'RU': "Пароль скопирован!",
                'EN': "Password copied!",
                'UA': "Пароль скопійовано!"
            },
            'footer_copyright': {
                'RU': "Данные экспортированы в защищенном режиме.",
                'EN': "Data exported in secure mode.",
                'UA': "Дані експортовано в захищеному режимі."
            }
        }
        
        search_placeholder = texts['search_placeholder'].get(lang, texts['search_placeholder']['RU'])
        reset_btn_text = texts['reset_btn'].get(lang, texts['reset_btn']['RU'])
        print_btn_text = texts['print_btn'].get(lang, texts['print_btn']['RU'])
        copy_hint_text = texts['copy_hint'].get(lang, texts['copy_hint']['RU'])
        copied_toast_text = texts['copied_toast'].get(lang, texts['copied_toast']['RU'])
        footer_text = texts['footer_copyright'].get(lang, texts['footer_copyright']['RU'])
        
        return f"""<!DOCTYPE html>
<html lang="{lang.lower()}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Pass Pro - {L.get('export_passwords', 'Passwords')}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #0b0f19;
            color: #f1f5f9;
            padding: 40px 20px;
            line-height: 1.5;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: #111827;
            border-radius: 16px;
            border: 1px solid #1f2937;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3), 0 8px 10px -6px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #064e3b 0%, #022c22 100%);
            padding: 30px;
            text-align: center;
            border-bottom: 1px solid #065f46;
        }}
        .header h1 {{
            font-size: 28px;
            font-weight: 700;
            color: #10b981;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
        }}
        .header p {{
            color: #a7f3d0;
            font-size: 14px;
            opacity: 0.85;
        }}
        .control-panel {{
            background: #1f2937;
            padding: 20px 30px;
            border-bottom: 1px solid #374151;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }}
        .search-row {{
            display: flex;
            gap: 12px;
            align-items: center;
        }}
        .search-wrapper {{
            position: relative;
            flex: 1;
        }}
        .search-box {{
            width: 100%;
            padding: 12px 16px;
            border-radius: 10px;
            border: 1px solid #4b5563;
            background: #0f172a;
            color: #fff;
            font-size: 14px;
            transition: all 0.2s ease;
        }}
        .search-box:focus {{
            outline: none;
            border-color: #10b981;
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
        }}
        .btn {{
            background: #059669;
            border: none;
            color: #fff;
            padding: 10px 20px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
            user-select: none;
        }}
        .btn:hover {{ background: #10b981; }}
        .btn-secondary {{
            background: #374151;
            border: 1px solid #4b5563;
        }}
        .btn-secondary:hover {{ background: #4b5563; }}
        .meta-row {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
            color: #9ca3af;
            border-top: 1px solid #374151;
            padding-top: 14px;
            flex-wrap: wrap;
            gap: 10px;
        }}
        .meta-item span {{
            color: #f3f4f6;
            font-weight: 600;
        }}
        .hint-badge {{
            background: #111827;
            padding: 4px 10px;
            border-radius: 6px;
            border: 1px solid #374151;
            color: #10b981;
            font-size: 12px;
        }}
        .content {{
            padding: 0;
            overflow-x: auto;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            font-size: 14px;
        }}
        th {{
            background: #1f2937;
            color: #9ca3af;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
            padding: 16px 24px;
            border-bottom: 2px solid #374151;
            cursor: pointer;
            user-select: none;
            transition: all 0.2s ease;
        }}
        th:hover {{
            background: #2563eb;
            color: #fff;
        }}
        th .sort-icon {{
            margin-left: 8px;
            display: inline-block;
            font-size: 11px;
            opacity: 0.5;
        }}
        th.sort-asc, th.sort-desc {{
            color: #fff;
            background: #2563eb;
        }}
        td {{
            padding: 16px 24px;
            border-bottom: 1px solid #1f2937;
            color: #e5e7eb;
            vertical-align: middle;
        }}
        tr:hover td {{
            background: #1f2937;
        }}
        .label-cell strong {{
            color: #60a5fa;
            font-size: 15px;
        }}
        .password-cell .password {{
            font-family: "JetBrains Mono", "Fira Code", "Consolas", monospace;
            color: #34d399;
            font-weight: bold;
            cursor: pointer;
            background: rgba(52, 211, 153, 0.1);
            padding: 6px 12px;
            border-radius: 8px;
            border: 1px solid rgba(52, 211, 153, 0.2);
            display: inline-block;
            transition: all 0.2s ease;
            font-size: 13px;
            word-break: break-all;
            max-width: 400px;
        }}
        .password-cell .password:hover {{
            color: #fbbf24;
            background: rgba(251, 191, 36, 0.1);
            border-color: rgba(251, 191, 36, 0.3);
            transform: translateY(-1px);
        }}
        .date-cell {{
            color: #9ca3af;
            font-size: 13px;
            font-family: monospace;
        }}
        .id-cell {{
            color: #6b7280;
            font-weight: 600;
            width: 60px;
        }}
        mark.highlight {{
            background: #b45309;
            color: #fff;
            padding: 2px 4px;
            border-radius: 4px;
        }}
        .footer {{
            background: #111827;
            padding: 20px 30px;
            text-align: center;
            color: #6b7280;
            font-size: 13px;
            border-top: 1px solid #1f2937;
        }}
        .toast {{
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #10b981;
            color: #fff;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.3);
            transform: translateY(100px);
            opacity: 0;
            pointer-events: none;
            transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            z-index: 9999;
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .toast.show {{
            transform: translateY(0);
            opacity: 1;
        }}
        
        @media print {{
            body {{ background: #fff; color: #000; padding: 0; margin: 0; }}
            .container {{ border: none; box-shadow: none; max-width: 100%; background: #fff; }}
            .control-panel, .hint-badge, th .sort-icon {{ display: none !important; }}
            .header {{ background: #f3f4f6 !important; border-bottom: 2px solid #000; padding: 15px; color: #000; }}
            .header h1 {{ color: #000; }}
            .header p {{ color: #374151; }}
            th {{ background: #e5e7eb !important; color: #000 !important; border-bottom: 2px solid #000; padding: 10px 12px; }}
            td {{ color: #000 !important; border-bottom: 1px solid #e5e7eb; padding: 10px 12px; background: transparent !important; }}
            .password-cell .password {{ background: none !important; border: none !important; padding: 0; color: #000 !important; }}
            .label-cell strong {{ color: #000 !important; }}
        }}
        
        @media (max-width: 768px) {{
            td, th {{ padding: 12px 16px; }}
            .password-cell .password {{ font-size: 11px; padding: 4px 8px; max-width: 200px; }}
            .container {{ margin: 10px; }}
            body {{ padding: 10px; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{L.get('export_app', 'Secure Pass Pro v4.0')}</h1>
            <p>{L.get('export_passwords', 'Passwords Export')}</p>
        </div>
        <div class="control-panel">
            <div class="search-row">
                <div class="search-wrapper">
                    <input type="text" id="searchInput" class="search-box" placeholder="{search_placeholder}" oninput="filterTable()">
                </div>
                <button class="btn btn-secondary" onclick="clearSearch()">{reset_btn_text}</button>
                <button class="btn" onclick="window.print()">{print_btn_text}</button>
            </div>
            <div class="meta-row">
                <div class="meta-item">{L.get('db_count', 'Records')}: <span id="recordCount">{data_count}</span></div>
                <div class="meta-item">{L.get('export_date', 'Export date')}: <span>{now}</span></div>
                <div class="meta-item hint-badge">{copy_hint_text}</div>
            </div>
        </div>
        <div class="content">
            <table id="passwordTable">
                <thead>
                    <tr>{header_html}</tr>
                </thead>
                <tbody id="tableBody">{rows}</tbody>
            </table>
        </div>
        <div class="footer">
            {L.get('export_app', 'Secure Pass Pro v4.0')} (c) {datetime.datetime.now().year} | {footer_text}
        </div>
    </div>
    
    <div id="copyToast" class="toast">{copied_toast_text}</div>

    <script>
        let currentSortCol = -1;
        let isSortAsc = true;

        function filterTable() {{
            const input = document.getElementById('searchInput');
            const query = input.value.trim().toLowerCase();
            const tbody = document.getElementById('tableBody');
            const rows = tbody.querySelectorAll('tr');
            let matchedCount = 0;

            rows.forEach(row => {{
                let rowMatches = false;
                const cells = row.querySelectorAll('td');
                
                cells.forEach(cell => {{
                    const targetElement = cell.querySelector('[data-value]') || cell;
                    const originalText = targetElement.getAttribute('data-value') || targetElement.innerText || '';
                    
                    if (query === '') {{
                        targetElement.innerHTML = originalText;
                        rowMatches = true;
                    }} else if (originalText.toLowerCase().includes(query)) {{
                        rowMatches = true;
                        const regex = new RegExp('(' + escapeRegExp(query) + ')', 'gi');
                        targetElement.innerHTML = originalText.replace(regex, '<mark class="highlight">$1</mark>');
                    }} else {{
                        targetElement.innerHTML = originalText;
                    }}
                }});

                if (rowMatches) {{
                    row.style.display = '';
                    matchedCount++;
                }} else {{
                    row.style.display = 'none';
                }}
            }});

            document.getElementById('recordCount').innerText = matchedCount;
        }}

        function clearSearch() {{
            document.getElementById('searchInput').value = '';
            filterTable();
        }}

        function escapeRegExp(string) {{
            return string.replace(/[.*+?^${{}}()|[\]\\\\]/g, '\\\\$&');
        }}

        function sortTable(colIndex) {{
            const tbody = document.getElementById('tableBody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            const headers = document.querySelectorAll('th');

            if (currentSortCol === colIndex) {{
                isSortAsc = !isSortAsc;
            }} else {{
                currentSortCol = colIndex;
                isSortAsc = true;
            }}

            headers.forEach((th, idx) => {{
                th.classList.remove('sort-asc', 'sort-desc');
                if (idx === colIndex) {{
                    th.classList.add(isSortAsc ? 'sort-asc' : 'sort-desc');
                }}
            }});

            rows.sort((rowA, rowB) => {{
                const cellA = rowA.cells[colIndex];
                const cellB = rowB.cells[colIndex];
                
                const targetA = cellA.querySelector('[data-value]') || cellA;
                const targetB = cellB.querySelector('[data-value]') || cellB;

                const valA = targetA.getAttribute('data-value') || targetA.innerText;
                const valB = targetB.getAttribute('data-value') || targetB.innerText;
                const fieldType = targetA.getAttribute('data-field') || cellA.getAttribute('class');

                if (fieldType === 'id-cell' || (colIndex === 0 && !isNaN(valA) && !isNaN(valB))) {{
                    return isSortAsc ? parseInt(valA) - parseInt(valB) : parseInt(valB) - parseInt(valA);
                }}

                if (fieldType === 'date-cell' && valA.includes('-') && valB.includes('-')) {{
                    return isSortAsc ? new Date(valA) - new Date(valB) : new Date(valB) - new Date(valA);
                }}

                return isSortAsc ? valA.localeCompare(valB) : valB.localeCompare(valA);
            }});

            rows.forEach(row => tbody.appendChild(row));
        }}

        document.getElementById('tableBody').addEventListener('click', function(e) {{
            const target = e.target.closest('.password');
            if (!target) return;

            const textToCopy = target.getAttribute('data-value') || target.innerText;
            
            navigator.clipboard.writeText(textToCopy).then(() => {{
                const toast = document.getElementById('copyToast');
                toast.classList.add('show');
                setTimeout(() => {{
                    toast.classList.remove('show');
                }}, 2000);
            }}).catch(err => {{
                console.error('Copy failed: ', err);
            }});
        }});
    </script>
</body>
</html>"""

    @staticmethod
    def show_export_dialog(data: List[Dict[str, Any]], parent, lang: str = "RU") -> None:
        """Extended dialog for export format selection
        Расширенный диалог выбора формата экспорта
        Розширений діалог вибору формату експорту"""
        from storage.database import PasswordDB
        from gui.dialogs import CTkMessageBox
        import customtkinter as ctk
        from localization.lang import LANGUAGES

        if not data:
            data = PasswordDB.get_all()

        if not data:
            CTkMessageBox.warning(parent, "Export", LANGUAGES.get(lang, LANGUAGES["RU"]).get("export_no_data", "No data to export!"))
            return

        L = LANGUAGES.get(lang, LANGUAGES["RU"])

        win = ctk.CTkToplevel(parent)
        win.title(L.get("export_title", "Export Data"))
        win.geometry("750x700")
        win.resizable(False, False)
        win.transient(parent)
        win.grab_set()
        win.attributes("-topmost", True)

        win.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - 750) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 700) // 2
        win.geometry(f"750x700+{x}+{y}")

        format_var = tk.StringVar(value="json")
        encrypt_var = tk.BooleanVar(value=False)
        encrypt_password = tk.StringVar()
        encrypt_error_label = None

        ctk.CTkLabel(win, text=L.get("export_format", "Export format:"),
                    font=("Segoe UI", 14, "bold")).pack(pady=(20, 10))

        format_frame = ctk.CTkFrame(win, fg_color="transparent")
        format_frame.pack(pady=5)

        ctk.CTkRadioButton(format_frame, text="JSON", variable=format_var,
                          value="json", font=("Segoe UI", 13)).pack(side="left", padx=15)
        ctk.CTkRadioButton(format_frame, text="CSV", variable=format_var,
                          value="csv", font=("Segoe UI", 13)).pack(side="left", padx=15)
        ctk.CTkRadioButton(format_frame, text="HTML", variable=format_var,
                          value="html", font=("Segoe UI", 13)).pack(side="left", padx=15)

        ctk.CTkFrame(win, height=2, fg_color="gray").pack(fill="x", padx=20, pady=10)

        ctk.CTkLabel(win, text=L.get("export_fields", "Select fields to export:"),
                    font=("Segoe UI", 13, "bold")).pack(pady=(5, 5))

        fields_frame = ctk.CTkFrame(win, fg_color="transparent")
        fields_frame.pack(pady=5)

        field_names = {
            'id': "#",
            'label': L.get("db_edit_label", "Label"),
            'password': L.get("pdf_pass", "Password"),
            'created': L.get("pdf_date", "Date"),
            'notes': L.get("db_notes", "Notes")
        }

        field_vars = {
            'id': tk.BooleanVar(value=True),
            'label': tk.BooleanVar(value=True),
            'password': tk.BooleanVar(value=True),
            'created': tk.BooleanVar(value=True),
            'notes': tk.BooleanVar(value=False)
        }

        for field, name in field_names.items():
            ctk.CTkCheckBox(fields_frame, text=name, variable=field_vars[field],
                           font=("Segoe UI", 12)).pack(side="left", padx=15)

        ctk.CTkFrame(win, height=2, fg_color="gray").pack(fill="x", padx=20, pady=10)

        ctk.CTkLabel(win, text=L.get("export_encoding", "Encoding (for CSV):"),
                    font=("Segoe UI", 13, "bold")).pack(pady=(5, 5))

        encoding_var = tk.StringVar(value="utf-8-sig")
        encoding_frame = ctk.CTkFrame(win, fg_color="transparent")
        encoding_frame.pack(pady=5)

        encodings = [
            ("UTF-8", "utf-8-sig"),
            ("UTF-16", "utf-16"),
            ("Windows-1251", "cp1251")
        ]
        for enc_name, enc_val in encodings:
            ctk.CTkRadioButton(encoding_frame, text=enc_name, variable=encoding_var,
                              value=enc_val, font=("Segoe UI", 11)).pack(anchor="w", padx=30, pady=2)

        ctk.CTkFrame(win, height=2, fg_color="gray").pack(fill="x", padx=20, pady=10)

        if CRYPTO_AVAILABLE:
            encrypt_check = ctk.CTkCheckBox(win, text=L.get("export_encrypt", "Encrypt export (requires password)"),
                                           variable=encrypt_var, font=("Segoe UI", 12))
            encrypt_check.pack(pady=(10, 5))

            encrypt_frame = ctk.CTkFrame(win, fg_color="transparent")
            encrypt_frame.pack(pady=5, fill="x", padx=20)

            center_frame = ctk.CTkFrame(encrypt_frame, fg_color="transparent")
            center_frame.pack(anchor="center")

            ctk.CTkLabel(center_frame, text=L.get("export_encrypt_password", "Encryption password:"),
                        font=("Segoe UI", 12)).pack(anchor="center", pady=(0, 5))
            encrypt_entry = ctk.CTkEntry(center_frame, textvariable=encrypt_password,
                                         show="*", width=300, height=35)
            encrypt_entry.pack(anchor="center")
            
            encrypt_error_label = ctk.CTkLabel(encrypt_frame, text="", font=("Segoe UI", 11), text_color="#E24B4A")
            encrypt_error_label.pack(pady=(5, 0))

            def validate_password(*args):
                if encrypt_var.get():
                    pwd = encrypt_password.get()
                    is_valid, error = validate_export_password(pwd)
                    if not is_valid and pwd:
                        encrypt_error_label.configure(text=error)
                    else:
                        encrypt_error_label.configure(text="")

            encrypt_password.trace_add("write", validate_password)

            def on_encrypt_change():
                if encrypt_var.get():
                    encrypt_entry.configure(state="normal")
                    validate_password()
                else:
                    encrypt_entry.configure(state="disabled")
                    encrypt_password.set("")
                    encrypt_error_label.configure(text="")

            encrypt_var.trace_add("write", lambda *args: on_encrypt_change())
            on_encrypt_change()
        else:
            ctk.CTkLabel(win, text="Encryption not available (install cryptography)",
                        font=("Segoe UI", 11), text_color="#FFA500").pack(pady=5)

        def do_export():
            fmt = format_var.get()
            selected_fields = [k for k, v in field_vars.items() if v.get()]

            if not selected_fields:
                CTkMessageBox.warning(win, L.get("export_title", "Export"),
                                     L.get("err_cat", "Select at least one category!"))
                return

            if encrypt_var.get():
                pwd = encrypt_password.get().strip()
                is_valid, error = validate_export_password(pwd)
                if not is_valid:
                    CTkMessageBox.warning(win, L.get("export_title", "Export"), error)
                    return

            extensions = {
                "json": ("JSON files", "*.json"),
                "csv": ("CSV files", "*.csv"),
                "html": ("HTML files", "*.html")
            }

            default_ext = f".{fmt}"
            if encrypt_var.get() and fmt == "json":
                default_ext = ".enc.json"

            file_path = filedialog.asksaveasfilename(
                defaultextension=default_ext,
                filetypes=[(extensions[fmt][0], extensions[fmt][1]), ("All files", "*.*")]
            )

            if file_path:
                success = False
                try:
                    # Sanitize data before export / Очищаем данные перед экспортом / Очищуємо дані перед експортом
                    export_data = sanitize_export_data(data)
                    
                    if fmt == "json":
                        success = DataExporter.export_json(
                            export_data, file_path, selected_fields,
                            encrypt_var.get(), encrypt_password.get().strip()
                        )
                    elif fmt == "csv":
                        success = DataExporter.export_csv(
                            export_data, file_path, selected_fields, encoding_var.get()
                        )
                    elif fmt == "html":
                        if encrypt_var.get():
                            CTkMessageBox.warning(win, L.get("export_title", "Export"),
                                                 "Encryption available only for JSON format!")
                            return
                        success = DataExporter.export_html(
                            export_data, file_path, lang, selected_fields
                        )

                    win.destroy()

                    if success:
                        msg = L.get("export_success", "Data exported: {0}").format(os.path.basename(file_path))
                        if encrypt_var.get() and fmt == "json":
                            msg += "\n" + L.get("export_encrypted", "File encrypted with password")
                            msg += f"\nPassword: {encrypt_password.get().strip()}"
                            msg += "\n" + L.get("master_warning", "Save password - without it decryption is impossible!")
                        CTkMessageBox.info(parent, L.get("export_title", "Export"), msg)
                    else:
                        CTkMessageBox.error(parent, L.get("err_title", "Error"),
                                           L.get("export_error", "Export error"))
                except EncryptionError as e:
                    logger.error(f"Encryption error: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('export_error', 'Export error')}:\n{str(e)}")
                except (OSError, IOError, PermissionError, ValueError, TypeError) as e:
                    logger.error(f"Export error: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       f"{L.get('export_error', 'Export error')}:\n{str(e)}")

        btn_frame = ctk.CTkFrame(win, fg_color="transparent")
        btn_frame.pack(pady=20)
        ctk.CTkButton(btn_frame, text=L.get("ok", "Export"), command=do_export,
                     width=140, height=40, fg_color="#2d6a4f", corner_radius=15,
                     font=("Segoe UI", 13, "bold")).pack(side="left", padx=15)
        ctk.CTkButton(btn_frame, text=L.get("cancel", "Cancel"), command=win.destroy,
                     width=140, height=40, fg_color="#8b0000", corner_radius=15,
                     font=("Segoe UI", 13, "bold")).pack(side="left", padx=15)

        win.after(100, lambda: win.attributes("-topmost", False))

    @staticmethod
    def export_all(data: List[Dict[str, Any]], parent, lang: str = "RU") -> None:
        """Simplified dialog for backward compatibility - calls the extended one
        Упрощённый диалог для обратной совместимости - вызывает расширенный
        Спрощений діалог для зворотної сумісності - викликає розширений"""
        DataExporter.show_export_dialog(data, parent, lang)