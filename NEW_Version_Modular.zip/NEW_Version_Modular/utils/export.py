"""
Data export utilities for JSON, CSV, HTML with encryption support
"""
import json
import csv
import os
import datetime
import tkinter as tk
from typing import List, Dict, Any, Optional
from tkinter import filedialog
from utils.logger import get_logger

# Попытка импорта криптографии для шифрования экспорта
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

logger = get_logger("export")


class DataExporter:
    """Экспорт данных в JSON, CSV, HTML с расширенными возможностями"""

    @staticmethod
    def encrypt_export_file(data: bytes, password: str) -> bytes:
        """Зашифровать экспортированные данные паролем"""
        if not CRYPTO_AVAILABLE:
            raise RuntimeError("Cryptography module not available for encryption")

        salt = os.urandom(16)
        nonce = os.urandom(12)

        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=600000,
        )
        key = kdf.derive(password.encode('utf-8'))

        aesgcm = AESGCM(key)
        ciphertext = aesgcm.encrypt(nonce, data, None)

        # Формат: salt(16) + nonce(12) + ciphertext
        return salt + nonce + ciphertext

    @staticmethod
    def export_json(data: List[Dict[str, Any]], file_path: str,
                    fields: List[str] = None, encrypt: bool = False,
                    password: str = None) -> bool:
        """Экспорт в JSON с выбором полей и шифрованием"""
        try:
            export_data = []
            for item in data:
                if fields:
                    filtered_item = {k: v for k, v in item.items() if k in fields}
                else:
                    filtered_item = item.copy()
                filtered_item = {k: v for k, v in filtered_item.items() if v is not None}
                export_data.append(filtered_item)

            export_wrapper = {
                "export_date": datetime.datetime.now().isoformat(),
                "app": "Secure Pass Pro v4.0",
                "count": len(data),
                "fields": fields if fields else list(data[0].keys()) if data else [],
                "passwords": export_data
            }

            json_data = json.dumps(export_wrapper, indent=2, ensure_ascii=False).encode('utf-8')

            if encrypt and password:
                json_data = DataExporter.encrypt_export_file(json_data, password)
                file_path = file_path.replace('.json', '.enc.json')

            with open(file_path, 'wb') as f:
                f.write(json_data)
            return True
        except (OSError, IOError, TypeError) as e:
            logger.error(f"JSON export error: {e}")
            return False

    @staticmethod
    def export_csv(data: List[Dict[str, Any]], file_path: str,
                   fields: List[str] = None, encoding: str = 'utf-8-sig') -> bool:
        """Экспорт в CSV с выбором полей и кодировки"""
        try:
            if not data:
                return False

            if fields is None:
                fields = ['id', 'label', 'password', 'created']

            existing_fields = [f for f in fields if f in data[0] or f == 'id']

            with open(file_path, 'w', encoding=encoding, newline='') as f:
                writer = csv.DictWriter(f, fieldnames=existing_fields)
                writer.writeheader()
                for row in data:
                    filtered_row = {k: row.get(k, '') for k in existing_fields}
                    filtered_row = {k: (v if v is not None else '') for k, v in filtered_row.items()}
                    writer.writerow(filtered_row)
            return True
        except (OSError, IOError, csv.Error) as e:
            logger.error(f"CSV export error: {e}")
            return False

    @staticmethod
    def export_html(data: List[Dict[str, Any]], file_path: str, lang: str = "RU",
                    fields: List[str] = None) -> bool:
        """Экспорт в HTML с интерактивным поиском, сортировкой, подсветкой и печатью"""
        try:
            from localization.lang import LANGUAGES
            L = LANGUAGES.get(lang, LANGUAGES["RU"])
            now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # Получаем переведенную фразу "Без метки" из словаря языка
            no_label_text = L.get("db_no_label", "No label")

            # Тексты для разных языков
            texts = {
                'search_placeholder': {
                    'RU': "Поиск по названию метки, значению пароля или дате создания...",
                    'EN': "Search by label, password or date...",
                    'UA': "Пошук за назвою мітки, значенням пароля або датою створення..."
                },
                'reset_btn': {'RU': "Сбросить", 'EN': "Reset", 'UA': "Скинути"},
                'print_btn': {'RU': "🖨️ Печать отчёта", 'EN': "🖨️ Print report", 'UA': "🖨️ Друк звіту"},
                'copy_hint': {
                    'RU': "💡 Кликните по паролю для быстрого копирования в буфер обмена",
                    'EN': "💡 Click on password to copy to clipboard",
                    'UA': "💡 Натисніть на пароль для швидкого копіювання в буфер обміну"
                },
                'copied_toast': {
                    'RU': "✅ Пароль успешно скопирован!",
                    'EN': "✅ Password copied successfully!",
                    'UA': "✅ Пароль успішно скопійовано!"
                },
                'footer_copyright': {
                    'RU': "Данные экспортированы в защищенном режиме.",
                    'EN': "Data exported in secure mode.",
                    'UA': "Дані експортовано в захищеному режимі."
                }
            }
            
            # Получаем текст для текущего языка
            search_placeholder = texts['search_placeholder'].get(lang, texts['search_placeholder']['RU'])
            reset_btn_text = texts['reset_btn'].get(lang, texts['reset_btn']['RU'])
            print_btn_text = texts['print_btn'].get(lang, texts['print_btn']['RU'])
            copy_hint_text = texts['copy_hint'].get(lang, texts['copy_hint']['RU'])
            copied_toast_text = texts['copied_toast'].get(lang, texts['copied_toast']['RU'])
            footer_text = texts['footer_copyright'].get(lang, texts['footer_copyright']['RU'])

            if fields is None:
                fields = ['id', 'label', 'password', 'created']

            # Заголовки таблицы
            headers = {
                'id': '#',
                'label': L.get('db_edit_label', 'Label'),
                'password': L.get('pdf_pass', 'Password'),
                'created': L.get('pdf_date', 'Date')
            }

            rows = ""
            for i, row in enumerate(data, 1):
                row_html = "<tr>"
                for field in fields:
                    raw_value = row.get(field, '')
                    if raw_value is None:
                        raw_value = ''
                    
                    if field == 'id':
                        value = str(i)
                    else:
                        value = str(raw_value)
                    
                    # Для поля label заменяем пустые значения и стандартные фразы на переведенную версию
                    if field == "label":
                        if not value or value.strip() == "" or value in ["Без метки", "No label", "Без мітки"]:
                            value = no_label_text
                        
                    escaped_value = value.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
                    
                    if field == "password":
                        css_class = "password"
                        row_html += f'<td><span class="{css_class}" data-field="{field}" data-value="{escaped_value}" title="{L.get("db_copy", "Copy")}">{escaped_value}</span></td>'
                    else:
                        css_class = "label-cell" if field == "label" else ("date-cell" if field == "created" else "id-cell")
                        row_html += f'<td class="{css_class}" data-field="{field}" data-value="{escaped_value}">{escaped_value}</td>'
                row_html += "</tr>"
                rows += row_html

            header_html = ""
            for index, field in enumerate(fields):
                header_text = headers.get(field, field)
                header_html += f'<th onclick="sortTable({index})" title="{L.get("export_sort_title", "Sort by")} {header_text}">{header_text}<span class="sort-icon">↕</span></th>'

            html = f"""<!DOCTYPE html>
<html lang="{lang.lower()}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Pass Pro - {L.get('export_passwords', 'Passwords')}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #0b0f19;
            color: #f1f5f9;
            padding: 40px 20px;
            line-height: 1.5;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: #111827;
            border-radius: 16px;
            border: 1px solid #1f2937;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3), 0 8px 10px -6px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #064e3b 0%, #022c22 100%);
            padding: 30px;
            text-align: center;
            border-bottom: 1px solid #065f46;
            position: relative;
        }}
        .header h1 {{
            font-size: 26px;
            font-weight: 700;
            color: #10b981;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }}
        .header p {{
            color: #a7f3d0;
            font-size: 14px;
            opacity: 0.85;
        }}
        .control-panel {{
            background: #1f2937;
            padding: 20px 30px;
            border-bottom: 1px solid #374151;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }}
        .search-row {{
            display: flex;
            gap: 12px;
            align-items: center;
        }}
        .search-wrapper {{
            position: relative;
            flex: 1;
        }}
        .search-wrapper::before {{
            content: "🔍";
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 14px;
            opacity: 0.6;
        }}
        .search-box {{
            width: 100%;
            padding: 11px 16px 11px 42px;
            border-radius: 10px;
            border: 1px solid #4b5563;
            background: #0f172a;
            color: #fff;
            font-size: 14px;
            transition: all 0.2s ease;
        }}
        .search-box:focus {{
            outline: none;
            border-color: #10b981;
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
        }}
        .btn {{
            background: #059669;
            border: none;
            color: #fff;
            padding: 11px 20px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
            user-select: none;
            white-space: nowrap;
        }}
        .btn:hover {{ background: #10b981; }}
        .btn-secondary {{
            background: #374151;
            border: 1px solid #4b5563;
        }}
        .btn-secondary:hover {{ background: #4b5563; }}
        .meta-row {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
            color: #9ca3af;
            border-top: 1px solid #374151;
            padding-top: 14px;
            flex-wrap: wrap;
            gap: 10px;
        }}
        .meta-item span {{
            color: #f3f4f6;
            font-weight: 600;
        }}
        .hint-badge {{
            background: #111827;
            padding: 4px 10px;
            border-radius: 6px;
            border: 1px solid #374151;
            color: #10b981;
        }}
        .content {{
            padding: 0;
            overflow-x: auto;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            font-size: 14px;
        }}
        th {{
            background: #1f2937;
            color: #9ca3af;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
            padding: 16px 24px;
            border-bottom: 2px solid #374151;
            cursor: pointer;
            user-select: none;
            transition: all 0.2s ease;
        }}
        th:hover {{
            background: #2563eb;
            color: #fff;
        }}
        th .sort-icon {{
            margin-left: 8px;
            display: inline-block;
            font-size: 11px;
            opacity: 0.5;
        }}
        th.sort-asc, th.sort-desc {{
            color: #fff;
            background: #2563eb;
        }}
        th.sort-asc .sort-icon {{ opacity: 1; content: "▲"; }}
        th.sort-desc .sort-icon {{ opacity: 1; content: "▼"; }}
        td {{
            padding: 16px 24px;
            border-bottom: 1px solid #1f2937;
            color: #e5e7eb;
            max-width: 320px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}
        tr:hover td {{
            background: #1f2937;
        }}
        .id-cell {{ color: #9ca3af; width: 70px; }}
        .label-cell {{ font-weight: 600; color: #f3f4f6; }}
        .password {{
            font-family: "JetBrains Mono", "Fira Code", "Consolas", monospace;
            color: #34d399;
            font-weight: bold;
            cursor: pointer;
            background: rgba(52, 211, 153, 0.05);
            padding: 4px 10px;
            border-radius: 6px;
            border: 1px solid rgba(52, 211, 153, 0.15);
            display: inline-block;
            transition: all 0.15s ease;
        }}
        .password:hover {{
            color: #fbbf24;
            background: rgba(251, 191, 36, 0.08);
            border-color: rgba(251, 191, 36, 0.3);
            transform: translateY(-1px);
        }}
        .date-cell {{ color: #9ca3af; font-size: 13px; }}
        
        mark.highlight {{
            background: #b45309;
            color: #fff;
            padding: 0px 2px;
            border-radius: 4px;
        }}
        
        .footer {{
            background: #111827;
            padding: 20px 30px;
            text-align: center;
            color: #6b7280;
            font-size: 13px;
            border-top: 1px solid #1f2937;
        }}
        .toast {{
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #10b981;
            color: #fff;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.3);
            transform: translateY(100px);
            opacity: 0;
            pointer-events: none;
            transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            z-index: 9999;
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .toast.show {{
            transform: translateY(0);
            opacity: 1;
        }}
        
        @media print {{
            body {{ background: #fff; color: #000; padding: 0; margin: 0; }}
            .container {{ border: none; box-shadow: none; max-width: 100%; background: #fff; }}
            .control-panel, .hint-badge, th .sort-icon {{ display: none !important; }}
            .header {{ background: #f3f4f6 !important; border-bottom: 2px solid #000; padding: 15px; color: #000; }}
            .header h1 {{ color: #000; }}
            .header p {{ color: #374151; }}
            th {{ background: #e5e7eb !important; color: #000 !important; border-bottom: 2px solid #000; padding: 10px 12px; }}
            td {{ color: #000 !important; border-bottom: 1px solid #e5e7eb; padding: 10px 12px; background: transparent !important; }}
            .password {{ background: none !important; border: none !important; padding: 0; color: #000 !important; font-size: 12px; }}
            .label-cell {{ color: #000 !important; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔐 {L.get('export_app', 'Secure Pass Pro v4.0')}</h1>
            <p>{L.get('export_passwords', 'Passwords Export')}</p>
        </div>
        <div class="control-panel">
            <div class="search-row">
                <div class="search-wrapper">
                    <input type="text" id="searchInput" class="search-box" placeholder="{search_placeholder}" oninput="filterTable()">
                </div>
                <button class="btn btn-secondary" onclick="clearSearch()">{reset_btn_text}</button>
                <button class="btn" onclick="window.print()">{print_btn_text}</button>
            </div>
            <div class="meta-row">
                <div class="meta-item">📊 {L.get('db_count', 'Records')}: <span id="recordCount">{len(data)}</span></div>
                <div class="meta-item">📅 {L.get('export_date', 'Export date')}: <span>{now}</span></div>
                <div class="meta-item hint-badge">{copy_hint_text}</div>
            </div>
        </div>
        <div class="content">
            <table id="passwordTable">
                <thead>
                    <tr>{header_html}</tr>
                </thead>
                <tbody id="tableBody">{rows}</tbody>
            </table>
        </div>
        <div class="footer">
            {L.get('export_app', 'Secure Pass Pro v4.0')} &copy; {datetime.datetime.now().year} | {footer_text}
        </div>
    </div>
    
    <div id="copyToast" class="toast">{copied_toast_text}</div>

    <script>
        let currentSortCol = -1;
        let isSortAsc = true;

        function filterTable() {{
            const input = document.getElementById('searchInput');
            const query = input.value.trim().toLowerCase();
            const tbody = document.getElementById('tableBody');
            const rows = tbody.querySelectorAll('tr');
            let matchedCount = 0;

            rows.forEach(row => {{
                let rowMatches = false;
                const cells = row.querySelectorAll('td');
                
                cells.forEach(cell => {{
                    const targetElement = cell.querySelector('[data-value]') || cell;
                    const originalText = targetElement.getAttribute('data-value') || targetElement.innerText || '';
                    
                    if (query === '') {{
                        targetElement.innerHTML = originalText;
                        rowMatches = true;
                    }} else if (originalText.toLowerCase().includes(query)) {{
                        rowMatches = true;
                        const regex = new RegExp('(' + escapeRegExp(query) + ')', 'gi');
                        targetElement.innerHTML = originalText.replace(regex, '<mark class="highlight">$1</mark>');
                    }} else {{
                        targetElement.innerHTML = originalText;
                    }}
                }});

                if (rowMatches) {{
                    row.style.display = '';
                    matchedCount++;
                }} else {{
                    row.style.display = 'none';
                }}
            }});

            document.getElementById('recordCount').innerText = matchedCount;
        }}

        function clearSearch() {{
            document.getElementById('searchInput').value = '';
            filterTable();
        }}

        function escapeRegExp(string) {{
            return string.replace(/[.*+?^${{}}()|[\]\\\\]/g, '\\\\$&');
        }}

        function sortTable(colIndex) {{
            const tbody = document.getElementById('tableBody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            const headers = document.querySelectorAll('th');

            if (currentSortCol === colIndex) {{
                isSortAsc = !isSortAsc;
            }} else {{
                currentSortCol = colIndex;
                isSortAsc = true;
            }}

            headers.forEach((th, idx) => {{
                th.classList.remove('sort-asc', 'sort-desc');
                const icon = th.querySelector('.sort-icon');
                if (idx === colIndex) {{
                    th.classList.add(isSortAsc ? 'sort-asc' : 'sort-desc');
                    icon.innerText = isSortAsc ? ' ▲' : ' ▼';
                }} else {{
                    icon.innerText = ' ↕';
                }}
            }});

            rows.sort((rowA, rowB) => {{
                const cellA = rowA.cells[colIndex];
                const cellB = rowB.cells[colIndex];
                
                const targetA = cellA.querySelector('[data-value]') || cellA;
                const targetB = cellB.querySelector('[data-value]') || cellB;

                const valA = targetA.getAttribute('data-value') || targetA.innerText;
                const valB = targetB.getAttribute('data-value') || targetB.innerText;
                const fieldType = targetA.getAttribute('data-field') || cellA.getAttribute('class');

                if (fieldType === 'id' || (colIndex === 0 && !isNaN(valA) && !isNaN(valB))) {{
                    return isSortAsc ? parseInt(valA) - parseInt(valB) : parseInt(valB) - parseInt(valA);
                }}

                if (fieldType === 'created' && valA.includes('-') && valB.includes('-')) {{
                    return isSortAsc ? new Date(valA) - new Date(valB) : new Date(valB) - new Date(valA);
                }}

                return isSortAsc ? valA.localeCompare(valB) : valB.localeCompare(valA);
            }});

            rows.forEach(row => tbody.appendChild(row));
        }}

        document.getElementById('tableBody').addEventListener('click', function(e) {{
            const target = e.target.closest('.password');
            if (!target) return;

            const textToCopy = target.getAttribute('data-value') || target.innerText;
            
            navigator.clipboard.writeText(textToCopy).then(() => {{
                const toast = document.getElementById('copyToast');
                toast.classList.add('show');
                setTimeout(() => {{
                    toast.classList.remove('show');
                }}, 2000);
            }}).catch(err => {{
                console.error('Copy failed: ', err);
            }});
        }});
    </script>
</body>
</html>"""

            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(html)
            return True
        except (OSError, IOError) as e:
            logger.error(f"HTML export error: {e}")
            return False

    @staticmethod
    def show_export_dialog(data: List[Dict[str, Any]], parent, lang: str = "RU") -> None:
        """Расширенный диалог выбора формата экспорта"""
        from storage.database import PasswordDB
        from gui.dialogs import CTkMessageBox
        import customtkinter as ctk
        from localization.lang import LANGUAGES

        if not data:
            data = PasswordDB.get_all()

        if not data:
            CTkMessageBox.warning(parent, "Export", LANGUAGES.get(lang, LANGUAGES["RU"]).get("export_no_data", "No data to export!"))
            return

        L = LANGUAGES.get(lang, LANGUAGES["RU"])

        win = ctk.CTkToplevel(parent)
        win.title(L.get("export_title", "Export Data"))
        win.geometry("750x700")
        win.resizable(False, False)
        win.transient(parent)
        win.grab_set()
        win.attributes("-topmost", True)

        win.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - 750) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 700) // 2
        win.geometry(f"750x700+{x}+{y}")

        format_var = tk.StringVar(value="json")
        encrypt_var = tk.BooleanVar(value=False)
        encrypt_password = tk.StringVar()

        ctk.CTkLabel(win, text=L.get("export_format", "Export format:"),
                    font=("Segoe UI", 14, "bold")).pack(pady=(20, 10))

        format_frame = ctk.CTkFrame(win, fg_color="transparent")
        format_frame.pack(pady=5)

        ctk.CTkRadioButton(format_frame, text="JSON", variable=format_var,
                          value="json", font=("Segoe UI", 13)).pack(side="left", padx=15)
        ctk.CTkRadioButton(format_frame, text="CSV", variable=format_var,
                          value="csv", font=("Segoe UI", 13)).pack(side="left", padx=15)
        ctk.CTkRadioButton(format_frame, text="HTML", variable=format_var,
                          value="html", font=("Segoe UI", 13)).pack(side="left", padx=15)

        ctk.CTkFrame(win, height=2, fg_color="gray").pack(fill="x", padx=20, pady=10)

        ctk.CTkLabel(win, text="📋 " + L.get("export_fields", "Select fields to export:"),
                    font=("Segoe UI", 13, "bold")).pack(pady=(5, 5))

        fields_frame = ctk.CTkFrame(win, fg_color="transparent")
        fields_frame.pack(pady=5)

        field_names = {
            'id': "#",
            'label': L.get("db_edit_label", "Label"),
            'password': L.get("pdf_pass", "Password"),
            'created': L.get("pdf_date", "Date")
        }

        field_vars = {
            'id': tk.BooleanVar(value=True),
            'label': tk.BooleanVar(value=True),
            'password': tk.BooleanVar(value=True),
            'created': tk.BooleanVar(value=True)
        }

        for field, name in field_names.items():
            ctk.CTkCheckBox(fields_frame, text=name, variable=field_vars[field],
                           font=("Segoe UI", 12)).pack(side="left", padx=15)

        ctk.CTkFrame(win, height=2, fg_color="gray").pack(fill="x", padx=20, pady=10)

        ctk.CTkLabel(win, text="🔤 " + L.get("export_encoding", "Encoding (for CSV):"),
                    font=("Segoe UI", 13, "bold")).pack(pady=(5, 5))

        encoding_var = tk.StringVar(value="utf-8-sig")
        encoding_frame = ctk.CTkFrame(win, fg_color="transparent")
        encoding_frame.pack(pady=5)

        encodings = [
            ("UTF-8", "utf-8-sig"),
            ("UTF-16", "utf-16"),
            ("Windows-1251", "cp1251")
        ]
        for enc_name, enc_val in encodings:
            ctk.CTkRadioButton(encoding_frame, text=enc_name, variable=encoding_var,
                              value=enc_val, font=("Segoe UI", 11)).pack(anchor="w", padx=30, pady=2)

        ctk.CTkFrame(win, height=2, fg_color="gray").pack(fill="x", padx=20, pady=10)

        if CRYPTO_AVAILABLE:
            encrypt_check = ctk.CTkCheckBox(win, text="🔒 " + L.get("export_encrypt", "Encrypt export (requires password)"),
                                           variable=encrypt_var, font=("Segoe UI", 12))
            encrypt_check.pack(pady=(10, 5))

            encrypt_frame = ctk.CTkFrame(win, fg_color="transparent")
            encrypt_frame.pack(pady=5, fill="x", padx=20)

            center_frame = ctk.CTkFrame(encrypt_frame, fg_color="transparent")
            center_frame.pack(anchor="center")

            ctk.CTkLabel(center_frame, text=L.get("export_encrypt_password", "Encryption password:"),
                        font=("Segoe UI", 12)).pack(anchor="center", pady=(0, 5))
            encrypt_entry = ctk.CTkEntry(center_frame, textvariable=encrypt_password,
                                         show="*", width=300, height=35)
            encrypt_entry.pack(anchor="center")

            def on_encrypt_change():
                if encrypt_var.get():
                    encrypt_entry.configure(state="normal")
                else:
                    encrypt_entry.configure(state="disabled")
                    encrypt_password.set("")

            encrypt_var.trace_add("write", lambda *args: on_encrypt_change())
            on_encrypt_change()
        else:
            ctk.CTkLabel(win, text="⚠️ Encryption not available (install cryptography)",
                        font=("Segoe UI", 11), text_color="#FFA500").pack(pady=5)

        def do_export():
            fmt = format_var.get()
            selected_fields = [k for k, v in field_vars.items() if v.get()]

            if not selected_fields:
                CTkMessageBox.warning(win, L.get("export_title", "Export"),
                                     L.get("err_cat", "Select at least one category!"))
                return

            if encrypt_var.get() and not encrypt_password.get().strip():
                CTkMessageBox.warning(win, L.get("export_title", "Export"),
                                     L.get("master_set_prompt", "Enter password for encryption!"))
                return

            extensions = {
                "json": ("JSON files", "*.json"),
                "csv": ("CSV files", "*.csv"),
                "html": ("HTML files", "*.html")
            }

            default_ext = f".{fmt}"
            if encrypt_var.get() and fmt == "json":
                default_ext = ".enc.json"

            file_path = filedialog.asksaveasfilename(
                defaultextension=default_ext,
                filetypes=[(extensions[fmt][0], extensions[fmt][1]), ("All files", "*.*")]
            )

            if file_path:
                success = False
                try:
                    if fmt == "json":
                        success = DataExporter.export_json(
                            data, file_path, selected_fields,
                            encrypt_var.get(), encrypt_password.get().strip()
                        )
                    elif fmt == "csv":
                        success = DataExporter.export_csv(
                            data, file_path, selected_fields, encoding_var.get()
                        )
                    elif fmt == "html":
                        if encrypt_var.get():
                            CTkMessageBox.warning(win, L.get("export_title", "Export"),
                                                 "Encryption available only for JSON format!")
                            return
                        success = DataExporter.export_html(
                            data, file_path, lang, selected_fields
                        )

                    win.destroy()

                    if success:
                        msg = L.get("export_success", "✅ Data exported: {0}").format(os.path.basename(file_path))
                        if encrypt_var.get() and fmt == "json":
                            msg += "\n🔒 " + L.get("export_encrypted", "File encrypted with password")
                            msg += f"\n📝 Password: {encrypt_password.get().strip()}"
                            msg += "\n⚠️ " + L.get("master_warning", "Save password - without it decryption is impossible!")
                        CTkMessageBox.info(parent, L.get("export_title", "Export"), msg)
                    else:
                        CTkMessageBox.error(parent, L.get("err_title", "Error"),
                                           L.get("export_error", "Export error"))
                except Exception as e:
                    logger.error(f"Export error: {e}")
                    CTkMessageBox.error(parent, L.get("err_title", "Error"),
                                       f"{L.get('export_error', 'Export error')}: {str(e)}")

        btn_frame = ctk.CTkFrame(win, fg_color="transparent")
        btn_frame.pack(pady=20)
        ctk.CTkButton(btn_frame, text="📤 " + L.get("ok", "Export"), command=do_export,
                     width=140, height=40, fg_color="#2d6a4f", corner_radius=15,
                     font=("Segoe UI", 13, "bold")).pack(side="left", padx=15)
        ctk.CTkButton(btn_frame, text=L.get("cancel", "Cancel"), command=win.destroy,
                     width=140, height=40, fg_color="#8b0000", corner_radius=15,
                     font=("Segoe UI", 13, "bold")).pack(side="left", padx=15)

        win.after(100, lambda: win.attributes("-topmost", False))

    @staticmethod
    def export_all(data: List[Dict[str, Any]], parent, lang: str = "RU") -> None:
        """Упрощённый диалог для обратной совместимости - вызывает расширенный"""
        DataExporter.show_export_dialog(data, parent, lang)