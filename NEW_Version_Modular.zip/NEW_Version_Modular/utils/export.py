"""
Data export utilities for JSON, CSV, HTML with encryption support
"""
import json
import csv
import os
import datetime
import tkinter as tk
from typing import List, Dict, Any, Optional
from tkinter import filedialog
from utils.logger import get_logger

# Попытка импорта криптографии для шифрования экспорта
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False

logger = get_logger("export")


class DataExporter:
    """Экспорт данных в JSON, CSV, HTML с расширенными возможностями"""

    @staticmethod
    def encrypt_export_file(data: bytes, password: str) -> bytes:
        """Зашифровать экспортированные данные паролем"""
        if not CRYPTO_AVAILABLE:
            raise RuntimeError("Cryptography module not available for encryption")

        salt = os.urandom(16)
        nonce = os.urandom(12)

        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=600000,
        )
        key = kdf.derive(password.encode('utf-8'))

        aesgcm = AESGCM(key)
        ciphertext = aesgcm.encrypt(nonce, data, None)

        # Формат: salt(16) + nonce(12) + ciphertext
        return salt + nonce + ciphertext

    @staticmethod
    def export_json(data: List[Dict[str, Any]], file_path: str,
                    fields: List[str] = None, encrypt: bool = False,
                    password: str = None) -> bool:
        """Экспорт в JSON с выбором полей и шифрованием"""
        try:
            export_data = []
            for item in data:
                if fields:
                    filtered_item = {k: v for k, v in item.items() if k in fields}
                else:
                    filtered_item = item.copy()
                filtered_item = {k: v for k, v in filtered_item.items() if v is not None}
                export_data.append(filtered_item)

            export_wrapper = {
                "export_date": datetime.datetime.now().isoformat(),
                "app": "Secure Pass Pro v4.0",
                "count": len(data),
                "fields": fields if fields else list(data[0].keys()) if data else [],
                "passwords": export_data
            }

            json_data = json.dumps(export_wrapper, indent=2, ensure_ascii=False).encode('utf-8')

            if encrypt and password:
                json_data = DataExporter.encrypt_export_file(json_data, password)
                file_path = file_path.replace('.json', '.enc.json')

            with open(file_path, 'wb') as f:
                f.write(json_data)
            return True
        except (OSError, IOError, TypeError) as e:
            logger.error(f"JSON export error: {e}")
            return False

    @staticmethod
    def export_csv(data: List[Dict[str, Any]], file_path: str,
                   fields: List[str] = None, encoding: str = 'utf-8-sig') -> bool:
        """Экспорт в CSV с выбором полей и кодировки"""
        try:
            if not data:
                return False

            if fields is None:
                fields = ['id', 'label', 'password', 'created']

            existing_fields = [f for f in fields if f in data[0] or f == 'id']

            with open(file_path, 'w', encoding=encoding, newline='') as f:
                writer = csv.DictWriter(f, fieldnames=existing_fields)
                writer.writeheader()
                for row in data:
                    filtered_row = {k: row.get(k, '') for k in existing_fields}
                    filtered_row = {k: (v if v is not None else '') for k, v in filtered_row.items()}
                    writer.writerow(filtered_row)
            return True
        except (OSError, IOError, csv.Error) as e:
            logger.error(f"CSV export error: {e}")
            return False

    @staticmethod
    def export_html(data: List[Dict[str, Any]], file_path: str, lang: str = "RU",
                    fields: List[str] = None) -> bool:
        """Экспорт в HTML с выбором полей и кнопкой печати"""
        try:
            from localization.lang import LANGUAGES
            L = LANGUAGES.get(lang, LANGUAGES["RU"])
            now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            if fields is None:
                fields = ['id', 'label', 'password', 'created']

            # Заголовки таблицы
            headers = {
                'id': '#',
                'label': L.get('db_edit_label', 'Label'),
                'password': L.get('pdf_pass', 'Password'),
                'created': L.get('pdf_date', 'Date')
            }

            rows = ""
            for i, row in enumerate(data, 1):
                row_html = "<tr>"
                for field in fields:
                    value = str(row.get(field, ''))
                    value = value.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
                    if field == 'id':
                        value = str(i)
                    css_class = "password" if field == "password" else ("label" if field == "label" else "date")
                    row_html += f'<td class="{css_class}" data-value="{value}">{value}</td>'
                row_html += "</tr>"
                rows += row_html

            header_html = ""
            for field in fields:
                header_html += f"<th>{headers.get(field, field)}</th>"

            html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Secure Pass Pro - {L.get('export_passwords', 'Passwords')}</title>
    <style>
        *{{margin:0;padding:0;box-sizing:border-box;}}
        body{{font-family:'Segoe UI',Arial;background:#0f0f1a;padding:20px;}}
        .container{{max-width:1300px;margin:0 auto;background:#0a0a0f;border-radius:16px;border:1px solid #2d6a4f;overflow:hidden;}}
        .header{{background:linear-gradient(135deg,#2d6a4f,#1b4332);padding:25px;text-align:center;color:#fff;}}
        .header h1{{font-size:28px;}}
        .toolbar{{background:#1a1a2e;padding:10px 20px;display:flex;justify-content:flex-end;gap:10px;border-bottom:1px solid #2d6a4f;}}
        .toolbar button{{background:#2d6a4f;border:none;color:#fff;padding:8px 16px;border-radius:8px;cursor:pointer;font-size:14px;transition:all 0.2s;}}
        .toolbar button:hover{{background:#40916c;}}
        .stats{{background:#1a1a2e;padding:12px 25px;display:flex;justify-content:space-between;color:#4EC9B0;border-bottom:1px solid #2d6a4f;flex-wrap:wrap;}}
        .stats span{{color:#fff;font-weight:bold;}}
        .content{{padding:20px;overflow-x:auto;}}
        table{{width:100%;border-collapse:collapse;}}
        th{{background:#2d6a4f;color:#fff;padding:12px;text-align:left;cursor:pointer;user-select:none;}}
        th:hover{{background:#40916c;}}
        th::after{{content:" ↕";opacity:0.5;margin-left:5px;font-size:12px;}}
        td{{padding:12px;border-bottom:1px solid #2a2a3e;color:#e0e0e0;}}
        tr:hover{{background:#1a1a2e;}}
        .password{{font-family:'Consolas',monospace;color:#4EC9B0;font-weight:bold;cursor:pointer;}}
        .password:hover{{color:#FFD700;text-decoration:underline;}}
        .label{{color:#FFD700;font-weight:600;}}
        .date{{color:#888;font-size:12px;}}
        .footer{{background:#1a1a2e;padding:12px;text-align:center;color:#888;font-size:12px;border-top:1px solid #2d6a4f;}}
        .search-box{{background:#1a1a2e;padding:10px 20px;display:flex;gap:10px;border-bottom:1px solid #2d6a4f;}}
        .search-box input{{flex:1;padding:8px 12px;border-radius:8px;border:1px solid #2d6a4f;background:#0f0f1a;color:#fff;font-size:14px;}}
        .search-box input:focus{{outline:none;border-color:#4EC9B0;}}
        .search-box button{{background:#2d6a4f;border:none;color:#fff;padding:8px 16px;border-radius:8px;cursor:pointer;}}
        .search-box button:hover{{background:#40916c;}}
        .copy-toast{{position:fixed;bottom:20px;right:20px;background:#2d6a4f;color:#fff;padding:10px 20px;border-radius:8px;opacity:0;transition:opacity 0.3s;z-index:1000;}}
        @media print{{.toolbar,.search-box,.stats .print-hide{{display:none;}}}}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔐 {L.get('export_app', 'Secure Pass Pro v4.0')}</h1>
            <p>{L.get('export_passwords', 'Passwords Export')}</p>
        </div>
        <div class="toolbar">
            <button onclick="window.print()">🖨️ Печать</button>
        </div>
        <div class="search-box">
            <input type="text" id="searchInput" placeholder="🔍 Поиск по метке, паролю или дате..." onkeyup="filterTable()">
            <button onclick="filterTable()">Найти</button>
            <button onclick="clearSearch()">Сбросить</button>
        </div>
        <div class="stats">
            <div>📊 {L.get('db_count', 'Records')}: <span id="recordCount">{len(data)}</span></div>
            <div>📅 {L.get('export_date', 'Export date')}: <span>{now}</span></div>
            <div class="print-hide">💡 Нажмите на пароль, чтобы скопировать | Нажмите на заголовок для сортировки</div>
        </div>
        <div class="content">
            <table id="passwordTable">
                <thead>
                    <tr>{header_html}</tr>
                </thead>
                <tbody id="tableBody">{rows}</tbody>
            </table>
        </div>
        <div class="footer">{L.get('export_app', 'Secure Pass Pro v4.0')} | {L.get('export_date', 'Export date')}: {now}</div>
    </div>
    <div id="copyToast" class="copy-toast">✅ Пароль скопирован!</div>

    <script>
        // Сортировка таблицы
        let sortColumn = -1;
        let sortAsc = true;

        function sortTable(colIndex) {{
            const tbody = document.getElementById('tableBody');
            const rows = Array.from(tbody.querySelectorAll('tr'));

            if (sortColumn === colIndex) {{
                sortAsc = !sortAsc;
            }} else {{
                sortColumn = colIndex;
                sortAsc = true;
            }}

            rows.sort((a, b) => {{
                let aVal = a.cells[colIndex].getAttribute('data-value') || a.cells[colIndex].innerText;
                let bVal = b.cells[colIndex].getAttribute('data-value') || b.cells[colIndex].innerText;

                // Для даты
                if (colIndex === 3 && aVal.includes('-')) {{
                    return sortAsc ? new Date(aVal) - new Date(bVal) : new Date(bVal) - new Date(aVal);
                }}

                // Для чисел
                if (colIndex === 0 && !isNaN(aVal) && !isNaN(bVal)) {{
                    return sortAsc ? parseInt(aVal) - parseInt(bVal) : parseInt(bVal) - parseInt(aVal);
                }}

                // Для текста
                return sortAsc ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
            }});

            rows.forEach(row => tbody.appendChild(row));

            // Обновляем заголовки
            const headers = document.querySelectorAll('th');
            headers.forEach((th, i) => {{
                th.style.background = i === colIndex ? '#40916c' : '#2d6a4f';
            }});
        }}

        // Привязываем сортировку к заголовкам
        document.querySelectorAll('th').forEach((th, index) => {{
            th.addEventListener('click', () => sortTable(index));
        }});

        // Поиск по таблице
        function filterTable() {{
            const input = document.getElementById('searchInput');
            const filter = input.value.toLowerCase();
            const tbody = document.getElementById('tableBody');
            const rows = tbody.querySelectorAll('tr');
            let visibleCount = 0;

            rows.forEach(row => {{
                let text = '';
                for (let cell of row.cells) {{
                    text += cell.innerText.toLowerCase() + ' ';
                }}
                if (text.includes(filter)) {{
                    row.style.display = '';
                    visibleCount++;
                }} else {{
                    row.style.display = 'none';
                }}
            }});

            document.getElementById('recordCount').innerText = visibleCount;
        }}

        function clearSearch() {{
            document.getElementById('searchInput').value = '';
            filterTable();
        }}

        // Копирование пароля по клику
        function copyToClipboard(text) {{
            navigator.clipboard.writeText(text).then(() => {{
                const toast = document.getElementById('copyToast');
                toast.style.opacity = '1';
                setTimeout(() => {{
                    toast.style.opacity = '0';
                }}, 1500);
            }});
        }}

        // Добавляем обработчики на пароли
        document.querySelectorAll('.password').forEach(el => {{
            el.addEventListener('click', () => copyToClipboard(el.innerText));
        }});

        // Подсветка при поиске
        function highlightText() {{
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            if (!searchTerm) return;

            document.querySelectorAll('.password, .label, .date').forEach(el => {{
                const text = el.innerText;
                if (text.toLowerCase().includes(searchTerm)) {{
                    el.style.backgroundColor = '#3a2a0a';
                    el.style.borderRadius = '4px';
                }} else {{
                    el.style.backgroundColor = '';
                }}
            }});
        }}

        // Обновляем highlight при фильтрации
        const originalFilterTable = filterTable;
        window.filterTable = function() {{
            originalFilterTable();
            highlightText();
        }};
    </script>
</body>
</html>"""

            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(html)
            return True
        except (OSError, IOError) as e:
            logger.error(f"HTML export error: {e}")
            return False

    @staticmethod
    def show_export_dialog(data: List[Dict[str, Any]], parent, lang: str = "RU") -> None:
        """Расширенный диалог выбора формата экспорта"""
        from storage.database import PasswordDB
        from gui.dialogs import CTkMessageBox
        import customtkinter as ctk
        from localization.lang import LANGUAGES

        if not data:
            data = PasswordDB.get_all()

        if not data:
            CTkMessageBox.warning(parent, "Экспорт", "Нет данных для экспорта!")
            return

        L = LANGUAGES.get(lang, LANGUAGES["RU"])

        win = ctk.CTkToplevel(parent)
        win.title(L.get("export_title", "Экспорт данных"))
        win.geometry("520x580")
        win.resizable(False, False)
        win.transient(parent)
        win.grab_set()
        win.attributes("-topmost", True)

        win.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - 520) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 580) // 2
        win.geometry(f"520x580+{x}+{y}")

        format_var = tk.StringVar(value="json")
        encrypt_var = tk.BooleanVar(value=False)
        encrypt_password = tk.StringVar()

        ctk.CTkLabel(win, text=L.get("export_format", "Формат экспорта:"),
                    font=("Segoe UI", 14, "bold")).pack(pady=(20, 10))

        format_frame = ctk.CTkFrame(win, fg_color="transparent")
        format_frame.pack(pady=5)

        ctk.CTkRadioButton(format_frame, text="JSON (структурированный)", variable=format_var,
                          value="json", font=("Segoe UI", 13)).pack(side="left", padx=15)
        ctk.CTkRadioButton(format_frame, text="CSV (Excel)", variable=format_var,
                          value="csv", font=("Segoe UI", 13)).pack(side="left", padx=15)
        ctk.CTkRadioButton(format_frame, text="HTML (веб-отчёт)", variable=format_var,
                          value="html", font=("Segoe UI", 13)).pack(side="left", padx=15)

        ctk.CTkFrame(win, height=2, fg_color="gray").pack(fill="x", padx=20, pady=10)

        ctk.CTkLabel(win, text="📋 " + L.get("export_fields", "Выберите поля для экспорта:"),
                    font=("Segoe UI", 13, "bold")).pack(pady=(5, 5))

        fields_frame = ctk.CTkFrame(win, fg_color="transparent")
        fields_frame.pack(pady=5)

        field_vars = {
            'id': tk.BooleanVar(value=True),
            'label': tk.BooleanVar(value=True),
            'password': tk.BooleanVar(value=True),
            'created': tk.BooleanVar(value=True)
        }

        ctk.CTkCheckBox(fields_frame, text="ID", variable=field_vars['id'],
                       font=("Segoe UI", 12)).pack(side="left", padx=15)
        ctk.CTkCheckBox(fields_frame, text="Метка", variable=field_vars['label'],
                       font=("Segoe UI", 12)).pack(side="left", padx=15)
        ctk.CTkCheckBox(fields_frame, text="Пароль", variable=field_vars['password'],
                       font=("Segoe UI", 12)).pack(side="left", padx=15)
        ctk.CTkCheckBox(fields_frame, text="Дата", variable=field_vars['created'],
                       font=("Segoe UI", 12)).pack(side="left", padx=15)

        ctk.CTkFrame(win, height=2, fg_color="gray").pack(fill="x", padx=20, pady=10)

        ctk.CTkLabel(win, text="🔤 " + L.get("export_encoding", "Кодировка (для CSV):"),
                    font=("Segoe UI", 13, "bold")).pack(pady=(5, 5))

        encoding_var = tk.StringVar(value="utf-8-sig")
        encoding_frame = ctk.CTkFrame(win, fg_color="transparent")
        encoding_frame.pack(pady=5)

        encodings = [("UTF-8 (рекомендуется)", "utf-8-sig"),
                     ("UTF-16", "utf-16"),
                     ("Windows-1251 (кириллица)", "cp1251")]
        for enc_name, enc_val in encodings:
            ctk.CTkRadioButton(encoding_frame, text=enc_name, variable=encoding_var,
                              value=enc_val, font=("Segoe UI", 11)).pack(anchor="w", padx=30, pady=2)

        ctk.CTkFrame(win, height=2, fg_color="gray").pack(fill="x", padx=20, pady=10)

        if CRYPTO_AVAILABLE:
            encrypt_check = ctk.CTkCheckBox(win, text="🔒 " + L.get("export_encrypt", "Зашифровать экспорт (требуется пароль)"),
                           variable=encrypt_var, font=("Segoe UI", 12))
            encrypt_check.pack(pady=(5, 5))

            encrypt_frame = ctk.CTkFrame(win, fg_color="transparent")
            encrypt_frame.pack(pady=5, fill="x", padx=20)

            ctk.CTkLabel(encrypt_frame, text=L.get("export_encrypt_password", "Пароль:"),
                        font=("Segoe UI", 12)).pack(side="left", padx=(0, 10))
            encrypt_entry = ctk.CTkEntry(encrypt_frame, textvariable=encrypt_password,
                                         show="*", width=200, height=32)
            encrypt_entry.pack(side="left")

            def on_encrypt_change():
                if encrypt_var.get():
                    encrypt_entry.configure(state="normal")
                else:
                    encrypt_entry.configure(state="disabled")
                    encrypt_password.set("")

            encrypt_var.trace_add("write", lambda *args: on_encrypt_change())
            on_encrypt_change()
        else:
            ctk.CTkLabel(win, text="⚠️ Шифрование недоступно (установите cryptography)",
                        font=("Segoe UI", 11), text_color="#FFA500").pack(pady=5)

        def do_export():
            fmt = format_var.get()

            selected_fields = [k for k, v in field_vars.items() if v.get()]

            if not selected_fields:
                CTkMessageBox.warning(win, "Экспорт", "Выберите хотя бы одно поле для экспорта!")
                return

            if encrypt_var.get() and not encrypt_password.get().strip():
                CTkMessageBox.warning(win, "Экспорт", "Введите пароль для шифрования!")
                return

            extensions = {
                "json": ("JSON files", "*.json"),
                "csv": ("CSV files", "*.csv"),
                "html": ("HTML files", "*.html")
            }

            default_ext = f".{fmt}"
            if encrypt_var.get() and fmt == "json":
                default_ext = ".enc.json"

            file_path = filedialog.asksaveasfilename(
                defaultextension=default_ext,
                filetypes=[(extensions[fmt][0], extensions[fmt][1]), ("All files", "*.*")]
            )

            if file_path:
                success = False
                try:
                    if fmt == "json":
                        success = DataExporter.export_json(
                            data, file_path, selected_fields,
                            encrypt_var.get(), encrypt_password.get().strip()
                        )
                    elif fmt == "csv":
                        success = DataExporter.export_csv(
                            data, file_path, selected_fields, encoding_var.get()
                        )
                    elif fmt == "html":
                        if encrypt_var.get():
                            CTkMessageBox.warning(win, "Экспорт", "Шифрование доступно только для JSON формата!")
                            return
                        success = DataExporter.export_html(
                            data, file_path, lang, selected_fields
                        )

                    win.destroy()

                    if success:
                        msg = f"✅ Экспортировано: {os.path.basename(file_path)}"
                        if encrypt_var.get() and fmt == "json":
                            msg += "\n🔒 Файл зашифрован паролем"
                            msg += f"\n📝 Пароль: {encrypt_password.get().strip()}"
                            msg += "\n⚠️ Сохраните пароль - без него невозможно расшифровать!"
                        CTkMessageBox.info(parent, L.get("export_title", "Экспорт"), msg)
                    else:
                        CTkMessageBox.error(parent, L.get("err_title", "Error"),
                                           L.get("export_error", "Ошибка экспорта"))
                except Exception as e:
                    logger.error(f"Export error: {e}")
                    CTkMessageBox.error(parent, L.get("err_title", "Error"),
                                       f"Ошибка экспорта: {str(e)}")

        btn_frame = ctk.CTkFrame(win, fg_color="transparent")
        btn_frame.pack(pady=20)
        ctk.CTkButton(btn_frame, text="📤 " + L.get("ok", "Экспорт"), command=do_export,
                     width=140, height=40, fg_color="#2d6a4f", corner_radius=15,
                     font=("Segoe UI", 13, "bold")).pack(side="left", padx=15)
        ctk.CTkButton(btn_frame, text=L.get("cancel", "Отмена"), command=win.destroy,
                     width=140, height=40, fg_color="#8b0000", corner_radius=15,
                     font=("Segoe UI", 13, "bold")).pack(side="left", padx=15)

        win.after(100, lambda: win.attributes("-topmost", False))

    @staticmethod
    def export_all(data: List[Dict[str, Any]], parent, lang: str = "RU") -> None:
        """Упрощённый диалог для обратной совместимости - вызывает расширенный"""
        DataExporter.show_export_dialog(data, parent, lang)
