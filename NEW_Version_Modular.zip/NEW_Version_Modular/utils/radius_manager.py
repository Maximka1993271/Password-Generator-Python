# utils/radius_manager.py
"""
Global radius manager for all buttons

Глобальный менеджер радиуса для всех кнопок
Глобальний менеджер радіусу для всіх кнопок
"""
import customtkinter as ctk

_current_radius = 25
_all_windows = []

def set_global_radius(radius: int):
    """Set global radius and update all buttons
    Установить глобальный радиус и обновить все кнопки
    Встановити глобальний радіус та оновити всі кнопки"""
    global _current_radius
    _current_radius = radius

    # Update all registered windows / Обновляем все зарегистрированные окна / Оновлюємо всі зареєстровані вікна
    for window in _all_windows[:]:
        if window and window.winfo_exists():
            try:
                _update_window_radius(window, radius)
            except:
                pass

def get_global_radius() -> int:
    return _current_radius

def register_window(window):
    """Register a window for radius updates
    Зарегистрировать окно для обновления радиуса
    Зареєструвати вікно для оновлення радіусу"""
    if window and window not in _all_windows:
        _all_windows.append(window)

def unregister_window(window):
    """Unregister a window / Отменить регистрацию окна / Скасувати реєстрацію вікна"""
    if window in _all_windows:
        _all_windows.remove(window)

def _update_window_radius(widget, radius: int):
    """Recursively update radius of all buttons in widget
    Рекурсивно обновить радиус всех кнопок в виджете
    Рекурсивно оновити радіус всіх кнопок у віджеті"""
    try:
        # Update buttons / Обновляем кнопки / Оновлюємо кнопки
        if isinstance(widget, ctk.CTkButton):
            try:
                widget.configure(corner_radius=radius)
            except:
                pass
        # Update entry fields / Обновляем поля ввода / Оновлюємо поля введення
        elif isinstance(widget, ctk.CTkEntry):
            try:
                widget.configure(corner_radius=radius)
            except:
                pass
        # Update text fields / Обновляем текстовые поля / Оновлюємо текстові поля
        elif isinstance(widget, ctk.CTkTextbox):
            try:
                widget.configure(corner_radius=radius)
            except:
                pass
        # Update scrollable frames / Обновляем фреймы со скроллом / Оновлюємо фрейми зі скролом
        elif isinstance(widget, ctk.CTkScrollableFrame):
            try:
                widget.configure(corner_radius=radius)
            except:
                pass

        # Recursively traverse children / Рекурсивно обходим всех детей / Рекурсивно обходимо всіх дітей
        for child in widget.winfo_children():
            _update_window_radius(child, radius)
    except:
        pass

def update_all_buttons_radius(radius: int):
    """Update radius of all buttons in all windows
    Обновить радиус всех кнопок во всех окнах
    Оновити радіус всіх кнопок у всіх вікнах"""
    set_global_radius(radius)