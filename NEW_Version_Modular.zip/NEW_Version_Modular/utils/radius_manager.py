# utils/radius_manager.py
"""
Глобальный менеджер радиуса для всех кнопок
"""
import customtkinter as ctk

_current_radius = 25
_all_windows = []

def set_global_radius(radius: int):
    """Установить глобальный радиус и обновить все кнопки"""
    global _current_radius
    _current_radius = radius

    # Обновляем все зарегистрированные окна
    for window in _all_windows[:]:
        if window and window.winfo_exists():
            try:
                _update_window_radius(window, radius)
            except:
                pass

def get_global_radius() -> int:
    return _current_radius

def register_window(window):
    """Зарегистрировать окно для обновления радиуса"""
    if window and window not in _all_windows:
        _all_windows.append(window)

def unregister_window(window):
    """Отменить регистрацию окна"""
    if window in _all_windows:
        _all_windows.remove(window)

def _update_window_radius(widget, radius: int):
    """Рекурсивно обновить радиус всех кнопок в виджете"""
    try:
        # Обновляем кнопки
        if isinstance(widget, ctk.CTkButton):
            try:
                widget.configure(corner_radius=radius)
            except:
                pass
        # Обновляем поля ввода
        elif isinstance(widget, ctk.CTkEntry):
            try:
                widget.configure(corner_radius=radius)
            except:
                pass
        # Обновляем текстовые поля
        elif isinstance(widget, ctk.CTkTextbox):
            try:
                widget.configure(corner_radius=radius)
            except:
                pass
        # Обновляем фреймы со скроллом
        elif isinstance(widget, ctk.CTkScrollableFrame):
            try:
                widget.configure(corner_radius=radius)
            except:
                pass

        # Рекурсивно обходим всех детей
        for child in widget.winfo_children():
            _update_window_radius(child, radius)
    except:
        pass

def update_all_buttons_radius(radius: int):
    """Обновить радиус всех кнопок во всех окнах"""
    set_global_radius(radius)
