"""
Helper functions and utilities
"""
import os
import sys
import math
import platform
import ctypes
import subprocess
import shutil
import tkinter as tk
from typing import Optional

_IS_WINDOWS = platform.system() == "Windows"
_IS_MACOS = platform.system() == "Darwin"
_IS_LINUX = platform.system() == "Linux"
_global_radius = 10

# Кэш для пути к звуковому файлу
_SOUND_CACHE = None


def get_global_radius() -> int:
    """Get global corner radius"""
    return _global_radius


def set_global_radius(radius: int) -> None:
    """Set global corner radius"""
    global _global_radius
    _global_radius = radius


def is_windows() -> bool:
    return _IS_WINDOWS


def is_macos() -> bool:
    return _IS_MACOS


def is_linux() -> bool:
    return _IS_LINUX


def center_screen(win: tk.Tk, width: int, height: int) -> None:
    """Center window on screen"""
    try:
        screen_w = win.winfo_screenwidth()
        screen_h = win.winfo_screenheight()
        x = max(0, (screen_w - width) // 2)
        y = max(0, (screen_h - height) // 2)
        win.geometry(f"{width}x{height}+{x}+{y}")
    except (tk.TclError, AttributeError) as e:
        print(f"[Helpers] Center screen error: {e}")
        # Fallback - просто устанавливаем размер
        win.geometry(f"{width}x{height}")


def get_resource_path(filename: str) -> str:
    """Get path to resource file (works for PyInstaller)"""
    try:
        if hasattr(sys, '_MEIPASS'):
            base_dir = sys._MEIPASS
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        return os.path.join(base_dir, filename)
    except Exception as e:
        print(f"[Helpers] Resource path error: {e}")
        return filename


def _get_sound_path() -> str:
    """
    Get sound file path with caching.
    Проверяет несколько возможных путей и кэширует результат.
    """
    global _SOUND_CACHE
    
    # Возвращаем кэшированный путь если есть
    if _SOUND_CACHE is not None:
        return _SOUND_CACHE
    
    # Список возможных путей
    possible_paths = []
    
    # 1. Путь через get_resource_path (правильный для PyInstaller)
    possible_paths.append(get_resource_path("Computer Mouse Click.mp3"))
    
    # 2. Путь относительно папки utils (на уровень выше)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(current_dir)
    possible_paths.append(os.path.join(parent_dir, "Computer Mouse Click.mp3"))
    
    # 3. Путь в корне проекта
    possible_paths.append(os.path.join(os.getcwd(), "Computer Mouse Click.mp3"))
    
    # 4. Путь в папке resources
    possible_paths.append(os.path.join(parent_dir, "resources", "Computer Mouse Click.mp3"))
    
    # 5. Для PyInstaller - временная папка
    if hasattr(sys, '_MEIPASS'):
        possible_paths.append(os.path.join(sys._MEIPASS, "Computer Mouse Click.mp3"))
    
    # Проверяем каждый путь
    for path in possible_paths:
        if path and os.path.exists(path) and os.path.isfile(path):
            _SOUND_CACHE = path
            print(f"[Helpers] Sound file found: {path}")
            return path
    
    # Файл не найден
    _SOUND_CACHE = ""
    print("[Helpers] Sound file not found in any location")
    return ""


def play_sound(sound_type: str = "click", sound_enabled: bool = True, 
               base_path: str = None) -> None:
    """
    Play sound effect with caching and fallback support.
    
    Args:
        sound_type: Тип звука (пока только "click")
        sound_enabled: Включен ли звук
        base_path: Альтернативный базовый путь (для совместимости)
    """
    if not sound_enabled:
        return
    
    # Получаем путь к звуковому файлу (с кэшированием)
    file_path = _get_sound_path()
    
    # Если файл не найден, просто выходим (не спамим ошибками)
    if not file_path:
        return
    
    try:
        if _IS_WINDOWS:
            _play_sound_windows(file_path)
        elif _IS_MACOS:
            _play_sound_macos(file_path)
        else:
            _play_sound_linux(file_path)
    except Exception as e:
        # Не спамим в лог при каждой ошибке звука
        print(f"[Helpers] Play sound error: {e}")


def _play_sound_windows(file_path: str) -> None:
    """Play sound on Windows using winmm.dll"""
    try:
        winmm = ctypes.windll.winmm
        alias = "app_click"
        
        # Закрываем предыдущее воспроизведение
        winmm.mciSendStringW(f'close {alias}', None, 0, 0)
        
        # Открываем файл
        result = winmm.mciSendStringW(
            f'open "{file_path}" type mpegvideo alias {alias}', 
            None, 0, 0
        )
        
        if result == 0:  # Успех
            # Воспроизводим
            winmm.mciSendStringW(f'play {alias} from 0', None, 0, 0)
            
            # Планируем закрытие через 1 секунду
            def close_sound():
                try:
                    winmm.mciSendStringW(f'close {alias}', None, 0, 0)
                except Exception:
                    pass
            
            import threading
            threading.Timer(1.0, close_sound).start()
            
    except Exception as e:
        print(f"[Helpers] Windows sound error: {e}")


def _play_sound_macos(file_path: str) -> None:
    """Play sound on macOS using afplay"""
    try:
        if shutil.which("afplay"):
            subprocess.Popen(
                ["afplay", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
    except Exception as e:
        print(f"[Helpers] macOS sound error: {e}")


def _play_sound_linux(file_path: str) -> None:
    """Play sound on Linux using available players"""
    try:
        # Пробуем mpg123
        if shutil.which("mpg123"):
            subprocess.Popen(
                ["mpg123", "-q", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
        # Пробуем ffplay
        elif shutil.which("ffplay"):
            subprocess.Popen(
                ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
        # Пробуем aplay (для WAV)
        elif shutil.which("aplay") and file_path.endswith('.wav'):
            subprocess.Popen(
                ["aplay", "-q", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
    except Exception as e:
        print(f"[Helpers] Linux sound error: {e}")


def apply_window_rounding(window) -> None:
    """Apply rounded corners to window (Windows only)"""
    if not _IS_WINDOWS:
        return
    try:
        window.update()
        hwnd = ctypes.windll.user32.GetParent(window.winfo_id())
        DWMWA_WINDOW_CORNER_PREFERENCE = 33
        DWMWCP_ROUND = 2
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            hwnd,
            DWMWA_WINDOW_CORNER_PREFERENCE,
            ctypes.byref(ctypes.c_int(DWMWCP_ROUND)),
            ctypes.sizeof(ctypes.c_int(DWMWCP_ROUND))
        )
    except Exception as e:
        print(f"[Helpers] Window rounding error: {e}")


def set_window_icon(window, icon_path: str = None) -> None:
    """Set window icon"""
    if icon_path is None:
        icon_path = get_resource_path("icon.ico")
    
    if not os.path.exists(icon_path):
        # Пробуем найти иконку в других местах
        alt_paths = [
            os.path.join(os.path.dirname(os.path.dirname(__file__)), "icon.ico"),
            os.path.join(os.getcwd(), "icon.ico"),
            "icon.ico"
        ]
        for path in alt_paths:
            if os.path.exists(path):
                icon_path = path
                break
        else:
            return
    
    try:
        if _IS_WINDOWS:
            window.iconbitmap(icon_path)
        else:
            try:
                img = tk.PhotoImage(file=icon_path)
                window.iconphoto(True, img)
                # Сохраняем ссылку чтобы изображение не удалилось
                if hasattr(window, '_icon_image'):
                    window._icon_image = img
                else:
                    window._icon_image = img
            except Exception as e:
                print(f"[Helpers] Icon photo error: {e}")
    except Exception as e:
        print(f"[Helpers] Set window icon error: {e}")


def get_screen_size() -> tuple:
    """Get screen size (width, height)"""
    try:
        root = tk.Tk()
        root.withdraw()
        width = root.winfo_screenwidth()
        height = root.winfo_screenheight()
        root.destroy()
        return (width, height)
    except Exception as e:
        print(f"[Helpers] Get screen size error: {e}")
        return (1920, 1080)  # Default


def is_admin() -> bool:
    """Check if program is running as administrator (Windows only)"""
    if not _IS_WINDOWS:
        return False
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False


def get_platform_info() -> dict:
    """Get detailed platform information"""
    return {
        'system': platform.system(),
        'release': platform.release(),
        'version': platform.version(),
        'machine': platform.machine(),
        'processor': platform.processor(),
        'python_version': sys.version,
        'is_admin': is_admin() if _IS_WINDOWS else False
    }


# Экспортируем основные функции
__all__ = [
    'get_global_radius',
    'set_global_radius',
    'center_screen',
    'get_resource_path',
    'play_sound',
    'is_windows',
    'is_macos',
    'is_linux',
    'apply_window_rounding',
    'set_window_icon',
    'get_screen_size',
    'is_admin',
    'get_platform_info'
]