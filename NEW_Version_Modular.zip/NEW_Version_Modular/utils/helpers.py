"""
Helper functions and utilities

Вспомогательные функции и утилиты
Допоміжні функції та утиліти
"""
import os
import sys
import math
import platform
import ctypes
import subprocess
import shutil
import tkinter as tk
import threading
import time
from typing import Optional, Tuple, Dict, Any, List
from functools import lru_cache

_IS_WINDOWS = platform.system() == "Windows"
_IS_MACOS = platform.system() == "Darwin"
_IS_LINUX = platform.system() == "Linux"
_global_radius = 10

# Cache for sound file path / Кэш для пути к звуковому файлу / Кеш для шляху до звукового файлу
_SOUND_CACHE = None
_SOUND_CACHE_LOCK = threading.Lock()


# ==================== MAIN FUNCTIONS / ОСНОВНЫЕ ФУНКЦИИ / ОСНОВНІ ФУНКЦІЇ ====================

def get_global_radius() -> int:
    """Get global corner radius / Получить глобальный радиус скругления / Отримати глобальний радіус заокруглення"""
    return _global_radius


def set_global_radius(radius: int) -> None:
    """Set global corner radius / Установить глобальный радиус скругления / Встановити глобальний радіус заокруглення"""
    global _global_radius
    _global_radius = radius


def is_windows() -> bool:
    return _IS_WINDOWS


def is_macos() -> bool:
    return _IS_MACOS


def is_linux() -> bool:
    return _IS_LINUX


def get_platform() -> str:
    """Get platform name / Получить имя платформы / Отримати ім'я платформи"""
    if _IS_WINDOWS:
        return "windows"
    elif _IS_MACOS:
        return "macos"
    else:
        return "linux"


# ==================== WINDOWS AND CENTERING / ОКНА И ЦЕНТРИРОВАНИЕ / ВІКНА ТА ЦЕНТРУВАННЯ ====================

def center_screen(win: tk.Tk, width: int, height: int) -> None:
    """Center window on screen / Центрировать окно на экране / Центрувати вікно на екрані"""
    try:
        screen_w = win.winfo_screenwidth()
        screen_h = win.winfo_screenheight()
        x = max(0, (screen_w - width) // 2)
        y = max(0, (screen_h - height) // 2)
        win.geometry(f"{width}x{height}+{x}+{y}")
    except (tk.TclError, AttributeError) as e:
        print(f"[Helpers] Center screen error: {e}")
        win.geometry(f"{width}x{height}")


def center_window_relative(parent, child, width: int, height: int) -> None:
    """Center child window relative to parent / Центрировать дочернее окно относительно родителя / Центрувати дочірнє вікно відносно батька"""
    try:
        parent.update_idletasks()
        parent_x = parent.winfo_x()
        parent_y = parent.winfo_y()
        parent_width = parent.winfo_width()
        parent_height = parent.winfo_height()
        x = parent_x + (parent_width - width) // 2
        y = parent_y + (parent_height - height) // 2
        
        screen_width = child.winfo_screenwidth()
        screen_height = child.winfo_screenheight()
        
        if x < 0:
            x = 10
        if y < 30:
            y = 30
        if x + width > screen_width:
            x = screen_width - width - 10
        if y + height > screen_height:
            y = screen_height - height - 10
        
        child.geometry(f"{width}x{height}+{x}+{y}")
    except (tk.TclError, AttributeError) as e:
        print(f"[Helpers] Center relative error: {e}")
        center_screen(child, width, height)


# ==================== PATHS AND RESOURCES / ПУТИ И РЕСУРСЫ / ШЛЯХИ ТА РЕСУРСИ ====================

def get_base_dir() -> str:
    """Get base directory (works for EXE and script)
    Получить базовую директорию (работает для EXE и скрипта)
    Отримати базову директорію (працює для EXE та скрипта)"""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


@lru_cache(maxsize=1)
def get_resource_path(filename: str) -> str:
    """Get path to resource file (works for PyInstaller) with caching
    Получить путь к файлу ресурса (работает для PyInstaller) с кэшированием
    Отримати шлях до файлу ресурсу (працює для PyInstaller) з кешуванням"""
    try:
        if hasattr(sys, '_MEIPASS'):
            base_dir = sys._MEIPASS
        else:
            base_dir = get_base_dir()
        return os.path.join(base_dir, filename)
    except (AttributeError, TypeError) as e:
        print(f"[Helpers] Resource path error: {e}")
        return filename


# ==================== SOUND / ЗВУК / ЗВУК ====================

def _get_sound_path() -> str:
    """Get sound file path with caching and thread safety
    Получить путь к звуковому файлу с кэшированием и потокобезопасностью
    Отримати шлях до звукового файлу з кешуванням та потокобезпекою"""
    global _SOUND_CACHE
    
    with _SOUND_CACHE_LOCK:
        if _SOUND_CACHE is not None:
            return _SOUND_CACHE
        
        # List of possible paths / Список возможных путей / Список можливих шляхів
        possible_paths = []
        base_dir = get_base_dir()
        
        possible_paths.append(get_resource_path("Computer Mouse Click.mp3"))
        possible_paths.append(os.path.join(base_dir, "Computer Mouse Click.mp3"))
        possible_paths.append(os.path.join(base_dir, "resources", "Computer Mouse Click.mp3"))
        possible_paths.append(os.path.join(os.getcwd(), "Computer Mouse Click.mp3"))
        
        if hasattr(sys, '_MEIPASS'):
            possible_paths.append(os.path.join(sys._MEIPASS, "Computer Mouse Click.mp3"))
        
        # Check each path / Проверяем каждый путь / Перевіряємо кожен шлях
        for path in possible_paths:
            if path and os.path.exists(path) and os.path.isfile(path):
                _SOUND_CACHE = path
                print(f"[Helpers] Sound file found: {path}")
                return path
        
        _SOUND_CACHE = ""
        print("[Helpers] Sound file not found in any location")
        return ""


def play_sound(sound_type: str = "click", sound_enabled: bool = True, 
               base_path: str = None) -> None:
    """Play sound effect with caching and fallback support
    Воспроизвести звуковой эффект с кэшированием и поддержкой fallback
    Відтворити звуковий ефект з кешуванням та підтримкою fallback"""
    if not sound_enabled:
        return
    
    file_path = _get_sound_path()
    if not file_path:
        return
    
    try:
        if _IS_WINDOWS:
            _play_sound_windows(file_path)
        elif _IS_MACOS:
            _play_sound_macos(file_path)
        else:
            _play_sound_linux(file_path)
    except (OSError, IOError, subprocess.SubprocessError) as e:
        print(f"[Helpers] Play sound error: {e}")


def _play_sound_windows(file_path: str) -> None:
    """Play sound on Windows using winmm.dll
    Воспроизвести звук на Windows через winmm.dll
    Відтворити звук на Windows через winmm.dll"""
    try:
        winmm = ctypes.windll.winmm
        alias = "app_click"
        
        winmm.mciSendStringW(f'close {alias}', None, 0, 0)
        
        result = winmm.mciSendStringW(
            f'open "{file_path}" type mpegvideo alias {alias}', 
            None, 0, 0
        )
        
        if result == 0:
            winmm.mciSendStringW(f'play {alias} from 0', None, 0, 0)
            
            def close_sound():
                try:
                    winmm.mciSendStringW(f'close {alias}', None, 0, 0)
                except (AttributeError, OSError):
                    pass
            
            threading.Timer(1.0, close_sound).start()
            
    except (AttributeError, OSError, TypeError) as e:
        print(f"[Helpers] Windows sound error: {e}")


def _play_sound_macos(file_path: str) -> None:
    """Play sound on macOS using afplay
    Воспроизвести звук на macOS через afplay
    Відтворити звук на macOS через afplay"""
    try:
        if shutil.which("afplay"):
            subprocess.Popen(
                ["afplay", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
    except (OSError, subprocess.SubprocessError) as e:
        print(f"[Helpers] macOS sound error: {e}")


def _play_sound_linux(file_path: str) -> None:
    """Play sound on Linux using available players
    Воспроизвести звук на Linux используя доступные проигрыватели
    Відтворити звук на Linux використовуючи доступні програвачі"""
    try:
        if shutil.which("mpg123"):
            subprocess.Popen(
                ["mpg123", "-q", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
        elif shutil.which("ffplay"):
            subprocess.Popen(
                ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
        elif shutil.which("paplay"):
            subprocess.Popen(
                ["paplay", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
    except (OSError, subprocess.SubprocessError) as e:
        print(f"[Helpers] Linux sound error: {e}")


# ==================== WINDOWS AND ICONS / ОКНА И ИКОНКИ / ВІКНА ТА ІКОНКИ ====================

def apply_window_rounding(window) -> None:
    """Apply rounded corners to window (Windows only)
    Применить скругленные углы к окну (только Windows)
    Застосувати заокруглені кути до вікна (тільки Windows)"""
    if not _IS_WINDOWS:
        return
    try:
        window.update()
        hwnd = ctypes.windll.user32.GetParent(window.winfo_id())
        DWMWA_WINDOW_CORNER_PREFERENCE = 33
        DWMWCP_ROUND = 2
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            hwnd,
            DWMWA_WINDOW_CORNER_PREFERENCE,
            ctypes.byref(ctypes.c_int(DWMWCP_ROUND)),
            ctypes.sizeof(ctypes.c_int(DWMWCP_ROUND))
        )
    except (AttributeError, OSError, TypeError) as e:
        print(f"[Helpers] Window rounding error: {e}")


def set_window_icon(window, icon_path: str = None) -> None:
    """Set window icon / Установить иконку окна / Встановити іконку вікна"""
    if icon_path is None:
        icon_path = get_resource_path("icon.ico")
    
    if not os.path.exists(icon_path):
        alt_paths = [
            os.path.join(get_base_dir(), "icon.ico"),
            os.path.join(os.getcwd(), "icon.ico"),
            "icon.ico"
        ]
        for path in alt_paths:
            if os.path.exists(path):
                icon_path = path
                break
        else:
            return
    
    try:
        if _IS_WINDOWS:
            window.iconbitmap(icon_path)
        else:
            try:
                img = tk.PhotoImage(file=icon_path)
                window.iconphoto(True, img)
                if hasattr(window, '_icon_image'):
                    window._icon_image = img
                else:
                    window._icon_image = img
            except (tk.TclError, AttributeError) as e:
                print(f"[Helpers] Icon photo error: {e}")
    except (tk.TclError, AttributeError) as e:
        print(f"[Helpers] Set window icon error: {e}")


# ==================== LINUX SPECIFIC FUNCTIONS / LINUX СПЕЦИФИЧНЫЕ ФУНКЦИИ / LINUX СПЕЦИФІЧНІ ФУНКЦІЇ ====================

def get_system_scaling() -> float:
    """Get system recommended scaling factor for Linux
    Получить рекомендуемый системой коэффициент масштабирования для Linux
    Отримати рекомендований системою коефіцієнт масштабування для Linux"""
    if not _IS_LINUX:
        return 1.0
    
    try:
        result = subprocess.run(
            ['xdpyinfo', '|', 'grep', 'dimensions'],
            shell=True, capture_output=True, text=True, timeout=2
        )
        if result.returncode == 0:
            import re
            match = re.search(r'(\d+)x(\d+)', result.stdout)
            if match:
                width = int(match.group(1))
                if width >= 3840:
                    return 2.0
                elif width >= 2560:
                    return 1.5
                elif width >= 1920:
                    return 1.25
    except (subprocess.SubprocessError, FileNotFoundError, ValueError, AttributeError):
        pass
    
    # Check for GDK scale / Проверка GDK scale / Перевірка GDK scale
    try:
        gdk_scale = os.environ.get('GDK_SCALE', '1')
        return float(gdk_scale)
    except (ValueError, TypeError):
        pass
    
    return 1.0


def get_linux_desktop_environment() -> str:
    """Get Linux desktop environment name
    Получить имя окружения рабочего стола Linux
    Отримати ім'я середовища робочого столу Linux"""
    if not _IS_LINUX:
        return "unknown"
    
    de = os.environ.get('XDG_CURRENT_DESKTOP', '')
    if de:
        return de.lower()
    
    de = os.environ.get('DESKTOP_SESSION', '')
    if de:
        return de.lower()
    
    return "unknown"


def is_wayland() -> bool:
    """Check if running under Wayland / Проверить, запущено ли под Wayland / Перевірити, чи запущено під Wayland"""
    if not _IS_LINUX:
        return False
    
    xdg_session_type = os.environ.get('XDG_SESSION_TYPE', '').lower()
    if xdg_session_type == 'wayland':
        return True
    
    wayland_display = os.environ.get('WAYLAND_DISPLAY', '')
    if wayland_display:
        return True
    
    return False


def apply_linux_theme(window) -> None:
    """Apply Linux-specific theme optimizations
    Применить Linux-специфичные оптимизации темы
    Застосувати Linux-специфічні оптимізації теми"""
    if not _IS_LINUX:
        return
    
    try:
        window.attributes('-type', 'dialog')
        
        if is_wayland():
            try:
                window.attributes('-type', 'normal')
            except (tk.TclError, AttributeError):
                pass
        
        de = get_linux_desktop_environment()
        if 'gnome' in de or 'unity' in de:
            import customtkinter as ctk
            ctk.set_widget_scaling(1.05)
        elif 'kde' in de or 'plasma' in de:
            import customtkinter as ctk
            ctk.set_widget_scaling(1.0)
        else:
            import customtkinter as ctk
            ctk.set_widget_scaling(1.05)
        
        scaling = get_system_scaling()
        if scaling > 1.0:
            import customtkinter as ctk
            ctk.set_widget_scaling(scaling * 0.95)
            
    except (tk.TclError, AttributeError, ImportError) as e:
        print(f"[Helpers] Linux theme error: {e}")


# ==================== SYSTEM FUNCTIONS / СИСТЕМНЫЕ ФУНКЦИИ / СИСТЕМНІ ФУНКЦІЇ ====================

def get_screen_size() -> Tuple[int, int]:
    """Get screen size (width, height) / Получить размер экрана (ширина, высота) / Отримати розмір екрану (ширина, висота)"""
    try:
        root = tk.Tk()
        root.withdraw()
        width = root.winfo_screenwidth()
        height = root.winfo_screenheight()
        root.destroy()
        return (width, height)
    except (tk.TclError, RuntimeError) as e:
        print(f"[Helpers] Get screen size error: {e}")
        return (1920, 1080)


def is_admin() -> bool:
    """Check if program is running as administrator (Windows only)
    Проверить, запущена ли программа от имени администратора (только Windows)
    Перевірити, чи запущено програму від імені адміністратора (тільки Windows)"""
    if not _IS_WINDOWS:
        return False
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except (AttributeError, OSError):
        return False


def get_platform_info() -> Dict[str, Any]:
    """Get detailed platform information / Получить детальную информацию о платформе / Отримати детальну інформацію про платформу"""
    info = {
        'system': platform.system(),
        'release': platform.release(),
        'version': platform.version(),
        'machine': platform.machine(),
        'processor': platform.processor(),
        'python_version': sys.version,
        'is_admin': is_admin() if _IS_WINDOWS else False
    }
    
    if _IS_LINUX:
        info['desktop_environment'] = get_linux_desktop_environment()
        info['is_wayland'] = is_wayland()
        info['scaling'] = get_system_scaling()
    
    return info


# ==================== HELPER UTILITIES / ВСПОМОГАТЕЛЬНЫЕ УТИЛИТЫ / ДОПОМІЖНІ УТИЛІТИ ====================

def format_time(seconds: int) -> str:
    """Format seconds into human readable string
    Форматировать секунды в человекочитаемую строку
    Форматувати секунди в читабельний рядок"""
    if seconds < 60:
        return f"{seconds} сек"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes} мин"
    elif seconds < 86400:
        hours = seconds // 3600
        return f"{hours} ч"
    else:
        days = seconds // 86400
        return f"{days} дн"


def truncate_string(text: str, max_length: int = 50, suffix: str = "...") -> str:
    """Truncate string to max length / Обрезать строку до максимальной длины / Обрізати рядок до максимальної довжини"""
    if len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix


def is_valid_filename(filename: str) -> bool:
    """Check if filename is valid / Проверить, является ли имя файла допустимым / Перевірити, чи є ім'я файлу допустимим"""
    invalid_chars = '<>:"/\\|?*'
    return not any(c in invalid_chars for c in filename)


def ensure_dir(path: str) -> bool:
    """Ensure directory exists, create if not
    Проверить существование директории, создать если нет
    Перевірити існування директорії, створити якщо немає"""
    try:
        os.makedirs(path, exist_ok=True)
        return True
    except (PermissionError, OSError) as e:
        print(f"[Helpers] Failed to create directory {path}: {e}")
        return False


# Export main functions / Экспортируем основные функции / Експортуємо основні функції
__all__ = [
    'get_global_radius',
    'set_global_radius',
    'center_screen',
    'center_window_relative',
    'get_resource_path',
    'play_sound',
    'is_windows',
    'is_macos',
    'is_linux',
    'get_platform',
    'apply_window_rounding',
    'set_window_icon',
    'get_screen_size',
    'is_admin',
    'get_platform_info',
    'get_system_scaling',
    'get_linux_desktop_environment',
    'is_wayland',
    'apply_linux_theme',
    'format_time',
    'truncate_string',
    'is_valid_filename',
    'ensure_dir',
    'get_base_dir',
]