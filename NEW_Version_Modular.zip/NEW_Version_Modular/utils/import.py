"""
Password import utilities for CSV, JSON, KeePass XML
"""
import json
import csv
import xml.etree.ElementTree as ET
import os
import datetime
from typing import List, Dict, Any, Optional
from tkinter import filedialog
from utils.logger import get_logger

logger = get_logger("import")


class PasswordImporter:
    """Импорт паролей из различных форматов"""

    @staticmethod
    def import_from_json(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из JSON формата"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            passwords = []

            # Поддерживаем два формата: простой массив или с обёрткой
            if isinstance(data, list):
                for i, item in enumerate(data):
                    passwords.append({
                        'label': item.get('label', item.get('name', f"Imported_{i}")),
                        'password': item.get('password', item.get('pwd', '')),
                        'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    })
            elif isinstance(data, dict):
                # Формат экспорта Secure Pass Pro
                items = data.get('passwords', data.get('items', []))
                for item in items:
                    passwords.append({
                        'label': item.get('label', item.get('name', 'Imported')),
                        'password': item.get('password', item.get('pwd', '')),
                        'created': item.get('created', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                    })

            return passwords
        except (json.JSONDecodeError, OSError, IOError) as e:
            logger.error(f"JSON import error: {e}")
            raise

    @staticmethod
    def import_from_csv(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из CSV формата"""
        try:
            passwords = []

            with open(file_path, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)

                # Определяем колонки
                fieldnames = reader.fieldnames or []
                label_col = None
                pwd_col = None
                date_col = None

                for col in fieldnames:
                    col_lower = col.lower()
                    if 'label' in col_lower or 'name' in col_lower or 'title' in col_lower:
                        label_col = col
                    elif 'password' in col_lower or 'pwd' in col_lower or 'pass' in col_lower:
                        pwd_col = col
                    elif 'created' in col_lower or 'date' in col_lower:
                        date_col = col

                # Если не нашли, берём первые колонки
                if label_col is None and len(fieldnames) > 0:
                    label_col = fieldnames[0]
                if pwd_col is None and len(fieldnames) > 1:
                    pwd_col = fieldnames[1]

                for row in reader:
                    label = row.get(label_col, '') if label_col else ''
                    password = row.get(pwd_col, '') if pwd_col else ''
                    created = row.get(date_col, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')) if date_col else datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                    if password:
                        passwords.append({
                            'label': label.strip() if label else f"Imported_{len(passwords)+1}",
                            'password': password.strip(),
                            'created': created
                        })

            return passwords
        except (OSError, IOError, csv.Error) as e:
            logger.error(f"CSV import error: {e}")
            raise

    @staticmethod
    def import_from_keepass_xml(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из KeePass XML формата"""
        try:
            tree = ET.parse(file_path)
            root = tree.getroot()

            passwords = []

            # Ищем элементы entry
            for entry in root.findall('.//Entry') or root.findall('.//entry'):
                title_elem = entry.find('.//Title') or entry.find('.//title')
                username_elem = entry.find('.//UserName') or entry.find('.//username')
                password_elem = entry.find('.//Password') or entry.find('.//password')
                url_elem = entry.find('.//URL') or entry.find('.//url')
                notes_elem = entry.find('.//Notes') or entry.find('.//notes')

                title = title_elem.text if title_elem is not None else ''
                password = password_elem.text if password_elem is not None else ''
                username = username_elem.text if username_elem is not None else ''
                url = url_elem.text if url_elem is not None else ''
                notes = notes_elem.text if notes_elem is not None else ''

                if password:
                    label = title
                    if username:
                        label += f" ({username})"
                    if url:
                        label += f" - {url}"

                    passwords.append({
                        'label': label[:100],
                        'password': password,
                        'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        'notes': notes[:500] if notes else ''
                    })

            return passwords
        except ET.ParseError as e:
            logger.error(f"KeePass XML parse error: {e}")
            raise
        except (OSError, IOError) as e:
            logger.error(f"KeePass XML import error: {e}")
            raise

    @staticmethod
    def import_from_bitwarden_json(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из Bitwarden JSON формата"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            passwords = []

            # Bitwarden экспорт имеет поле "items"
            items = data.get('items', [])
            for item in items:
                login = item.get('login', {})
                password = login.get('password', '')

                if password:
                    name = item.get('name', '')
                    username = login.get('username', '')

                    label = name
                    if username:
                        label += f" ({username})"

                    passwords.append({
                        'label': label[:100],
                        'password': password,
                        'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    })

            return passwords
        except (json.JSONDecodeError, OSError, IOError) as e:
            logger.error(f"Bitwarden JSON import error: {e}")
            raise

    @staticmethod
    def import_from_1password_csv(file_path: str) -> List[Dict[str, Any]]:
        """Импорт из 1Password CSV формата"""
        try:
            passwords = []

            with open(file_path, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)

                for row in reader:
                    # 1Password формат: title, password, url, username
                    title = row.get('title', row.get('Title', ''))
                    password = row.get('password', row.get('Password', ''))
                    username = row.get('username', row.get('Username', ''))
                    url = row.get('url', row.get('URL', ''))

                    if password:
                        label = title
                        if username:
                            label += f" ({username})"
                        if url:
                            label += f" - {url}"

                        passwords.append({
                            'label': label[:100],
                            'password': password,
                            'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        })

            return passwords
        except (OSError, IOError, csv.Error) as e:
            logger.error(f"1Password CSV import error: {e}")
            raise

    @staticmethod
    def import_all(parent, lang: str = "RU") -> None:
        """Диалог выбора формата и импорт"""
        from storage.database import PasswordDB
        from gui.dialogs import CTkMessageBox
        import customtkinter as ctk
        import tkinter as tk
        from localization.lang import LANGUAGES

        L = LANGUAGES.get(lang, LANGUAGES["RU"])

        # Окно выбора формата
        win = ctk.CTkToplevel(parent)
        win.title(L.get("import_title", "Import Passwords"))
        win.geometry("350x350")
        win.resizable(False, False)
        win.transient(parent)
        win.grab_set()
        win.attributes("-topmost", True)

        # Центрирование
        win.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - 350) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 350) // 2
        win.geometry(f"350x350+{x}+{y}")

        format_var = tk.StringVar(value="json")

        ctk.CTkLabel(win, text=L.get("import_format", "Import format:"),
                    font=("Segoe UI", 14, "bold")).pack(pady=(20, 10))

        formats = [
            ("json", "JSON (Secure Pass Pro)"),
            ("csv", "CSV (Excel)"),
            ("keepass", "KeePass XML"),
            ("bitwarden", "Bitwarden JSON"),
            ("onepassword", "1Password CSV")
        ]

        for fmt, text in formats:
            ctk.CTkRadioButton(win, text=text, variable=format_var,
                              value=fmt, font=("Segoe UI", 12)).pack(anchor="w", padx=30, pady=3)

        ctk.CTkLabel(win, text="", font=("Segoe UI", 10), text_color="gray").pack(pady=5)
        ctk.CTkLabel(win, text=L.get("import_warning", "Import only from trusted sources!"),
                    font=("Segoe UI", 10), text_color="#FFA500").pack()

        def do_import():
            fmt = format_var.get()
            extensions = {
                "json": ("JSON files", "*.json"),
                "csv": ("CSV files", "*.csv"),
                "keepass": ("KeePass XML", "*.xml"),
                "bitwarden": ("Bitwarden JSON", "*.json"),
                "onepassword": ("1Password CSV", "*.csv")
            }

            path = filedialog.askopenfilename(
                title="Select file to import",
                filetypes=[(extensions[fmt][0], extensions[fmt][1]), ("All files", "*.*")]
            )

            if path:
                try:
                    if fmt == "json":
                        passwords = PasswordImporter.import_from_json(path)
                    elif fmt == "csv":
                        passwords = PasswordImporter.import_from_csv(path)
                    elif fmt == "keepass":
                        passwords = PasswordImporter.import_from_keepass_xml(path)
                    elif fmt == "bitwarden":
                        passwords = PasswordImporter.import_from_bitwarden_json(path)
                    elif fmt == "onepassword":
                        passwords = PasswordImporter.import_from_1password_csv(path)
                    else:
                        passwords = []

                    if not passwords:
                        CTkMessageBox.warning(win, L.get("import_title", "Import"),
                                             L.get("import_no_passwords", "No passwords found in file!"))
                        return

                    # Показываем предпросмотр
                    preview = "\n".join([f"- {p['label']}" for p in passwords[:10]])
                    if len(passwords) > 10:
                        preview += f"\n... and {len(passwords) - 10} more"

                    if not CTkMessageBox.question(win, L.get("import_title", "Import"),
                        f"{L.get('import_found', 'Passwords found')}: {len(passwords)}\n\n{preview}\n\n{L.get('import_confirm', 'Import?')}"):
                        return

                    # Импортируем
                    imported = 0
                    for pwd in passwords:
                        try:
                            PasswordDB.save(pwd['label'], pwd['password'])
                            imported += 1
                        except Exception as e:
                            logger.error(f"Import save error: {e}")

                    win.destroy()

                    CTkMessageBox.info(parent, L.get("import_title", "Import"),
                                      L.get("import_success", "Imported: {0}").format(imported))

                    # Обновляем окно БД если открыто
                    if hasattr(parent, '_refresh_db_window'):
                        parent._refresh_db_window()
                    elif hasattr(parent, 'refresh'):
                        parent.refresh()

                except Exception as e:
                    logger.error(f"Import error: {e}")
                    CTkMessageBox.error(win, L.get("err_title", "Error"),
                                       L.get("import_error", "Import error: {0}").format(str(e)))

        btn_frame = ctk.CTkFrame(win, fg_color="transparent")
        btn_frame.pack(pady=20)
        ctk.CTkButton(btn_frame, text=L.get("ok", "Import"), command=do_import,
                     width=120, fg_color="#2d6a4f", corner_radius=15).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text=L.get("cancel", "Cancel"), command=win.destroy,
                     width=120, fg_color="#8b0000", corner_radius=15).pack(side="left", padx=5)

        win.after(100, lambda: win.attributes("-topmost", False))