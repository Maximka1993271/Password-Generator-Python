#!/usr/bin/env python3
"""
Secure Pass Pro v4.0 - Главный файл запуска
"""

import sys
import os

# Добавляем текущую папку в путь поиска модулей
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


if __name__ == "__main__":
    import customtkinter as ctk
    from gui.main_window import SecurePassPro
    
    # Настройка темы
    ctk.set_appearance_mode("System")
    ctk.set_default_color_theme("blue")
    
    # Запуск приложения
    app = SecurePassPro()
    app.mainloop()