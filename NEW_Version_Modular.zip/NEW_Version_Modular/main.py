#!/usr/bin/env python3
"""
Secure Pass Pro v4.0 - Professional Password Generator
Main entry point

Secure Pass Pro v4.0 - Профессиональный генератор паролей
Главная точка входа

Secure Pass Pro v4.0 - Професійний генератор паролів
Головна точка входу
"""

import sys
import os
import json
import ctypes
import platform

# Add current directory to path for proper imports
# Добавляем текущую директорию в путь для корректных импортов
# Додаємо поточну директорію до шляху для коректних імпортів
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def setup_console_for_windows() -> None:
    """Setup console for Windows to support ANSI colors
    Настройка консоли для Windows для поддержки ANSI цветов
    Налаштування консолі для Windows для підтримки ANSI кольорів"""
    if platform.system() == "Windows":
        try:
            # Enable ANSI support in Windows console
            # Включение поддержки ANSI в консоли Windows
            # Ввімкнення підтримки ANSI в консолі Windows
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
        except (AttributeError, OSError):
            pass


def check_python_version() -> None:
    """Check Python version compatibility
    Проверка совместимости версии Python
    Перевірка сумісності версії Python"""
    if sys.version_info < (3, 8):
        print("❌ Secure Pass Pro requires Python 3.8 or higher!")
        print("❌ Secure Pass Pro требует Python 3.8 или выше!")
        print("❌ Secure Pass Pro вимагає Python 3.8 або вище!")
        sys.exit(1)


def check_dependencies() -> bool:
    """Check required dependencies / Проверка необходимых зависимостей / Перевірка необхідних залежностей"""
    missing = []
    
    # Critical dependencies / Критические зависимости / Критичні залежності
    critical = [
        ('customtkinter', 'customtkinter'),
        ('PIL', 'Pillow'),
        ('cryptography', 'cryptography'),
    ]
    
    for module, package in critical:
        try:
            __import__(module)
        except ImportError:
            missing.append(package)
    
    if missing:
        print("=" * 50)
        print("Secure Pass Pro - Missing Dependencies")
        print("=" * 50)
        print("\n❌ The following packages are required:\n")
        for pkg in missing:
            print(f"   - {pkg}")
        print("\n📦 Install with:")
        print(f"   pip install {' '.join(missing)}")
        print("\n" + "=" * 50)
        return False
    
    return True


def create_desktop_shortcut() -> None:
    """Create desktop shortcut (Windows only)
    Создать ярлык на рабочем столе (только Windows)
    Створити ярлик на робочому столі (тільки Windows)"""
    if platform.system() != "Windows":
        return
    
    try:
        import winshell
        from win32com.client import Dispatch
        
        desktop = winshell.desktop()
        path = os.path.join(desktop, "Secure Pass Pro.lnk")
        
        if os.path.exists(path):
            return
        
        shell = Dispatch('WScript.Shell')
        shortcut = shell.CreateShortCut(path)
        shortcut.Targetpath = sys.executable
        shortcut.WorkingDirectory = os.path.dirname(sys.executable)
        shortcut.IconLocation = sys.executable
        shortcut.save()
        
        print("✅ Desktop shortcut created successfully")
        print("✅ Ярлык на рабочем столе успешно создан")
        print("✅ Ярлик на робочому столі успішно створено")
    except ImportError:
        pass
    except Exception as e:
        print(f"⚠️ Could not create desktop shortcut: {e}")


def main() -> None:
    """Main entry point / Главная точка входа / Головна точка входу"""
    # Setup console / Настройка консоли / Налаштування консолі
    setup_console_for_windows()
    
    # Check Python version / Проверка версии Python / Перевірка версії Python
    check_python_version()
    
    # Check dependencies / Проверка зависимостей / Перевірка залежностей
    if not check_dependencies():
        sys.exit(1)
    
    # Import after dependency check for better error messages
    # Импорт после проверки зависимостей для лучших сообщений об ошибках
    # Імпорт після перевірки залежностей для кращих повідомлень про помилки
    import customtkinter as ctk
    from gui.main_window import SecurePassPro
    from security.master import MasterPassword
    from security.panic import init_panic_cleanup
    from utils.logger import get_logger, enable_debug_logs
    from utils.paths import get_config_file, get_config_dir
    
    # Initialize logger / Инициализация логгера / Ініціалізація логера
    logger = get_logger("main")
    
    # Create config directory if needed / Создаём директорию конфигов если нужно / Створюємо директорію конфігів якщо потрібно
    os.makedirs(get_config_dir(), exist_ok=True)
    
    # Load config to get language and theme settings
    # Загружаем конфиг для получения настроек языка и темы
    # Завантажуємо конфіг для отримання налаштувань мови та теми
    config_file = get_config_file()
    startup_lang = "RU"
    startup_theme = "dark"
    
    try:
        if os.path.exists(config_file):
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
                if "LANG" in config and config["LANG"] in ("RU", "EN", "UA"):
                    startup_lang = config["LANG"]
                if "THEME" in config:
                    if config["THEME"] == "Light":
                        startup_theme = "light"
                    elif config["THEME"] == "Dark":
                        startup_theme = "dark"
    except (OSError, IOError, json.JSONDecodeError) as e:
        print(f"⚠️ Could not load config: {e}")
    
    # Initialize panic cleanup / Инициализация аварийной очистки / Ініціалізація аварійного очищення
    init_panic_cleanup()
    
    # Set appearance mode / Установка режима отображения / Встановлення режиму відображення
    ctk.set_appearance_mode(startup_theme)
    ctk.set_default_color_theme("blue")
    
    # Prompt for master password and start application
    # Запрос мастер-пароля и запуск приложения
    # Запит майстер-пароля та запуск програми
    if not MasterPassword.prompt_on_startup(startup_lang, startup_theme):
        logger.info("Application closed by user during master password prompt")
        sys.exit(0)
    
    # Create and run application / Создание и запуск приложения / Створення та запуск програми
    try:
        app = SecurePassPro()
        
        # Try to create desktop shortcut (non-critical) / Пытаемся создать ярлык (не критично) / Намагаємося створити ярлик (не критично)
        try:
            create_desktop_shortcut()
        except Exception as e:
            logger.debug(f"Desktop shortcut creation skipped: {e}")
        
        logger.info("Application started successfully")
        app.mainloop()
        
    except KeyboardInterrupt:
        logger.info("Application interrupted by user")
        print("\n\n👋 Secure Pass Pro closed.")
        print("\n\n👋 Secure Pass Pro закрыт.")
        print("\n\n👋 Secure Pass Pro закрито.")
    except Exception as e:
        logger.exception(f"Fatal error: {e}")
        print(f"\n\n❌ Fatal error: {e}")
        print(f"\n\n❌ Критическая ошибка: {e}")
        print(f"\n\n❌ Критична помилка: {e}")
        sys.exit(1)
    finally:
        logger.info("Application shutdown complete")


if __name__ == "__main__":
    main()