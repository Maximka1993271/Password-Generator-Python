#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Secure Pass Pro v4.0 — Cryptographically secure password generator
Author: Maxim Melnikov

English:
Secure Pass Pro v4.0 — Cryptographically secure password generator
Full 3-language support (RU, EN, UA)
Cross-platform: Windows, Linux, macOS

Русский:
Secure Pass Pro v4.0 — Криптографически безопасный генератор паролей
Полная поддержка 3 языков (RU, EN, UA)
Кросс-платформенность: Windows, Linux, macOS

Українська:
Secure Pass Pro v4.0 — Криптографічно безпечний генератор паролів
Повна підтримка 3 мов (RU, EN, UA)
Кросплатформеність: Windows, Linux, macOS
"""

import sys
import os
import json
import traceback
import platform
import tkinter as tk
from typing import Optional, Dict, Any

# Setup logging early / Настройка логирования / Налаштування логування
from utils.logger import get_logger, log_crash_report
logger = get_logger("launcher")

# Anti-debugging protection (must be early) / Анти-отладочная защита / Анти-відлагоджувальний захист
try:
    from security.antidebug import init_anti_debug
    init_anti_debug()
    logger.debug("Anti-debugging initialized")
except ImportError as e:
    logger.warning(f"Anti-debug module not available: {e}")
except (AttributeError, RuntimeError, OSError) as e:
    logger.error(f"Anti-debug error: {e}")

# Add current directory to path for imports
# Добавляем текущую директорию в путь
# Додаємо поточну директорію до шляху
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def get_startup_config() -> Dict[str, str]:
    """
    Load startup configuration from config file.
    Supports 3 languages: RU, EN, UA.
    
    Загружает конфигурацию запуска из файла конфигурации.
    Поддерживает 3 языка: RU, EN, UA.
    
    Завантажує конфігурацію запуску з файлу конфігурації.
    Підтримує 3 мови: RU, EN, UA.
    
    Returns:
        Dictionary with 'lang' and 'theme' keys
        Словарь с ключами 'lang' и 'theme'
        Словник з ключами 'lang' та 'theme'
    """
    config = {"lang": "RU", "theme": "dark"}
    
    try:
        from utils.paths import get_config_file
        config_file = get_config_file()
        
        if os.path.exists(config_file):
            with open(config_file, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            
            if cfg.get("LANG") in ("RU", "EN", "UA"):
                config["lang"] = cfg["LANG"]
            
            if cfg.get("THEME") == "Light":
                config["theme"] = "light"
            elif cfg.get("THEME") == "Dark":
                config["theme"] = "dark"
                
            logger.info(f"Loaded startup config: lang={config['lang']}, theme={config['theme']}")
    except json.JSONDecodeError as e:
        logger.error(f"Config JSON decode error: {e}")
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Config file read error: {e}")
    except (KeyError, ValueError, TypeError) as e:
        logger.error(f"Config parsing error: {e}")
    
    return config


def setup_early_environment() -> None:
    """
    Setup early environment settings (cross-platform).
    
    Настраивает ранние параметры окружения (кросс-платформенно).
    Налаштовує ранні параметри середовища (кросплатформено).
    """
    # Set higher recursion limit for deep UI trees
    try:
        sys.setrecursionlimit(10000)
    except (ValueError, RuntimeError) as e:
        logger.debug(f"Failed to set recursion limit: {e}")
    
    # Set up Windows-specific console
    if platform.system() == "Windows":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
        except (AttributeError, OSError, TypeError, ImportError) as e:
            logger.debug(f"Windows console setup error: {e}")
    
    # Set up Linux-specific environment
    elif platform.system() == "Linux":
        try:
            # Set QT scale factor for better HiDPI support
            if "QT_SCALE_FACTOR" not in os.environ:
                os.environ["QT_SCALE_FACTOR"] = "1"
            # Set GDK scale for GTK apps
            if "GDK_SCALE" not in os.environ:
                os.environ["GDK_SCALE"] = "1"
        except (KeyError, TypeError, ValueError, OSError) as e:  # ✅ Исправлено
            logger.debug(f"Linux environment setup error: {e}")
    
    # Set up macOS-specific environment
    elif platform.system() == "Darwin":
        try:
            # Set NSHighResolutionCapable for retina display support
            if "NSHighResolutionCapable" not in os.environ:
                os.environ["NSHighResolutionCapable"] = "True"
        except (KeyError, TypeError, ValueError, OSError) as e:  # ✅ Исправлено
            logger.debug(f"macOS environment setup error: {e}")


def check_python_version() -> bool:
    """
    Check Python version compatibility.
    
    Проверка совместимости версии Python.
    Перевірка сумісності версії Python.
    
    Returns:
        True if version is compatible, False otherwise
        True если версия совместима, False если нет
        True якщо версія сумісна, False якщо ні
    """
    if sys.version_info < (3, 8):
        error_msg = (
            "Secure Pass Pro requires Python 3.8 or higher!\n"
            "Secure Pass Pro требует Python 3.8 или выше!\n"
            "Secure Pass Pro вимагає Python 3.8 або вище!"
        )
        print(error_msg)
        logger.critical(error_msg)
        return False
    return True


def check_dependencies() -> bool:
    """
    Check required dependencies (cross-platform).
    
    Проверка необходимых зависимостей (кросс-платформенно).
    Перевірка необхідних залежностей (кросплатформено).
    
    Returns:
        True if all dependencies are available, False otherwise
        True если все зависимости доступны, False если нет
        True якщо всі залежності доступні, False якщо ні
    """
    missing = []
    
    # Critical dependencies / Критические зависимости / Критичні залежності
    critical = [
        ('customtkinter', 'customtkinter'),
        ('PIL', 'Pillow'),
        ('cryptography', 'cryptography'),
    ]
    
    for module, package in critical:
        try:
            __import__(module)
        except ImportError as e:
            missing.append(package)
            logger.debug(f"Missing dependency: {package} - {e}")
    
    if missing:
        print("=" * 50)
        print("Secure Pass Pro - Missing Dependencies")
        print("=" * 50)
        print("\nThe following packages are required:\n")
        for pkg in missing:
            print(f"   - {pkg}")
        print("\nInstall with:")
        print(f"   pip install {' '.join(missing)}")
        print("\n" + "=" * 50)
        logger.error(f"Missing dependencies: {missing}")
        return False
    
    logger.info("All dependencies are available")
    return True


def create_desktop_shortcut() -> None:
    """
    Create desktop shortcut (cross-platform: Windows, Linux, macOS).
    
    Создать ярлык на рабочем столе (кросс-платформенно).
    Створити ярлик на робочому столі (кросплатформено).
    """
    system = platform.system()
    
    try:
        if system == "Windows":
            import winshell
            from win32com.client import Dispatch
            
            desktop = winshell.desktop()
            path = os.path.join(desktop, "Secure Pass Pro.lnk")
            
            if os.path.exists(path):
                return
            
            shell = Dispatch('WScript.Shell')
            shortcut = shell.CreateShortCut(path)
            shortcut.Targetpath = sys.executable
            shortcut.WorkingDirectory = os.path.dirname(sys.executable)
            shortcut.IconLocation = sys.executable
            shortcut.save()
            
            print("Desktop shortcut created successfully (Windows)")
            logger.info("Desktop shortcut created on Windows")
            
        elif system == "Linux":
            # Create .desktop file for Linux
            desktop = os.path.expanduser("~/Desktop")
            if not os.path.exists(desktop):
                desktop = os.path.expanduser("~/.local/share/applications")
            
            path = os.path.join(desktop, "securepasspro.desktop")
            if os.path.exists(path):
                return
            
            exe_path = sys.executable if getattr(sys, 'frozen', False) else sys.argv[0]
            icon_path = os.path.join(os.path.dirname(exe_path), "icon.png")
            if not os.path.exists(icon_path):
                icon_path = ""
            
            with open(path, 'w', encoding='utf-8') as f:
                f.write("[Desktop Entry]\n")
                f.write("Version=1.0\n")
                f.write("Type=Application\n")
                f.write("Name=Secure Pass Pro\n")
                f.write("Comment=Password generator and manager\n")
                f.write(f"Exec={exe_path}\n")
                if icon_path:
                    f.write(f"Icon={icon_path}\n")
                f.write("Terminal=false\n")
                f.write("Categories=Utility;Security;\n")
                f.write("StartupWMClass=SecurePassPro\n")
            
            os.chmod(path, 0o755)
            print("Desktop shortcut created successfully (Linux)")
            logger.info("Desktop shortcut created on Linux")
            
        elif system == "Darwin":  # macOS
            # Create .app bundle or alias on macOS
            desktop = os.path.expanduser("~/Desktop")
            exe_path = sys.executable if getattr(sys, 'frozen', False) else sys.argv[0]
            
            # For macOS, create a simple .command file
            path = os.path.join(desktop, "Secure Pass Pro.command")
            if os.path.exists(path):
                return
            
            with open(path, 'w', encoding='utf-8') as f:
                f.write("#!/bin/bash\n")
                f.write(f'cd "{os.path.dirname(exe_path)}"\n')
                f.write(f'"{exe_path}"\n')
            
            os.chmod(path, 0o755)
            print("Desktop shortcut created successfully (macOS)")
            logger.info("Desktop shortcut created on macOS")
            
    except ImportError as e:
        logger.debug(f"Desktop shortcut modules not available: {e}")
    except (AttributeError, OSError, RuntimeError, TypeError, PermissionError) as e:  # ✅ Уже исправлено
        logger.warning(f"Could not create desktop shortcut: {e}")


def apply_platform_theme(app) -> None:
    """
    Apply platform-specific theme optimizations.
    
    Применяет платформенно-специфичные оптимизации темы.
    Застосовує платформенно-специфічні оптимізації теми.
    
    Args:
        app: Application instance / Экземпляр приложения / Екземпляр додатку
    """
    system = platform.system()
    
    try:
        if system == "Linux":
            from utils.helpers import apply_linux_theme
            apply_linux_theme(app)
            logger.debug("Linux theme applied")
        elif system == "Darwin":
            from utils.helpers import apply_macos_theme
            apply_macos_theme(app)
            logger.debug("macOS theme applied")
    except ImportError as e:
        logger.debug(f"Platform theme module not available: {e}")
    except (AttributeError, RuntimeError, OSError) as e:
        logger.debug(f"Platform theme error: {e}")


def run_application(startup_config: Dict[str, str]) -> int:
    """
    Run the main application (cross-platform).
    
    Запускает основное приложение (кросс-платформенно).
    Запускає основний додаток (кросплатформено).
    
    Args:
        startup_config: Startup configuration with 'lang' and 'theme'
        startup_config: Конфигурация запуска с 'lang' и 'theme'
        startup_config: Конфігурація запуску з 'lang' та 'theme'
    
    Returns:
        Exit code (0 for success, non-zero for error)
        Код завершения (0 при успехе, не ноль при ошибке)
        Код завершення (0 при успіху, не нуль при помилці)
    """
    try:
        from gui.main_window import SecurePassPro
        from security.master import MasterPassword
        import customtkinter as ctk
        from security.panic import init_panic_cleanup
        
        # Initialize panic cleanup
        try:
            init_panic_cleanup()
            logger.info("Panic cleanup initialized")
        except (ImportError, AttributeError, RuntimeError, OSError) as e:
            logger.warning(f"Panic cleanup initialization failed: {e}")
        
        # Set appearance mode
        try:
            ctk.set_appearance_mode(startup_config["theme"])
            ctk.set_default_color_theme("blue")
            logger.debug(f"Appearance mode set to: {startup_config['theme']}")
        except (ValueError, AttributeError, RuntimeError) as e:
            logger.error(f"Failed to set appearance mode: {e}")
            return 1
        
        # Apply platform-specific theme optimizations
        try:
            # Create a temporary window to apply theme
            temp_window = ctk.CTk()
            temp_window.withdraw()
            apply_platform_theme(temp_window)
            temp_window.destroy()
        except (ImportError, AttributeError, RuntimeError, OSError, ValueError, tk.TclError) as e:  # ✅ Исправлено
            logger.debug(f"Platform theme pre-application error: {e}")
        
        # Prompt for master password and start application
        try:
            if not MasterPassword.prompt_on_startup(startup_config["lang"], startup_config["theme"]):
                logger.info("Application closed by user during master password prompt")
                return 0
        except (ImportError, AttributeError, RuntimeError, OSError, ValueError) as e:
            logger.error(f"Master password prompt failed: {e}")
            return 1
        
        # Create and run application
        try:
            app = SecurePassPro()
            
            # Apply platform-specific theme to the actual app
            apply_platform_theme(app)
            
            logger.info("Application started successfully")
            
            # Try to create desktop shortcut (non-critical)
            try:
                create_desktop_shortcut()
            except (ImportError, AttributeError, OSError, RuntimeError, PermissionError) as e:
                logger.debug(f"Desktop shortcut creation skipped: {e}")
            
            app.mainloop()
            return 0
            
        except KeyboardInterrupt:
            logger.info("Application interrupted by user")
            print("\n\nSecure Pass Pro closed.")
            print("\n\nSecure Pass Pro закрыт.")
            print("\n\nSecure Pass Pro закрито.")
            return 0
        except (RuntimeError, AttributeError, OSError, ImportError) as e:
            logger.exception(f"Application runtime error: {e}")
            return 1
            
    except ImportError as e:
        logger.critical(f"Failed to import application modules: {e}")
        return 1
    except (AttributeError, RuntimeError, OSError, ValueError) as e:
        logger.critical(f"Application initialization error: {e}")
        return 1


def main() -> int:
    """
    Main entry point (cross-platform).
    
    Главная точка входа (кросс-платформенно).
    Головна точка входу (кросплатформено).
    
    Returns:
        Exit code / Код завершения / Код завершення
    """
    # Setup early environment
    try:
        setup_early_environment()
    except (RuntimeError, OSError, AttributeError) as e:
        print(f"Warning: Early environment setup failed: {e}")
    
    # Check Python version
    if not check_python_version():
        return 1
    
    # Check dependencies
    if not check_dependencies():
        return 1
    
    # Load startup configuration
    try:
        startup_config = get_startup_config()
    except (OSError, IOError, json.JSONDecodeError, KeyError, ValueError) as e:
        logger.error(f"Failed to load startup config: {e}, using defaults")
        startup_config = {"lang": "RU", "theme": "dark"}
    
    # Run application
    exit_code = run_application(startup_config)
    
    # Final cleanup
    try:
        logger.info(f"Application exiting with code: {exit_code}")
    except (NameError, RuntimeError):
        pass
    
    return exit_code


if __name__ == "__main__":
    sys.exit(main())