#!/usr/bin/env python3
"""
Secure Pass Pro v4.0 - Главный файл запуска

Особенности:
- Автоматическое определение платформы (Windows/Linux/macOS)
- Обработка ошибок импорта
- Настройка окружения перед запуском
- Поддержка PyInstaller (замороженный режим)
- Оптимизация для разных ОС
"""

import sys
import os
import platform


def setup_environment():
    """Настройка окружения перед запуском"""
    
    # Добавляем текущую папку в путь поиска модулей
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if current_dir not in sys.path:
        sys.path.insert(0, current_dir)
    
    # Настройка для PyInstaller (замороженное приложение)
    if getattr(sys, 'frozen', False):
        # При запуске из .exe
        application_path = os.path.dirname(sys.executable)
        os.chdir(application_path)
    else:
        # При запуске из скрипта
        application_path = current_dir
    
    # Настройка для разных ОС
    system = platform.system()
    
    if system == "Windows":
        # Windows: настройка DPI для высокого разрешения
        try:
            import ctypes
            ctypes.windll.user32.SetProcessDPIAware()
        except (AttributeError, ImportError, OSError):
            pass
    
    elif system == "Linux":
        # Linux: настройка для Wayland и HiDPI
        if 'WAYLAND_DISPLAY' in os.environ:
            os.environ['GDK_BACKEND'] = 'wayland'
        # Для HiDPI дисплеев
        if 'GDK_SCALE' not in os.environ:
            os.environ['GDK_SCALE'] = '1'
    
    elif system == "Darwin":
        # macOS: настройка для retina дисплеев
        os.environ['NSHighResolutionCapable'] = 'True'
    
    return application_path


def check_dependencies():
    """Проверяет наличие необходимых зависимостей"""
    missing = []
    
    required = [
        ('customtkinter', 'customtkinter'),
        ('PIL', 'Pillow'),
        ('cryptography', 'cryptography'),
        ('argon2', 'argon2-cffi'),
    ]
    
    optional = [
        ('sqlcipher3', 'sqlcipher3'),
        ('qrcode', 'qrcode'),
        ('fpdf', 'fpdf'),
        ('requests', 'requests'),
    ]
    
    for module, name in required:
        try:
            __import__(module)
        except ImportError:
            missing.append(name)
    
    if missing:
        print(f"Warning: Missing required modules: {', '.join(missing)}")
        print("Install: pip install " + " ".join(missing))
        return False
    
    # Проверяем опциональные модули (только предупреждение)
    optional_missing = []
    for module, name in optional:
        try:
            __import__(module)
        except ImportError:
            optional_missing.append(name)
    
    if optional_missing:
        print(f"Info: Optional modules not installed: {', '.join(optional_missing)}")
        print("  Some features may be unavailable")
    
    return True


def setup_logging():
    """Настройка логирования"""
    try:
        from utils.logger import get_logger
        logger = get_logger("launcher")
        logger.info("=" * 50)
        logger.info("Secure Pass Pro v4.0 starting")
        logger.info(f"Python version: {sys.version}")
        logger.info(f"Platform: {platform.system()} {platform.release()}")
        logger.info(f"Frozen: {getattr(sys, 'frozen', False)}")
        logger.info("=" * 50)
        return logger
    except ImportError as e:
        print(f"Warning: Logger not available: {e}")
        return None


def show_splash_screen():
    """Показывает заставку при запуске (опционально)"""
    # Можно реализовать splash screen если нужно
    pass


def main():
    """Главная функция запуска"""
    
    # Настройка окружения
    app_path = setup_environment()
    
    # Настройка логирования
    logger = setup_logging()
    
    # Проверка зависимостей
    if not check_dependencies():
        if logger:
            logger.error("Missing dependencies")
        print("Error: missing required dependencies")
        print("Run: pip install -r requirements.txt")
        input("Press Enter to exit...")
        sys.exit(1)
    
    # Импорт после проверки зависимостей
    try:
        import customtkinter as ctk
    except ImportError as e:
        print(f"Error importing customtkinter: {e}")
        print("Install: pip install customtkinter")
        input("Press Enter to exit...")
        sys.exit(1)
    
    # Настройка темы
    ctk.set_appearance_mode("System")
    ctk.set_default_color_theme("blue")
    
    # Настройка масштабирования для разных ОС
    if platform.system() == "Linux":
        try:
            from utils.helpers import get_system_scaling
            scaling = get_system_scaling()
            if scaling > 1.0:
                ctk.set_widget_scaling(scaling)
                ctk.set_window_scaling(scaling)
        except ImportError:
            pass
    
    # Импорт главного окна
    try:
        from gui.main_window import SecurePassPro
        from security.master import MasterPassword
        from security.panic import init_panic_cleanup
    except ImportError as e:
        print(f"Error importing modules: {e}")
        print("Make sure all files are in place")
        if logger:
            logger.error(f"Import error: {e}")
        input("Press Enter to exit...")
        sys.exit(1)
    
    # Инициализация panic cleanup
    try:
        init_panic_cleanup()
    except Exception as e:
        print(f"Warning: Panic cleanup init error: {e}")
    
    # Определение языка и темы для стартового окна
    startup_lang = "RU"
    startup_theme = "dark"
    
    try:
        from utils.paths import get_config_file
        import json
        
        config_file = get_config_file()
        if os.path.exists(config_file):
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
            if "LANG" in config and config["LANG"] in ("RU", "EN", "UA"):
                startup_lang = config["LANG"]
            if "THEME" in config:
                if config["THEME"] == "Light":
                    startup_theme = "light"
                elif config["THEME"] == "Dark":
                    startup_theme = "dark"
    except Exception as e:
        if logger:
            logger.debug(f"Config read on startup: {e}")
    
    # Запрос мастер-пароля
    if not MasterPassword.prompt_on_startup(startup_lang, startup_theme):
        if logger:
            logger.info("User cancelled master password, exiting")
        sys.exit(0)
    
    # Запуск приложения
    try:
        if logger:
            logger.info("Starting main application window")
        
        app = SecurePassPro()
        app.mainloop()
        
    except KeyboardInterrupt:
        if logger:
            logger.info("Application terminated by user")
        print("\nProgram terminated")
    except Exception as e:
        print(f"Fatal error: {e}")
        if logger:
            logger.critical(f"Fatal error: {e}", exc_info=True)
        
        # Показываем сообщение об ошибке
        try:
            from gui.dialogs import CTkMessageBox
            root = ctk.CTk()
            root.withdraw()
            CTkMessageBox.error(None, "Fatal error", 
                               f"An error occurred during startup:\n\n{str(e)}\n\n"
                               "Check the securepasspro.log file")
            root.destroy()
        except Exception:
            pass
        
        input("Press Enter to exit...")
        sys.exit(1)
    finally:
        if logger:
            logger.info("Application shutdown complete")


if __name__ == "__main__":
    main()