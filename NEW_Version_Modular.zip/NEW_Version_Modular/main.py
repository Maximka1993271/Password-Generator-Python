#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Secure Pass Pro v4.0 — Cryptographically secure password generator
Author: Maxim Melnikov

Secure Pass Pro v4.0 — Криптографически безопасный генератор паролей
Secure Pass Pro v4.0 — Криптографічно безпечний генератор паролів
"""

import sys
import os
import json
import traceback
import platform
from typing import Optional, Dict, Any

# Setup logging early / Настройка логирования / Налаштування логування
from utils.logger import get_logger, log_crash_report
logger = get_logger("launcher")

# Anti-debugging protection (must be early) / Анти-отладочная защита / Анти-відлагоджувальний захист
try:
    from security.antidebug import init_anti_debug
    init_anti_debug()
    logger.debug("Anti-debugging initialized")
except ImportError as e:
    logger.warning(f"Anti-debug module not available: {e}")
except (AttributeError, RuntimeError, OSError) as e:
    logger.error(f"Anti-debug error: {e}")

# Add current directory to path for imports / Добавляем текущую директорию в путь / Додаємо поточну директорію до шляху
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def get_startup_config() -> Dict[str, str]:
    """
    Load startup configuration from config file.
    
    Загружает конфигурацию запуска из файла конфигурации.
    Завантажує конфігурацію запуску з файлу конфігурації.
    
    Returns:
        Dictionary with 'lang' and 'theme' keys
        Словарь с ключами 'lang' и 'theme'
        Словник з ключами 'lang' та 'theme'
    """
    config = {"lang": "RU", "theme": "dark"}
    
    try:
        from utils.paths import get_config_file
        config_file = get_config_file()
        
        if os.path.exists(config_file):
            with open(config_file, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            
            if cfg.get("LANG") in ("RU", "EN", "UA"):
                config["lang"] = cfg["LANG"]
            
            if cfg.get("THEME") == "Light":
                config["theme"] = "light"
            elif cfg.get("THEME") == "Dark":
                config["theme"] = "dark"
                
            logger.info(f"Loaded startup config: lang={config['lang']}, theme={config['theme']}")
    except json.JSONDecodeError as e:
        logger.error(f"Config JSON decode error: {e}")
        # Use defaults / Используем значения по умолчанию / Використовуємо значення за замовчуванням
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Config file read error: {e}")
        # Use defaults / Используем значения по умолчанию / Використовуємо значення за замовчуванням
    except (KeyError, ValueError, TypeError) as e:
        logger.error(f"Config parsing error: {e}")
        # Use defaults / Используем значения по умолчанию / Використовуємо значення за замовчуванням
    
    return config


def setup_early_environment() -> None:
    """
    Setup early environment settings.
    
    Настраивает ранние параметры окружения.
    Налаштовує ранні параметри середовища.
    """
    # Set higher recursion limit for deep UI trees
    # Устанавливаем более высокий лимит рекурсии для глубоких UI деревьев
    # Встановлюємо вищий ліміт рекурсії для глибоких UI дерев
    try:
        sys.setrecursionlimit(10000)
    except (ValueError, RuntimeError) as e:
        logger.debug(f"Failed to set recursion limit: {e}")
    
    # Set up Windows-specific console
    # Настройка консоли для Windows
    # Налаштування консолі для Windows
    if platform.system() == "Windows":
        try:
            import ctypes
            # Enable ANSI support in Windows console
            # Включение поддержки ANSI в консоли Windows
            # Ввімкнення підтримки ANSI в консолі Windows
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
        except (AttributeError, OSError, TypeError, ImportError) as e:
            logger.debug(f"Windows console setup error: {e}")


def check_python_version() -> bool:
    """
    Check Python version compatibility.
    
    Проверка совместимости версии Python.
    Перевірка сумісності версії Python.
    
    Returns:
        True if version is compatible, False otherwise
        True если версия совместима, False если нет
        True якщо версія сумісна, False якщо ні
    """
    if sys.version_info < (3, 8):
        error_msg = (
            "Secure Pass Pro requires Python 3.8 or higher!\n"
            "Secure Pass Pro требует Python 3.8 или выше!\n"
            "Secure Pass Pro вимагає Python 3.8 або вище!"
        )
        print(error_msg)
        logger.critical(error_msg)
        return False
    return True


def check_dependencies() -> bool:
    """
    Check required dependencies.
    
    Проверка необходимых зависимостей.
    Перевірка необхідних залежностей.
    
    Returns:
        True if all dependencies are available, False otherwise
        True если все зависимости доступны, False если нет
        True якщо всі залежності доступні, False якщо ні
    """
    missing = []
    
    # Critical dependencies / Критические зависимости / Критичні залежності
    critical = [
        ('customtkinter', 'customtkinter'),
        ('PIL', 'Pillow'),
        ('cryptography', 'cryptography'),
    ]
    
    for module, package in critical:
        try:
            __import__(module)
        except ImportError as e:
            missing.append(package)
            logger.debug(f"Missing dependency: {package} - {e}")
    
    if missing:
        print("=" * 50)
        print("Secure Pass Pro - Missing Dependencies")
        print("=" * 50)
        print("\nThe following packages are required:\n")
        for pkg in missing:
            print(f"   - {pkg}")
        print("\nInstall with:")
        print(f"   pip install {' '.join(missing)}")
        print("\n" + "=" * 50)
        logger.error(f"Missing dependencies: {missing}")
        return False
    
    logger.info("All dependencies are available")
    return True


def create_desktop_shortcut() -> None:
    """
    Create desktop shortcut (Windows only).
    
    Создать ярлык на рабочем столе (только Windows).
    Створити ярлик на робочому столі (тільки Windows).
    """
    if platform.system() != "Windows":
        return
    
    try:
        import winshell
        from win32com.client import Dispatch
        
        desktop = winshell.desktop()
        path = os.path.join(desktop, "Secure Pass Pro.lnk")
        
        if os.path.exists(path):
            return
        
        shell = Dispatch('WScript.Shell')
        shortcut = shell.CreateShortCut(path)
        shortcut.Targetpath = sys.executable
        shortcut.WorkingDirectory = os.path.dirname(sys.executable)
        shortcut.IconLocation = sys.executable
        shortcut.save()
        
        print("Desktop shortcut created successfully")
        print("Ярлык на рабочем столе успешно создан")
        print("Ярлик на робочому столі успішно створено")
        logger.info("Desktop shortcut created")
    except ImportError as e:
        logger.debug(f"Desktop shortcut modules not available: {e}")
    except (AttributeError, OSError, RuntimeError, TypeError) as e:
        logger.warning(f"Could not create desktop shortcut: {e}")


def run_application(startup_config: Dict[str, str]) -> int:
    """
    Run the main application.
    
    Запускает основное приложение.
    Запускає основний додаток.
    
    Args:
        startup_config: Startup configuration with 'lang' and 'theme'
        startup_config: Конфигурация запуска с 'lang' и 'theme'
        startup_config: Конфігурація запуску з 'lang' та 'theme'
    
    Returns:
        Exit code (0 for success, non-zero for error)
        Код завершения (0 при успехе, не ноль при ошибке)
        Код завершення (0 при успіху, не нуль при помилці)
    """
    try:
        from gui.main_window import SecurePassPro
        from security.master import MasterPassword
        import customtkinter as ctk
        from security.panic import init_panic_cleanup
        
        # Initialize panic cleanup / Инициализация аварийной очистки / Ініціалізація аварійного очищення
        try:
            init_panic_cleanup()
            logger.info("Panic cleanup initialized")
        except (ImportError, AttributeError, RuntimeError, OSError) as e:
            logger.warning(f"Panic cleanup initialization failed: {e}")
        
        # Set appearance mode / Установка режима отображения / Встановлення режиму відображення
        try:
            ctk.set_appearance_mode(startup_config["theme"])
            ctk.set_default_color_theme("blue")
            logger.debug(f"Appearance mode set to: {startup_config['theme']}")
        except (ValueError, AttributeError, RuntimeError) as e:
            logger.error(f"Failed to set appearance mode: {e}")
            return 1
        
        # Prompt for master password and start application
        # Запрос мастер-пароля и запуск приложения
        # Запит майстер-пароля та запуск програми
        try:
            if not MasterPassword.prompt_on_startup(startup_config["lang"], startup_config["theme"]):
                logger.info("Application closed by user during master password prompt")
                return 0
        except (ImportError, AttributeError, RuntimeError, OSError, ValueError) as e:
            logger.error(f"Master password prompt failed: {e}")
            return 1
        
        # Create and run application / Создание и запуск приложения / Створення та запуск програми
        try:
            app = SecurePassPro()
            logger.info("Application started successfully")
            
            # Try to create desktop shortcut (non-critical) / Пытаемся создать ярлык (не критично) / Намагаємося створити ярлик (не критично)
            try:
                create_desktop_shortcut()
            except (ImportError, AttributeError, OSError, RuntimeError) as e:
                logger.debug(f"Desktop shortcut creation skipped: {e}")
            
            app.mainloop()
            return 0
            
        except KeyboardInterrupt:
            logger.info("Application interrupted by user")
            print("\n\nSecure Pass Pro closed.")
            print("\n\nSecure Pass Pro закрыт.")
            print("\n\nSecure Pass Pro закрито.")
            return 0
        except (RuntimeError, AttributeError, OSError, ImportError) as e:
            logger.exception(f"Application runtime error: {e}")
            return 1
            
    except ImportError as e:
        logger.critical(f"Failed to import application modules: {e}")
        return 1
    except (AttributeError, RuntimeError, OSError, ValueError) as e:
        logger.critical(f"Application initialization error: {e}")
        return 1


def main() -> int:
    """
    Main entry point.
    
    Главная точка входа.
    Головна точка входу.
    
    Returns:
        Exit code / Код завершения / Код завершення
    """
    # Setup early environment / Настройка раннего окружения / Налаштування раннього середовища
    try:
        setup_early_environment()
    except (RuntimeError, OSError, AttributeError) as e:
        print(f"Warning: Early environment setup failed: {e}")
    
    # Check Python version / Проверка версии Python / Перевірка версії Python
    if not check_python_version():
        return 1
    
    # Check dependencies / Проверка зависимостей / Перевірка залежностей
    if not check_dependencies():
        return 1
    
    # Load startup configuration / Загрузка конфигурации запуску / Завантаження конфігурації запуску
    try:
        startup_config = get_startup_config()
    except (OSError, IOError, json.JSONDecodeError, KeyError, ValueError) as e:
        logger.error(f"Failed to load startup config: {e}, using defaults")
        startup_config = {"lang": "RU", "theme": "dark"}
    
    # Run application / Запуск приложения / Запуск додатку
    exit_code = run_application(startup_config)
    
    # Final cleanup / Финальная очистка / Фінальне очищення
    try:
        logger.info(f"Application exiting with code: {exit_code}")
    except (NameError, RuntimeError):
        pass
    
    return exit_code


if __name__ == "__main__":
    sys.exit(main())