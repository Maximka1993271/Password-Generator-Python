"""
Main application window
Главное окно приложения
Головне вікно програми
"""
from __future__ import annotations
from collections import deque
import os
import sys
import json
import time
import tkinter as tk
import webbrowser
from typing import Optional, Dict, Any

import customtkinter as ctk

from core.generator import PasswordGenerator, StrengthCalculator
from security.master import MasterPassword
from security.encryption import clear_master_key, reencrypt_all, set_key_from_master
from security.panic import PanicCleanup
from storage.database import PasswordDB
from storage.config import Config
from localization.lang import LANGUAGES
from gui.dialogs import CTkMessageBox, CTkInputDialog
from gui.widgets import ToolTip
from utils.helpers import (
    get_global_radius, set_global_radius, center_screen,
    get_resource_path, play_sound, is_windows, is_macos, is_linux,
    apply_window_rounding, set_window_icon, apply_linux_theme, get_system_scaling
)
from utils.paths import get_base_dir, get_config_dir, get_config_file
from utils.logger import get_logger
from utils.radius_manager import register_window

# Import for 2FA / Импорт для 2FA / Імпорт для 2FA
from security.totp import init_totp_from_config, save_totp_to_config, get_totp_manager
from utils.qr_utils import QRUtils

logger = get_logger("main_window")

# Import mixin groups / Импорт групп миксинов / Імпорт груп міксинів
from gui.mixins import UIMixins, SecurityMixins, OpsMixins, VisualMixins

HISTORY_MAX = 50
UPD_URL = "https://github.com/Maximka1993271/Password-Generator-Python/releases"

BASE_DIR = get_base_dir()
CONFIG_DIR = get_config_dir()
CONFIG_FILE = get_config_file()


class SecurePassPro(
    UIMixins,      # UI settings / UI настройки / UI налаштування
    SecurityMixins, # Security / Безопасность / Безпека
    OpsMixins,      # Operations / Операции / Операції
    VisualMixins,   # Visual effects / Визуальные эффекты / Візуальні ефекти
    ctk.CTk
):
    """Main application window / Главное окно приложения / Головне вікно програми"""

    def __init__(self) -> None:
        super().__init__()

        # Settings / Настройки / Налаштування
        self.current_lang = "RU"
        self.current_theme = "Dark"
        self.current_radius = 25
        self.current_font_size = 14
        self.clipboard_timeout = 60
        self._clipboard_timer: Optional[str] = None
        self._rgb_anim_id: Optional[str] = None
        self._pulse_animation_id: Optional[str] = None
        self._suspend_check_id: Optional[str] = None
        self._minimize_check_id: Optional[str] = None
        self._lock_check_timer: Optional[str] = None

        # RGB Speed and Width settings / Настройки скорости и толщины RGB / Налаштування швидкості та товщини RGB
        self.rgb_speed_setting = "normal"
        self.rgb_width_setting = "normal"

        # Auto-lock / Автоблокировка / Автоблокування
        self.auto_lock_enabled = tk.BooleanVar(value=False)
        self.auto_lock_timeout = 5
        self._last_activity_time = time.time()
        self._lock_check_id: Optional[str] = None
        self._was_minimized = False
        self._last_lock_state = False

        self._radius_timer = None
        self._clip_timer = None
        self._auto_timer = None
        self._font_timer = None

        set_global_radius(self.current_radius)

        # ========== LINUX ADAPTATION / ЛИНУКС АДАПТАЦИЯ / АДАПТАЦІЯ ДЛЯ LINUX ==========
        if is_linux():
            apply_linux_theme(self)
            scaling = get_system_scaling()
            if scaling > 1.0:
                ctk.set_widget_scaling(scaling)
                ctk.set_window_scaling(scaling)
        # ==========================================================

        # UI Variables / Переменные интерфейса / Змінні інтерфейсу
        self.upper_var = tk.BooleanVar(value=False)
        self.lower_var = tk.BooleanVar(value=False)
        self.digits_var = tk.BooleanVar(value=False)
        self.symb_var = tk.BooleanVar(value=False)
        self.ambig_var = tk.BooleanVar(value=False)
        self.unambig_var = tk.BooleanVar(value=False)
        self.at_least_var = tk.BooleanVar(value=False)
        self.hide_var = tk.BooleanVar(value=False)
        self.no_repeat_var = tk.BooleanVar(value=False)
        self.sound_enabled = tk.BooleanVar(value=True)
        self.rgb_enabled = tk.BooleanVar(value=True)

        self.history: deque = deque(maxlen=HISTORY_MAX)
        self._rgb_t = 0.0

        # Windows / Окна / Вікна
        self.settings_window: Optional[ctk.CTkToplevel] = None
        self.about_window: Optional[ctk.CTkToplevel] = None
        self.history_window: Optional[ctk.CTkToplevel] = None
        self.qr_window: Optional[ctk.CTkToplevel] = None
        self.db_window: Optional[ctk.CTkToplevel] = None

        # Widget references / Ссылки на виджеты / Посилання на віджети
        self._tooltips: Dict[str, ToolTip] = {}
        self.lang_buttons: Dict[str, ctk.CTkButton] = {}
        self.theme_buttons: Dict[str, ctk.CTkButton] = {}
        self.settings_labels: Dict[str, Any] = {}
        self._master_set_btn: Optional[ctk.CTkButton] = None
        self._master_status_label: Optional[ctk.CTkLabel] = None
        self._sound_btn: Optional[ctk.CTkButton] = None
        self._close_btn: Optional[ctk.CTkButton] = None
        self._clip_timeout_label_ref: Optional[ctk.CTkLabel] = None
        self._rgb_on_btn_ref: Optional[ctk.CTkButton] = None
        self._rgb_off_btn_ref: Optional[ctk.CTkButton] = None
        self._auto_lock_btn: Optional[ctk.CTkButton] = None
        self._auto_lock_slider: Optional[ctk.CTkSlider] = None
        self._auto_lock_label_ref: Optional[ctk.CTkLabel] = None
        self.auto_save_btn: Optional[ctk.CTkButton] = None
        self.auto_save_var = tk.BooleanVar(value=False)

        # 2FA elements / Элементы 2FA / Елементи 2FA
        self._2fa_status_label: Optional[ctk.CTkLabel] = None
        self._2fa_settings_btn: Optional[ctk.CTkButton] = None

        # RGB canvases / Холсты RGB / Полотна RGB
        self._rgb_c_top: Optional[tk.Canvas] = None
        self._rgb_c_bottom: Optional[tk.Canvas] = None
        self._rgb_c_left: Optional[tk.Canvas] = None
        self._rgb_c_right: Optional[tk.Canvas] = None

        self._icon_image: Optional[tk.PhotoImage] = None
        self._pdf_font_path = get_resource_path("DejaVuSans.ttf")

        # Initialize password generator / Инициализация генератора паролей / Ініціалізація генератора паролів
        self.generator = PasswordGenerator()
        self.strength_calc = StrengthCalculator()
        self.config = Config()

        # Initialize 2FA / Инициализация 2FA / Ініціалізація 2FA
        init_totp_from_config(self.config)
        MasterPassword.set_config(self.config)
        
        if not QRUtils.is_available():
            logger.warning("QR code module not available. 2FA setup will show text only.")
            # QR code module not available / Модуль QR-кода не доступен / Модуль QR-коду не доступний

        # Setup UI / Настройка интерфейса / Налаштування інтерфейсу
        ctk.set_widget_scaling(1.0)
        ctk.set_window_scaling(1.0)

        self.title("Secure Pass Pro v4.0")
        
        # ==================== WINDOW SETTINGS / НАСТРОЙКИ ОКНА / НАЛАШТУВАННЯ ВІКНА ====================
        # Allow minimize and resize / Разрешаем сворачивание и изменение размера / Дозволяємо згортання та зміну розміру
        self.resizable(True, True)
        self.minsize(800, 650)
        self.geometry("950x800")
        set_window_icon(self)
        # ========================================================

        self._create_rgb_canvases()
        self._setup_ui()
        self._apply_lang("RU")
        self._center_main_window()
        apply_window_rounding(self)

        # Bind keys / Привязка клавиш / Прив'язка клавіш
        self.bind('<F5>', lambda e: self._generate())
        self.bind('<Control-c>', lambda e: self._copy() if self.focus_get() is not self.entry_res else None)
        self.bind('<Control-s>', lambda e: self._save())
        self.bind('<Control-o>', lambda e: self._open())
        self.bind('<Escape>', lambda e: self._close_settings() if self.settings_window else None)

        # Activity tracking for auto-lock / Отслеживание активности для автоблокировки / Відстеження активності для автоблокування
        self.bind_all('<Key>', self._reset_activity_timer)
        self.bind_all('<Button>', self._reset_activity_timer)
        self.bind_all('<Motion>', self._reset_activity_timer)

        # Load settings AFTER UI is created / Загружаем настройки ПОСЛЕ создания интерфейсу / Завантажуємо налаштування ПІСЛЯ створення інтерфейсу
        self.after(50, self._load_all_settings)
        self.after(100, self._start_lock_checker)
        self.protocol("WM_DELETE_WINDOW", self._on_closing)

        # Register panic cleanup / Регистрируем аварийную очистку / Реєструємо аварійне очищення
        PanicCleanup.register_clipboard_cleanup(self._emergency_clipboard_clear)
        PanicCleanup.register_cleanup_callback(self._emergency_cleanup)

        # Register main window for radius updates / Регистрируем главное окно для обновления радиуса / Реєструємо головне вікно для оновлення радіусу
        register_window(self)

    def _emergency_clipboard_clear(self) -> None:
        """Emergency clipboard clear on crash / Аварийная очистка буфера обмена / Аварійне очищення буфера обміну"""
        try:
            self.clipboard_clear()
            for _ in range(3):
                self.clipboard_append(" " * 64)
                self.update()
                self.clipboard_clear()
                self.update()
        except (tk.TclError, OSError, AttributeError) as e:
            logger.debug(f"Emergency clipboard clear error: {e}")

    def _emergency_cleanup(self) -> None:
        """Emergency cleanup on crash / Аварийная очистка / Аварійне очищення"""
        self._stop_rgb()
        try:
            PasswordDB.close_all_connections()
        except (ImportError, AttributeError, OSError) as e:
            logger.debug(f"Emergency cleanup error: {e}")

    def _load_all_settings(self) -> None:
        """Load all settings from config file
        Загрузить все настройки из файла конфигурации
        Завантажити всі налаштування з файлу конфігурації"""
        default_config = {
            "THEME": "Dark",
            "LANG": "RU",
            "SOUND": True,
            "RGB": True,
            "RGB_SPEED": "normal",
            "RGB_WIDTH": "normal",
            "RADIUS": 25,
            "font_size": 14,
            "CLIP_TIMEOUT": 60,
            "AUTO_LOCK": False,
            "AUTO_LOCK_TIMEOUT": 5,
            "auto_save": False
        }

        need_save = False

        if not os.path.exists(CONFIG_FILE):
            need_save = True
            config = default_config.copy()
        else:
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    config = json.load(f)
                for key in default_config:
                    if key not in config:
                        config[key] = default_config[key]
                        need_save = True
            except json.JSONDecodeError as e:
                logger.error(f"JSON decode error: {e}, using defaults")
                config = default_config.copy()
                need_save = True
            except PermissionError as e:
                logger.error(f"Permission error reading config: {e}, using defaults")
                config = default_config.copy()
                need_save = True
            except OSError as e:
                logger.error(f"OS error reading config: {e}, using defaults")
                config = default_config.copy()
                need_save = True

        if need_save:
            try:
                os.makedirs(CONFIG_DIR, exist_ok=True)
                with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                    json.dump(config, f, indent=2, ensure_ascii=False)
            except PermissionError as e:
                logger.error(f"Cannot save config (permission): {e}")
            except OSError as e:
                logger.error(f"Cannot save config (OS error): {e}")

        self.config.update(config)

        self.current_theme = config.get("THEME", "Dark")
        self.current_lang = config.get("LANG", "RU")
        self.sound_enabled.set(config.get("SOUND", True))
        self.rgb_enabled.set(config.get("RGB", True))

        self.rgb_speed_setting = config.get("RGB_SPEED", "normal")
        if self.rgb_speed_setting not in ["slow", "normal", "fast"]:
            self.rgb_speed_setting = "normal"

        self.rgb_width_setting = config.get("RGB_WIDTH", "normal")
        if self.rgb_width_setting not in ["thin", "normal", "thick"]:
            self.rgb_width_setting = "normal"

        self.current_radius = config.get("RADIUS", 25)
        self.current_font_size = config.get("font_size", 14)
        self.clipboard_timeout = config.get("CLIP_TIMEOUT", 60)
        self.auto_lock_enabled.set(config.get("AUTO_LOCK", False))
        self.auto_lock_timeout = config.get("AUTO_LOCK_TIMEOUT", 5)
        self.auto_save_var.set(config.get("auto_save", False))

        set_global_radius(self.current_radius)
        self._change_radius(self.current_radius)
        self._apply_font_size(self.current_font_size)

        actual_theme = self._get_actual_theme()
        ctk.set_appearance_mode(self.current_theme)
        self.after(50, lambda: self._apply_theme_colors(actual_theme))
        self.after(60, lambda: self.configure(fg_color="#F3F3F3" if actual_theme == "light" else "#1d1e1e"))

        if self.rgb_enabled.get():
            self.after(200, self._start_rgb)

        self._update_master_status_label()
        self._update_auto_lock_label()
        self._update_rgb_speed_buttons()
        self._update_rgb_width_buttons()

        self._update_2fa_status_in_settings()

        self._apply_lang(self.current_lang)

    def _update_2fa_status_in_settings(self) -> None:
        """Update 2FA status in settings window if open
        Обновляет статус 2FA в окне настроек если оно открыто
        Оновлює статус 2FA у вікні налаштувань якщо воно відкрите"""
        if hasattr(self, 'settings_window') and self.settings_window and self.settings_window.winfo_exists():
            if hasattr(self, '_2fa_status_label') and self._2fa_status_label:
                try:
                    self._2fa_status_label.configure(
                        text=self._get_2fa_status_text(),
                        text_color=self._get_2fa_status_color()
                    )
                except (tk.TclError, AttributeError) as e:
                    logger.debug(f"Update 2FA status error: {e}")

    def _get_2fa_status_text(self) -> str:
        L = LANGUAGES[self.current_lang]
        if self.config.is_2fa_enabled():
            return L.get("2fa_status_enabled", "Enabled")
        else:
            return L.get("2fa_status_disabled", "Disabled")

    def _get_2fa_status_color(self) -> str:
        if self.config.is_2fa_enabled():
            return "#2ECC71"
        else:
            return "#888888"

    def _update_2fa_buttons(self) -> None:
        self._update_2fa_status_in_settings()

    def _on_closing(self) -> None:
        """Close application with resource cleanup
        Закрытие приложения с очисткой ресурсов
        Закриття програми з очищенням ресурсів"""
        self._stop_rgb()
        self._emergency_clipboard_clear()

        for timer in [self._pulse_animation_id, self._clipboard_timer,
                      self._lock_check_id, self._suspend_check_id, self._minimize_check_id]:
            if timer:
                try:
                    self.after_cancel(timer)
                except (tk.TclError, ValueError) as e:
                    logger.debug(f"Cancel timer error: {e}")

        try:
            PasswordDB.close_all_connections()
        except (ImportError, AttributeError, OSError) as e:
            logger.debug(f"DB close error: {e}")

        for win_attr in ("settings_window", "about_window", "history_window", "qr_window", "db_window"):
            win = getattr(self, win_attr, None)
            if win is not None:
                try:
                    win.destroy()
                except tk.TclError as e:
                    logger.debug(f"Window destroy error for {win_attr}: {e}")

        self.quit()
        self.destroy()
        sys.exit(0)


# ==================== ENTRY POINT / ТОЧКА ВХОДА / ТОЧКА ВХОДУ ====================
if __name__ == "__main__":
    ctk.set_appearance_mode("System")
    ctk.set_default_color_theme("blue")

    _startup_lang = "RU"
    _startup_theme = "dark"

    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as _f:
                try:
                    _cfg = json.load(_f)
                except json.JSONDecodeError:
                    _cfg = {}
                if "LANG" in _cfg and _cfg["LANG"] in ("RU", "EN", "UA"):
                    _startup_lang = _cfg["LANG"]
                if "THEME" in _cfg:
                    if _cfg["THEME"] == "Light":
                        _startup_theme = "light"
                    elif _cfg["THEME"] == "Dark":
                        _startup_theme = "dark"
    except (OSError, IOError, PermissionError) as e:
        logger.debug(f"Error reading config on startup: {e}")

    from security.panic import init_panic_cleanup
    init_panic_cleanup()

    if not MasterPassword.prompt_on_startup(_startup_lang, _startup_theme):
        sys.exit(0)

    app = SecurePassPro()
    app.mainloop()