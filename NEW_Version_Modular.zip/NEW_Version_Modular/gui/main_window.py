"""
Main application window
"""
from __future__ import annotations
from collections import deque
import os
import sys
import json
import math
import time
import ctypes
import tempfile
import tkinter as tk
import webbrowser
from typing import Optional, Dict, Any, List

import customtkinter as ctk

from core.generator import PasswordGenerator, StrengthCalculator
from security.master import MasterPassword
from security.encryption import clear_master_key, reencrypt_all, set_key_from_master
from storage.database import PasswordDB
from storage.config import Config
from localization.lang import LANGUAGES
from gui.dialogs import CTkMessageBox, CTkInputDialog
from gui.widgets import ToolTip
from utils.helpers import (
    get_global_radius, set_global_radius, center_screen,
    get_resource_path, play_sound, is_windows, is_macos, is_linux,
    apply_window_rounding, set_window_icon
)
from utils.paths import get_base_dir, get_config_dir, get_config_file

# Import all mixins
from gui.mixins import (
    RGBMixin,
    AutoLockMixin,
    PasswordOpsMixin,
    MasterMixin,
    SettingsMixin,
    SettingsWindowMixin,
    DialogsMixin,
    HIBPMixin,
    UISetupMixin
)

# ==================== CONSTANTS & PORTABLE LOGIC ====================
HISTORY_MAX = 50
UPD_URL = "https://github.com/Maximka1993271/Password-Generator-Python/releases"

BASE_DIR = get_base_dir()
CONFIG_DIR = get_config_dir()
CONFIG_FILE = get_config_file()

OLD_CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".securepasspro")
if os.path.exists(OLD_CONFIG_DIR):
    print(f"[Cleanup] Old config folder left untouched: {OLD_CONFIG_DIR}")
# =====================================================================


class SecurePassPro(
    RGBMixin,
    AutoLockMixin,
    PasswordOpsMixin,
    MasterMixin,
    SettingsMixin,
    SettingsWindowMixin,
    DialogsMixin,
    HIBPMixin,
    UISetupMixin,
    ctk.CTk
):
    """Main application window"""
    
    def __init__(self) -> None:
        super().__init__()
        
        # Settings
        self.current_lang = "RU"
        self.current_theme = "Dark"
        self.current_radius = 25
        self.current_font_size = 14
        self.clipboard_timeout = 60
        self._clipboard_timer: Optional[str] = None
        self._rgb_anim_id: Optional[str] = None
        self._pulse_animation_id: Optional[str] = None
        
        # Auto-lock
        self.auto_lock_enabled = tk.BooleanVar(value=False)
        self.auto_lock_timeout = 5
        self._last_activity_time = time.time()
        self._lock_check_id: Optional[str] = None
        
        # Таймеры для плавных слайдеров
        self._radius_timer = None
        self._clip_timer = None
        self._auto_timer = None
        self._font_timer = None
        
        set_global_radius(self.current_radius)
        
        # UI Variables
        self.upper_var = tk.BooleanVar(value=False)
        self.lower_var = tk.BooleanVar(value=False)
        self.digits_var = tk.BooleanVar(value=False)
        self.symb_var = tk.BooleanVar(value=False)
        self.ambig_var = tk.BooleanVar(value=False)
        self.unambig_var = tk.BooleanVar(value=False)
        self.at_least_var = tk.BooleanVar(value=False)
        self.hide_var = tk.BooleanVar(value=False)
        self.no_repeat_var = tk.BooleanVar(value=False)
        self.sound_enabled = tk.BooleanVar(value=True)
        self.rgb_enabled = tk.BooleanVar(value=True)
        
        self.history: deque = deque(maxlen=HISTORY_MAX)
        self._rgb_t = 0.0
        
        # Windows
        self.settings_window: Optional[ctk.CTkToplevel] = None
        self.about_window: Optional[ctk.CTkToplevel] = None
        self.history_window: Optional[ctk.CTkToplevel] = None
        self.qr_window: Optional[ctk.CTkToplevel] = None
        self.db_window: Optional[ctk.CTkToplevel] = None
        
        # Widget references
        self._tooltips: Dict[str, ToolTip] = {}
        self.lang_buttons: Dict[str, ctk.CTkButton] = {}
        self.theme_buttons: Dict[str, ctk.CTkButton] = {}
        self.settings_labels: Dict[str, Any] = {}
        self._master_set_btn: Optional[ctk.CTkButton] = None
        self._master_status_label: Optional[ctk.CTkLabel] = None
        self._sound_btn: Optional[ctk.CTkButton] = None
        self._close_btn: Optional[ctk.CTkButton] = None
        self._clip_timeout_label_ref: Optional[ctk.CTkLabel] = None
        self._rgb_on_btn_ref: Optional[ctk.CTkButton] = None
        self._rgb_off_btn_ref: Optional[ctk.CTkButton] = None
        self._auto_lock_btn: Optional[ctk.CTkButton] = None
        self._auto_lock_slider: Optional[ctk.CTkSlider] = None
        self._auto_lock_label_ref: Optional[ctk.CTkLabel] = None
        self.auto_save_btn: Optional[ctk.CTkButton] = None
        self.auto_save_var = tk.BooleanVar(value=False)
        
        # RGB canvases
        self._rgb_c_top: Optional[tk.Canvas] = None
        self._rgb_c_bottom: Optional[tk.Canvas] = None
        self._rgb_c_left: Optional[tk.Canvas] = None
        self._rgb_c_right: Optional[tk.Canvas] = None
        
        self._icon_image: Optional[tk.PhotoImage] = None
        self._pdf_font_path = get_resource_path("DejaVuSans.ttf")
        
        # Initialize password generator
        self.generator = PasswordGenerator()
        self.strength_calc = StrengthCalculator()
        self.config = Config()
        
        # Setup UI
        ctk.set_widget_scaling(1.0)
        ctk.set_window_scaling(1.0)
        
        self.title("Secure Pass Pro v4.0")
        self.resizable(False, False)
        set_window_icon(self)
        
        self._create_rgb_canvases()
        self._setup_ui()
        self._apply_lang("RU")
        self._center_main_window()
        apply_window_rounding(self)
        
        # Bind keys
        self.bind('<F5>', lambda e: self._generate())
        self.bind('<Control-c>', lambda e: self._copy() if self.focus_get() is not self.entry_res else None)
        self.bind('<Control-s>', lambda e: self._save())
        self.bind('<Control-o>', lambda e: self._open())
        self.bind('<Escape>', lambda e: self._close_settings() if self.settings_window else None)
        
        # Activity tracking for auto-lock
        self.bind_all('<Key>', self._reset_activity_timer)
        self.bind_all('<Button>', self._reset_activity_timer)
        self.bind_all('<Motion>', self._reset_activity_timer)
        
        # Load settings
        self.after(50, self._load_all_settings)
        self.after(100, self._start_lock_checker)
        self.protocol("WM_DELETE_WINDOW", self._on_closing)
    
    def _load_all_settings(self) -> None:
        default_config = {
            "THEME": "Dark",
            "LANG": "RU",
            "SOUND": True,
            "RGB": True,
            "RADIUS": 25,
            "font_size": 14,
            "CLIP_TIMEOUT": 60,
            "AUTO_LOCK": False,
            "AUTO_LOCK_TIMEOUT": 5,
            "auto_save": False
        }
        
        need_save = False
        
        if not os.path.exists(CONFIG_FILE):
            need_save = True
            config = default_config.copy()
        else:
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    config = json.load(f)
                for key in default_config:
                    if key not in config:
                        config[key] = default_config[key]
                        need_save = True
            except json.JSONDecodeError as e:
                print(f"[Config] JSON decode error: {e}, using defaults")
                config = default_config.copy()
                need_save = True
            except PermissionError as e:
                print(f"[Config] Permission error: {e}, using defaults")
                config = default_config.copy()
                need_save = True
            except OSError as e:
                print(f"[Config] OS error: {e}, using defaults")
                config = default_config.copy()
                need_save = True
        
        if need_save:
            try:
                os.makedirs(CONFIG_DIR, exist_ok=True)
                with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                    json.dump(config, f, indent=2, ensure_ascii=False)
            except PermissionError as e:
                print(f"[Config] Cannot save config: {e}")
            except OSError as e:
                print(f"[Config] Cannot save config: {e}")
        
        self.config.update(config)
        
        self.current_theme = config.get("THEME", "Dark")
        self.current_lang = config.get("LANG", "RU")
        self.sound_enabled.set(config.get("SOUND", True))
        self.rgb_enabled.set(config.get("RGB", True))
        self.current_radius = config.get("RADIUS", 25)
        self.current_font_size = config.get("font_size", 14)
        self.clipboard_timeout = config.get("CLIP_TIMEOUT", 60)
        self.auto_lock_enabled.set(config.get("AUTO_LOCK", False))
        self.auto_lock_timeout = config.get("AUTO_LOCK_TIMEOUT", 5)
        self.auto_save_var.set(config.get("auto_save", False))
        
        set_global_radius(self.current_radius)
        self._change_radius(self.current_radius)
        self._apply_font_size(self.current_font_size)
        
        actual_theme = self._get_actual_theme()
        ctk.set_appearance_mode(self.current_theme)
        self.after(50, lambda: self._apply_theme_colors(actual_theme))
        self.after(60, lambda: self.configure(fg_color="#F3F3F3" if actual_theme == "light" else "#1d1e1e"))
        
        if self.rgb_enabled.get():
            self.after(200, self._start_rgb)
        
        self._update_master_status_label()
        self._update_auto_lock_label()
        
        self._apply_lang(self.current_lang)
    
    def _on_closing(self) -> None:
        """Закрытие приложения с очисткой ресурсов"""
        self._stop_rgb()
        
        if self._pulse_animation_id:
            try:
                self.after_cancel(self._pulse_animation_id)
            except Exception:
                pass
        
        if self._clipboard_timer:
            try:
                self.after_cancel(self._clipboard_timer)
            except Exception:
                pass
        
        if self._lock_check_id:
            try:
                self.after_cancel(self._lock_check_id)
            except Exception:
                pass
        
        # Закрываем соединения с БД
        try:
            PasswordDB.close_all_connections()
        except Exception:
            pass
        
        for win_attr in ("settings_window", "about_window", "history_window", "qr_window", "db_window"):
            win = getattr(self, win_attr, None)
            if win is not None:
                try:
                    win.destroy()
                except Exception:
                    pass
        
        self.destroy()


# ==================== ENTRY POINT ====================
if __name__ == "__main__":
    ctk.set_appearance_mode("System")
    ctk.set_default_color_theme("blue")
    
    _startup_lang = "RU"
    _startup_theme = "dark"
    
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as _f:
                try:
                    _cfg = json.load(_f)
                except json.JSONDecodeError:
                    _cfg = {}
                if "LANG" in _cfg and _cfg["LANG"] in ("RU", "EN", "UA"):
                    _startup_lang = _cfg["LANG"]
                if "THEME" in _cfg:
                    if _cfg["THEME"] == "Light":
                        _startup_theme = "light"
                    elif _cfg["THEME"] == "Dark":
                        _startup_theme = "dark"
    except Exception:
        pass
    
    if not MasterPassword.prompt_on_startup(_startup_lang, _startup_theme):
        sys.exit(0)
    
    app = SecurePassPro()
    app.mainloop()