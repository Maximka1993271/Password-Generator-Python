"""
Master password mixin for SecurePassPro
"""
import time
from gui.dialogs import CTkMessageBox, CTkInputDialog
from security.master import MasterPassword
from security.encryption import set_key_from_master, clear_master_key, reencrypt_all
from localization.lang import LANGUAGES
import customtkinter as ctk
from utils.helpers import get_global_radius, center_screen


class MasterMixin:
    """Mixin class for master password management and lock screen"""
    
    def _update_master_status_label(self) -> None:
        if self._master_status_label and self._master_status_label.winfo_exists():
            L = LANGUAGES[self.current_lang]
            if MasterPassword.is_set():
                self._master_status_label.configure(text=f"{L['master_current']} 🔒 {L['master_status_set']}", text_color="#2ECC71")
            else:
                self._master_status_label.configure(text=f"{L['master_current']} 🔓 {L['master_status_not_set']}", text_color="#FF4444")
    
    def _update_master_buttons(self) -> None:
        if not self._master_set_btn or not self._master_set_btn.winfo_exists():
            return
        L = LANGUAGES[self.current_lang]
        if MasterPassword.is_set():
            self._master_set_btn.configure(
                text="🔒 " + L["master_btn_remove"],
                fg_color="#8b0000",
                hover_color="#8b0000",
                command=self._remove_master_password
            )
        else:
            self._master_set_btn.configure(
                text="🔓 " + L["master_btn_set"],
                fg_color="#2d6a4f",
                hover_color="#2d6a4f",
                command=self._toggle_master_password
            )
    
    def _toggle_master_password(self) -> None:
        L = LANGUAGES[self.current_lang]
        actual_theme = self._get_actual_theme()
        
        if MasterPassword.is_set():
            current = CTkInputDialog.ask(self, L["master_title"], L["master_prompt"], show="*", theme=actual_theme, lang=self.current_lang)
            if current is None:
                return
            if not MasterPassword.verify(current):
                CTkMessageBox.error(self, L.get("err_title", "Error"), L["master_wrong"].format(1, 1))
                return
            try:
                reencrypt_all(old_master=current, new_master=None)
                MasterPassword.remove()
                clear_master_key()
            except Exception as exc:
                CTkMessageBox.error(
                    self,
                    L.get("err_title", "Error"),
                    L.get("master_remove_error", "Не удалось удалить мастер-пароль.") + f"\n\n{exc}"
                )
                return
            CTkMessageBox.info(self, L["master_title"], L["master_removed"])
        else:
            new_pwd = CTkInputDialog.ask(self, L["master_set_title"], L["master_set_prompt"], show="*", theme=actual_theme, lang=self.current_lang)
            if new_pwd is None or new_pwd == "":
                return
            import re as _re
            if len(new_pwd) < 8:
                CTkMessageBox.error(self, L.get("err_title", "Error"),
                    L.get("master_too_short", "Пароль слишком короткий. Минимум 8 символов."))
                return
            if not _re.search(r"[0-9!@#$%^&*()_+=\[\]{};:,.<>/?@%-]", new_pwd):
                CTkMessageBox.error(self, L.get("err_title", "Error"),
                    L.get("master_weak", "Пароль слишком простой. Добавьте цифру или спецсимвол."))
                return
            confirm = CTkInputDialog.ask(self, L["master_set_title"], L["master_confirm"], show="*", theme=actual_theme, lang=self.current_lang)
            if confirm is None:
                return
            if new_pwd != confirm:
                CTkMessageBox.error(self, L.get("err_title", "Error"), L["master_mismatch"])
                return
            try:
                MasterPassword.set_password(new_pwd)
                reencrypt_all(old_master=None, new_master=new_pwd)
                set_key_from_master(new_pwd)
            except Exception as exc:
                MasterPassword.remove()
                clear_master_key()
                CTkMessageBox.error(
                    self,
                    L.get("err_title", "Error"),
                    L.get("master_set_error", "Не удалось установить мастер-пароль.") + f"\n\n{exc}"
                )
                return
            CTkMessageBox.info(self, L["master_title"], L["master_set_ok"])
        
        self._update_master_buttons()
        self._update_master_status_label()
    
    def _remove_master_password(self) -> None:
        L = LANGUAGES[self.current_lang]
        if not MasterPassword.is_set():
            return
        if CTkMessageBox.question(self, L["master_title"], L["master_remove_confirm"]):
            current = CTkInputDialog.ask(self, L["master_title"], L["master_prompt"],
                                         show="*", theme=self._get_actual_theme(),
                                         lang=self.current_lang)
            if not current or not MasterPassword.verify(current):
                CTkMessageBox.error(self, L.get("err_title", "Error"), L["master_wrong"].format(1, 1))
                return
            try:
                reencrypt_all(old_master=current, new_master=None)
                MasterPassword.remove()
                clear_master_key()
            except Exception as exc:
                CTkMessageBox.error(
                    self,
                    L.get("err_title", "Error"),
                    L.get("master_remove_error", "Не удалось удалить мастер-пароль.") + f"\n\n{exc}"
                )
                return
            CTkMessageBox.info(self, L["master_title"], L["master_removed"])
            self._update_master_buttons()
            self._update_master_status_label()
    
    def _show_lock_screen(self) -> bool:
        L = LANGUAGES[self.current_lang]
        theme = self._get_actual_theme()
        colors = self._get_colors_for_theme(theme)
        radius = get_global_radius()
        
        win = ctk.CTkToplevel(self)
        win.title(L["win_title"])
        win.resizable(False, False)
        win.grab_set()
        win.attributes("-topmost", True)
        
        w, h = 450, 340
        center_screen(win, w, h)
        win.configure(fg_color=colors["bg"])
        
        ctk.CTkLabel(win, text="🔒", font=("Segoe UI", 64), text_color="#4EC9B0").pack(pady=(30, 10))
        ctk.CTkLabel(win, text=L.get("auto_lock_title", "Program Locked"), 
                    font=("Segoe UI", 18, "bold"), text_color=colors["label_text"]).pack(pady=(0, 10))
        
        entry = ctk.CTkEntry(win, width=340, height=45, font=("Segoe UI", 16), show="*",
                            fg_color=colors["entry_bg"], text_color=colors["fg"], corner_radius=radius)
        entry.pack(pady=(0, 20))
        entry.focus_set()
        
        result = [False]
        attempts = [0]
        MAX_ATT = 5

        attempts_lbl = ctk.CTkLabel(win, text="", font=("Segoe UI", 12),
                                     text_color="#E24B4A")
        attempts_lbl.pack(pady=(0, 4))

        def _lock_delay(seconds):
            unlock_btn.configure(state="disabled")
            entry.configure(state="disabled")
            def _tick(s):
                if s <= 0:
                    unlock_btn.configure(state="normal")
                    entry.configure(state="normal")
                    entry.focus_set()
                    attempts_lbl.configure(
                        text=L["master_wrong"].format(attempts[0], MAX_ATT))
                else:
                    attempts_lbl.configure(
                        text=f"⏳ {L.get('lock_wait', 'Подождите')} {s} сек...")
                    win.after(1000, lambda: _tick(s - 1))
            _tick(seconds)

        def on_unlock():
            pwd = entry.get()
            if MasterPassword.verify(pwd):
                set_key_from_master(pwd)
                result[0] = True
                win.destroy()
                return
            attempts[0] += 1
            entry.delete(0, "end")
            if attempts[0] >= MAX_ATT:
                attempts_lbl.configure(
                    text=L.get("lock_max_attempts",
                               "Превышено число попыток. Приложение закрывается..."))
                win.after(2000, lambda: (win.destroy(), self.destroy()))
                return
            delay = [0, 0, 3, 5, 10, 30][min(attempts[0], 5)]
            if delay:
                _lock_delay(delay)
            else:
                attempts_lbl.configure(
                    text=L["master_wrong"].format(attempts[0], MAX_ATT))
                entry.focus_set()

        entry.bind("<Return>", lambda e: on_unlock())

        # Нормальная круглая кнопка
        unlock_btn = ctk.CTkButton(win, text=L.get("unlock", "Разблокировать"),
                                    width=180, height=50, command=on_unlock,
                                    fg_color="#2d6a4f", hover_color="#40916c",
                                    corner_radius=25,
                                    font=("Segoe UI", 15, "bold"))
        unlock_btn.pack(pady=(6, 30))

        win.protocol("WM_DELETE_WINDOW", lambda: None)
        win.after(100, lambda: win.attributes("-topmost", False))
        self.wait_window(win)

        return result[0]