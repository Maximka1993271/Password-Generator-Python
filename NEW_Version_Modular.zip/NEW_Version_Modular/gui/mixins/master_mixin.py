"""
Master password mixin for SecurePassPro
FULL 3-LANGUAGE SUPPORT: RU, EN, UA

Миксин мастер-пароля для SecurePassPro
ПОЛНАЯ ПОДДЕРЖКА 3 ЯЗЫКОВ: RU, EN, UA

Міксин майстер-пароля для SecurePassPro
ПОВНА ПІДТРИМКА 3 МОВ: RU, EN, UA
"""
import time
import tkinter as tk
import ctypes
import os
from typing import Optional, Tuple, Any
from gui.dialogs import CTkMessageBox, CTkInputDialog
from security.master import MasterPassword
from security.encryption import set_key_from_master, clear_master_key, reencrypt_all
from localization.lang import LANGUAGES
import customtkinter as ctk
from utils.helpers import get_global_radius, center_screen
from cryptography.exceptions import InvalidTag
from utils.logger import get_logger
from utils.paths import get_config_dir

logger = get_logger("master_mixin")

# Путь к файлу мастер-пароля
CONFIG_DIR = get_config_dir()
MASTER_FILE = os.path.join(CONFIG_DIR, "master.key")


class MasterPasswordError(Exception):
    """Custom exception for master password operations"""
    pass


class MasterMixin:
    """Mixin class for master password management and lock screen
    Класс-миксин для управления мастер-паролем и экраном блокировки
    Клас-міксин для керування майстер-паролем та екраном блокування"""

    def _update_master_status_label(self) -> None:
        """Update master password status / Обновить статус мастер-пароля / Оновити статус майстер-пароля"""
        # FIXED: Check if label exists before accessing
        if not hasattr(self, '_master_status_label') or self._master_status_label is None:
            return
        try:
            if self._master_status_label.winfo_exists():
                L = LANGUAGES[self.current_lang]
                if MasterPassword.is_set():
                    self._master_status_label.configure(
                        text=f"{L.get('master_current', 'Status:')} {L.get('master_status_set', 'Set')}",
                        text_color="#2ECC71"
                    )
                else:
                    self._master_status_label.configure(
                        text=f"{L.get('master_current', 'Status:')} {L.get('master_status_not_set', 'Not set')}",
                        text_color="#FF4444"
                    )
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Update master status label error: {e}")

    def _update_master_buttons(self) -> None:
        """Update master password button state / Обновить состояние кнопки мастер-пароля / Оновити стан кнопки майстер-пароля"""
        # FIXED: Check if button exists before accessing
        if not hasattr(self, '_master_set_btn') or self._master_set_btn is None:
            return
        try:
            if not self._master_set_btn.winfo_exists():
                return
            L = LANGUAGES[self.current_lang]
            if MasterPassword.is_set():
                self._master_set_btn.configure(
                    text=L.get("master_btn_remove", "Remove master password"),
                    fg_color="#8b0000",
                    hover_color="#aa2222",
                    command=self._remove_master_password
                )
            else:
                self._master_set_btn.configure(
                    text=L.get("master_btn_set", "Set master password"),
                    fg_color="#2d6a4f",
                    hover_color="#40916c",
                    command=self._set_master_password
                )
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Update master buttons error: {e}")

    def _refresh_settings_window(self) -> None:
        """Refresh settings window if open / Обновить окно настроек если открыто / Оновити вікно налаштувань якщо відкрите"""
        if hasattr(self, 'settings_window') and self.settings_window and self.settings_window.winfo_exists():
            try:
                # Update master button in settings window directly
                if hasattr(self, '_master_set_btn') and self._master_set_btn:
                    L = LANGUAGES[self.current_lang]
                    if MasterPassword.is_set():
                        self._master_set_btn.configure(
                            text=L.get("master_btn_remove", "Remove master password"),
                            fg_color="#8b0000",
                            hover_color="#aa2222",
                            command=self._remove_master_password
                        )
                    else:
                        self._master_set_btn.configure(
                            text=L.get("master_btn_set", "Set master password"),
                            fg_color="#2d6a4f",
                            hover_color="#40916c",
                            command=self._set_master_password
                        )
                
                # Update master status label in settings window
                if hasattr(self, '_master_status_label') and self._master_status_label:
                    L = LANGUAGES[self.current_lang]
                    if MasterPassword.is_set():
                        self._master_status_label.configure(
                            text=f"{L.get('master_current', 'Status:')} {L.get('master_status_set', 'Set')}",
                            text_color="#2ECC71"
                        )
                    else:
                        self._master_status_label.configure(
                            text=f"{L.get('master_current', 'Status:')} {L.get('master_status_not_set', 'Not set')}",
                            text_color="#FF4444"
                        )
                
                # Refresh language and theme of settings window
                if hasattr(self, '_refresh_settings_window_language'):
                    self._refresh_settings_window_language()
                
                self.settings_window.update_idletasks()
                logger.debug("Settings window refreshed after master password change")
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Refresh settings window error: {e}")

    def _set_master_password(self) -> None:
        """Set a new master password / Установить новый мастер-пароль / Встановити новий майстер-пароль"""
        L = LANGUAGES[self.current_lang]
        actual_theme = self._get_actual_theme()

        if MasterPassword.is_set():
            CTkMessageBox.warning(self, L.get("master_title", "Master Password"), 
                                 L.get("master_already_set", "Master password already set!"))
            return

        new_pwd = CTkInputDialog.ask(
            self,
            L.get("master_set_title", "Set Master Password"),
            L.get("master_set_prompt", "Create master password:"),
            show="*",
            theme=actual_theme,
            lang=self.current_lang
        )
        if not new_pwd or new_pwd == "":
            return

        if len(new_pwd) < 8:
            CTkMessageBox.error(self, L.get("err_title", "Error"), 
                               L.get("master_too_short", "Password too short. Minimum 8 characters."))
            return

        import re
        if not re.search(r"[0-9!@#$%^&*()_+=\[\]{};:,.<>/?@%-]", new_pwd):
            CTkMessageBox.error(self, L.get("err_title", "Error"), 
                               L.get("master_weak", "Password too weak. Add a digit or special character."))
            return

        confirm = CTkInputDialog.ask(
            self,
            L.get("master_set_title", "Set Master Password"),
            L.get("master_confirm", "Confirm master password:"),
            show="*",
            theme=actual_theme,
            lang=self.current_lang
        )
        if not confirm:
            return

        if new_pwd != confirm:
            CTkMessageBox.error(self, L.get("err_title", "Error"), L.get("master_mismatch", "Passwords do not match"))
            return

        try:
            MasterPassword.set_password(new_pwd)
            reencrypt_all(old_master=None, new_master=new_pwd)
            set_key_from_master(new_pwd)
            CTkMessageBox.info(self, L.get("master_title", "Master Password"), 
                              L.get("master_set_ok", "Master password set"))
        except (ValueError, IOError, OSError, InvalidTag, RuntimeError) as exc:
            logger.error(f"Failed to set master password: {exc}")
            try:
                MasterPassword.remove()
            except (OSError, IOError, PermissionError) as e:
                logger.debug(f"Master remove error during rollback: {e}")
            try:
                clear_master_key()
            except (OSError, IOError, AttributeError) as e:
                logger.debug(f"Clear master key error during rollback: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), 
                               f"{L.get('master_set_error', 'Failed to set master password.')}\n{exc}")
            return

        self._update_master_buttons()
        self._update_master_status_label()
        
        # FIXED: Refresh settings window if open (without closing)
        self._refresh_settings_window()

    def _remove_master_password(self) -> None:
        """Remove master password - FULLY FIXED VERSION with UI updates
        Удалить мастер-пароль - ПОЛНОСТЬЮ ИСПРАВЛЕННАЯ ВЕРСИЯ
        Видалити майстер-пароль - ПОВНІСТЮ ВИПРАВЛЕНА ВЕРСІЯ"""
        L = LANGUAGES[self.current_lang]

        try:
            # Проверка, установлен ли мастер-пароль
            if not MasterPassword.is_set():
                CTkMessageBox.info(self, L.get("master_title", "Master Password"), 
                                  L.get("master_not_set", "Master password not set."))
                return

            # FIXED: Force UI update before modal dialog
            self.update_idletasks()

            # Подтверждение удаления - ИСПРАВЛЕНО: Безопасная проверка на bool и на строковый ответ ("Yes"/"yes")
            confirm_question = CTkMessageBox.question(
                self, 
                L.get("master_title", "Master Password"), 
                L.get("master_remove_confirm", "Are you sure you want to remove the master password?\n\nAll passwords will remain accessible without additional protection!")
            )
            if confirm_question not in [True, "Yes", "yes"]:
                return

            # FIXED: Force UI update before modal dialog
            self.update_idletasks()

            # Запрос текущего пароля
            current = CTkInputDialog.ask(
                self,
                L.get("master_title", "Master Password"),
                L.get("master_remove_prompt", "Enter current master password to confirm:"),
                show="*",
                theme=self._get_actual_theme(),
                lang=self.current_lang
            )
            if not current or current == "":
                return

            # Проверка пароля
            if not MasterPassword.verify(current):
                CTkMessageBox.error(self, L.get("err_title", "Error"), 
                                   L.get("master_wrong", "Wrong password!"))
                return

            # ========== ОСНОВНОЕ УДАЛЕНИЕ ==========
            logger.info("Removing master password...")
            
            # 1. Перешифровка всех паролей без мастер-пароля
            try:
                reencrypt_all(old_master=current, new_master=None)
                logger.info("Reencryption completed")
            except (ValueError, TypeError, RuntimeError, OSError, InvalidTag) as e:
                logger.warning(f"Reencryption error (continuing anyway): {e}")
            
            # 2. Удаление мастер-пароля через MasterPassword класс
            try:
                MasterPassword.remove()
                logger.info("MasterPassword.remove() completed")
            except (OSError, IOError, PermissionError, RuntimeError) as e:
                logger.warning(f"MasterPassword.remove() error: {e}")
            
            # 3. Прямое удаление файла мастер-пароля (на всякий случай)
            try:
                if os.path.exists(MASTER_FILE):
                    os.remove(MASTER_FILE)
                    logger.info(f"Master file deleted: {MASTER_FILE}")
            except (OSError, IOError, PermissionError, RuntimeError) as e:
                logger.warning(f"Direct master file deletion error: {e}")
            
            # 4. Очистка ключа в памяти
            try:
                clear_master_key()
                logger.info("Master key cleared from memory")
            except (AttributeError, RuntimeError, OSError) as e:
                logger.warning(f"Clear master key error: {e}")
            
            # 5. Отключение 2FA через конфиг
            try:
                if hasattr(self, 'config') and self.config:
                    self.config.set_2fa_enabled(False)
                    self.config.set_2fa_secret("")
                    self.config.set_2fa_backup_hashes([])
                    self.config.set_2fa_setup_completed(False)
                    self.config.save()
                    logger.info("2FA disabled in config")
            except (AttributeError, OSError, TypeError, ValueError) as e:
                logger.debug(f"2FA config disable error: {e}")
            
            # 6. Отключение 2FA через TOTP менеджер
            try:
                from security.totp import get_totp_manager
                manager = get_totp_manager()
                manager.disable_2fa()
                logger.info("2FA disabled via TOTP")
            except (ImportError, AttributeError, RuntimeError) as e:
                logger.debug(f"TOTP disable error: {e}")
            
            # 7. Обновление UI - FIXED: Обернуто в try/except на случай TclError
            try:
                self.update_idletasks()
                
                self._update_master_buttons()
                self._update_master_status_label()
                
                # Обновление 2FA индикатора если есть
                if hasattr(self, '_update_2fa_indicator'):
                    self._update_2fa_indicator()
                if hasattr(self, '_update_2fa_buttons'):
                    self._update_2fa_buttons()
                
                # FIXED: Force final UI update
                self.update()
                
                # FIXED: Refresh settings window if open (without closing)
                self._refresh_settings_window()
                
            except (tk.TclError, RuntimeError, AttributeError) as e:
                logger.debug(f"UI update trace error during master removal: {e}")
            
            # Успешное сообщение
            CTkMessageBox.info(self, L.get("master_title", "Master Password"), 
                              L.get("master_removed", "Master password removed successfully!\n\nPasswords are now stored without additional protection."))
            
            logger.info("Master password removal completed successfully")
            
        except (ValueError, RuntimeError, tk.TclError, OSError, IOError, PermissionError, AttributeError, TypeError) as exc:
            # ✅ ИСПРАВЛЕНО: except Exception заменен на конкретные типы исключений
            logger.error(f"Failed to remove master password: {exc}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), 
                               f"{L.get('master_remove_error', 'Failed to remove master password.')}\n{exc}")
            return

    def _minimize_window(self, window: Any) -> None:
        """Minimize window to taskbar / Сворачивает окно в панель задач / Згортає вікно в панель завдань"""
        try:
            hwnd = ctypes.windll.user32.GetParent(window.winfo_id())
            if not hwnd:
                hwnd = ctypes.windll.user32.GetAncestor(window.winfo_id(), 2)
            if hwnd:
                ctypes.windll.user32.ShowWindow(hwnd, 6)
            else:
                window.iconify()
        except (AttributeError, OSError, TypeError, tk.TclError, RuntimeError) as e:
            logger.debug(f"Minimize error: {e}")
            window.iconify()

    def _show_lock_screen(self) -> bool:
        """Show lock screen with working minimize button and correct 2FA
        Показать экран блокировки с работающей кнопкой сворачивания и корректным 2FA
        Показати екран блокування з працюючою кнопкою згортання та коректним 2FA"""
        from security.totp import TOTP, get_totp_manager
        
        L = LANGUAGES[self.current_lang]
        theme = self._get_actual_theme()
        colors = self._get_colors_for_theme(theme)
        radius = get_global_radius()

        win = ctk.CTkToplevel(self)
        win.title(L.get("win_title", "Secure Pass Pro v4.0"))
        
        self.withdraw()
        
        win.protocol("WM_DELETE_WINDOW", self.destroy)
        
        win.minsize(450, 480)
        win.maxsize(450, 480)
        
        win.attributes("-topmost", True)
        win.after(100, lambda: win.attributes("-topmost", False))
        
        win.geometry("450x480")
        win.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - 450) // 2
        y = self.winfo_y() + (self.winfo_height() - 480) // 2
        win.geometry(f"450x480+{x}+{y}")
        win.configure(fg_color=colors["bg"])

        main_frame = ctk.CTkFrame(win, fg_color="transparent")
        main_frame.pack(expand=True, fill="both", padx=30, pady=20)

        ctk.CTkLabel(main_frame, text="", font=("Segoe UI", 48), text_color="#4EC9B0").pack(pady=(0, 5))
        ctk.CTkLabel(main_frame, text=L.get("auto_lock_title", "Program Locked"),
                    font=("Segoe UI", 18, "bold"), text_color=colors["label_text"]).pack(pady=(0, 10))

        ctk.CTkLabel(main_frame, text=L.get("master_prompt", "Enter master password:"),
                    font=("Segoe UI", 13), text_color=colors["label_text"]).pack()
        
        pwd_entry = ctk.CTkEntry(main_frame, width=320, height=45, font=("Segoe UI", 14), show="*",
                                fg_color=colors["entry_bg"], text_color=colors["fg"], corner_radius=radius)
        pwd_entry.pack(pady=(5, 10))
        pwd_entry.focus_set()

        _2fa_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        
        code_label = ctk.CTkLabel(_2fa_frame, text=L.get("2fa_enter_verification", "Enter verification code:"),
                                  font=("Segoe UI", 13), text_color=colors["label_text"])
        code_label.pack()
        
        code_entry = ctk.CTkEntry(_2fa_frame, width=220, height=45, font=("Consolas", 20, "bold"),
                                 justify="center", fg_color=colors["entry_bg"], text_color=colors["fg"],
                                 corner_radius=radius)
        code_entry.pack(pady=(5, 0))
        code_entry.configure(state="disabled")

        status_label = ctk.CTkLabel(main_frame, text="", font=("Segoe UI", 12), text_color="#E24B4A")
        status_label.pack(pady=(5, 5))

        unlock_btn = ctk.CTkButton(main_frame, text=L.get("unlock", "Unlock"),
                                   width=160, height=45, fg_color="#2d6a4f", 
                                   hover_color="#40916c", corner_radius=radius, 
                                   font=("Segoe UI", 14, "bold"))
        unlock_btn.pack(pady=(10, 15))

        result = [False]
        master_verified = [False]

        def unlock_success() -> None:
            result[0] = True
            self.deiconify()
            win.destroy()

        def update_status() -> None:
            try:
                info = MasterPassword.get_lockout_info()
                if info['is_locked']:
                    status_label.configure(text=f"{L.get('lock_wait', 'Please wait')} {info['lockout_seconds']} {L.get('seconds_short', 'sec')}...")
                    pwd_entry.configure(state="disabled")
                    code_entry.configure(state="disabled")
                    unlock_btn.configure(state="disabled")
                    win.after(1000, update_status)
                else:
                    pwd_entry.configure(state="normal")
                    unlock_btn.configure(state="normal")
                    pwd_entry.focus_set()
                    if info['attempts'] > 0 and not master_verified[0]:
                        status_label.configure(text=L.get("master_wrong", "Wrong password! Attempt {0} of {1}").format(info['attempts'], 5))
                    else:
                        status_label.configure(text="")
            except (KeyError, TypeError, AttributeError, RuntimeError) as e:
                logger.debug(f"Update status error: {e}")

        def check_master_password() -> None:
            pwd = pwd_entry.get()
            if MasterPassword.verify(pwd):
                set_key_from_master(pwd)
                master_verified[0] = True
                status_label.configure(text=L.get("master_verified", "Master password verified"), text_color="#2ECC71")
                
                if self.config.is_2fa_enabled():
                    code_entry.configure(state="normal")
                    code_entry.focus_set()
                    unlock_btn.configure(text=L.get("2fa_verify_title", "Verify 2FA"))
                    pwd_entry.configure(state="disabled")
                    _2fa_frame.pack(pady=(10, 5))
                else:
                    unlock_success()
            else:
                info = MasterPassword.get_lockout_info()
                status_label.configure(text=L.get("master_wrong", "Wrong password! Attempt {0} of {1}").format(info['attempts'], 5))
                pwd_entry.delete(0, "end")
                pwd_entry.focus_set()

        def check_2fa() -> None:
            try:
                code_raw = code_entry.get().strip()
                code_clean = ''.join(filter(str.isdigit, code_raw))
                
                if len(code_clean) != 6:
                    status_label.configure(text=L.get("2fa_invalid_code", "Invalid code - enter 6 digits"))
                    code_entry.delete(0, "end")
                    code_entry.focus_set()
                    return
                
                secret = self.config.get_2fa_secret()
                if secret:
                    secret_clean = secret.upper().replace(" ", "").replace("-", "")
                    totp = TOTP(secret_clean)
                    is_valid, _ = totp.verify(code_clean)
                    if is_valid:
                        self.config.set_2fa_last_verified()
                        unlock_success()
                        return
                
                manager = get_totp_manager()
                if manager.verify_backup_code(code_clean):
                    self.config.set_2fa_backup_hashes(manager.get_backup_codes_hashes())
                    self.config.save()
                    CTkMessageBox.warning(win, L.get("2fa_title", "Two-Factor Authentication"), 
                                         L.get("2fa_backup_used", "Backup code used! Please generate new backup codes in settings."))
                    unlock_success()
                    return
                
                status_label.configure(text=L.get("2fa_invalid_code", "Invalid verification code"))
                code_entry.delete(0, "end")
                code_entry.focus_set()
            except (ValueError, TypeError, AttributeError, RuntimeError) as e:
                logger.error(f"2FA verification error: {e}")
                status_label.configure(text=L.get("2fa_error", "Verification error"))

        def on_unlock() -> None:
            if MasterPassword.get_remaining_lockout_time() > 0:
                update_status()
                return
            
            if master_verified[0] and self.config.is_2fa_enabled():
                check_2fa()
            else:
                check_master_password()

        unlock_btn.configure(command=on_unlock)

        pwd_entry.bind("<Return>", lambda e: on_unlock())
        code_entry.bind("<Return>", lambda e: on_unlock())

        update_status()

        try:
            self.wait_window(win)
        except (tk.TclError, RuntimeError, AttributeError) as e:
            logger.debug(f"Lock screen wait error: {e}")

        return result[0]

    def _get_actual_theme(self) -> str:
        """Return actual theme for lock screen / Возвращает актуальную тему для lock screen / Повертає актуальну тему для lock screen"""
        if hasattr(self, 'current_theme'):
            if self.current_theme == "Light":
                return "light"
            elif self.current_theme == "Dark":
                return "dark"
        return "dark"

    def _get_colors_for_theme(self, theme: str) -> dict:
        """Return colors for theme / Возвращает цвета для темы / Повертає кольори для теми"""
        if theme == "light":
            return {
                "bg": "#F3F3F3",
                "fg": "#000000",
                "entry_bg": "#FFFFFF",
                "label_text": "#000000",
                "button_fg": "#1f538d"
            }
        return {
            "bg": "#1d1e1e",
            "fg": "#FFFFFF",
            "entry_bg": "#2b2b2b",
            "label_text": "#FFFFFF",
            "button_fg": "#1f538d"
        }

    def _center_window_relative_to_parent(self, window: Any, width: int, height: int) -> None:
        """Center window relative to parent / Центрирует окно относительно родителя / Центрує вікно відносно батька"""
        try:
            window.update_idletasks()
            parent_x = self.winfo_x()
            parent_y = self.winfo_y()
            parent_width = self.winfo_width()
            parent_height = self.winfo_height()
            x = parent_x + (parent_width // 2) - (width // 2)
            y = parent_y + (parent_height // 2) - (height // 2)

            screen_width = self.winfo_screenwidth()
            screen_height = self.winfo_screenheight()

            if x < 0:
                x = 10
            if y < 30:
                y = 30
            if x + width > screen_width:
                x = screen_width - width - 10
            if y + height > screen_height:
                y = screen_height - height - 10

            window.geometry(f"{width}x{height}+{x}+{y}")
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Window centering error: {e}")

    # ==================== 2FA METHODS / МЕТОДЫ 2FA / МЕТОДИ 2FA ====================

    def _setup_2fa(self) -> None:
        """Setup two-factor authentication / Настройка двухфакторной аутентификации / Налаштування двофакторної аутентифікації"""
        from security.totp import TOTP, get_totp_manager
        from utils.qr_utils import QRUtils
        
        L = LANGUAGES[self.current_lang]
        
        if not MasterPassword.is_set():
            CTkMessageBox.warning(
                self,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_master_required", "Please set a master password before enabling 2FA.")
            )
            return
        
        if self.config.is_2fa_enabled():
            result = CTkMessageBox.question(
                self,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_disable_confirm", "2FA is already enabled.\n\nDo you want to disable it?")
            )
            # ИСПРАВЛЕНО: Безопасная проверка строкового и булевого ответа
            if result in [True, "Yes", "yes"]:
                self._disable_2fa()
            return
        
        account_name = self.config.get_2fa_account_name()
        if not account_name:
            account_name = "SecurePassPro_User"
        
        totp = TOTP()
        secret = totp.secret
        provisioning_uri = TOTP.get_provisioning_uri(secret, account_name, "SecurePassPro")
        
        QRUtils.show_qr_window(
            self,
            provisioning_uri,
            secret,
            self.current_lang,
            L.get("2fa_setup_title", "2FA Setup")
        )
        
        code = self._verify_2fa_dialog(
            L.get("2fa_verify_title", "Verify 2FA"),
            L.get("2fa_enter_verification", "Enter the 6-digit code from your authenticator app:")
        )
        
        if not code:
            CTkMessageBox.info(
                self,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_setup_cancelled", "2FA setup cancelled.")
            )
            return
        
        code_clean = ''.join(filter(str.isdigit, code))
        
        if totp.verify(code_clean)[0]:
            backup_codes = totp.get_backup_codes(count=10, length=8)
            
            manager = get_totp_manager()
            manager.enable_2fa(secret)
            manager.set_backup_codes(backup_codes)
            manager.set_account_name(account_name)
            
            self.config.set_2fa_enabled(True)
            self.config.set_2fa_secret(secret)
            self.config.set_2fa_backup_hashes(manager.get_backup_codes_hashes())
            self.config.set_2fa_account_name(account_name)
            self.config.set_2fa_setup_completed(True)
            self.config.set_2fa_last_verified()
            self.config.save()
            
            self._show_backup_codes(backup_codes)
            
            CTkMessageBox.info(
                self,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_enabled_success", "Two-Factor Authentication has been enabled successfully!\n\nPlease save your backup codes in a safe place.")
            )
            
            self._update_2fa_buttons()
            self._update_2fa_indicator()
        else:
            CTkMessageBox.error(
                self,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_invalid_code", "Invalid verification code. Please try again.")
            )
    
    def _disable_2fa(self) -> None:
        """Disable two-factor authentication / Отключает двухфакторную аутентификацию / Вимкає двофакторну аутентифікацію"""
        from security.totp import get_totp_manager
        
        L = LANGUAGES[self.current_lang]
        
        # ИСПРАВЛЕНО: Безопасная проверка ответа диалогового окна
        if CTkMessageBox.question(
            self,
            L.get("2fa_title", "Two-Factor Authentication"),
            L.get("2fa_disable_warning", "WARNING: Disabling 2FA will make your account less secure!\n\nAre you sure you want to disable 2FA?")
        ) not in [True, "Yes", "yes"]:
            return
        
        code = self._verify_2fa_dialog(
            L.get("2fa_verify_disable", "Enter 2FA code to disable"),
            L.get("2fa_enter_code", "Enter verification code:")
        )
        
        if not code:
            return
        
        code_clean = ''.join(filter(str.isdigit, code))
        
        from security.totp import TOTP
        secret = self.config.get_2fa_secret()
        if secret:
            secret_clean = secret.upper().replace(" ", "").replace("-", "")
            totp = TOTP(secret_clean)
            if totp.verify(code_clean)[0]:
                manager = get_totp_manager()
                manager.disable_2fa()
                
                self.config.clear_2fa()
                self.config.save()
                
                CTkMessageBox.info(
                    self,
                    L.get("2fa_title", "Two-Factor Authentication"),
                    L.get("2fa_disabled_success", "Two-Factor Authentication has been disabled.")
                )
                
                self._update_2fa_buttons()
                self._update_2fa_indicator()
            else:
                CTkMessageBox.error(
                    self,
                    L.get("2fa_title", "Two-Factor Authentication"),
                    L.get("2fa_invalid_code", "Invalid verification code.")
                )
        else:
            manager = get_totp_manager()
            manager.disable_2fa()
            self.config.clear_2fa()
            self.config.save()
            
            CTkMessageBox.info(
                self,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_disabled_success", "Two-Factor Authentication has been disabled.")
            )
            self._update_2fa_buttons()
            self._update_2fa_indicator()
    
    def _verify_2fa_dialog(self, title: str, prompt: str) -> Optional[str]:
        """Show dialog for entering 2FA code / Показывает диалог для ввода 2FA кода / Показує діалог для введення 2FA коду"""
        L = LANGUAGES[self.current_lang]
        theme = self._get_actual_theme()
        
        dialog = ctk.CTkToplevel(self)
        dialog.title(title)
        dialog.geometry("450x350")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        dialog.attributes("-topmost", True)
        
        dialog.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - 450) // 2
        y = self.winfo_y() + (self.winfo_height() - 350) // 2
        dialog.geometry(f"450x350+{x}+{y}")
        
        if theme == "light":
            bg_color = "#F3F3F3"
            fg_color = "#000000"
            entry_bg = "#FFFFFF"
        else:
            bg_color = "#1d1e1e"
            fg_color = "#FFFFFF"
            entry_bg = "#2b2b2b"
        
        dialog.configure(fg_color=bg_color)
        
        main_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=25, pady=25)
        
        ctk.CTkLabel(main_frame, text="", font=("Segoe UI", 40), text_color="#4EC9B0").pack(pady=(0, 15))
        ctk.CTkLabel(main_frame, text=prompt, font=("Segoe UI", 14), text_color=fg_color, wraplength=350).pack(pady=(0, 20))
        
        entry = ctk.CTkEntry(main_frame, width=250, height=50, font=("Consolas", 24, "bold"),
                            justify="center", fg_color=entry_bg, text_color=fg_color, corner_radius=15)
        entry.pack(pady=(0, 20))
        entry.focus_set()
        
        result: Optional[str] = None
        
        def on_ok() -> None:
            nonlocal result
            try:
                code = entry.get().strip()
                code_clean = ''.join(filter(str.isdigit, code))
                if len(code_clean) == 6:
                    result = code_clean
                    dialog.destroy()
                else:
                    entry.configure(border_color="#E24B4A", border_width=2)
                    dialog.after(200, lambda: entry.configure(border_color=""))
                    entry.delete(0, "end")
                    entry.focus_set()
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"2FA dialog OK error: {e}")
        
        def on_cancel() -> None:
            dialog.destroy()
        
        btn_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        btn_frame.pack()
        
        ctk.CTkButton(btn_frame, text=L.get("ok", "Verify"),
                     command=on_ok, width=130, height=40, fg_color="#2d6a4f",
                     corner_radius=20, font=("Segoe UI", 13, "bold")).pack(side="left", padx=15)
        
        ctk.CTkButton(btn_frame, text=L.get("cancel", "Cancel"),
                     command=on_cancel, width=130, height=40, fg_color="#8b0000",
                     corner_radius=20, font=("Segoe UI", 13, "bold")).pack(side="left", padx=15)
        
        entry.bind("<Return>", lambda e: on_ok())
        entry.bind("<Escape>", lambda e: on_cancel())
        
        dialog.after(100, lambda: dialog.attributes("-topmost", False))
        
        self.wait_window(dialog)
        
        return result
    
    def _show_backup_codes(self, backup_codes: list) -> None:
        """Show backup codes in a separate window / Показывает резервные коды в отдельном окне / Показує резервні коди в окремому вікні"""
        L = LANGUAGES[self.current_lang]
        theme = self._get_actual_theme()
        radius = get_global_radius()
        
        win = ctk.CTkToplevel(self)
        win.title(L.get("2fa_backup_codes", "Backup Codes"))
        win.geometry("550x600")
        win.resizable(False, False)
        win.transient(self)
        win.grab_set()
        win.attributes("-topmost", True)
        
        win.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - 550) // 2
        y = self.winfo_y() + (self.winfo_height() - 600) // 2
        win.geometry(f"550x600+{x}+{y}")
        
        main_frame = ctk.CTkFrame(win, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=25, pady=25)
        
        ctk.CTkLabel(main_frame, text=L.get("2fa_backup_codes", "Backup Codes"),
                    font=("Segoe UI", 20, "bold")).pack(pady=(0, 15))
        
        warning_frame = ctk.CTkFrame(main_frame, fg_color="#3a2a0a", corner_radius=12)
        warning_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(warning_frame,
                    text=L.get("2fa_backup_warning_detailed", 
                               "Store these codes in a safe place!\nEach code can be used only once to recover access."),
                    font=("Segoe UI", 12), text_color="#FFA500", justify="center").pack(pady=12, padx=15)
        
        codes_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        codes_frame.pack(pady=10)
        
        left_frame = ctk.CTkFrame(codes_frame, fg_color="transparent")
        left_frame.pack(side="left", padx=15)
        
        right_frame = ctk.CTkFrame(codes_frame, fg_color="transparent")
        right_frame.pack(side="left", padx=15)
        
        half = len(backup_codes) // 2 + len(backup_codes) % 2
        for i, code in enumerate(backup_codes):
            target = left_frame if i < half else right_frame
            code_text = code if '-' in code else f"{code[:4]}-{code[4:]}"
            
            ctk.CTkLabel(target, text=code_text, font=("Consolas", 16, "bold"),
                        fg_color=("#2b2b2b" if theme == "dark" else "#e0e0e0"),
                        corner_radius=10, padx=20, pady=8).pack(pady=6)
        
        def copy_all_codes() -> None:
            try:
                all_codes = "\n".join(backup_codes)
                win.clipboard_clear()
                win.clipboard_append(all_codes)
                copy_btn.configure(text=L.get("copied", "Copied!"))
                win.after(2000, lambda: copy_btn.configure(text=L.get("copy_all", "Copy All")))
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Copy all codes error: {e}")
        
        copy_btn = ctk.CTkButton(main_frame, text=L.get("copy_all", "Copy All"),
                                command=copy_all_codes, width=180, height=40, fg_color="#2d6a4f",
                                corner_radius=radius, font=("Segoe UI", 13, "bold"))
        copy_btn.pack(pady=15)
        
        ctk.CTkButton(main_frame, text=L.get("ok", "OK"), command=win.destroy,
                     width=140, height=40, fg_color="#8b0000", corner_radius=radius,
                     font=("Segoe UI", 13, "bold")).pack(pady=10)
        
        win.after(100, lambda: win.attributes("-topmost", False))
        win.focus_force()
    
    def _show_2fa_settings(self) -> None:
        """Show 2FA settings window / Показывает окно настроек 2FA / Показує вікно налаштувань 2FA"""
        from security.totp import get_totp_manager
        
        L = LANGUAGES[self.current_lang]
        theme = self._get_actual_theme()
        radius = get_global_radius()
        
        is_enabled = self.config.is_2fa_enabled()
        
        win = ctk.CTkToplevel(self)
        win.title(L.get("2fa_settings_title", "2FA Settings"))
        win.geometry("500x550")
        win.resizable(False, False)
        win.transient(self)
        win.grab_set()
        win.attributes("-topmost", True)
        
        win.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - 500) // 2
        y = self.winfo_y() + (self.winfo_height() - 550) // 2
        win.geometry(f"500x550+{x}+{y}")
        
        main_frame = ctk.CTkFrame(win, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=25, pady=25)
        
        ctk.CTkLabel(main_frame, text=L.get("2fa_settings_title", "2FA Settings"),
                    font=("Segoe UI", 22, "bold")).pack(pady=(0, 15))
        
        if is_enabled:
            status_text = L.get("2fa_status_enabled", "Enabled")
            status_color = "#2ECC71"
        else:
            status_text = L.get("2fa_status_disabled", "Disabled")
            status_color = "#FF4444"
        
        ctk.CTkLabel(main_frame, text=status_text, font=("Segoe UI", 15, "bold"),
                    text_color=status_color).pack(pady=(0, 20))
        
        ctk.CTkFrame(main_frame, height=2, fg_color="#2d6a4f").pack(fill="x", pady=10)
        
        if is_enabled:
            manager = get_totp_manager()
            backup_count = manager.get_backup_codes_count()
            
            ctk.CTkLabel(main_frame, text=L.get("2fa_backup_codes_info", "Backup Codes"),
                        font=("Segoe UI", 17, "bold")).pack(anchor="w", pady=(15, 8))
            
            ctk.CTkLabel(main_frame, text=L.get("2fa_backup_count", "Remaining backup codes: {0}").format(backup_count),
                        font=("Segoe UI", 13)).pack(anchor="w", pady=(0, 15))
            
            def generate_new_backup() -> None:
                from security.totp import TOTP, get_totp_manager
                
                # ИСПРАВЛЕНО: Безопасная проверка ответа на генерацию резервных кодов
                if CTkMessageBox.question(win, L.get("2fa_title", "Two-Factor Authentication"),
                    L.get("2fa_regenerate_backup_confirm", "Generating new backup codes will invalidate old ones.\n\nContinue?")) in [True, "Yes", "yes"]:
                    
                    code = self._verify_2fa_dialog(
                        L.get("2fa_verify_regenerate", "Enter 2FA code to generate new backup codes"),
                        L.get("2fa_enter_code", "Enter verification code:")
                    )
                    
                    if code:
                        secret = self.config.get_2fa_secret()
                        if secret:
                            secret_clean = secret.upper().replace(" ", "").replace("-", "")
                            totp = TOTP(secret_clean)
                            if totp.verify(code)[0]:
                                new_codes = totp.get_backup_codes(count=10, length=8)
                                manager = get_totp_manager()
                                manager.set_backup_codes(new_codes)
                                self.config.set_2fa_backup_hashes(manager.get_backup_codes_hashes())
                                self.config.save()
                                self._show_backup_codes(new_codes)
                                CTkMessageBox.info(win, L.get("2fa_title", "Two-Factor Authentication"),
                                                 L.get("2fa_backup_regenerated", "New backup codes generated successfully!"))
                                win.destroy()
                            else:
                                CTkMessageBox.error(win, L.get("err_title", "Error"),
                                                  L.get("2fa_invalid_code", "Invalid verification code."))
            
            ctk.CTkButton(main_frame, text=L.get("2fa_regenerate_backup", "Generate New Backup Codes"),
                         command=generate_new_backup, width=320, height=45, fg_color="#FF9800",
                         corner_radius=radius, font=("Segoe UI", 13, "bold")).pack(pady=15)
            
            ctk.CTkButton(main_frame, text=L.get("2fa_disable", "Disable 2FA"),
                         command=lambda: [win.destroy(), self._disable_2fa()],
                         width=320, height=45, fg_color="#8b0000", corner_radius=radius,
                         font=("Segoe UI", 13, "bold")).pack(pady=15)
        else:
            ctk.CTkLabel(main_frame, text=L.get("2fa_description", 
                      "Two-Factor Authentication adds an extra layer of security.\n\n"
                      "You will need to enter a 6-digit code from an authenticator app\n"
                      "every time you unlock the program."),
                      wraplength=420, justify="center", font=("Segoe UI", 12)).pack(pady=15)
            
            ctk.CTkButton(main_frame, text=L.get("2fa_enable", "Enable 2FA"),
                         command=lambda: [win.destroy(), self._setup_2fa()],
                         width=320, height=50, fg_color="#2d6a4f", corner_radius=radius,
                         font=("Segoe UI", 15, "bold")).pack(pady=25)
        
        ctk.CTkButton(main_frame, text=L.get("close", "Close"), command=win.destroy,
                     width=140, height=40, fg_color="#607D8B", corner_radius=radius,
                     font=("Segoe UI", 13, "bold")).pack(pady=20)
        
        win.after(100, lambda: win.attributes("-topmost", False))
    
    def _update_2fa_buttons(self) -> None:
        """Update 2FA button states in settings / Обновляет состояние кнопок 2FA в настройках / Оновлює стан кнопок 2FA в налаштуваннях"""
        try:
            if hasattr(self, '_2fa_status_label') and self._2fa_status_label and self._2fa_status_label.winfo_exists():
                L = LANGUAGES[self.current_lang]
                if self.config.is_2fa_enabled():
                    self._2fa_status_label.configure(
                        text=L.get("2fa_status_enabled", "Enabled"),
                        text_color="#2ECC71"
                    )
                else:
                    self._2fa_status_label.configure(
                        text=L.get("2fa_status_disabled", "Disabled"),
                        text_color="#FF4444"
                    )
        except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
            logger.debug(f"Update 2FA buttons error: {e}")
    
    def _update_2fa_indicator(self) -> None:
        """Update 2FA indicator in main window / Обновляет индикатор 2FA в главном окне / Оновлює індикатор 2FA в головному вікні"""
        try:
            if hasattr(self, '_2fa_indicator_label') and self._2fa_indicator_label and self._2fa_indicator_label.winfo_exists():
                L = LANGUAGES[self.current_lang]
                if self.config.is_2fa_enabled():
                    self._2fa_indicator_label.configure(
                        text=L.get("2fa_status_enabled", "2FA Enabled"),
                        text_color="#2ECC71"
                    )
                else:
                    self._2fa_indicator_label.configure(
                        text=L.get("2fa_status_disabled", "2FA Disabled"),
                        text_color="#888888"
                    )
        except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
            logger.debug(f"Update 2FA indicator error: {e}")