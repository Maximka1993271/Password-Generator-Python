"""
Master password mixin for SecurePassPro
"""
import time
import tkinter as tk
from gui.dialogs import CTkMessageBox, CTkInputDialog
from security.master import MasterPassword
from security.encryption import set_key_from_master, clear_master_key, reencrypt_all
from localization.lang import LANGUAGES
import customtkinter as ctk
from utils.helpers import get_global_radius, center_screen
from cryptography.exceptions import InvalidTag
from utils.logger import get_logger

logger = get_logger("master_mixin")


class MasterMixin:
    """Mixin class for master password management and lock screen"""
    
    def _update_master_status_label(self) -> None:
        """Обновить статус мастер-пароля"""
        try:
            if self._master_status_label and self._master_status_label.winfo_exists():
                L = LANGUAGES[self.current_lang]
                if MasterPassword.is_set():
                    self._master_status_label.configure(
                        text=f"{L['master_current']} 🔒 {L['master_status_set']}", 
                        text_color="#2ECC71"
                    )
                else:
                    self._master_status_label.configure(
                        text=f"{L['master_current']} 🔓 {L['master_status_not_set']}", 
                        text_color="#FF4444"
                    )
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Update master status label error: {e}")
    
    def _update_master_buttons(self) -> None:
        """Обновить состояние кнопки мастер-пароля"""
        try:
            if not self._master_set_btn or not self._master_set_btn.winfo_exists():
                return
            L = LANGUAGES[self.current_lang]
            if MasterPassword.is_set():
                self._master_set_btn.configure(
                    text="🔒 " + L["master_btn_remove"],
                    fg_color="#8b0000",
                    hover_color="#aa2222",
                    command=self._remove_master_password
                )
            else:
                self._master_set_btn.configure(
                    text="🔓 " + L["master_btn_set"],
                    fg_color="#2d6a4f",
                    hover_color="#40916c",
                    command=self._set_master_password
                )
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Update master buttons error: {e}")
    
    def _set_master_password(self) -> None:
        """Установить новый мастер-пароль (диалог центрирован относительно главного окна)"""
        L = LANGUAGES[self.current_lang]
        actual_theme = self._get_actual_theme()
        
        if MasterPassword.is_set():
            CTkMessageBox.warning(self, L["master_title"], L.get("master_already_set", "Мастер-пароль уже установлен!"))
            return
        
        # Диалог центрируется относительно главного окна (self)
        new_pwd = CTkInputDialog.ask(
            self,  # parent - главное окно
            L["master_set_title"], 
            L["master_set_prompt"], 
            show="*", 
            theme=actual_theme, 
            lang=self.current_lang
        )
        if not new_pwd or new_pwd == "":
            return
        
        if len(new_pwd) < 8:
            CTkMessageBox.error(self, L.get("err_title", "Error"), L.get("master_too_short", "Пароль слишком короткий. Минимум 8 символов."))
            return
        
        import re
        if not re.search(r"[0-9!@#$%^&*()_+=\[\]{};:,.<>/?@%-]", new_pwd):
            CTkMessageBox.error(self, L.get("err_title", "Error"), L.get("master_weak", "Пароль слишком простой. Добавьте цифру или спецсимвол."))
            return
        
        confirm = CTkInputDialog.ask(
            self,  # parent - главное окно
            L["master_set_title"], 
            L["master_confirm"], 
            show="*", 
            theme=actual_theme, 
            lang=self.current_lang
        )
        if not confirm:
            return
        
        if new_pwd != confirm:
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["master_mismatch"])
            return
        
        try:
            MasterPassword.set_password(new_pwd)
            reencrypt_all(old_master=None, new_master=new_pwd)
            set_key_from_master(new_pwd)
            CTkMessageBox.info(self, L["master_title"], L["master_set_ok"])
        except (ValueError, IOError, OSError, InvalidTag) as exc:
            logger.error(f"Failed to set master password: {exc}")
            try:
                MasterPassword.remove()
            except (OSError, IOError):
                pass
            try:
                clear_master_key()
            except:
                pass
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"{L.get('master_set_error', 'Не удалось установить мастер-пароль.')}\n{exc}")
            return
        
        self._update_master_buttons()
        self._update_master_status_label()
    
    def _remove_master_password(self) -> None:
        """Удалить мастер-пароль (диалоги центрированы относительно главного окна)"""
        L = LANGUAGES[self.current_lang]
        
        if not MasterPassword.is_set():
            CTkMessageBox.info(self, L["master_title"], L.get("master_not_set", "Мастер-пароль не установлен."))
            return
        
        # Подтверждение удаления на текущем языке
        if not CTkMessageBox.question(self, L["master_title"], L.get("master_remove_confirm", "Вы уверены, что хотите удалить мастер-пароль?")):
            return
        
        # Запрос текущего пароля
        current = CTkInputDialog.ask(
            self,  # parent - главное окно
            L["master_title"], 
            L.get("master_remove_prompt", "Введите текущий мастер-пароль для подтверждения:"), 
            show="*", 
            theme=self._get_actual_theme(), 
            lang=self.current_lang
        )
        if not current or current == "":
            return
        
        if not MasterPassword.verify(current):
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["master_wrong"].format(1, 1))
            return
        
        try:
            reencrypt_all(old_master=current, new_master=None)
            MasterPassword.remove()
            clear_master_key()
            CTkMessageBox.info(self, L["master_title"], L["master_removed"])
        except (ValueError, IOError, OSError, InvalidTag) as exc:
            logger.error(f"Failed to remove master password: {exc}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"{L.get('master_remove_error', 'Не удалось удалить мастер-пароль.')}\n{exc}")
            return
        
        self._update_master_buttons()
        self._update_master_status_label()
    
    def _show_lock_screen(self) -> bool:
        """Показать экран блокировки"""
        L = LANGUAGES[self.current_lang]
        theme = self._get_actual_theme()
        colors = self._get_colors_for_theme(theme)
        radius = get_global_radius()
        
        win = ctk.CTkToplevel(self)
        win.title(L["win_title"])
        win.resizable(False, False)
        win.grab_set()
        win.attributes("-topmost", True)
        
        center_screen(win, 400, 300)
        win.configure(fg_color=colors["bg"])
        
        ctk.CTkLabel(win, text="🔒", font=("Segoe UI", 48), text_color="#4EC9B0").pack(pady=(20, 5))
        ctk.CTkLabel(win, text=L.get("auto_lock_title", "Program Locked"), 
                    font=("Segoe UI", 16, "bold"), text_color=colors["label_text"]).pack(pady=(0, 15))
        
        entry = ctk.CTkEntry(win, width=300, height=40, font=("Segoe UI", 14), show="*",
                            fg_color=colors["entry_bg"], text_color=colors["fg"], corner_radius=radius)
        entry.pack(pady=(0, 15))
        entry.focus_set()
        
        result = [False]
        status_label = ctk.CTkLabel(win, text="", font=("Segoe UI", 11), text_color="#E24B4A")
        status_label.pack(pady=(0, 5))

        def update_lockout_status():
            info = MasterPassword.get_lockout_info()
            if info['is_locked']:
                status_label.configure(text=f"⏳ {L.get('lock_wait', 'Подождите')} {info['lockout_seconds']} сек...")
                entry.configure(state="disabled")
                unlock_btn.configure(state="disabled")
                win.after(1000, update_lockout_status)
            else:
                entry.configure(state="normal")
                unlock_btn.configure(state="normal")
                entry.focus_set()
                if info['attempts'] > 0:
                    status_label.configure(text=L["master_wrong"].format(info['attempts'], 5))

        def on_unlock():
            if MasterPassword.get_remaining_lockout_time() > 0:
                update_lockout_status()
                return
            
            pwd = entry.get()
            try:
                if MasterPassword.verify(pwd):
                    set_key_from_master(pwd)
                    result[0] = True
                    win.destroy()
                    return
            except (ValueError, TypeError, AttributeError, InvalidTag) as e:
                logger.error(f"LockScreen verification error: {e}")
            
            info = MasterPassword.get_lockout_info()
            if info['is_locked']:
                status_label.configure(text=f"⏳ {L.get('lock_wait', 'Подождите')} {info['lockout_seconds']} сек...")
                entry.delete(0, "end")
                entry.configure(state="disabled")
                unlock_btn.configure(state="disabled")
                win.after(1000, update_lockout_status)
            else:
                status_label.configure(text=L["master_wrong"].format(info['attempts'], 5))
                entry.delete(0, "end")
                entry.focus_set()

        entry.bind("<Return>", lambda e: on_unlock())

        unlock_btn = ctk.CTkButton(win, text=L.get("unlock", "Разблокировать"),
                                    width=140, height=36, command=on_unlock,
                                    fg_color="#2d6a4f", hover_color="#40916c",
                                    corner_radius=17, font=("Segoe UI", 12, "bold"))
        unlock_btn.pack(pady=(5, 20))

        win.protocol("WM_DELETE_WINDOW", lambda: None)
        win.after(100, lambda: win.attributes("-topmost", False))
        update_lockout_status()
        
        try:
            self.wait_window(win)
        except (tk.TclError, RuntimeError) as e:
            logger.debug(f"Lock screen wait error: {e}")
        
        return result[0]