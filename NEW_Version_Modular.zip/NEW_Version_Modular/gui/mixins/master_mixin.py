"""
Master password mixin for SecurePassPro
"""
import time
from gui.dialogs import CTkMessageBox, CTkInputDialog
from security.master import MasterPassword
from security.encryption import set_key_from_master, clear_master_key, reencrypt_all
from localization.lang import LANGUAGES
import customtkinter as ctk
from utils.helpers import get_global_radius, center_screen
from cryptography.exceptions import InvalidTag


class MasterMixin:
    """Mixin class for master password management and lock screen"""
    
    def _update_master_status_label(self) -> None:
        if self._master_status_label and self._master_status_label.winfo_exists():
            L = LANGUAGES[self.current_lang]
            if MasterPassword.is_set():
                self._master_status_label.configure(text=f"{L['master_current']} 🔒 {L['master_status_set']}", text_color="#2ECC71")
            else:
                self._master_status_label.configure(text=f"{L['master_current']} 🔓 {L['master_status_not_set']}", text_color="#FF4444")
    
    def _update_master_buttons(self) -> None:
        if not self._master_set_btn or not self._master_set_btn.winfo_exists():
            return
        L = LANGUAGES[self.current_lang]
        if MasterPassword.is_set():
            self._master_set_btn.configure(
                text="🔒 " + L["master_btn_remove"],
                fg_color="#8b0000",
                hover_color="#8b0000",
                command=self._remove_master_password
            )
        else:
            self._master_set_btn.configure(
                text="🔓 " + L["master_btn_set"],
                fg_color="#2d6a4f",
                hover_color="#2d6a4f",
                command=self._toggle_master_password
            )
    
    def _toggle_master_password(self) -> None:
        L = LANGUAGES[self.current_lang]
        actual_theme = self._get_actual_theme()
        
        if MasterPassword.is_set():
            current = CTkInputDialog.ask(self, L["master_title"], L["master_prompt"], show="*", theme=actual_theme, lang=self.current_lang)
            if current is None:
                return
            if not MasterPassword.verify(current):
                CTkMessageBox.error(self, L.get("err_title", "Error"), L["master_wrong"].format(1, 1))
                return
            try:
                reencrypt_all(old_master=current, new_master=None)
                MasterPassword.remove()
                clear_master_key()
            except (ValueError, IOError, OSError) as exc:
                CTkMessageBox.error(
                    self,
                    L.get("err_title", "Error"),
                    L.get("master_remove_error", "Не удалось удалить мастер-пароль.") + f"\n\n{exc}"
                )
                return
            CTkMessageBox.info(self, L["master_title"], L["master_removed"])
        else:
            new_pwd = CTkInputDialog.ask(self, L["master_set_title"], L["master_set_prompt"], show="*", theme=actual_theme, lang=self.current_lang)
            if new_pwd is None or new_pwd == "":
                return
            import re as _re
            if len(new_pwd) < 8:
                CTkMessageBox.error(self, L.get("err_title", "Error"),
                    L.get("master_too_short", "Пароль слишком короткий. Минимум 8 символов."))
                return
            if not _re.search(r"[0-9!@#$%^&*()_+=\[\]{};:,.<>/?@%-]", new_pwd):
                CTkMessageBox.error(self, L.get("err_title", "Error"),
                    L.get("master_weak", "Пароль слишком простой. Добавьте цифру или спецсимвол."))
                return
            confirm = CTkInputDialog.ask(self, L["master_set_title"], L["master_confirm"], show="*", theme=actual_theme, lang=self.current_lang)
            if confirm is None:
                return
            if new_pwd != confirm:
                CTkMessageBox.error(self, L.get("err_title", "Error"), L["master_mismatch"])
                return
            try:
                MasterPassword.set_password(new_pwd)
                reencrypt_all(old_master=None, new_master=new_pwd)
                set_key_from_master(new_pwd)
            except (ValueError, IOError, OSError) as exc:
                MasterPassword.remove()
                clear_master_key()
                CTkMessageBox.error(
                    self,
                    L.get("err_title", "Error"),
                    L.get("master_set_error", "Не удалось установить мастер-пароль.") + f"\n\n{exc}"
                )
                return
            CTkMessageBox.info(self, L["master_title"], L["master_set_ok"])
        
        self._update_master_buttons()
        self._update_master_status_label()
    
    def _remove_master_password(self) -> None:
        L = LANGUAGES[self.current_lang]
        if not MasterPassword.is_set():
            return
        if CTkMessageBox.question(self, L["master_title"], L["master_remove_confirm"]):
            current = CTkInputDialog.ask(self, L["master_title"], L["master_prompt"],
                                         show="*", theme=self._get_actual_theme(),
                                         lang=self.current_lang)
            if not current or not MasterPassword.verify(current):
                CTkMessageBox.error(self, L.get("err_title", "Error"), L["master_wrong"].format(1, 1))
                return
            try:
                reencrypt_all(old_master=current, new_master=None)
                MasterPassword.remove()
                clear_master_key()
            except (ValueError, IOError, OSError) as exc:
                CTkMessageBox.error(
                    self,
                    L.get("err_title", "Error"),
                    L.get("master_remove_error", "Не удалось удалить мастер-пароль.") + f"\n\n{exc}"
                )
                return
            CTkMessageBox.info(self, L["master_title"], L["master_removed"])
            self._update_master_buttons()
            self._update_master_status_label()
    
    def _show_lock_screen(self) -> bool:
        L = LANGUAGES[self.current_lang]
        theme = self._get_actual_theme()
        colors = self._get_colors_for_theme(theme)
        radius = get_global_radius()
        
        win = ctk.CTkToplevel(self)
        win.title(L["win_title"])
        win.resizable(False, False)
        win.grab_set()
        win.attributes("-topmost", True)
        
        w, h = 450, 380
        center_screen(win, w, h)
        win.configure(fg_color=colors["bg"])
        
        ctk.CTkLabel(win, text="🔒", font=("Segoe UI", 64), text_color="#4EC9B0").pack(pady=(30, 10))
        ctk.CTkLabel(win, text=L.get("auto_lock_title", "Program Locked"), 
                    font=("Segoe UI", 18, "bold"), text_color=colors["label_text"]).pack(pady=(0, 10))
        
        entry = ctk.CTkEntry(win, width=340, height=45, font=("Segoe UI", 16), show="*",
                            fg_color=colors["entry_bg"], text_color=colors["fg"], corner_radius=radius)
        entry.pack(pady=(0, 20))
        entry.focus_set()
        
        result = [False]
        attempts = [0]
        MAX_ATT = 5
        status_label = ctk.CTkLabel(win, text="", font=("Segoe UI", 12), text_color="#E24B4A")
        status_label.pack(pady=(0, 4))

        def update_lockout_status():
            info = MasterPassword.get_lockout_info()
            if info['is_locked']:
                status_label.configure(text=f"⏳ {L.get('lock_wait', 'Подождите')} {info['lockout_seconds']} {L.get('seconds_short', 'сек')}...")
                entry.configure(state="disabled")
                unlock_btn.configure(state="disabled")
                win.after(1000, update_lockout_status)
            else:
                entry.configure(state="normal")
                unlock_btn.configure(state="normal")
                entry.focus_set()
                if info['attempts'] > 0:
                    status_label.configure(text=L["master_wrong"].format(info['attempts'], 5))
                else:
                    status_label.configure(text="")

        def on_unlock():
            if MasterPassword.get_remaining_lockout_time() > 0:
                update_lockout_status()
                return
            
            pwd = entry.get()
            try:
                if MasterPassword.verify(pwd):
                    set_key_from_master(pwd)
                    result[0] = True
                    win.destroy()
                    return
            except (ValueError, TypeError, AttributeError) as e:
                print(f"[LockScreen] Verification error: {e}")
            
            info = MasterPassword.get_lockout_info()
            if info['is_locked']:
                status_label.configure(text=f"⏳ {L.get('lock_wait', 'Подождите')} {info['lockout_seconds']} {L.get('seconds_short', 'сек')}...")
                entry.delete(0, "end")
                entry.configure(state="disabled")
                unlock_btn.configure(state="disabled")
                win.after(1000, update_lockout_status)
            else:
                status_label.configure(text=L["master_wrong"].format(info['attempts'], 5))
                entry.delete(0, "end")
                entry.focus_set()

        entry.bind("<Return>", lambda e: on_unlock())

        unlock_btn = ctk.CTkButton(win, text=L.get("unlock", "Разблокировать"),
                                    width=160, height=40, command=on_unlock,
                                    fg_color="#2d6a4f", hover_color="#40916c",
                                    corner_radius=6, border_width=1,
                                    border_color="#1f543d",
                                    font=("Segoe UI", 13, "bold"))
        unlock_btn.pack(pady=(6, 30))

        win.protocol("WM_DELETE_WINDOW", lambda: None)
        win.after(100, lambda: win.attributes("-topmost", False))
        
        update_lockout_status()
        
        try:
            self.wait_window(win)
        except (tk.TclError, RuntimeError):
            pass
        
        return result[0]