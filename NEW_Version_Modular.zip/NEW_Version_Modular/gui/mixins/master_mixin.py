"""
Master password mixin for SecurePassPro
"""
import time
import tkinter as tk
import ctypes
from gui.dialogs import CTkMessageBox, CTkInputDialog
from security.master import MasterPassword
from security.encryption import set_key_from_master, clear_master_key, reencrypt_all
from localization.lang import LANGUAGES
import customtkinter as ctk
from utils.helpers import get_global_radius, center_screen
from cryptography.exceptions import InvalidTag
from utils.logger import get_logger

logger = get_logger("master_mixin")


class MasterMixin:
    """Mixin class for master password management and lock screen"""

    def _update_master_status_label(self) -> None:
        """Обновить статус мастер-пароля"""
        try:
            if self._master_status_label and self._master_status_label.winfo_exists():
                L = LANGUAGES[self.current_lang]
                if MasterPassword.is_set():
                    self._master_status_label.configure(
                        text=f"{L['master_current']} {L['master_status_set']}",
                        text_color="#2ECC71"
                    )
                else:
                    self._master_status_label.configure(
                        text=f"{L['master_current']} {L['master_status_not_set']}",
                        text_color="#FF4444"
                    )
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Update master status label error: {e}")

    def _update_master_buttons(self) -> None:
        """Обновить состояние кнопки мастер-пароля"""
        try:
            if not self._master_set_btn or not self._master_set_btn.winfo_exists():
                return
            L = LANGUAGES[self.current_lang]
            if MasterPassword.is_set():
                self._master_set_btn.configure(
                    text=L["master_btn_remove"],
                    fg_color="#8b0000",
                    hover_color="#aa2222",
                    command=self._remove_master_password
                )
            else:
                self._master_set_btn.configure(
                    text=L["master_btn_set"],
                    fg_color="#2d6a4f",
                    hover_color="#40916c",
                    command=self._set_master_password
                )
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Update master buttons error: {e}")

    def _set_master_password(self) -> None:
        """Установить новый мастер-пароль"""
        L = LANGUAGES[self.current_lang]
        actual_theme = self._get_actual_theme()

        if MasterPassword.is_set():
            CTkMessageBox.warning(self, L["master_title"], L.get("master_already_set", "Master password already set!"))
            return

        new_pwd = CTkInputDialog.ask(
            self,
            L["master_set_title"],
            L["master_set_prompt"],
            show="*",
            theme=actual_theme,
            lang=self.current_lang
        )
        if not new_pwd or new_pwd == "":
            return

        if len(new_pwd) < 8:
            CTkMessageBox.error(self, L.get("err_title", "Error"), L.get("master_too_short", "Password too short. Minimum 8 characters."))
            return

        import re
        if not re.search(r"[0-9!@#$%^&*()_+=\[\]{};:,.<>/?@%-]", new_pwd):
            CTkMessageBox.error(self, L.get("err_title", "Error"), L.get("master_weak", "Password too weak. Add a digit or special character."))
            return

        confirm = CTkInputDialog.ask(
            self,
            L["master_set_title"],
            L["master_confirm"],
            show="*",
            theme=actual_theme,
            lang=self.current_lang
        )
        if not confirm:
            return

        if new_pwd != confirm:
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["master_mismatch"])
            return

        try:
            MasterPassword.set_password(new_pwd)
            reencrypt_all(old_master=None, new_master=new_pwd)
            set_key_from_master(new_pwd)
            CTkMessageBox.info(self, L["master_title"], L["master_set_ok"])
        except (ValueError, IOError, OSError, InvalidTag) as exc:
            logger.error(f"Failed to set master password: {exc}")
            try:
                MasterPassword.remove()
            except (OSError, IOError):
                pass
            try:
                clear_master_key()
            except (OSError, IOError, AttributeError):
                pass
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"{L.get('master_set_error', 'Failed to set master password.')}\n{exc}")
            return

        self._update_master_buttons()
        self._update_master_status_label()

    def _remove_master_password(self) -> None:
        """Удалить мастер-пароль"""
        L = LANGUAGES[self.current_lang]

        if not MasterPassword.is_set():
            CTkMessageBox.info(self, L["master_title"], L.get("master_not_set", "Master password not set."))
            return

        if not CTkMessageBox.question(self, L["master_title"], L.get("master_remove_confirm", "Are you sure you want to remove the master password?")):
            return

        current = CTkInputDialog.ask(
            self,
            L["master_title"],
            L.get("master_remove_prompt", "Enter current master password to confirm:"),
            show="*",
            theme=self._get_actual_theme(),
            lang=self.current_lang
        )
        if not current or current == "":
            return

        if not MasterPassword.verify(current):
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["master_wrong"].format(1, 1))
            return

        try:
            reencrypt_all(old_master=current, new_master=None)
            MasterPassword.remove()
            clear_master_key()
            CTkMessageBox.info(self, L["master_title"], L["master_removed"])
        except (ValueError, IOError, OSError, InvalidTag) as exc:
            logger.error(f"Failed to remove master password: {exc}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"{L.get('master_remove_error', 'Failed to remove master password.')}\n{exc}")
            return

        self._update_master_buttons()
        self._update_master_status_label()

    def _minimize_window(self, window):
        """Сворачивает окно в панель задач"""
        try:
            hwnd = ctypes.windll.user32.GetParent(window.winfo_id())
            if not hwnd:
                hwnd = ctypes.windll.user32.GetAncestor(window.winfo_id(), 2)
            if hwnd:
                ctypes.windll.user32.ShowWindow(hwnd, 6)
            else:
                window.iconify()
        except (AttributeError, OSError, TypeError, tk.TclError) as e:
            logger.debug(f"Minimize error: {e}")
            window.iconify()

    def _show_lock_screen(self) -> bool:
        """Показать экран блокировки с работающей кнопкой сворачивания и корректным 2FA"""
        from security.totp import TOTP, get_totp_manager
        
        L = LANGUAGES[self.current_lang]
        theme = self._get_actual_theme()
        colors = self._get_colors_for_theme(theme)
        radius = get_global_radius()

        win = ctk.CTkToplevel(self)
        win.title(L["win_title"])
        
        self.withdraw()
        
        win.protocol("WM_DELETE_WINDOW", self.destroy)
        
        win.minsize(450, 480)
        win.maxsize(450, 480)
        
        win.attributes("-topmost", True)
        win.after(100, lambda: win.attributes("-topmost", False))
        
        win.geometry("450x480")
        win.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - 450) // 2
        y = self.winfo_y() + (self.winfo_height() - 480) // 2
        win.geometry(f"450x480+{x}+{y}")
        win.configure(fg_color=colors["bg"])

        main_frame = ctk.CTkFrame(win, fg_color="transparent")
        main_frame.pack(expand=True, fill="both", padx=30, pady=20)

        ctk.CTkLabel(main_frame, text="", font=("Segoe UI", 48), text_color="#4EC9B0").pack(pady=(0, 5))
        ctk.CTkLabel(main_frame, text=L.get("auto_lock_title", "Program Locked"),
                    font=("Segoe UI", 18, "bold"), text_color=colors["label_text"]).pack(pady=(0, 10))

        ctk.CTkLabel(main_frame, text=L.get("master_prompt", "Enter master password:"),
                    font=("Segoe UI", 13), text_color=colors["label_text"]).pack()
        
        pwd_entry = ctk.CTkEntry(main_frame, width=320, height=45, font=("Segoe UI", 14), show="*",
                                fg_color=colors["entry_bg"], text_color=colors["fg"], corner_radius=radius)
        pwd_entry.pack(pady=(5, 10))
        pwd_entry.focus_set()

        _2fa_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        
        code_label = ctk.CTkLabel(_2fa_frame, text=L.get("2fa_enter_code", "Enter verification code:"),
                                  font=("Segoe UI", 13), text_color=colors["label_text"])
        code_label.pack()
        
        code_entry = ctk.CTkEntry(_2fa_frame, width=220, height=45, font=("Consolas", 20, "bold"),
                                 justify="center", fg_color=colors["entry_bg"], text_color=colors["fg"],
                                 corner_radius=radius)
        code_entry.pack(pady=(5, 0))
        code_entry.configure(state="disabled")

        status_label = ctk.CTkLabel(main_frame, text="", font=("Segoe UI", 12), text_color="#E24B4A")
        status_label.pack(pady=(5, 5))

        unlock_btn = ctk.CTkButton(main_frame, text=L.get("unlock", "Unlock"),
                                   width=160, height=45, fg_color="#2d6a4f", 
                                   hover_color="#40916c", corner_radius=radius, 
                                   font=("Segoe UI", 14, "bold"))
        unlock_btn.pack(pady=(10, 15))

        result = [False]
        master_verified = [False]

        def unlock_success():
            result[0] = True
            self.deiconify()
            win.destroy()

        def update_status():
            info = MasterPassword.get_lockout_info()
            if info['is_locked']:
                status_label.configure(text=f"{L.get('lock_wait', 'Please wait')} {info['lockout_seconds']} {L.get('seconds_short', 'sec')}...")
                pwd_entry.configure(state="disabled")
                code_entry.configure(state="disabled")
                unlock_btn.configure(state="disabled")
                win.after(1000, update_status)
            else:
                pwd_entry.configure(state="normal")
                unlock_btn.configure(state="normal")
                pwd_entry.focus_set()
                if info['attempts'] > 0 and not master_verified[0]:
                    status_label.configure(text=L["master_wrong"].format(info['attempts'], 5))
                else:
                    status_label.configure(text="")

        def check_master_password():
            pwd = pwd_entry.get()
            if MasterPassword.verify(pwd):
                set_key_from_master(pwd)
                master_verified[0] = True
                status_label.configure(text="Master password verified", text_color="#2ECC71")
                
                if self.config.is_2fa_enabled():
                    code_entry.configure(state="normal")
                    code_entry.focus_set()
                    unlock_btn.configure(text=L.get("2fa_verify_title", "Verify 2FA"))
                    pwd_entry.configure(state="disabled")
                    _2fa_frame.pack(pady=(10, 5))
                else:
                    unlock_success()
            else:
                info = MasterPassword.get_lockout_info()
                status_label.configure(text=L["master_wrong"].format(info['attempts'], 5))
                pwd_entry.delete(0, "end")
                pwd_entry.focus_set()

        def check_2fa():
            code_raw = code_entry.get().strip()
            code_clean = ''.join(filter(str.isdigit, code_raw))
            
            if len(code_clean) != 6:
                status_label.configure(text=L.get("2fa_invalid_code", "Invalid code - enter 6 digits"))
                code_entry.delete(0, "end")
                code_entry.focus_set()
                return
            
            secret = self.config.get_2fa_secret()
            if secret:
                secret_clean = secret.upper().replace(" ", "").replace("-", "")
                totp = TOTP(secret_clean)
                is_valid, _ = totp.verify(code_clean)
                if is_valid:
                    self.config.set_2fa_last_verified()
                    unlock_success()
                    return
            
            manager = get_totp_manager()
            if manager.verify_backup_code(code_clean):
                self.config.set_2fa_backup_hashes(manager.get_backup_codes_hashes())
                self.config.save()
                CTkMessageBox.warning(win, L.get("2fa_title", "2FA"), 
                                     L.get("2fa_backup_used", "Backup code used!"))
                unlock_success()
                return
            
            status_label.configure(text=L.get("2fa_invalid_code", "Invalid verification code"))
            code_entry.delete(0, "end")
            code_entry.focus_set()

        def on_unlock():
            if MasterPassword.get_remaining_lockout_time() > 0:
                update_status()
                return
            
            if master_verified[0] and self.config.is_2fa_enabled():
                check_2fa()
            else:
                check_master_password()

        unlock_btn.configure(command=on_unlock)

        pwd_entry.bind("<Return>", lambda e: on_unlock())
        code_entry.bind("<Return>", lambda e: on_unlock())

        update_status()

        try:
            self.wait_window(win)
        except (tk.TclError, RuntimeError) as e:
            logger.debug(f"Lock screen wait error: {e}")

        return result[0]

    # ==================== 2FA МЕТОДЫ ====================

    def _setup_2fa(self) -> None:
        """Настройка двухфакторной аутентификации"""
        from security.totp import TOTP, get_totp_manager
        from utils.qr_utils import QRUtils
        
        L = LANGUAGES[self.current_lang]
        
        if not MasterPassword.is_set():
            CTkMessageBox.warning(
                self,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_master_required", "Please set a master password before enabling 2FA.")
            )
            return
        
        if self.config.is_2fa_enabled():
            result = CTkMessageBox.question(
                self,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_disable_confirm", "2FA is already enabled.\n\nDo you want to disable it?")
            )
            if result:
                self._disable_2fa()
            return
        
        account_name = self.config.get_2fa_account_name()
        if not account_name:
            account_name = "SecurePassPro_User"
        
        totp = TOTP()
        secret = totp.secret
        provisioning_uri = TOTP.get_provisioning_uri(secret, account_name, "SecurePassPro")
        
        QRUtils.show_qr_window(
            self,
            provisioning_uri,
            secret,
            self.current_lang,
            L.get("2fa_setup_title", "2FA Setup")
        )
        
        code = self._verify_2fa_dialog(
            L.get("2fa_verify_title", "Verify 2FA"),
            L.get("2fa_enter_verification", "Enter the 6-digit code from your authenticator app:")
        )
        
        if not code:
            CTkMessageBox.info(
                self,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_setup_cancelled", "2FA setup cancelled.")
            )
            return
        
        code_clean = ''.join(filter(str.isdigit, code))
        
        if totp.verify(code_clean)[0]:
            backup_codes = totp.get_backup_codes(count=10, length=8)
            
            manager = get_totp_manager()
            manager.enable_2fa(secret)
            manager.set_backup_codes(backup_codes)
            manager.set_account_name(account_name)
            
            self.config.set_2fa_enabled(True)
            self.config.set_2fa_secret(secret)
            self.config.set_2fa_backup_hashes(manager.get_backup_codes_hashes())
            self.config.set_2fa_account_name(account_name)
            self.config.set_2fa_setup_completed(True)
            self.config.set_2fa_last_verified()
            self.config.save()
            
            self._show_backup_codes(backup_codes)
            
            CTkMessageBox.info(
                self,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_enabled_success", "Two-Factor Authentication has been enabled successfully!\n\nPlease save your backup codes in a safe place.")
            )
            
            self._update_2fa_buttons()
            self._update_2fa_indicator()
        else:
            CTkMessageBox.error(
                self,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_invalid_code", "Invalid verification code. Please try again.")
            )
    
    def _disable_2fa(self) -> None:
        """Отключает двухфакторную аутентификацию"""
        from security.totp import get_totp_manager
        
        L = LANGUAGES[self.current_lang]
        
        if not CTkMessageBox.question(
            self,
            L.get("2fa_title", "Two-Factor Authentication"),
            L.get("2fa_disable_warning", "WARNING: Disabling 2FA will make your account less secure!\n\nAre you sure you want to disable 2FA?")
        ):
            return
        
        code = self._verify_2fa_dialog(
            L.get("2fa_verify_disable", "Enter 2FA code to disable"),
            L.get("2fa_enter_code", "Enter verification code:")
        )
        
        if not code:
            return
        
        code_clean = ''.join(filter(str.isdigit, code))
        
        from security.totp import TOTP
        secret = self.config.get_2fa_secret()
        if secret:
            secret_clean = secret.upper().replace(" ", "").replace("-", "")
            totp = TOTP(secret_clean)
            if totp.verify(code_clean)[0]:
                manager = get_totp_manager()
                manager.disable_2fa()
                
                self.config.clear_2fa()
                self.config.save()
                
                CTkMessageBox.info(
                    self,
                    L.get("2fa_title", "Two-Factor Authentication"),
                    L.get("2fa_disabled_success", "Two-Factor Authentication has been disabled.")
                )
                
                self._update_2fa_buttons()
                self._update_2fa_indicator()
            else:
                CTkMessageBox.error(
                    self,
                    L.get("2fa_title", "Two-Factor Authentication"),
                    L.get("2fa_invalid_code", "Invalid verification code.")
                )
        else:
            manager = get_totp_manager()
            manager.disable_2fa()
            self.config.clear_2fa()
            self.config.save()
            
            CTkMessageBox.info(
                self,
                L.get("2fa_title", "Two-Factor Authentication"),
                L.get("2fa_disabled_success", "Two-Factor Authentication has been disabled.")
            )
            self._update_2fa_buttons()
            self._update_2fa_indicator()
    
    def _verify_2fa_dialog(self, title: str, prompt: str) -> str:
        """Показывает диалог для ввода 2FA кода"""
        theme = self._get_actual_theme()
        
        dialog = ctk.CTkToplevel(self)
        dialog.title(title)
        dialog.geometry("450x350")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        dialog.attributes("-topmost", True)
        
        dialog.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - 450) // 2
        y = self.winfo_y() + (self.winfo_height() - 350) // 2
        dialog.geometry(f"450x350+{x}+{y}")
        
        if theme == "light":
            bg_color = "#F3F3F3"
            fg_color = "#000000"
            entry_bg = "#FFFFFF"
        else:
            bg_color = "#1d1e1e"
            fg_color = "#FFFFFF"
            entry_bg = "#2b2b2b"
        
        dialog.configure(fg_color=bg_color)
        
        main_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=25, pady=25)
        
        ctk.CTkLabel(main_frame, text="", font=("Segoe UI", 40), text_color="#4EC9B0").pack(pady=(0, 15))
        ctk.CTkLabel(main_frame, text=prompt, font=("Segoe UI", 14), text_color=fg_color, wraplength=350).pack(pady=(0, 20))
        
        entry = ctk.CTkEntry(main_frame, width=250, height=50, font=("Consolas", 24, "bold"),
                            justify="center", fg_color=entry_bg, text_color=fg_color, corner_radius=15)
        entry.pack(pady=(0, 20))
        entry.focus_set()
        
        result = [None]
        
        def on_ok():
            code = entry.get().strip()
            code_clean = ''.join(filter(str.isdigit, code))
            if len(code_clean) == 6:
                result[0] = code_clean
                dialog.destroy()
            else:
                entry.configure(border_color="#E24B4A", border_width=2)
                dialog.after(200, lambda: entry.configure(border_color=""))
                entry.delete(0, "end")
                entry.focus_set()
        
        def on_cancel():
            dialog.destroy()
        
        btn_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        btn_frame.pack()
        
        ctk.CTkButton(btn_frame, text=LANGUAGES[self.current_lang].get("ok", "Verify"),
                     command=on_ok, width=130, height=40, fg_color="#2d6a4f",
                     corner_radius=20, font=("Segoe UI", 13, "bold")).pack(side="left", padx=15)
        
        ctk.CTkButton(btn_frame, text=LANGUAGES[self.current_lang].get("cancel", "Cancel"),
                     command=on_cancel, width=130, height=40, fg_color="#8b0000",
                     corner_radius=20, font=("Segoe UI", 13, "bold")).pack(side="left", padx=15)
        
        entry.bind("<Return>", lambda e: on_ok())
        entry.bind("<Escape>", lambda e: on_cancel())
        
        dialog.after(100, lambda: dialog.attributes("-topmost", False))
        
        self.wait_window(dialog)
        
        return result[0]
    
    def _show_backup_codes(self, backup_codes: list) -> None:
        """Показывает резервные коды в отдельном окне"""
        L = LANGUAGES[self.current_lang]
        theme = self._get_actual_theme()
        radius = get_global_radius()
        
        win = ctk.CTkToplevel(self)
        win.title(L.get("2fa_backup_codes", "Backup Codes"))
        win.geometry("550x600")
        win.resizable(False, False)
        win.transient(self)
        win.grab_set()
        win.attributes("-topmost", True)
        
        win.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - 550) // 2
        y = self.winfo_y() + (self.winfo_height() - 600) // 2
        win.geometry(f"550x600+{x}+{y}")
        
        main_frame = ctk.CTkFrame(win, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=25, pady=25)
        
        ctk.CTkLabel(main_frame, text=L.get("2fa_backup_codes", "Backup Codes"),
                    font=("Segoe UI", 20, "bold")).pack(pady=(0, 15))
        
        warning_frame = ctk.CTkFrame(main_frame, fg_color="#3a2a0a", corner_radius=12)
        warning_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(warning_frame,
                    text=L.get("2fa_backup_warning_detailed", 
                               "Store these codes in a safe place!\nEach code can be used only once to recover access."),
                    font=("Segoe UI", 12), text_color="#FFA500", justify="center").pack(pady=12, padx=15)
        
        codes_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        codes_frame.pack(pady=10)
        
        left_frame = ctk.CTkFrame(codes_frame, fg_color="transparent")
        left_frame.pack(side="left", padx=15)
        
        right_frame = ctk.CTkFrame(codes_frame, fg_color="transparent")
        right_frame.pack(side="left", padx=15)
        
        half = len(backup_codes) // 2 + len(backup_codes) % 2
        for i, code in enumerate(backup_codes):
            target = left_frame if i < half else right_frame
            code_text = code if '-' in code else f"{code[:4]}-{code[4:]}"
            
            ctk.CTkLabel(target, text=code_text, font=("Consolas", 16, "bold"),
                        fg_color=("#2b2b2b" if theme == "dark" else "#e0e0e0"),
                        corner_radius=10, padx=20, pady=8).pack(pady=6)
        
        def copy_all_codes():
            all_codes = "\n".join(backup_codes)
            win.clipboard_clear()
            win.clipboard_append(all_codes)
            copy_btn.configure(text=L.get("copied", "Copied!"))
            win.after(2000, lambda: copy_btn.configure(text=L.get("copy_all", "Copy All")))
        
        copy_btn = ctk.CTkButton(main_frame, text=L.get("copy_all", "Copy All"),
                                command=copy_all_codes, width=180, height=40, fg_color="#2d6a4f",
                                corner_radius=radius, font=("Segoe UI", 13, "bold"))
        copy_btn.pack(pady=15)
        
        ctk.CTkButton(main_frame, text=L.get("ok", "OK"), command=win.destroy,
                     width=140, height=40, fg_color="#8b0000", corner_radius=radius,
                     font=("Segoe UI", 13, "bold")).pack(pady=10)
        
        win.after(100, lambda: win.attributes("-topmost", False))
        win.focus_force()
    
    def _show_2fa_settings(self) -> None:
        """Показывает окно настроек 2FA"""
        from security.totp import get_totp_manager
        
        L = LANGUAGES[self.current_lang]
        theme = self._get_actual_theme()
        radius = get_global_radius()
        
        is_enabled = self.config.is_2fa_enabled()
        
        win = ctk.CTkToplevel(self)
        win.title(L.get("2fa_settings_title", "2FA Settings"))
        win.geometry("500x550")
        win.resizable(False, False)
        win.transient(self)
        win.grab_set()
        win.attributes("-topmost", True)
        
        win.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - 500) // 2
        y = self.winfo_y() + (self.winfo_height() - 550) // 2
        win.geometry(f"500x550+{x}+{y}")
        
        main_frame = ctk.CTkFrame(win, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=25, pady=25)
        
        ctk.CTkLabel(main_frame, text=L.get("2fa_settings_title", "2FA Settings"),
                    font=("Segoe UI", 22, "bold")).pack(pady=(0, 15))
        
        if is_enabled:
            status_text = L.get("2fa_status_enabled", "Enabled")
            status_color = "#2ECC71"
        else:
            status_text = L.get("2fa_status_disabled", "Disabled")
            status_color = "#FF4444"
        
        ctk.CTkLabel(main_frame, text=status_text, font=("Segoe UI", 15, "bold"),
                    text_color=status_color).pack(pady=(0, 20))
        
        ctk.CTkFrame(main_frame, height=2, fg_color="#2d6a4f").pack(fill="x", pady=10)
        
        if is_enabled:
            manager = get_totp_manager()
            backup_count = manager.get_backup_codes_count()
            
            ctk.CTkLabel(main_frame, text=L.get("2fa_backup_codes_info", "Backup Codes"),
                        font=("Segoe UI", 17, "bold")).pack(anchor="w", pady=(15, 8))
            
            ctk.CTkLabel(main_frame, text=L.get("2fa_backup_count", "Remaining backup codes: {0}").format(backup_count),
                        font=("Segoe UI", 13)).pack(anchor="w", pady=(0, 15))
            
            def generate_new_backup():
                from security.totp import TOTP, get_totp_manager
                
                if CTkMessageBox.question(win, L.get("2fa_title", "Two-Factor Authentication"),
                    L.get("2fa_regenerate_backup_confirm", "Generating new backup codes will invalidate old ones.\n\nContinue?")):
                    
                    code = self._verify_2fa_dialog(
                        L.get("2fa_verify_regenerate", "Enter 2FA code to generate new backup codes"),
                        L.get("2fa_enter_code", "Enter verification code:")
                    )
                    
                    if code:
                        secret = self.config.get_2fa_secret()
                        if secret:
                            secret_clean = secret.upper().replace(" ", "").replace("-", "")
                            totp = TOTP(secret_clean)
                            if totp.verify(code)[0]:
                                new_codes = totp.get_backup_codes(count=10, length=8)
                                manager = get_totp_manager()
                                manager.set_backup_codes(new_codes)
                                self.config.set_2fa_backup_hashes(manager.get_backup_codes_hashes())
                                self.config.save()
                                self._show_backup_codes(new_codes)
                                CTkMessageBox.info(win, L.get("2fa_title", "Two-Factor Authentication"),
                                                 L.get("2fa_backup_regenerated", "New backup codes generated successfully!"))
                                win.destroy()
                            else:
                                CTkMessageBox.error(win, L.get("err_title", "Error"),
                                                  L.get("2fa_invalid_code", "Invalid verification code."))
            
            ctk.CTkButton(main_frame, text=L.get("2fa_regenerate_backup", "Generate New Backup Codes"),
                         command=generate_new_backup, width=320, height=45, fg_color="#FF9800",
                         corner_radius=radius, font=("Segoe UI", 13, "bold")).pack(pady=15)
            
            ctk.CTkButton(main_frame, text=L.get("2fa_disable", "Disable 2FA"),
                         command=lambda: [win.destroy(), self._disable_2fa()],
                         width=320, height=45, fg_color="#8b0000", corner_radius=radius,
                         font=("Segoe UI", 13, "bold")).pack(pady=15)
        else:
            ctk.CTkLabel(main_frame, text=L.get("2fa_description", 
                      "Two-Factor Authentication adds an extra layer of security.\n\n"
                      "You will need to enter a 6-digit code from an authenticator app\n"
                      "every time you unlock the program."),
                      wraplength=420, justify="center", font=("Segoe UI", 12)).pack(pady=15)
            
            ctk.CTkButton(main_frame, text=L.get("2fa_enable", "Enable 2FA"),
                         command=lambda: [win.destroy(), self._setup_2fa()],
                         width=320, height=50, fg_color="#2d6a4f", corner_radius=radius,
                         font=("Segoe UI", 15, "bold")).pack(pady=25)
        
        ctk.CTkButton(main_frame, text=L.get("close", "Close"), command=win.destroy,
                     width=140, height=40, fg_color="#607D8B", corner_radius=radius,
                     font=("Segoe UI", 13, "bold")).pack(pady=20)
        
        win.after(100, lambda: win.attributes("-topmost", False))
    
    def _update_2fa_buttons(self) -> None:
        """Обновляет состояние кнопок 2FA в настройках"""
        try:
            if hasattr(self, '_2fa_status_label') and self._2fa_status_label and self._2fa_status_label.winfo_exists():
                L = LANGUAGES[self.current_lang]
                if self.config.is_2fa_enabled():
                    self._2fa_status_label.configure(
                        text=L.get("2fa_status_enabled", "Enabled"),
                        text_color="#2ECC71"
                    )
                else:
                    self._2fa_status_label.configure(
                        text=L.get("2fa_status_disabled", "Disabled"),
                        text_color="#FF4444"
                    )
        except (tk.TclError, AttributeError, KeyError) as e:
            logger.debug(f"Update 2FA buttons error: {e}")
    
    def _update_2fa_indicator(self) -> None:
        """Обновляет индикатор 2FA в главном окне"""
        try:
            if hasattr(self, '_2fa_indicator_label') and self._2fa_indicator_label and self._2fa_indicator_label.winfo_exists():
                L = LANGUAGES[self.current_lang]
                if self.config.is_2fa_enabled():
                    self._2fa_indicator_label.configure(
                        text=L.get("2fa_status_enabled", "2FA Enabled"),
                        text_color="#2ECC71"
                    )
                else:
                    self._2fa_indicator_label.configure(
                        text=L.get("2fa_status_disabled", "2FA Disabled"),
                        text_color="#FF4444"
                    )
        except (tk.TclError, AttributeError, KeyError) as e:
            logger.debug(f"Update 2FA indicator error: {e}")