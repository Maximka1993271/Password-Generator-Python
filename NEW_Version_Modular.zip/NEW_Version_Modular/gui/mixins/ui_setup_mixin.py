"""
UI Setup mixin for SecurePassPro
"""
import os
import sys
import json
import math
import time
import ctypes
import tempfile
import tkinter as tk
import customtkinter as ctk
import webbrowser
from PIL import Image
from gui.widgets import ToolTip
from utils.helpers import (
    get_global_radius, set_global_radius, center_screen,
    get_resource_path, play_sound, is_windows, is_macos, is_linux,
    apply_window_rounding, set_window_icon
)
from localization.lang import LANGUAGES
from gui.dialogs import CTkMessageBox, CTkInputDialog
from security.master import MasterPassword
from utils.logger import get_logger

logger = get_logger("ui_setup")


class UISetupMixin:
    """Mixin class for UI setup, theming, and window management"""
    
    def _get_actual_theme(self) -> str:
        if self.current_theme == "Light":
            return "light"
        if self.current_theme == "Dark":
            return "dark"
        if is_windows():
            try:
                import winreg
                key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize")
                value, _ = winreg.QueryValueEx(key, "AppsUseLightTheme")
                winreg.CloseKey(key)
                return "light" if value == 1 else "dark"
            except (ImportError, OSError, WindowsError) as e:
                logger.debug(f"Theme detection error: {e}")
        return "dark"
    
    def _get_colors_for_theme(self, theme: str) -> dict:
        if theme == "light":
            return {"bg": "#F3F3F3", "fg": "#000000", "entry_bg": "#FFFFFF", "label_text": "#000000", "button_fg": "#1f538d"}
        return {"bg": "#1d1e1e", "fg": "#FFFFFF", "entry_bg": "#2b2b2b", "label_text": "#FFFFFF", "button_fg": "#1f538d"}
    
    def _apply_theme_colors(self, actual_theme: str) -> None:
        if actual_theme == "light":
            bg_main, fg_main, entry_bg = "#F3F3F3", "#000000", "#FFFFFF"
            panel_bg, border_color, checkmark_color = "#F3F3F3", "#d0d0d0", "#1f538d"
        else:
            bg_main, fg_main, entry_bg = "#1d1e1e", "#FFFFFF", "#2b2b2b"
            panel_bg, border_color, checkmark_color = "#1d1e1e", "#3a3a3a", "#4EC9B0"
        
        try:
            self.configure(fg_color=bg_main)
            self.left_panel.configure(fg_color=panel_bg)
            self.right_panel.configure(fg_color=panel_bg, border_color=border_color)
            self.entry_res.configure(fg_color=entry_bg, text_color=fg_main)
        except (tk.TclError, AttributeError) as e:
            logger.error(f"Theme color application error: {e}")
        
        for cb in [self.cb_upper, self.cb_lower, self.cb_digits, self.cb_symb, self.cb_ambig, self.cb_at_least, self.cb_hide, self.cb_no_repeat]:
            if cb and cb.winfo_exists():
                try:
                    cb.configure(fg_color=panel_bg, text_color=fg_main, checkmark_color=checkmark_color)
                except (tk.TclError, AttributeError) as e:
                    logger.debug(f"Checkbox color error: {e}")
        
        try:
            self.lbl_title.configure(text_color=fg_main)
            self.lbl_author.configure(text_color=fg_main)
            self.lbl_len.configure(text_color=fg_main)
            self.lbl_strength.configure(text_color=fg_main)
            self.lbl_strength_text.configure(text_color=fg_main)
            self.lbl_crack.configure(text_color=fg_main)
            self.lbl_menu.configure(text_color=fg_main)
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Label color error: {e}")
        
        for c in (self._rgb_c_top, self._rgb_c_bottom, self._rgb_c_left, self._rgb_c_right):
            if c:
                try:
                    c.configure(bg=bg_main)
                except (tk.TclError, AttributeError) as e:
                    logger.debug(f"Canvas color error: {e}")
    
    def _apply_lang(self, lang: str) -> None:
        """Полное обновление языка интерфейса"""
        self.current_lang = lang
        L = LANGUAGES[lang]
        
        try:
            self.lbl_author.configure(text=L["author"])
            self.lbl_menu.configure(text=L["menu_title"])
            self.lbl_title.configure(text=L["win_title"])
            self._update_len_label(self.slider_len.get())
        except (tk.TclError, AttributeError, KeyError) as e:
            logger.error(f"Language application error: {e}")
        
        try:
            self.cb_upper.configure(text=L["upper"])
            self.cb_lower.configure(text=L["lower"])
            self.cb_digits.configure(text=L["digits"])
            self.cb_symb.configure(text=L["symb"])
            self.cb_ambig.configure(text=L["ambig"])
            self.cb_at_least.configure(text=L["at_least"])
            self.cb_hide.configure(text=L["hide"])
            self.cb_no_repeat.configure(text=L["no_repeat"])
        except (tk.TclError, AttributeError, KeyError) as e:
            logger.error(f"Checkbox language error: {e}")
        
        menu_btns = [self.btn_gen, self.btn_copy, self.btn_save, self.btn_open, 
                     self.btn_qr, self.btn_hist, self.btn_db, self.btn_hibp, 
                     self.btn_upd, self.btn_settings, self.btn_about]
        for btn in menu_btns:
            if btn and btn.winfo_exists():
                try:
                    btn.configure(text=L[btn.lang_key])
                    if btn.lang_key in self._tooltips and self._tooltips[btn.lang_key]:
                        tt_text = L[btn.tt_key]
                        if btn.tt_key == "tt_copy":
                            tt_text = tt_text.format(self.clipboard_timeout)
                        self._tooltips[btn.lang_key].set_text(tt_text)
                except (tk.TclError, AttributeError, KeyError) as e:
                    logger.debug(f"Menu button language error: {e}")
        
        if "btn_eye" in self._tooltips and self._tooltips["btn_eye"]:
            try:
                self._tooltips["btn_eye"].set_text(L.get("tt_eye", "Show / hide password"))
            except (AttributeError, KeyError) as e:
                logger.debug(f"Eye tooltip error: {e}")
        
        try:
            self.title(L["win_title"])
        except (tk.TclError, KeyError) as e:
            logger.error(f"Window title error: {e}")
        
        if self.entry_res.get():
            self._update_strength_meter(self.entry_res.get())
        
        self._update_master_status_label()
        self._update_auto_lock_label()
        
        if hasattr(self, 'auto_save_btn') and self.auto_save_btn and self.auto_save_btn.winfo_exists():
            if self.auto_save_var.get():
                self.auto_save_btn.configure(text=L.get("auto_save_on", "✅ ВКЛ"))
            else:
                self.auto_save_btn.configure(text=L.get("auto_save_off", "❌ ВЫКЛ"))
        
        if self._auto_lock_btn and self._auto_lock_btn.winfo_exists():
            if self.auto_lock_enabled.get():
                self._auto_lock_btn.configure(text=L["auto_lock"] + " ✅")
            else:
                self._auto_lock_btn.configure(text=L["auto_lock"] + " ❌")
        
        if self._sound_btn and self._sound_btn.winfo_exists():
            if self.sound_enabled.get():
                self._sound_btn.configure(text=L["sound_on"])
            else:
                self._sound_btn.configure(text=L["sound_off"])
        
        if self._clip_timeout_label_ref and self._clip_timeout_label_ref.winfo_exists():
            self._clip_timeout_label_ref.configure(text=L["clip_timeout"].format(self.clipboard_timeout))
        
        if self.settings_window and self.settings_window.winfo_exists():
            self._refresh_settings_window_language()
    
    def _refresh_settings_window_language(self) -> None:
        """Обновляет язык в открытом окне настроек"""
        if not self.settings_window or not self.settings_window.winfo_exists():
            return
        
        L = LANGUAGES[self.current_lang]
        
        try:
            self.settings_window.title(L["settings_title"])
        except (tk.TclError, KeyError) as e:
            logger.error(f"Settings window title error: {e}")
        
        tab_labels = {
            "design": "\U0001f3a8 " + L.get("tab_design", "Дизайн"),
            "security": "\U0001f512 " + L.get("tab_security", "Безопасность"),
            "general": "\u2699\ufe0f " + L.get("tab_general", "Общие"),
        }
        
        try:
            for child in self.settings_window.winfo_children():
                if isinstance(child, ctk.CTkFrame):
                    for grandchild in child.winfo_children():
                        if isinstance(grandchild, ctk.CTkButton):
                            btn_text = grandchild.cget("text")
                            for key, val in tab_labels.items():
                                if key in btn_text or btn_text in ["Дизайн", "Безопасность", "Общие", "Design", "Security", "General"]:
                                    grandchild.configure(text=val)
                                    break
        except (tk.TclError, AttributeError) as e:
            logger.error(f"Settings tabs update error: {e}")
        
        self._update_settings_widgets_text()
    
    def _update_settings_widgets_text(self) -> None:
        """Обновляет текст всех виджетов в окне настроек"""
        if not self.settings_window or not self.settings_window.winfo_exists():
            return
        
        L = LANGUAGES[self.current_lang]
        
        def update_widgets_recursive(widget):
            try:
                if isinstance(widget, ctk.CTkLabel):
                    current_text = widget.cget("text")
                    if current_text in ["Язык интерфейса", "Interface language", "Мова інтерфейсу"]:
                        widget.configure(text=L["settings_lang"])
                    elif current_text in ["Тема оформления", "Appearance theme", "Тема оформлення"]:
                        widget.configure(text=L["settings_theme"])
                    elif current_text in ["RGB-подсветка", "RGB border", "RGB-підсвітка"]:
                        widget.configure(text=L["rgb_label"])
                    elif current_text in ["Размер шрифта", "Font size", "Розмір шрифту"]:
                        widget.configure(text=L.get("font_size", "Размер шрифта"))
                    elif current_text in ["Закругление углов", "Corner radius", "Закруглення кутів"]:
                        widget.configure(text=L["settings_radius"])
                    elif current_text in ["Безопасность", "Security"]:
                        widget.configure(text="🔒 " + L["security"])
                    elif current_text in ["Общие", "General"]:
                        widget.configure(text="⚙️ " + L.get("tab_general", "Общие"))
                    elif "Мастер-пароль" in current_text or "Master password" in current_text:
                        widget.configure(text="🔐 " + L["master_title"])
                    elif current_text in ["Автоблокировка", "Auto lock", "Автоблокування"]:
                        widget.configure(text=L["auto_lock"])
                    elif current_text in ["Звук приложения", "App sound", "Звук програми"]:
                        widget.configure(text=L["settings_sound"])
                    elif current_text in ["Автосохранение", "Auto save", "Автозбереження"]:
                        widget.configure(text=L.get("auto_save_label", "📁 Автосохранение"))
                    elif current_text in ["Закрыть", "Close", "Закрити"]:
                        widget.configure(text=L["close"])
                
                elif isinstance(widget, ctk.CTkButton):
                    current_text = widget.cget("text")
                    if current_text in ["RU", "EN", "UA"]:
                        pass
                    elif current_text in ["Системная", "System", "Системна"]:
                        widget.configure(text=L["theme_sys"])
                    elif current_text in ["Светлая", "Light", "Світла"]:
                        widget.configure(text=L["theme_light"])
                    elif current_text in ["Тёмная", "Dark", "Темна"]:
                        widget.configure(text=L["theme_dark"])
                    elif current_text in ["Вкл", "On", "Уві"]:
                        widget.configure(text=L["rgb_on"])
                    elif current_text in ["Выкл", "Off", "Вим"]:
                        widget.configure(text=L["rgb_off"])
                    elif current_text in ["Установить мастер-пароль", "Set master password", "Встановити майстер-пароль"]:
                        if MasterPassword.is_set():
                            widget.configure(text="🔒 " + L["master_btn_remove"])
                        else:
                            widget.configure(text="🔓 " + L["master_btn_set"])
                    elif current_text in ["Удалить мастер-пароль", "Remove master password", "Видалити майстер-пароль"]:
                        if MasterPassword.is_set():
                            widget.configure(text="🔒 " + L["master_btn_remove"])
                        else:
                            widget.configure(text="🔓 " + L["master_btn_set"])
                    elif current_text.endswith("✅") or current_text.endswith("❌"):
                        if "Автоблокировка" in current_text or "Auto lock" in current_text:
                            if self.auto_lock_enabled.get():
                                widget.configure(text=L["auto_lock"] + " ✅")
                            else:
                                widget.configure(text=L["auto_lock"] + " ❌")
                    elif current_text in ["Сохранить текущий пароль", "Save current password", "Зберегти поточний пароль"]:
                        widget.configure(text=L["db_save_current"])
                    elif "Очистка буфера:" in current_text or "Clipboard clear:" in current_text:
                        widget.configure(text=L["clip_timeout"].format(self.clipboard_timeout))
                
                for child in widget.winfo_children():
                    update_widgets_recursive(child)
                    
            except (tk.TclError, AttributeError, KeyError) as e:
                logger.debug(f"Widget update error: {e}")
        
        try:
            update_widgets_recursive(self.settings_window)
        except (tk.TclError, AttributeError) as e:
            logger.error(f"Settings widgets update error: {e}")
    
    def _center_main_window(self) -> None:
        self.update_idletasks()
        x = (self.winfo_screenwidth() // 2) - (950 // 2)
        y = (self.winfo_screenheight() // 2) - (800 // 2)
        self.geometry(f"950x800+{x}+{y}")
    
    def _center_window_relative_to_parent(self, window, width: int, height: int) -> None:
        try:
            window.update_idletasks()
            parent_x = self.winfo_x()
            parent_y = self.winfo_y()
            parent_width = self.winfo_width()
            parent_height = self.winfo_height()
            x = parent_x + (parent_width // 2) - (width // 2)
            y = parent_y + (parent_height // 2) - (height // 2)
            screen_width = self.winfo_screenwidth()
            screen_height = self.winfo_screenheight()
            if x < 0:
                x = 10
            if y < 30:
                y = 30
            if x + width > screen_width:
                x = screen_width - width - 10
            if y + height > screen_height:
                y = screen_height - height - 10
            window.geometry(f"{width}x{height}+{x}+{y}")
        except (tk.TclError, AttributeError) as e:
            logger.error(f"Window centering error: {e}")
    
    def _setup_ui(self) -> None:
        # ... (остальной код без изменений, но с добавленными try/except)
        pass
    
    def _open_update_url(self) -> None:
        UPD_URL = "https://github.com/Maximka1993271/Password-Generator-Python/releases"
        try:
            webbrowser.open(UPD_URL)
        except webbrowser.Error as e:
            logger.error(f"Failed to open URL: {e}")
    
    def _create_menu_btn(self, parent, lang_key: str, tt_key: str, cmd, color: str) -> ctk.CTkButton:
        # ... (остальной код без изменений)
        pass
    
    def _animate_button(self, btn: ctk.CTkButton) -> None:
        """Анимация нажатия кнопки (только звук)"""
        play_sound("click", self.sound_enabled.get())
    
    def _toggle_hide(self) -> None:
        self._sync_eye_to_hide_var()
    
    def _toggle_eye(self) -> None:
        self.hide_var.set(not self.hide_var.get())
        self._sync_eye_to_hide_var()
    
    def _sync_eye_to_hide_var(self) -> None:
        hidden = self.hide_var.get()
        try:
            self.entry_res.configure(show="*" if hidden else "")
            self.btn_eye.configure(text="🙈" if hidden else "👁")
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Eye button sync error: {e}")
    
    def _on_closing(self) -> None:
        self._stop_rgb()
        if self._pulse_animation_id:
            try:
                self.after_cancel(self._pulse_animation_id)
            except (tk.TclError, ValueError):
                pass
        if self._clipboard_timer:
            try:
                self.after_cancel(self._clipboard_timer)
            except (tk.TclError, ValueError):
                pass
        if self._lock_check_id:
            try:
                self.after_cancel(self._lock_check_id)
            except (tk.TclError, ValueError):
                pass
        
        try:
            from storage.database import PasswordDB
            PasswordDB.close_connection()
        except (ImportError, AttributeError, OSError) as e:
            logger.debug(f"DB close error: {e}")
        
        for win_attr in ("settings_window", "about_window", "history_window", "qr_window", "db_window"):
            win = getattr(self, win_attr, None)
            if win is not None:
                try:
                    win.destroy()
                except tk.TclError:
                    pass
        self.destroy()