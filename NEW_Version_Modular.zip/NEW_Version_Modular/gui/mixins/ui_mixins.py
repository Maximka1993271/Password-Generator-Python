"""
UI-related mixins grouped together
"""
from gui.mixins.ui_setup_mixin import UISetupMixin
from gui.mixins.settings_mixin import SettingsMixin
from gui.mixins.settings_window_mixin import SettingsWindowMixin
from gui.mixins.dialogs_mixin import DialogsMixin

__all__ = [
    'UISetupMixin',
    'SettingsMixin',
    'SettingsWindowMixin',
    'DialogsMixin'
]