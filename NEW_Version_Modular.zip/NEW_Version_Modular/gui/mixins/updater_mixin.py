"""
Updater mixin for SecurePassPro
"""
import threading
from utils.updater import check_for_updates, perform_update, get_current_version
from gui.dialogs import CTkMessageBox
from localization.lang import LANGUAGES
from utils.logger import get_logger

logger = get_logger("updater_mixin")


class UpdaterMixin:
    """Mixin class for update checking functionality"""
    
    def _check_for_updates(self) -> None:
        """Проверить наличие обновлений (асинхронно)"""
        L = LANGUAGES[self.current_lang]
        
        # Отключаем кнопку на время проверки
        if hasattr(self, 'btn_upd') and self.btn_upd:
            old_text = self.btn_upd.cget("text")
            self.btn_upd.configure(state="disabled", text=L.get("hibp_checking", "Проверка..."))
        
        def _worker():
            try:
                release = check_for_updates(self)
                self.after(0, lambda: self._on_update_check_result(release))
            except Exception as e:
                logger.error(f"Update check error: {e}")
                self.after(0, lambda: self._on_update_check_result(None))
            finally:
                self.after(0, lambda: self._restore_update_button())
        
        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()
    
    def _on_update_check_result(self, release) -> None:
        """Обработать результат проверки обновлений"""
        L = LANGUAGES[self.current_lang]
        
        if release is None:
            CTkMessageBox.info(
                self,
                L.get("update_check", "Проверка обновлений"),
                L.get("update_not_available", "Нет доступных обновлений.\n\nУ вас установлена последняя версия.")
            )
        else:
            message = L.get("update_available", "Доступна новая версия {0}").format(release.version)
            if CTkMessageBox.question(
                self,
                L.get("update_available_title", "Доступно обновление"),
                message + "\n\nУстановить сейчас?"
            ):
                self._perform_update()
    
    def _restore_update_button(self) -> None:
        """Восстановить кнопку обновления"""
        if hasattr(self, 'btn_upd') and self.btn_upd:
            L = LANGUAGES[self.current_lang]
            self.btn_upd.configure(state="normal", text=L.get("btn_upd", "Обновить программу"))
    
    def _perform_update(self) -> None:
        """Выполнить обновление программы"""
        L = LANGUAGES[self.current_lang]
        
        # Отключаем кнопку
        if hasattr(self, 'btn_upd') and self.btn_upd:
            self.btn_upd.configure(state="disabled", text=L.get("please_wait", "Пожалуйста, подождите..."))
        
        def _worker():
            try:
                success = perform_update(self)
                
                if not success:
                    self.after(0, lambda: CTkMessageBox.error(
                        self,
                        L.get("err_title", "Ошибка"),
                        L.get("update_error", "Не удалось установить обновление.")
                    ))
            except Exception as e:
                logger.error(f"Update error: {e}")
                self.after(0, lambda: CTkMessageBox.error(
                    self,
                    L.get("err_title", "Ошибка"),
                    f"Не удалось установить обновление: {e}"
                ))
            finally:
                self.after(0, self._restore_update_button)
        
        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()