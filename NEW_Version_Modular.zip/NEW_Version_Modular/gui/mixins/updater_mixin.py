"""
Updater mixin for SecurePassPro

Миксин обновления для SecurePassPro
Міксин оновлення для SecurePassPro
"""
import threading
import tkinter as tk
from typing import Optional, Any
from utils.updater import check_for_updates, perform_update, rollback_update, get_current_version, get_update_status
from gui.dialogs import CTkMessageBox
from localization.lang import LANGUAGES
from utils.logger import get_logger

logger = get_logger("updater_mixin")


class UpdaterMixin:
    """Mixin class for update checking functionality
    Класс-миксин для функциональности проверки обновлений
    Клас-міксин для функціональності перевірки оновлень"""

    def _check_for_updates(self) -> None:
        """Check for updates (asynchronously) with progress dialog
        Проверить наличие обновлений (асинхронно) с диалогом прогресса
        Перевірити наявність оновлень (асинхронно) з діалогом прогресу"""
        L = LANGUAGES[self.current_lang]
        
        # Store button state for restoration / Сохраняем состояние кнопки для восстановления / Зберігаємо стан кнопки для відновлення
        old_text = ""
        if hasattr(self, 'btn_upd') and self.btn_upd:
            try:
                old_text = self.btn_upd.cget("text")
                self.btn_upd.configure(state="disabled", text=L.get("hibp_checking", "Checking..."))
            except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                logger.debug(f"Button configure error: {e}")
        
        # Show progress dialog / Показываем диалог прогресса / Показуємо діалог прогресу
        progress_window = None
        try:
            import customtkinter as ctk
            progress_window = ctk.CTkToplevel(self)
            progress_window.title(L.get("update_check", "Check for updates"))
            progress_window.geometry("350x150")
            progress_window.resizable(False, False)
            progress_window.transient(self)
            progress_window.grab_set()
            progress_window.attributes("-topmost", True)
            
            # Center window / Центрируем окно / Центруємо вікно
            self._center_window_relative_to_parent(progress_window, 350, 150)
            
            main_frame = ctk.CTkFrame(progress_window, fg_color="transparent")
            main_frame.pack(fill="both", expand=True, padx=20, pady=20)
            
            ctk.CTkLabel(
                main_frame,
                text=L.get("update_check", "Check for updates"),
                font=("Segoe UI", 14, "bold")
            ).pack(pady=(0, 10))
            
            progress_bar = ctk.CTkProgressBar(main_frame, width=280)
            progress_bar.pack(pady=10)
            progress_bar.set(0)
            
            status_label = ctk.CTkLabel(main_frame, text=L.get("please_wait", "Please wait..."), font=("Segoe UI", 11))
            status_label.pack()
            
            def animate_progress(i=0):
                if progress_window and progress_window.winfo_exists():
                    if i <= 90:
                        try:
                            progress_bar.set(i / 100)
                            progress_window.after(30, lambda: animate_progress(i + 2))
                        except (tk.TclError, AttributeError, RuntimeError):
                            pass
            
            animate_progress()
        except (ImportError, AttributeError, RuntimeError, tk.TclError) as e:
            logger.debug(f"Progress window creation error: {e}")
            progress_window = None

        def _worker():
            release = None
            try:
                release = check_for_updates(self)
                self.after(0, lambda: self._on_update_check_result(release, progress_window))
            except (ImportError, AttributeError, RuntimeError, OSError) as e:
                logger.error(f"Update check error: {e}")
                self.after(0, lambda: self._on_update_check_result(None, progress_window))
            finally:
                self.after(0, lambda: self._restore_update_button(old_text))

        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()

    def _on_update_check_result(self, release, progress_window: Optional[Any] = None) -> None:
        """Process update check result with progress window cleanup
        Обработать результат проверки обновлений с очисткой окна прогресса
        Обробити результат перевірки оновлень з очищенням вікна прогресу"""
        # Close progress window / Закрываем окно прогресса / Закриваємо вікно прогресу
        if progress_window and progress_window.winfo_exists():
            try:
                progress_window.destroy()
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        L = LANGUAGES[self.current_lang]

        if release is None:
            CTkMessageBox.info(
                self,
                L.get("update_check", "Check for updates"),
                L.get("update_not_available", "No updates available.\n\nYou are running the latest version.")
            )
        else:
            # Format update message with details / Форматируем сообщение об обновлении с деталями / Форматуємо повідомлення про оновлення з деталями
            message = L.get("update_available", "New version {0} available").format(release.version)
            message += f"\n\nDate: {release.published_at[:10]}"
            message += f"\nSize: {release.size // 1024 // 1024} MB"
            
            if CTkMessageBox.question(
                self,
                L.get("update_available_title", "Update available"),
                message + "\n\n" + L.get("update_confirm_message", "Install now?")
            ):
                self._perform_update_with_progress(release)

    def _restore_update_button(self, old_text: str = "") -> None:
        """Restore update button / Восстановить кнопку обновления / Відновити кнопку оновлення"""
        if hasattr(self, 'btn_upd') and self.btn_upd:
            try:
                L = LANGUAGES[self.current_lang]
                button_text = old_text if old_text else L.get("btn_upd", "Update")
                self.btn_upd.configure(state="normal", text=button_text)
            except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                logger.debug(f"Button restore error: {e}")

    def _perform_update_with_progress(self, release) -> None:
        """Perform update with progress dialog and cancel support
        Выполнить обновление с диалогом прогресса и поддержкой отмены
        Виконати оновлення з діалогом прогресу та підтримкою скасування"""
        L = LANGUAGES[self.current_lang]
        
        # Create progress window with cancel button
        # Создаём окно прогресса с кнопкой отмены
        # Створюємо вікно прогресу з кнопкою скасування
        progress_window = None
        cancel_requested = False
        update_thread = None
        
        try:
            import customtkinter as ctk
            
            progress_window = ctk.CTkToplevel(self)
            progress_window.title(L.get("update_confirm_title", "Update"))
            progress_window.geometry("450x250")
            progress_window.resizable(False, False)
            progress_window.transient(self)
            progress_window.grab_set()
            progress_window.attributes("-topmost", True)
            
            # Center window / Центрируем окно / Центруємо вікно
            self._center_window_relative_to_parent(progress_window, 450, 250)
            
            main_frame = ctk.CTkFrame(progress_window, fg_color="transparent")
            main_frame.pack(fill="both", expand=True, padx=20, pady=20)
            
            ctk.CTkLabel(
                main_frame,
                text=L.get("download_start", "Downloading update..."),
                font=("Segoe UI", 14, "bold")
            ).pack(pady=(0, 10))
            
            progress_bar = ctk.CTkProgressBar(main_frame, width=350)
            progress_bar.pack(pady=10)
            progress_bar.set(0)
            
            status_label = ctk.CTkLabel(main_frame, text="0%", font=("Segoe UI", 11))
            status_label.pack(pady=(0, 10))
            
            # Cancel button / Кнопка отмены / Кнопка скасування
            cancel_btn = ctk.CTkButton(
                main_frame,
                text=L.get("cancel", "Cancel"),
                width=120,
                height=35,
                fg_color="#8b0000",
                hover_color="#cc0000",
                state="normal"
            )
            cancel_btn.pack(pady=10)
            
            def on_cancel():
                nonlocal cancel_requested
                cancel_requested = True
                try:
                    cancel_btn.configure(state="disabled", text=L.get("please_wait", "Cancelling..."))
                except (tk.TclError, AttributeError, RuntimeError):
                    pass
            
            cancel_btn.configure(command=on_cancel)
            
            def update_progress(progress: float):
                if progress_window and progress_window.winfo_exists() and not cancel_requested:
                    try:
                        progress_bar.set(progress)
                        percent = int(progress * 100)
                        status_label.configure(text=f"{percent}%")
                        progress_window.update_idletasks()
                    except (tk.TclError, AttributeError, RuntimeError):
                        pass
            
            def update_status(message: str):
                if progress_window and progress_window.winfo_exists() and not cancel_requested:
                    try:
                        status_label.configure(text=message)
                        progress_window.update_idletasks()
                    except (tk.TclError, AttributeError, RuntimeError):
                        pass
            
            def _do_update():
                nonlocal cancel_requested
                try:
                    update_status(L.get("download_start", "Downloading update..."))
                    from utils.updater import SecureUpdater
                    updater = SecureUpdater(self, progress_callback=update_progress)
                    
                    # Check if cancelled / Проверяем отмену / Перевіряємо скасування
                    if cancel_requested:
                        update_status(L.get("update_cancelled", "Update cancelled"))
                        if progress_window and progress_window.winfo_exists():
                            progress_window.after(1000, lambda: progress_window.destroy() if progress_window and progress_window.winfo_exists() else None)
                        return
                    
                    status, update_path = updater.download_update(release)
                    
                    # Check if cancelled during download / Проверяем отмену во время загрузки / Перевіряємо скасування під час завантаження
                    if cancel_requested:
                        update_status(L.get("update_cancelled", "Update cancelled"))
                        if progress_window and progress_window.winfo_exists():
                            progress_window.after(1000, lambda: progress_window.destroy() if progress_window and progress_window.winfo_exists() else None)
                        return
                    
                    if status.value != "success" or not update_path:
                        error_msg = L.get("update_error", "Update error")
                        self.after(0, lambda: CTkMessageBox.error(self, L.get("err_title", "Error"), error_msg))
                        if progress_window and progress_window.winfo_exists():
                            self.after(0, lambda: progress_window.destroy() if progress_window and progress_window.winfo_exists() else None)
                        return
                    
                    update_status(L.get("update_installing", "Installing update..."))
                    progress_bar.set(0.95)
                    
                    install_result = updater.install_update(update_path)
                    
                    if install_result.value == "success":
                        update_status(L.get("update_restart", "Update installed, restarting..."))
                        progress_bar.set(1.0)
                        if progress_window and progress_window.winfo_exists():
                            progress_window.after(2000, lambda: progress_window.destroy() if progress_window and progress_window.winfo_exists() else None)
                    elif install_result.value == "rollback_success":
                        update_status(L.get("update_rollback", "Rollback performed"))
                        self.after(2000, lambda: CTkMessageBox.warning(self, L.get("update_title", "Update"), L.get("update_rollback_message", "Installation failed, rolled back to previous version")))
                        if progress_window and progress_window.winfo_exists():
                            progress_window.after(3000, lambda: progress_window.destroy() if progress_window and progress_window.winfo_exists() else None)
                    else:
                        error_msg = L.get("update_error", "Update installation error")
                        self.after(0, lambda: CTkMessageBox.error(self, L.get("err_title", "Error"), error_msg))
                        if progress_window and progress_window.winfo_exists():
                            progress_window.after(2000, lambda: progress_window.destroy() if progress_window and progress_window.winfo_exists() else None)
                        
                except (ImportError, AttributeError, RuntimeError, OSError) as e:
                    logger.error(f"Update error: {e}")
                    self.after(0, lambda: CTkMessageBox.error(self, L.get("err_title", "Error"), f"Failed to install update: {e}"))
                    if progress_window and progress_window.winfo_exists():
                        progress_window.after(2000, lambda: progress_window.destroy() if progress_window and progress_window.winfo_exists() else None)
            
            update_thread = threading.Thread(target=_do_update, daemon=True)
            update_thread.start()
            
            # Monitor thread completion / Мониторим завершение потока / Моніторимо завершення потоку
            def check_thread():
                if not update_thread.is_alive():
                    if progress_window and progress_window.winfo_exists():
                        try:
                            progress_window.destroy()
                        except (tk.TclError, AttributeError, RuntimeError):
                            pass
                    return
                if progress_window and progress_window.winfo_exists() and not cancel_requested:
                    progress_window.after(500, check_thread)
            
            if progress_window and progress_window.winfo_exists():
                progress_window.after(500, check_thread)
            
        except (ImportError, AttributeError, RuntimeError, tk.TclError) as e:
            logger.error(f"Progress dialog error: {e}")
            # Fallback to simple update without progress dialog
            # Fallback к простому обновлению без диалога прогресса
            # Fallback до простого оновлення без діалогу прогресу
            self._perform_update()

    def _perform_update(self) -> None:
        """Perform program update (simple version without progress)
        Выполнить обновление программы (простая версия без прогресса)
        Виконати оновлення програми (проста версія без прогресу)"""
        L = LANGUAGES[self.current_lang]

        # Disable button / Отключаем кнопку / Вимкаємо кнопку
        old_text = ""
        if hasattr(self, 'btn_upd') and self.btn_upd:
            try:
                old_text = self.btn_upd.cget("text")
                self.btn_upd.configure(state="disabled", text=L.get("please_wait", "Please wait..."))
            except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                logger.debug(f"Button configure error: {e}")

        def _worker():
            try:
                success = perform_update(self)

                if not success:
                    self.after(0, lambda: CTkMessageBox.error(
                        self,
                        L.get("err_title", "Error"),
                        L.get("update_error", "Failed to install update.")
                    ))
            except (ImportError, AttributeError, RuntimeError, OSError) as e:
                logger.error(f"Update error: {e}")
                self.after(0, lambda: CTkMessageBox.error(
                    self,
                    L.get("err_title", "Error"),
                    f"Failed to install update: {e}"
                ))
            finally:
                self.after(0, lambda: self._restore_update_button(old_text))

        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()

    def _show_rollback_dialog(self) -> None:
        """Show rollback dialog for reverting to previous version
        Показать диалог отката к предыдущей версии
        Показати діалог відкату до попередньої версії"""
        L = LANGUAGES[self.current_lang]
        
        try:
            status = get_update_status()
        except (ImportError, AttributeError, RuntimeError) as e:
            logger.error(f"Failed to get update status: {e}")
            status = {"has_backups": False}
        
        if not status.get("has_backups", False):
            CTkMessageBox.info(
                self,
                L.get("update_rollback", "Rollback"),
                L.get("update_no_backup", "No saved backups for rollback.")
            )
            return
        
        if CTkMessageBox.question(
            self,
            L.get("update_rollback", "Rollback"),
            L.get("update_rollback_confirm", "Are you sure you want to rollback to the previous version?\n\nAny unsaved changes will be lost.")
        ):
            self._perform_rollback()

    def _perform_rollback(self) -> None:
        """Perform rollback to previous version with progress dialog
        Выполнить откат к предыдущей версии с диалогом прогресса
        Виконати відкат до попередньої версії з діалогом прогресу"""
        L = LANGUAGES[self.current_lang]
        
        # Create progress window / Создаём окно прогресса / Створюємо вікно прогресу
        progress_window = None
        try:
            import customtkinter as ctk
            
            progress_window = ctk.CTkToplevel(self)
            progress_window.title(L.get("update_rollback", "Rollback"))
            progress_window.geometry("350x150")
            progress_window.resizable(False, False)
            progress_window.transient(self)
            progress_window.grab_set()
            progress_window.attributes("-topmost", True)
            
            self._center_window_relative_to_parent(progress_window, 350, 150)
            
            main_frame = ctk.CTkFrame(progress_window, fg_color="transparent")
            main_frame.pack(fill="both", expand=True, padx=20, pady=20)
            
            ctk.CTkLabel(
                main_frame,
                text=L.get("update_rollback", "Rollback to previous version..."),
                font=("Segoe UI", 14, "bold")
            ).pack(pady=(0, 10))
            
            progress_bar = ctk.CTkProgressBar(main_frame, width=280)
            progress_bar.pack(pady=10)
            progress_bar.set(0)
            
            status_label = ctk.CTkLabel(main_frame, text=L.get("please_wait", "Please wait..."), font=("Segoe UI", 11))
            status_label.pack()
            
            progress_bar.set(0.5)
            
        except (ImportError, AttributeError, RuntimeError, tk.TclError) as e:
            logger.debug(f"Rollback progress window error: {e}")
            progress_window = None

        def _worker():
            try:
                from utils.updater import rollback_update
                success = rollback_update(self)
                
                if success:
                    self.after(0, lambda: CTkMessageBox.info(
                        self,
                        L.get("update_rollback", "Rollback"),
                        L.get("update_rollback_success", "Rollback completed successfully.\n\nThe application will restart.")
                    ))
                else:
                    self.after(0, lambda: CTkMessageBox.error(
                        self,
                        L.get("err_title", "Error"),
                        L.get("update_rollback_error", "Failed to rollback.")
                    ))
            except (ImportError, AttributeError, RuntimeError, OSError) as e:
                logger.error(f"Rollback error: {e}")
                self.after(0, lambda: CTkMessageBox.error(
                    self,
                    L.get("err_title", "Error"),
                    f"Failed to rollback: {e}"
                ))
            finally:
                if progress_window and progress_window.winfo_exists():
                    self.after(500, lambda: progress_window.destroy() if progress_window and progress_window.winfo_exists() else None)

        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()