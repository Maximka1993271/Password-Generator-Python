"""
Auto-lock mixin for SecurePassPro
"""
import time
import tkinter as tk
from security.master import MasterPassword
from utils.logger import get_logger

logger = get_logger("auto_lock")


class AutoLockMixin:
    """Mixin class for auto-lock functionality on inactivity"""
    
    def _reset_activity_timer(self, event=None) -> None:
        if not self.auto_lock_enabled.get():
            return
        self._last_activity_time = time.time()
    
    def _start_lock_checker(self) -> None:
        self._check_lock()
    
    def _check_lock(self) -> None:
        if not self.auto_lock_enabled.get():
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        if not MasterPassword.is_set():
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        # Если открыто окно настроек — сбрасываем таймер
        if self.settings_window and self.settings_window.winfo_exists():
            self._last_activity_time = time.time()
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        # Если открыто окно базы данных — сбрасываем таймер
        if self.db_window and self.db_window.winfo_exists():
            self._last_activity_time = time.time()
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        # Если открыто окно истории — сбрасываем таймер
        if self.history_window and self.history_window.winfo_exists():
            self._last_activity_time = time.time()
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        # Если открыто окно QR — сбрасываем таймер
        if self.qr_window and self.qr_window.winfo_exists():
            self._last_activity_time = time.time()
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        # Если открыто окно About — сбрасываем таймер
        if self.about_window and self.about_window.winfo_exists():
            self._last_activity_time = time.time()
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        idle_time = time.time() - self._last_activity_time
        if idle_time >= self.auto_lock_timeout * 60:
            self._lock_program()
        
        self._lock_check_id = self.after(1000, self._check_lock)
    
    def _close_all_child_windows(self) -> None:
        """Закрывает все дочерние окна перед блокировкой"""
        windows = [
            ('db_window', '_close_db_window'),
            ('settings_window', '_close_settings'),
            ('history_window', '_close_history'),
            ('qr_window', '_close_qr'),
            ('about_window', '_close_about'),
        ]
        
        for win_attr, close_method in windows:
            win = getattr(self, win_attr, None)
            if win and win.winfo_exists():
                try:
                    if hasattr(self, close_method):
                        getattr(self, close_method)()
                    else:
                        win.destroy()
                except tk.TclError as e:
                    logger.debug(f"Window close error for {win_attr}: {e}")
                except AttributeError as e:
                    logger.debug(f"Attribute error for {win_attr}: {e}")
                setattr(self, win_attr, None)
    
    def _lock_program(self) -> None:
        """Блокирует программу при бездействии"""
        if not MasterPassword.is_set():
            return
        
        # Закрываем ВСЕ дочерние окна перед блокировкой
        self._close_all_child_windows()
        
        rgb_was_enabled = self.rgb_enabled.get()
        if rgb_was_enabled:
            try:
                self._stop_rgb()
            except (AttributeError, tk.TclError) as e:
                logger.debug(f"RGB stop error: {e}")
        
        # Скрываем главное окно
        try:
            self.withdraw()
        except tk.TclError as e:
            logger.error(f"Cannot withdraw window: {e}")
            return
        
        # Показываем экран блокировки
        unlocked = self._show_lock_screen()
        
        if unlocked:
            try:
                self.deiconify()
                self.lift()
                self.focus_force()
            except tk.TclError as e:
                logger.error(f"Window restore error: {e}")
                return
            
            if rgb_was_enabled:
                try:
                    self._start_rgb()
                except (AttributeError, tk.TclError) as e:
                    logger.debug(f"RGB start error: {e}")
            
            self._last_activity_time = time.time()
        else:
            self._on_closing()