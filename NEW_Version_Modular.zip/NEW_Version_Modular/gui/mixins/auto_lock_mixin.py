"""
Auto-lock mixin for SecurePassPro
"""
import time
import tkinter as tk
import platform
from security.master import MasterPassword
from utils.logger import get_logger

logger = get_logger("auto_lock")

# Platform detection
_is_windows = platform.system() == "Windows"
_is_macos = platform.system() == "Darwin"
_is_linux = platform.system() == "Linux"


class AutoLockMixin:
    """Mixin class for auto-lock functionality on inactivity, suspend, workstation lock, and minimize"""

    def _reset_activity_timer(self, event=None) -> None:
        if not self.auto_lock_enabled.get():
            return
        self._last_activity_time = time.time()

    def _start_lock_checker(self) -> None:
        self._check_lock()
        self._start_suspend_detection()
        self._start_workstation_lock_detection()
        self._start_minimize_detection()

    # ==================== LOCK ON SUSPEND (ГИБЕРНАЦИЯ/СОН) ====================

    def _start_suspend_detection(self) -> None:
        """Start detection for system suspend/resume"""
        if _is_windows:
            self._check_suspend_windows()
        elif _is_macos:
            self._check_suspend_macos()
        elif _is_linux:
            self._check_suspend_linux()

    def _check_suspend_windows(self) -> None:
        """Detect Windows suspend/resume"""
        try:
            import ctypes
            user32 = ctypes.windll.user32

            # Get current window handle
            hwnd = self.winfo_id()

            # Set up window procedure for power messages
            old_wndproc = user32.GetWindowLongW(hwnd, -4)

            def wndproc(hwnd, msg, wParam, lParam):
                if msg == 0x0218:  # WM_POWERBROADCAST
                    if wParam == 0x0001:  # PBT_APMSUSPEND
                        logger.debug("System suspend detected, locking program")
                        self.after(0, self._lock_program)
                return ctypes.windll.user32.CallWindowProcW(old_wndproc, hwnd, msg, wParam, lParam)

            # Set new window procedure
            new_wndproc = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int)(wndproc)
            user32.SetWindowLongW(hwnd, -4, new_wndproc)

        except (ImportError, AttributeError, OSError, TypeError) as e:
            logger.debug(f"Windows suspend detection failed: {e}")

    def _check_suspend_macos(self) -> None:
        """Detect macOS suspend/resume"""
        try:
            import subprocess
            import threading

            def monitor():
                last_time = time.time()
                while True:
                    try:
                        result = subprocess.run(['sysctl', '-n', 'kern.boottime'], capture_output=True, text=True, timeout=5)
                        if result.returncode == 0:
                            import re
                            match = re.search(r'sec = (\d+)', result.stdout)
                            if match:
                                uptime = time.time() - float(match.group(1))
                                if uptime < last_time - 5:
                                    logger.debug("macOS suspend detected, locking program")
                                    self.after(0, self._lock_program)
                                last_time = uptime
                    except (subprocess.SubprocessError, ValueError, TypeError) as e:
                        pass
                    time.sleep(10)

            thread = threading.Thread(target=monitor, daemon=True)
            thread.start()
        except ImportError as e:
            logger.debug(f"macOS suspend detection failed: {e}")

    def _check_suspend_linux(self) -> None:
        """Detect Linux suspend/resume"""
        try:
            import subprocess
            import threading

            def monitor():
                last_line = None
                while True:
                    try:
                        result = subprocess.run(['journalctl', '--since=now', '-n', '5', '-o', 'cat'],
                                                capture_output=True, text=True, timeout=5)
                        if result.returncode == 0:
                            for line in result.stdout.split('\n'):
                                if 'Resuming' in line or 'resumed' in line:
                                    if line != last_line:
                                        logger.debug("Linux resume detected")
                                        last_line = line
                    except (subprocess.SubprocessError, ValueError, TypeError) as e:
                        pass
                    time.sleep(10)

            thread = threading.Thread(target=monitor, daemon=True)
            thread.start()
        except ImportError as e:
            logger.debug(f"Linux suspend detection failed: {e}")

    # ==================== LOCK ON WORKSTATION LOCK (БЛОКИРОВКА РАБОЧЕГО СТОЛА) ====================

    def _start_workstation_lock_detection(self) -> None:
        """Start detection for workstation lock (Windows only)"""
        if _is_windows:
            self._check_workstation_lock_windows()

    def _check_workstation_lock_windows(self) -> None:
        """Detect Windows workstation lock/unlock"""
        try:
            import ctypes

            user32 = ctypes.windll.user32
            hwnd = self.winfo_id()

            old_wndproc = user32.GetWindowLongW(hwnd, -4)

            def wndproc(hwnd, msg, wParam, lParam):
                if msg == 0x02B1:  # WM_WTSSESSION_CHANGE
                    if wParam == 0x0007:  # WTS_SESSION_LOCK
                        logger.debug("Workstation locked, locking program")
                        self.after(0, self._lock_program)
                    elif wParam == 0x0008:  # WTS_SESSION_UNLOCK
                        logger.debug("Workstation unlocked")
                return ctypes.windll.user32.CallWindowProcW(old_wndproc, hwnd, msg, wParam, lParam)

            new_wndproc = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int)(wndproc)
            user32.SetWindowLongW(hwnd, -4, new_wndproc)

            # Register for session notifications
            try:
                wtsapi32 = ctypes.windll.wtsapi32
                wtsapi32.WTSRegisterSessionNotification(hwnd, 0)
            except (AttributeError, OSError) as e:
                logger.debug(f"WTSRegisterSessionNotification failed: {e}")

        except (ImportError, AttributeError, OSError, TypeError) as e:
            logger.debug(f"Windows workstation lock detection failed: {e}")

    # ==================== LOCK ON MINIMIZE (СВОРАЧИВАНИЕ ОКНА) ====================

    def _start_minimize_detection(self) -> None:
        """Start detection for window minimize/restore"""
        self._check_minimize()

    def _check_minimize(self) -> None:
        """Check if window was minimized"""
        try:
            if not self.winfo_exists():
                return

            is_minimized = False

            if _is_windows:
                try:
                    import ctypes
                    is_minimized = ctypes.windll.user32.IsIconic(self.winfo_id())
                except (ImportError, AttributeError, OSError) as e:
                    logger.debug(f"IsIconic check failed: {e}")

            if self.auto_lock_enabled.get() and MasterPassword.is_set():
                if is_minimized:
                    if not getattr(self, '_was_minimized', False):
                        logger.debug("Window minimized, locking program")
                        self.after(0, self._lock_program)
                        self._was_minimized = True
                else:
                    self._was_minimized = False

        except (tk.TclError, RuntimeError) as e:
            logger.debug(f"Minimize check error: {e}")

        if hasattr(self, '_minimize_check_id') and self._minimize_check_id:
            try:
                self.after_cancel(self._minimize_check_id)
            except (tk.TclError, ValueError) as e:
                logger.debug(f"Cancel minimize check error: {e}")
        self._minimize_check_id = self.after(1000, self._check_minimize)

    # ==================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ====================

    def _close_all_child_windows(self) -> None:
        """Закрывает все дочерние окна перед блокировкой"""
        windows = [
            ('db_window', '_close_db_window'),
            ('settings_window', '_close_settings'),
            ('history_window', '_close_history'),
            ('qr_window', '_close_qr'),
            ('about_window', '_close_about'),
        ]

        for win_attr, close_method in windows:
            win = getattr(self, win_attr, None)
            if win and win.winfo_exists():
                try:
                    if hasattr(self, close_method):
                        getattr(self, close_method)()
                    else:
                        win.destroy()
                except (tk.TclError, AttributeError) as e:
                    logger.debug(f"Window close error for {win_attr}: {e}")
                setattr(self, win_attr, None)

    def _check_lock(self) -> None:
        """Check inactivity and lock if needed"""
        if not self.auto_lock_enabled.get():
            self._lock_check_id = self.after(1000, self._check_lock)
            return

        if not MasterPassword.is_set():
            self._lock_check_id = self.after(1000, self._check_lock)
            return

        # Skip if any child window is open
        child_windows = ['settings_window', 'db_window', 'history_window', 'qr_window', 'about_window']
        for win_attr in child_windows:
            win = getattr(self, win_attr, None)
            if win and win.winfo_exists():
                self._last_activity_time = time.time()
                self._lock_check_id = self.after(1000, self._check_lock)
                return

        idle_time = time.time() - self._last_activity_time
        if idle_time >= self.auto_lock_timeout * 60:
            self._lock_program()

        self._lock_check_id = self.after(1000, self._check_lock)

    def _lock_program(self) -> None:
        """Блокирует программу"""
        if not MasterPassword.is_set():
            return

        self._close_all_child_windows()

        rgb_was_enabled = self.rgb_enabled.get()
        if rgb_was_enabled:
            try:
                self._stop_rgb()
            except (AttributeError, tk.TclError) as e:
                logger.debug(f"RGB stop error: {e}")

        try:
            self.withdraw()
        except tk.TclError as e:
            logger.error(f"Cannot withdraw window: {e}")
            return

        unlocked = self._show_lock_screen()

        if unlocked:
            try:
                self.deiconify()
                self.lift()
                self.focus_force()
            except tk.TclError as e:
                logger.error(f"Window restore error: {e}")
                return

            if rgb_was_enabled:
                try:
                    self._start_rgb()
                except (AttributeError, tk.TclError) as e:
                    logger.debug(f"RGB start error: {e}")

            self._last_activity_time = time.time()
            self._was_minimized = False
        else:
            self._on_closing()
