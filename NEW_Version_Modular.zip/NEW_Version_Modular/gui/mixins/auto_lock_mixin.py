"""
Auto-lock mixin for SecurePassPro
"""
import time
from security.master import MasterPassword


class AutoLockMixin:
    """Mixin class for auto-lock functionality on inactivity"""
    
    def _reset_activity_timer(self, event=None) -> None:
        if not self.auto_lock_enabled.get():
            return
        self._last_activity_time = time.time()
    
    def _start_lock_checker(self) -> None:
        self._check_lock()
    
    def _check_lock(self) -> None:
        if not self.auto_lock_enabled.get():
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        if not MasterPassword.is_set():
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        # Если открыто окно настроек — сбрасываем таймер (пользователь активен)
        if self.settings_window and self.settings_window.winfo_exists():
            self._last_activity_time = time.time()
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        # Если открыто окно базы данных — сбрасываем таймер
        if self.db_window and self.db_window.winfo_exists():
            self._last_activity_time = time.time()
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        # Если открыто окно истории — сбрасываем таймер
        if self.history_window and self.history_window.winfo_exists():
            self._last_activity_time = time.time()
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        # Если открыто окно QR — сбрасываем таймер
        if self.qr_window and self.qr_window.winfo_exists():
            self._last_activity_time = time.time()
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        # Если открыто окно About — сбрасываем таймер
        if self.about_window and self.about_window.winfo_exists():
            self._last_activity_time = time.time()
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        idle_time = time.time() - self._last_activity_time
        if idle_time >= self.auto_lock_timeout * 60:
            self._lock_program()
        
        self._lock_check_id = self.after(1000, self._check_lock)
    
    def _close_all_child_windows(self) -> None:
        """Закрывает все дочерние окна перед блокировкой"""
        # Список всех дочерних окон с их методами безопасного закрытия
        windows = [
            ('db_window', '_close_db_window'),
            ('settings_window', '_close_settings'),
            ('history_window', '_close_history'),
            ('qr_window', '_close_qr'),
            ('about_window', '_close_about'),
        ]
        
        for win_attr, close_method in windows:
            win = getattr(self, win_attr, None)
            if win and win.winfo_exists():
                try:
                    # Пытаемся использовать безопасный метод закрытия, если он есть
                    if hasattr(self, close_method):
                        getattr(self, close_method)()
                    else:
                        win.destroy()
                except Exception:
                    try:
                        win.destroy()
                    except Exception:
                        pass
                setattr(self, win_attr, None)
    
    def _lock_program(self) -> None:
        """Блокирует программу при бездействии"""
        if not MasterPassword.is_set():
            return
        
        # Закрываем ВСЕ дочерние окна перед блокировкой
        self._close_all_child_windows()
        
        rgb_was_enabled = self.rgb_enabled.get()
        if rgb_was_enabled:
            self._stop_rgb()
        
        # Скрываем главное окно
        self.withdraw()
        
        # Показываем экран блокировки
        unlocked = self._show_lock_screen()
        
        if unlocked:
            # Восстанавливаем главное окно
            self.deiconify()
            self.lift()
            self.focus_force()
            
            if rgb_was_enabled:
                self._start_rgb()
            
            # Сбрасываем таймер активности
            self._last_activity_time = time.time()
        else:
            # Пользователь закрыл окно блокировки — выходим
            self._on_closing()