"""
Auto-lock mixin for SecurePassPro
"""
import time
from security.master import MasterPassword


class AutoLockMixin:
    """Mixin class for auto-lock functionality on inactivity"""
    
    def _reset_activity_timer(self, event=None) -> None:
        if not self.auto_lock_enabled.get():
            return
        self._last_activity_time = time.time()
    
    def _start_lock_checker(self) -> None:
        self._check_lock()
    
    def _check_lock(self) -> None:
        if not self.auto_lock_enabled.get():
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        if not MasterPassword.is_set():
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        if self.settings_window and self.settings_window.winfo_exists():
            self._last_activity_time = time.time()
            self._lock_check_id = self.after(1000, self._check_lock)
            return
        
        idle_time = time.time() - self._last_activity_time
        if idle_time >= self.auto_lock_timeout * 60:
            self._lock_program()
        
        self._lock_check_id = self.after(1000, self._check_lock)
    
    def _lock_program(self) -> None:
        if not MasterPassword.is_set():
            return
        
        # БЕЗОПАСНОСТЬ: Надежно закрываем ВСЕ дочерние Toplevel-окна при автоблокировке
        # Используются точные имена атрибутов из DialogsMixin и SettingsWindowMixin
        for win_attr in ['db_window', 'settings_window', 'qr_window', 'hist_window', 'about_window']:
            win = getattr(self, win_attr, None)
            if win and win.winfo_exists():
                try:
                    # Для окна настроек вызываем штатный метод очистки ссылок, если он доступен
                    if win_attr == 'settings_window' and hasattr(self, '_close_settings'):
                        self._close_settings()
                    else:
                        win.destroy()
                except Exception:
                    pass
                setattr(self, win_attr, None)
        
        rgb_was_enabled = self.rgb_enabled.get()
        if rgb_was_enabled:
            self._stop_rgb()
        
        self.withdraw()
        unlocked = self._show_lock_screen()
        
        if unlocked:
            self.deiconify()
            self.lift()
            self.focus_force()
            if rgb_was_enabled:
                self._start_rgb()
            self._last_activity_time = time.time()
        else:
            self._on_closing()