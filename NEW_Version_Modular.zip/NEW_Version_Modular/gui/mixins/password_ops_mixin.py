"""
Password operations mixin for SecurePassPro
"""
import os
import datetime
from tkinter import filedialog
import subprocess
from fpdf import FPDF
from utils.helpers import play_sound, is_windows, is_macos, is_linux
from storage.database import PasswordDB
from gui.dialogs import CTkMessageBox
from security.integrity import verify_file_integrity, save_file_with_hash
import tkinter as tk
from localization.lang import LANGUAGES


class PasswordOperationsMixin:
    """Mixin class for password generation, copy, save, open operations"""
    
    def _update_len_label(self, val: float) -> None:
        L = LANGUAGES[self.current_lang]
        self.lbl_len.configure(text=f"{L['len']}: {int(val)}")
    
    def _get_min_length(self) -> int:
        count = sum([self.upper_var.get(), self.lower_var.get(), self.digits_var.get(), self.symb_var.get()])
        return max(4, count)
    
    def _update_strength_meter(self, password: str) -> None:
        if not password:
            self.lbl_strength_text.configure(text="")
            self.lbl_strength.configure(text="")
            self.lbl_crack.configure(text="")
            self.lbl_stars_top.configure(text="")
            return
        
        L = LANGUAGES[self.current_lang]
        stats = self.strength_calc.calculate(password)
        
        self.lbl_strength.configure(text=L["strength"].format(stats['combinations']))
        
        if stats['strength_level'] == 'weak':
            stars_display, stars_color, st_text = "★☆☆☆☆", "#FF4C4C", L["st_low"]
        elif stats['strength_level'] == 'medium':
            if stats['entropy_bits'] < 60:
                stars_display, stars_color, st_text = "★★★☆☆", "#FFA500", L["st_mid"]
            else:
                stars_display, stars_color, st_text = "★★★★☆", "#FFD700", L["st_mid"]
        else:
            stars_display, stars_color, st_text = "★★★★★", "#2ECC71", L["st_high"]
        
        self.lbl_stars_top.configure(text=stars_display, text_color=stars_color)
        self.lbl_strength_text.configure(text=st_text, text_color=stars_color)
        self.lbl_crack.configure(text=L["crack_time"].format(L[stats['crack_time_label']]), text_color=stars_color)
        
        self._animate_password_field(stats['strength_level'])
    
    def _animate_password_field(self, strength_type: str = "medium") -> None:
        original_border = self.entry_res.cget("border_color")
        
        if strength_type == "weak":
            neon_colors = ["#FF4444", "#FF6666", "#FF8888", "#FF6666", "#FF4444"]
        elif strength_type == "strong":
            neon_colors = ["#2ECC71", "#55DD88", "#88EEAA", "#55DD88", "#2ECC71"]
        else:
            neon_colors = ["#FFA500", "#FFBB33", "#FFCC66", "#FFBB33", "#FFA500"]
        
        def pulse_step(step: int = 0) -> None:
            if step < len(neon_colors):
                try:
                    self.entry_res.configure(border_color=neon_colors[step], border_width=3)
                    self._pulse_animation_id = self.after(60, lambda: pulse_step(step + 1))
                except Exception:
                    pass
            else:
                try:
                    self.entry_res.configure(border_color=original_border if original_border else "#2b2b2b", border_width=2)
                except Exception:
                    pass
                self._pulse_animation_id = None
        
        if self._pulse_animation_id:
            try:
                self.after_cancel(self._pulse_animation_id)
            except Exception:
                pass
        pulse_step()
    
    def _generate(self) -> None:
        if hasattr(self, 'btn_gen') and self.btn_gen:
            self._animate_button(self.btn_gen)
        
        L = LANGUAGES[self.current_lang]
        
        self.generator.use_upper = self.upper_var.get()
        self.generator.use_lower = self.lower_var.get()
        self.generator.use_digits = self.digits_var.get()
        self.generator.use_special = self.symb_var.get()
        self.generator.exclude_ambiguous = self.ambig_var.get()
        self.generator.exclude_unambiguous = self.unambig_var.get()
        self.generator.min_each = self.at_least_var.get()
        self.generator.no_repeat = self.no_repeat_var.get()
        self.generator.length = int(self.slider_len.get())
        
        if not (self.generator.use_upper or self.generator.use_lower or self.generator.use_digits or self.generator.use_special):
            CTkMessageBox.warning(self, L.get("err_title", "Error"), L["err_cat"])
            return
        
        password = self.generator.generate()

        if password is None and self.generator.no_repeat:
            CTkMessageBox.warning(self, L.get("err_title", "Error"), L["err_no_repeat"] + L["err_no_repeat_fallback"])
            self.generator.no_repeat = False
            password = self.generator.generate()
            self.generator.no_repeat = True
        
        if password is None:
            CTkMessageBox.warning(self, L.get("err_title", "Error"), L["err_pool_small"])
            return
        
        if password:
            self.entry_res.delete(0, "end")
            self.entry_res.insert(0, password)
            self.history.append(password)
            self._update_strength_meter(password)
            play_sound("generate", self.sound_enabled.get())
            
            if self.auto_save_var.get():
                label = f"Auto {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                try:
                    PasswordDB.save(label, password)
                    print(f"[AutoSave] Saved: {label}")
                except Exception as exc:
                    CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_save"].format(exc))
    
    def _copy(self) -> None:
        if hasattr(self, 'btn_copy') and self.btn_copy:
            self._animate_button(self.btn_copy)
        
        pwd = self.entry_res.get().strip()
        if not pwd:
            return
        
        L = LANGUAGES[self.current_lang]
        play_sound("copy", self.sound_enabled.get())
        
        self.clipboard_clear()
        self.clipboard_append(pwd)
        
        # Исправление наложения таймеров буфера обмена
        if hasattr(self, '_clipboard_timer') and self._clipboard_timer:
            try:
                self.after_cancel(self._clipboard_timer)
            except Exception:
                pass
        
        self._clipboard_timer = self.after(self.clipboard_timeout * 1000, lambda value=pwd: self._clear_clipboard_if_unchanged(value))
        
        old_text = self.btn_copy.cget("text")
        self.btn_copy.configure(text=L["copied"].format(self.clipboard_timeout))
        self.after(2000, lambda: self.btn_copy.configure(text=old_text))
    
    def _clear_clipboard_if_unchanged(self, expected: str) -> None:
        try:
            if not self.winfo_exists():
                return
                
            if self.clipboard_get() == expected:
                self.clipboard_clear()
                L = LANGUAGES[self.current_lang]
                CTkMessageBox.info(self, L["master_title"], L.get("clipboard_cleared", "✅ Clipboard cleared!"))
        except Exception:
            pass
        finally:
            self._clipboard_timer = None
    
    def _verify_pdf(self, path: str) -> bool:
        try:
            with open(path, "rb") as f:
                header = f.read(5)
                return header == b"%PDF-"
        except Exception:
            return False
    
    def _save(self) -> None:
        L = LANGUAGES[self.current_lang]
        pwd = self.entry_res.get().strip()
        if not pwd:
            return
        
        path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text Files", "*.txt"), ("Password Files", "*.key"), ("Log Files", "*.log"), ("PDF Files", "*.pdf"), ("All Files", "*.*")])
        
        if not path:
            return
        
        try:
            ext = os.path.splitext(path)[1].lower()
            
            if ext == ".pdf":
                pdf = FPDF()
                pdf.set_author("Maxim Melnikov")
                pdf.set_creator("Secure Pass Pro v4.0")
                pdf.set_title("Secure Pass Pro Password")
                pdf.add_page()
                
                # Поддержка кириллицы (ищет файл шрифта в папке проекта assets)
                font_path = os.path.join(os.path.dirname(__file__), "..", "..", "assets", "DejaVuSans.ttf")
                if os.path.exists(font_path):
                    pdf.add_font('DejaVu', '', font_path, uni=True)
                    pdf.set_font('DejaVu', '', 14)
                else:
                    pdf.set_font('Arial', 'B', 16)
                    
                pdf.cell(200, 10, txt="Secure Pass Pro v4.0", ln=True, align='C')
                
                if os.path.exists(font_path):
                    pdf.set_font('DejaVu', '', 11)
                else:
                    pdf.set_font('Arial', '', 12)
                    
                pdf.ln(10)
                pdf.cell(200, 10, txt=f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", ln=True)
                pdf.cell(200, 10, txt=f"Password: {pwd}", ln=True)
                pdf.output(path)
                
                if not self._verify_pdf(path):
                    raise IOError(L["err_integrity"])
            else:
                pwd_bytes = pwd.encode("utf-8")
                success = save_file_with_hash(path, pwd_bytes)
                if not success:
                    raise IOError(L["err_integrity"])
            
            play_sound("success", self.sound_enabled.get())
            fname = os.path.basename(path)
            self.title(f"✅ {fname}")
            self.after(3000, lambda: self.title(L["win_title"]))
        except Exception as e:
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_save"].format(e))
    
    def _open(self) -> None:
        L = LANGUAGES[self.current_lang]
        
        path = filedialog.askopenfilename(title="Select password file", filetypes=[("All Files", "*.*"), ("Text Files", "*.txt"), ("Password Files", "*.key"), ("Log Files", "*.log"), ("PDF Files", "*.pdf")])
        
        if not path:
            return
        
        try:
            ext = os.path.splitext(path)[1].lower()
            
            if path.lower().endswith(".sha256"):
                CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_unsupported"].format(".sha256"))
                return
            
            if ext == ".pdf":
                if is_windows():
                    os.startfile(path)
                elif is_macos():
                    subprocess.run(["open", path], check=False)
                else:
                    subprocess.run(["xdg-open", path], check=False)
                play_sound("success", self.sound_enabled.get())
                return
            
            if not verify_file_integrity(path):
                if CTkMessageBox.question(self, L.get("err_title", "Error"), L["integrity_warn"]):
                    pass
                else:
                    return
            
            content = None
            encodings = ['utf-8', 'cp1251', 'latin-1', 'cp866', 'koi8-r']
            
            for encoding in encodings:
                try:
                    with open(path, 'r', encoding=encoding) as f:
                        content = f.read().strip()
                    break
                except (UnicodeDecodeError, UnicodeError):
                    continue
            
            if content is None:
                with open(path, 'rb') as f:
                    raw_bytes = f.read()
                    content = raw_bytes.decode('utf-8', errors='replace').strip()
            
            if not content:
                raise ValueError("File is empty")
            
            self.entry_res.delete(0, "end")
            self.entry_res.insert(0, content)
            self._update_strength_meter(content)
            play_sound("success", self.sound_enabled.get())
            
        except Exception as e:
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_open"].format(str(e)))