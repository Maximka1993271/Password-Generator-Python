"""
Password operations mixin for SecurePassPro
"""
import os
import datetime
import ctypes
import sqlite3
import time
import secrets
from tkinter import filedialog
import subprocess
from fpdf import FPDF
from utils.helpers import play_sound, is_windows, is_macos, is_linux, get_resource_path
from storage.database import PasswordDB
from gui.dialogs import CTkMessageBox
from security.clipboard import set_clipboard, clear_clipboard
import tkinter as tk
from localization.lang import LANGUAGES
from utils.logger import get_logger
from core.generator import SecureString, secure_compare, _clear_string, SecurePasswordContext, PasswordGenerator
from cryptography.exceptions import InvalidTag

logger = get_logger("password_ops")


def _secure_zero(data: bytearray) -> None:
    """Обнуляет bytearray через ctypes.memset"""
    if data is None:
        return
    try:
        length = len(data)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(data)), 0, length)
    except (TypeError, AttributeError, OSError) as e:
        logger.debug(f"Memory zeroing failed: {e}")
        for i in range(len(data)):
            data[i] = 0


def _clear_string(s: str) -> None:
    """Пытается очистить строку (через обнуление bytearray)"""
    try:
        if s and not s.startswith(('[encrypted', 'enc1:', 'enc2:', 'enc3:')):
            ba = bytearray(s.encode('utf-8'))
            _secure_zero(ba)
    except (UnicodeEncodeError, TypeError, MemoryError) as e:
        logger.debug(f"String clearing failed: {e}")


class PasswordOpsMixin:
    """Mixin class for password generation, copy, save, open operations"""
    
    def _update_len_label(self, val: float) -> None:
        L = LANGUAGES[self.current_lang]
        self.lbl_len.configure(text=f"{L['len']}: {int(val)}")
    
    def _get_min_length(self) -> int:
        count = sum([self.upper_var.get(), self.lower_var.get(), self.digits_var.get(), self.symb_var.get()])
        return max(4, count)
    
    def _update_strength_meter(self, password: str) -> None:
        if not password:
            self.lbl_strength_text.configure(text="")
            self.lbl_strength.configure(text="")
            self.lbl_crack.configure(text="")
            self.lbl_stars_top.configure(text="")
            return
        
        L = LANGUAGES[self.current_lang]
        stats = self.strength_calc.calculate(password)
        
        self.lbl_strength.configure(text=L["strength"].format(stats['combinations']))
        
        if stats['strength_level'] == 'weak':
            stars_display, stars_color, st_text = "★☆☆☆☆", "#FF4C4C", L["st_low"]
        elif stats['strength_level'] == 'medium':
            if stats['entropy_bits'] < 60:
                stars_display, stars_color, st_text = "★★★☆☆", "#FFA500", L["st_mid"]
            else:
                stars_display, stars_color, st_text = "★★★★☆", "#FFD700", L["st_mid"]
        else:
            stars_display, stars_color, st_text = "★★★★★", "#2ECC71", L["st_high"]
        
        self.lbl_stars_top.configure(text=stars_display, text_color=stars_color)
        self.lbl_strength_text.configure(text=st_text, text_color=stars_color)
        self.lbl_crack.configure(text=L["crack_time"].format(L[stats['crack_time_label']]), text_color=stars_color)
        
        self._animate_password_field(stats['strength_level'])
    
    def _animate_password_field(self, strength_type: str = "medium") -> None:
        original_border = self.entry_res.cget("border_color")
        
        if strength_type == "weak":
            neon_colors = ["#FF4444", "#FF6666", "#FF8888", "#FF6666", "#FF4444"]
        elif strength_type == "strong":
            neon_colors = ["#2ECC71", "#55DD88", "#88EEAA", "#55DD88", "#2ECC71"]
        else:
            neon_colors = ["#FFA500", "#FFBB33", "#FFCC66", "#FFBB33", "#FFA500"]
        
        def pulse_step(step: int = 0) -> None:
            if step < len(neon_colors):
                try:
                    self.entry_res.configure(border_color=neon_colors[step], border_width=3)
                    self._pulse_animation_id = self.after(60, lambda: pulse_step(step + 1))
                except (tk.TclError, AttributeError) as e:
                    logger.debug(f"Animation pulse error: {e}")
            else:
                try:
                    self.entry_res.configure(border_color=original_border if original_border else "#2b2b2b", border_width=2)
                except (tk.TclError, AttributeError) as e:
                    logger.debug(f"Border reset error: {e}")
                self._pulse_animation_id = None
        
        if self._pulse_animation_id:
            try:
                self.after_cancel(self._pulse_animation_id)
            except (tk.TclError, ValueError) as e:
                logger.debug(f"Animation cancel error: {e}")
        pulse_step()
    
    def _generate(self) -> None:
        """Генерация пароля с безопасной очисткой"""
        if hasattr(self, 'btn_gen') and self.btn_gen:
            self._animate_button(self.btn_gen)
        
        L = LANGUAGES[self.current_lang]
        
        self.generator.use_upper = self.upper_var.get()
        self.generator.use_lower = self.lower_var.get()
        self.generator.use_digits = self.digits_var.get()
        self.generator.use_special = self.symb_var.get()
        self.generator.exclude_ambiguous = self.ambig_var.get()
        self.generator.exclude_unambiguous = self.unambig_var.get()
        self.generator.min_each = self.at_least_var.get()
        self.generator.no_repeat = self.no_repeat_var.get()
        self.generator.length = int(self.slider_len.get())
        
        if not (self.generator.use_upper or self.generator.use_lower or 
                self.generator.use_digits or self.generator.use_special):
            CTkMessageBox.warning(self, L.get("err_title", "Error"), L["err_cat"])
            return
        
        try:
            # Используем безопасную генерацию с контекстным менеджером
            with SecurePasswordContext() as ctx:
                secure_pwd = self.generator.generate_secure()
                
                if secure_pwd is None and self.generator.no_repeat:
                    CTkMessageBox.warning(self, L.get("err_title", "Error"), 
                                         L["err_no_repeat"] + L["err_no_repeat_fallback"])
                    self.generator.no_repeat = False
                    secure_pwd = self.generator.generate_secure()
                    self.generator.no_repeat = True
                
                if secure_pwd is None:
                    CTkMessageBox.warning(self, L.get("err_title", "Error"), L["err_pool_small"])
                    return
                
                password = secure_pwd.get_string()
                ctx.set_password(secure_pwd)  # Сохраняем для очистки
                
                if password:
                    try:
                        self.entry_res.delete(0, "end")
                        self.entry_res.insert(0, password)
                        self.history.append(password)
                        self._update_strength_meter(password)
                        play_sound("generate", self.sound_enabled.get())
                    except (tk.TclError, AttributeError) as e:
                        logger.error(f"UI update error: {e}")
                    
                    if self.auto_save_var.get():
                        label = f"Auto {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                        try:
                            PasswordDB.save(label, password)
                            logger.debug(f"[AutoSave] Saved: {label}")
                        except (sqlite3.Error, ValueError, OSError) as exc:
                            logger.error(f"AutoSave error: {exc}")
                            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_save"].format(exc))
                    
                    # Очищаем пароль из памяти
                    _clear_string(password)
                    
        except InvalidTag as e:
            logger.error(f"Invalid authentication tag during generation: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), "Ошибка шифрования: неверный тег аутентификации")
        except ValueError as e:
            logger.error(f"Value error during generation: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"Ошибка генерации: {e}")
        except Exception as e:
            logger.error(f"Generation error: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"Ошибка генерации: {e}")
    
    def _clear_clipboard_windows_api(self) -> None:
        """
        Дополнительная очистка буфера обмена через Windows API.
        Более надёжный способ на Windows.
        """
        if not is_windows():
            return
        
        try:
            import ctypes
            from ctypes import wintypes
            
            user32 = ctypes.windll.user32
            
            # Открываем буфер обмена
            if user32.OpenClipboard(0):
                try:
                    # Очищаем буфер
                    user32.EmptyClipboard()
                    logger.debug("Clipboard cleared via Windows API")
                except (AttributeError, OSError) as e:
                    logger.debug(f"Windows API clipboard clear error: {e}")
                finally:
                    try:
                        user32.CloseClipboard()
                    except (AttributeError, OSError):
                        pass
        except (ImportError, AttributeError, OSError) as e:
            logger.debug(f"Windows API error: {e}")
    
    def _clear_clipboard(self) -> None:
        """
        Очистить буфер обмена с многократной перезаписью для безопасности.
        Перезаписывает буфер случайными данными несколько раз.
        """
        try:
            if not self.winfo_exists():
                return
            
            # Количество перезаписей (рекомендуется 3-5)
            overwrite_passes = 5
            
            for i in range(overwrite_passes):
                try:
                    # Генерируем случайные данные для перезаписи
                    junk = secrets.token_hex(512)  # 1024 байта случайных данных
                    
                    # Перезаписываем буфер
                    self.clipboard_clear()
                    self.clipboard_append(junk)
                    self.update()
                    
                    # Небольшая задержка между перезаписями
                    time.sleep(0.01)
                    
                    # Очищаем случайные данные из памяти
                    _clear_string(junk)
                    
                except (tk.TclError, OSError, AttributeError) as e:
                    logger.debug(f"Clipboard overwrite pass {i + 1} failed: {e}")
                    continue
            
            # Финальная очистка
            self.clipboard_clear()
            self.update()
            
            # Дополнительная очистка для Windows через API
            if is_windows():
                self._clear_clipboard_windows_api()
            
            logger.debug(f"Clipboard securely cleared with {overwrite_passes} overwrites")
            
        except (tk.TclError, OSError, AttributeError) as e:
            logger.debug(f"Clipboard secure clear error: {e}")
            # Fallback: простая очистка
            try:
                self.clipboard_clear()
            except (tk.TclError, OSError):
                pass
        finally:
            self._clipboard_timer = None
    
    def _emergency_clipboard_clear(self) -> None:
        """
        Экстренная очистка буфера обмена (вызывается при панике или закрытии).
        Максимально агрессивная очистка.
        """
        try:
            # Несколько быстрых перезаписей
            for _ in range(3):
                try:
                    self.clipboard_clear()
                    self.clipboard_append(" " * 256)
                    self.update()
                except (tk.TclError, OSError):
                    pass
            
            # Финальная очистка
            self.clipboard_clear()
            self.update()
            
            # Windows API очистка
            if is_windows():
                self._clear_clipboard_windows_api()
            
            logger.debug("Emergency clipboard clear performed")
        except (tk.TclError, OSError, AttributeError) as e:
            logger.debug(f"Emergency clipboard clear error: {e}")
    
    def _copy(self) -> None:
        """Копировать пароль в буфер обмена с безопасной очисткой"""
        # Анимация кнопки
        if hasattr(self, 'btn_copy') and self.btn_copy:
            self._animate_button(self.btn_copy)
        
        # Получаем пароль из поля ввода
        pwd = self.entry_res.get().strip()
        
        if not pwd:
            CTkMessageBox.warning(self, "Внимание", "Нет пароля для копирования!")
            return
        
        L = LANGUAGES[self.current_lang]
        
        # Очищаем старый таймер
        if hasattr(self, '_clipboard_timer') and self._clipboard_timer:
            try:
                self.after_cancel(self._clipboard_timer)
            except (tk.TclError, ValueError) as e:
                logger.debug(f"Clipboard timer cancel error: {e}")
        
        # Копируем в буфер обмена
        try:
            # Очищаем буфер
            self.clipboard_clear()
            # Копируем пароль
            self.clipboard_append(pwd)
            # Для tkinter нужно обновить, чтобы данные сохранились
            self.update()
            
            logger.info(f"Password copied to clipboard (length: {len(pwd)})")
            play_sound("copy", self.sound_enabled.get())
            
        except (tk.TclError, OSError, AttributeError) as e:
            logger.error(f"Clipboard copy error: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"Не удалось скопировать: {e}")
            _clear_string(pwd)
            return
        
        # Устанавливаем таймер для автоматической очистки
        timeout_ms = self.clipboard_timeout * 1000
        self._clipboard_timer = self.after(timeout_ms, self._clear_clipboard)
        
        # Показываем сообщение об успехе
        old_text = self.btn_copy.cget("text")
        self.btn_copy.configure(text=L["copied"].format(self.clipboard_timeout))
        self.after(2000, lambda: self.btn_copy.configure(text=old_text))
        
        # Показываем уведомление
        CTkMessageBox.info(self, L.get("dlg_title_copied", "Буфер обмена"), L["pwd_done"])
        
        # Очищаем пароль из памяти
        _clear_string(pwd)
    
    def _verify_pdf(self, path: str) -> bool:
        try:
            with open(path, "rb") as f:
                header = f.read(5)
                return header == b"%PDF-"
        except (OSError, IOError) as e:
            logger.debug(f"PDF verification error: {e}")
            return False
    
    def _save(self) -> None:
        L = LANGUAGES[self.current_lang]
        pwd = self.entry_res.get().strip()
        if not pwd:
            CTkMessageBox.warning(self, L.get("warn", "Внимание"), L["no_pwd"])
            return
        
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[
                ("Text Files", "*.txt"),
                ("Password Files", "*.key"),
                ("Log Files", "*.log"),
                ("PDF Files", "*.pdf"),
                ("All Files", "*.*")
            ]
        )
        
        if not path:
            _clear_string(pwd)
            return
        
        try:
            ext = os.path.splitext(path)[1].lower()
            
            if ext == ".pdf":
                pdf = FPDF()
                pdf.set_author("Maxim Melnikov")
                pdf.set_creator("Secure Pass Pro v4.0")
                pdf.set_title("Secure Pass Pro Password")
                
                font_path = get_resource_path("DejaVuSans.ttf")
                pdf.add_page()
                pdf.set_font('Arial', 'B', 16)
                pdf.cell(200, 10, txt="Secure Pass Pro v4.0", ln=True, align='C')
                pdf.ln(10)
                
                if os.path.exists(font_path):
                    pdf.add_font('DejaVu', '', font_path, uni=True)
                    pdf.set_font('DejaVu', '', 12)
                else:
                    pdf.set_font('Arial', '', 12)
                
                pdf.cell(200, 10, txt=f"{L['pdf_date']}: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", ln=True)
                pdf.cell(200, 10, txt=f"{L['pdf_pass']}: {pwd}", ln=True)
                pdf.output(path)
                
                if not self._verify_pdf(path):
                    raise IOError(L["err_integrity"])
            else:
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(pwd)
                
                if not os.path.exists(path) or os.path.getsize(path) == 0:
                    raise IOError("Файл не был записан")
            
            play_sound("success", self.sound_enabled.get())
            fname = os.path.basename(path)
            self.title(f"✅ {fname}")
            self.after(3000, lambda: self.title(L["win_title"]))
            
        except PermissionError as e:
            logger.error(f"Permission error saving: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"Нет прав на запись: {e}")
        except OSError as e:
            logger.error(f"OS error saving: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"Ошибка файловой системы: {e}")
        except (ValueError, IOError) as e:
            logger.error(f"IO error saving: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_save"].format(e))
        finally:
            _clear_string(pwd)
    
    def _open(self) -> None:
        L = LANGUAGES[self.current_lang]
        
        path = filedialog.askopenfilename(
            title="Select password file",
            filetypes=[
                ("All Files", "*.*"),
                ("Text Files", "*.txt"),
                ("Password Files", "*.key"),
                ("Log Files", "*.log"),
                ("PDF Files", "*.pdf")
            ]
        )
        
        if not path:
            return
        
        try:
            ext = os.path.splitext(path)[1].lower()
            
            if path.lower().endswith(".sha256"):
                CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_unsupported"].format(".sha256"))
                return
            
            if ext == ".pdf":
                if is_windows():
                    os.startfile(path)
                elif is_macos():
                    subprocess.run(["open", path], check=False)
                else:
                    subprocess.run(["xdg-open", path], check=False)
                play_sound("success", self.sound_enabled.get())
                return
            
            content = None
            encodings = ['utf-8', 'cp1251', 'latin-1', 'cp866', 'koi8-r']
            
            for encoding in encodings:
                try:
                    with open(path, 'r', encoding=encoding) as f:
                        content = f.read().strip()
                    break
                except (UnicodeDecodeError, UnicodeError) as e:
                    logger.debug(f"Encoding {encoding} failed: {e}")
                    continue
            
            if content is None:
                try:
                    with open(path, 'rb') as f:
                        raw_bytes = f.read()
                        content = raw_bytes.decode('utf-8', errors='replace').strip()
                except (OSError, IOError) as e:
                    logger.error(f"Binary read error: {e}")
                    raise ValueError("Cannot read file") from e
            
            if not content:
                raise ValueError("File is empty")
            
            self.entry_res.delete(0, "end")
            self.entry_res.insert(0, content)
            self._update_strength_meter(content)
            play_sound("success", self.sound_enabled.get())
            
            # Очищаем содержимое из памяти после использования
            _clear_string(content)
            
        except PermissionError as e:
            logger.error(f"Permission error opening: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"Нет прав на чтение: {e}")
        except UnicodeDecodeError as e:
            logger.error(f"Encoding error opening: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_open"].format(f"Неверная кодировка: {e}"))
        except (ValueError, IOError, OSError) as e:
            logger.error(f"Error opening: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_open"].format(str(e)))