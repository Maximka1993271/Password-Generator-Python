"""
Password operations mixin for SecurePassPro
FIXED: Добавлены duplicate detection, import sanitization, export validation, safer CRUD operations

Миксин операций с паролями для SecurePassPro
FIXED: Добавлены duplicate detection, import sanitization, export validation, safer CRUD operations

Міксин операцій з паролями для SecurePassPro
FIXED: Додано duplicate detection, import sanitization, export validation, safer CRUD operations
"""
import os
import datetime
import ctypes
import sqlite3
import time
import secrets
import re
from tkinter import filedialog
import subprocess
from fpdf import FPDF
from utils.helpers import play_sound, is_windows, is_macos, is_linux, get_resource_path
from storage.database import PasswordDB
from gui.dialogs import CTkMessageBox
from security.clipboard import set_clipboard, clear_clipboard
import tkinter as tk
from localization.lang import LANGUAGES
from utils.logger import get_logger
from core.generator import SecureString, secure_compare, _clear_string, SecurePasswordContext, PasswordGenerator
from cryptography.exceptions import InvalidTag
from typing import Optional, List, Dict, Any

logger = get_logger("password_ops")

# Maximum password length for import/export
MAX_PASSWORD_LENGTH = 1000
MAX_LABEL_LENGTH = 200
MAX_NOTES_LENGTH = 500


def _secure_zero(data: bytearray) -> None:
    """Zero out bytearray via ctypes.memset
    Обнуляет bytearray через ctypes.memset
    Обнуляє bytearray через ctypes.memset"""
    if data is None:
        return
    try:
        length = len(data)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(data)), 0, length)
    except (TypeError, AttributeError, OSError) as e:
        logger.debug(f"Memory zeroing failed: {e}")
        for i in range(len(data)):
            data[i] = 0


def _clear_string(s: str) -> None:
    """Attempt to clear string (via bytearray zeroing)
    Пытается очистить строку (через обнуление bytearray)
    Намагається очистити рядок (через обнулення bytearray)"""
    try:
        if s and not s.startswith(('[encrypted', 'enc1:', 'enc2:', 'enc3:')):
            ba = bytearray(s.encode('utf-8'))
            _secure_zero(ba)
    except (UnicodeEncodeError, TypeError, MemoryError) as e:
        logger.debug(f"String clearing failed: {e}")


def sanitize_label(label: str, max_length: int = MAX_LABEL_LENGTH) -> str:
    """Sanitize label for database storage
    Очищает метку для хранения в БД
    Очищує мітку для зберігання в БД"""
    if not label:
        return "Без метки"
    
    # Remove control characters / Удаляем управляющие символы / Видаляємо керуючі символи
    sanitized = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', str(label))
    
    # Remove leading/trailing whitespace / Удаляем пробелы в начале и конце / Видаляємо пробіли на початку та в кінці
    sanitized = sanitized.strip()
    
    # Limit length / Ограничиваем длину / Обмежуємо довжину
    if len(sanitized) > max_length:
        sanitized = sanitized[:max_length]
    
    return sanitized if sanitized else "Без метки"


def validate_password_strength(password: str) -> tuple:
    """Validate password strength for saving
    Проверяет надёжность пароля для сохранения
    Перевіряє надійність пароля для збереження"""
    if not password:
        return False, "Password is empty"
    
    if len(password) < 4:
        return False, "Password too short (minimum 4 characters)"
    
    # Check for common weak patterns / Проверка на слабые паттерны / Перевірка на слабкі патерни
    weak_patterns = ['123456', 'password', 'qwerty', 'admin', 'letmein', 'welcome']
    for pattern in weak_patterns:
        if pattern.lower() in password.lower():
            return False, f"Password contains weak pattern: {pattern}"
    
    return True, ""


class PasswordOpsMixin:
    """Mixin class for password generation, copy, save, open operations
    Класс-миксин для операций генерации, копирования, сохранения, открытия паролей
    Клас-міксин для операцій генерації, копіювання, збереження, відкриття паролів"""

    def _update_len_label(self, val: float) -> None:
        L = LANGUAGES[self.current_lang]
        try:
            self.lbl_len.configure(text=f"{L['len']}: {int(val)}")
        except (tk.TclError, KeyError, AttributeError) as e:
            logger.debug(f"Update length label error: {e}")

    def _get_min_length(self) -> int:
        count = sum([self.upper_var.get(), self.lower_var.get(), self.digits_var.get(), self.symb_var.get()])
        return max(4, count)

    def _update_strength_meter(self, password: str) -> None:
        if not password:
            try:
                self.lbl_strength_text.configure(text="")
                self.lbl_strength.configure(text="")
                self.lbl_crack.configure(text="")
                self.lbl_stars_top.configure(text="")
            except (tk.TclError, AttributeError, RuntimeError):
                pass
            return

        L = LANGUAGES[self.current_lang]
        try:
            stats = self.strength_calc.calculate(password)
        except (ValueError, TypeError, AttributeError) as e:
            logger.error(f"Strength calculation error: {e}")
            return

        try:
            self.lbl_strength.configure(text=L["strength"].format(stats['combinations']))
        except (tk.TclError, KeyError, AttributeError) as e:
            logger.debug(f"Strength label update error: {e}")

        if stats['strength_level'] == 'weak':
            stars_display, stars_color, st_text = "Weak", "#FF4C4C", L["st_low"]
        elif stats['strength_level'] == 'medium':
            if stats['entropy_bits'] < 60:
                stars_display, stars_color, st_text = "Medium", "#FFA500", L["st_mid"]
            else:
                stars_display, stars_color, st_text = "Medium+", "#FFD700", L["st_mid"]
        else:
            stars_display, stars_color, st_text = "Strong", "#2ECC71", L["st_high"]

        try:
            self.lbl_stars_top.configure(text=stars_display, text_color=stars_color)
            self.lbl_strength_text.configure(text=st_text, text_color=stars_color)
            self.lbl_crack.configure(text=L["crack_time"].format(L[stats['crack_time_label']]), text_color=stars_color)
        except (tk.TclError, KeyError, AttributeError) as e:
            logger.debug(f"Strength indicators update error: {e}")

        self._animate_password_field(stats['strength_level'])

    def _animate_password_field(self, strength_type: str = "medium") -> None:
        try:
            original_border = self.entry_res.cget("border_color")
        except (tk.TclError, AttributeError):
            original_border = "#2b2b2b"

        if strength_type == "weak":
            neon_colors = ["#FF4444", "#FF6666", "#FF8888", "#FF6666", "#FF4444"]
        elif strength_type == "strong":
            neon_colors = ["#2ECC71", "#55DD88", "#88EEAA", "#55DD88", "#2ECC71"]
        else:
            neon_colors = ["#FFA500", "#FFBB33", "#FFCC66", "#FFBB33", "#FFA500"]

        def pulse_step(step: int = 0) -> None:
            if step < len(neon_colors):
                try:
                    self.entry_res.configure(border_color=neon_colors[step], border_width=3)
                    self._pulse_animation_id = self.after(60, lambda: pulse_step(step + 1))
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Animation pulse error: {e}")
            else:
                try:
                    self.entry_res.configure(border_color=original_border if original_border else "#2b2b2b", border_width=2)
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Border reset error: {e}")
                self._pulse_animation_id = None

        if self._pulse_animation_id:
            try:
                self.after_cancel(self._pulse_animation_id)
            except (tk.TclError, ValueError, RuntimeError) as e:
                logger.debug(f"Animation cancel error: {e}")
        pulse_step()

    def _check_duplicate_password(self, password: str) -> bool:
        """
        Check if password already exists in the database.
        
        Проверяет, существует ли уже такой пароль в базе.
        Перевіряє, чи вже існує такий пароль у базі.
        
        Args:
            password: Password to check / Пароль для проверки / Пароль для перевірки
        
        Returns:
            True if duplicate found / True если дубликат найден / True якщо дублікат знайдено
        """
        try:
            all_passwords = PasswordDB.get_all()
            for record in all_passwords:
                if record.get("password") == password:
                    return True
        except (sqlite3.Error, OSError, IOError, ValueError, TypeError) as e:
            logger.error(f"Duplicate check error: {e}")
        return False

    def _sanitize_import_content(self, content: str) -> str:
        """
        Sanitize imported content.
        Removes potentially dangerous characters.
        
        Санитизация импортируемого содержимого.
        Удаляет потенциально опасные символы.
        
        Санітизація імпортованого вмісту.
        Видаляє потенційно небезпечні символи.
        
        Args:
            content: Original content / Исходное содержимое / Вихідний вміст
        
        Returns:
            Sanitized content / Очищенное содержимое / Очищений вміст
        """
        if not content:
            return ""
        
        # Remove null characters and control characters (except \n, \r, \t)
        # Удаляем нулевые символы и управляющие символы (кроме \n, \r, \t)
        # Видаляємо нульові символи та керуючі символи (крім \n, \r, \t)
        sanitized = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', content)
        
        # Remove Unicode control characters / Удаляем управляющие символы Unicode / Видаляємо керуючі символи Unicode
        sanitized = re.sub(r'[\u200B-\u200D\uFEFF]', '', sanitized)
        
        # Limit length (max 1000 characters for password)
        # Ограничиваем длину (максимум 1000 символов для пароля)
        # Обмежуємо довжину (максимум 1000 символів для пароля)
        if len(sanitized) > MAX_PASSWORD_LENGTH:
            sanitized = sanitized[:MAX_PASSWORD_LENGTH]
        
        return sanitized

    def _validate_export_path(self, path: str) -> bool:
        """
        Check if export path is safe.
        
        Проверяет, что путь для экспорта безопасен.
        Перевіряє, що шлях для експорту безпечний.
        
        Args:
            path: Export path / Путь для экспорта / Шлях для експорту
        
        Returns:
            True if path is safe / True если путь безопасен / True якщо шлях безпечний
        """
        try:
            # Check that directory exists or can be created
            # Проверяем, что директория существует или может быть создана
            # Перевіряємо, що директорія існує або може бути створена
            directory = os.path.dirname(path)
            if directory and not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
            
            # Check that we can write to the file
            # Проверяем, что можно записать в файл
            # Перевіряємо, що можна записати у файл
            test_file = path + ".test"
            with open(test_file, 'w') as f:
                f.write("test")
            os.remove(test_file)
            
            return True
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Export path validation error: {e}")
            return False

    def _generate(self) -> None:
        """Generate password with secure clearing and duplicate checking
        Генерация пароля с безопасной очисткой и проверкой дубликатов
        Генерація пароля з безпечним очищенням та перевіркою дублікатів"""
        if hasattr(self, 'btn_gen') and self.btn_gen:
            self._animate_button(self.btn_gen)

        L = LANGUAGES[self.current_lang]

        self.generator.use_upper = self.upper_var.get()
        self.generator.use_lower = self.lower_var.get()
        self.generator.use_digits = self.digits_var.get()
        self.generator.use_special = self.symb_var.get()
        self.generator.exclude_ambiguous = self.ambig_var.get()
        self.generator.exclude_unambiguous = self.unambig_var.get()
        self.generator.min_each = self.at_least_var.get()
        self.generator.no_repeat = self.no_repeat_var.get()
        self.generator.length = int(self.slider_len.get())

        if not (self.generator.use_upper or self.generator.use_lower or
                self.generator.use_digits or self.generator.use_special):
            CTkMessageBox.warning(self, L.get("err_title", "Error"), L["err_cat"])
            return

        try:
            # Use secure generation with context manager
            # Используем безопасную генерацию с контекстным менеджером
            # Використовуємо безпечну генерацію з контекстним менеджером
            with SecurePasswordContext() as ctx:
                secure_pwd = self.generator.generate_secure()

                if secure_pwd is None and self.generator.no_repeat:
                    CTkMessageBox.warning(self, L.get("err_title", "Error"),
                                         L["err_no_repeat"] + L["err_no_repeat_fallback"])
                    self.generator.no_repeat = False
                    secure_pwd = self.generator.generate_secure()
                    self.generator.no_repeat = True

                if secure_pwd is None:
                    CTkMessageBox.warning(self, L.get("err_title", "Error"), L["err_pool_small"])
                    return

                password = secure_pwd.get_string()
                ctx.set_password(secure_pwd)

                if password:
                    # Validate password strength / Проверка надёжности пароля / Перевірка надійності пароля
                    is_valid, validation_msg = validate_password_strength(password)
                    if not is_valid:
                        L_local = LANGUAGES[self.current_lang]
                        if not CTkMessageBox.question(
                            self,
                            L_local.get("warn", "Warning"),
                            f"{validation_msg}\n\n{L_local.get('continue_anyway', 'Continue anyway?')}"
                        ):
                            _clear_string(password)
                            return
                    
                    # Check for duplicate / Проверка на дубликат / Перевірка на дублікат
                    if self.auto_save_var.get() and self._check_duplicate_password(password):
                        L_local = LANGUAGES[self.current_lang]
                        if not CTkMessageBox.question(
                            self,
                            L_local.get("warn", "Warning"),
                            L_local.get("duplicate_warning", "This password already exists in the database.\n\nSave anyway?")
                        ):
                            _clear_string(password)
                            return

                    try:
                        self.entry_res.delete(0, "end")
                        self.entry_res.insert(0, password)
                        self.history.append(password)
                        self._update_strength_meter(password)
                        play_sound("generate", self.sound_enabled.get())
                    except (tk.TclError, AttributeError, RuntimeError) as e:
                        logger.error(f"UI update error: {e}")

                    if self.auto_save_var.get():
                        label = f"Auto {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                        label = sanitize_label(label)
                        try:
                            PasswordDB.save(label, password)
                            logger.debug(f"[AutoSave] Saved: {label}")
                        except (sqlite3.Error, ValueError, OSError, IOError) as exc:
                            logger.error(f"AutoSave error: {exc}")
                            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_save"].format(exc))

                    _clear_string(password)

        except InvalidTag as e:
            logger.error(f"Invalid authentication tag during generation: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), "Encryption error: invalid authentication tag")
        except (ValueError, TypeError, RuntimeError, AttributeError) as e:
            logger.error(f"Value error during generation: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"Generation error: {e}")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"IO error during generation: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"IO error: {e}")

    def _clear_clipboard_windows_api(self) -> None:
        """
        Additional clipboard clearing via Windows API.
        More reliable method on Windows.
        
        Дополнительная очистка буфера обмена через Windows API.
        Более надёжный способ на Windows.
        
        Додаткове очищення буфера обміну через Windows API.
        Більш надійний спосіб на Windows.
        """
        if not is_windows():
            return

        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.windll.user32

            # Open clipboard / Открываем буфер обмена / Відкриваємо буфер обміну
            if user32.OpenClipboard(0):
                try:
                    user32.EmptyClipboard()
                    logger.debug("Clipboard cleared via Windows API")
                except (AttributeError, OSError) as e:
                    logger.debug(f"Windows API clipboard clear error: {e}")
                finally:
                    try:
                        user32.CloseClipboard()
                    except (AttributeError, OSError):
                        pass
        except (ImportError, AttributeError, OSError, TypeError) as e:
            logger.debug(f"Windows API error: {e}")

    def _clear_clipboard(self) -> None:
        """
        Clear clipboard with multiple overwrites for security.
        Overwrites clipboard with random data several times.
        
        Очистить буфер обмена с многократной перезаписью для безопасности.
        Перезаписывает буфер случайными данными несколько раз.
        
        Очистити буфер обміну з багаторазовим перезаписом для безпеки.
        Перезаписує буфер випадковими даними кілька разів.
        """
        try:
            if not self.winfo_exists():
                return

            # Number of overwrites (recommended 3-5)
            # Количество перезаписей (рекомендуется 3-5)
            # Кількість перезаписів (рекомендується 3-5)
            overwrite_passes = 5

            for i in range(overwrite_passes):
                try:
                    # Generate random data for overwrite
                    # Генерируем случайные данные для перезаписи
                    # Генеруємо випадкові дані для перезапису
                    junk = secrets.token_hex(512)

                    # Overwrite buffer / Перезаписываем буфер / Перезаписуємо буфер
                    self.clipboard_clear()
                    self.clipboard_append(junk)
                    self.update()

                    time.sleep(0.01)

                    _clear_string(junk)

                except (tk.TclError, OSError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Clipboard overwrite pass {i + 1} failed: {e}")
                    continue

            self.clipboard_clear()
            self.update()

            if is_windows():
                self._clear_clipboard_windows_api()

            logger.debug(f"Clipboard securely cleared with {overwrite_passes} overwrites")

        except (tk.TclError, OSError, AttributeError, RuntimeError) as e:
            logger.debug(f"Clipboard secure clear error: {e}")
            try:
                self.clipboard_clear()
            except (tk.TclError, OSError, RuntimeError):
                pass
        finally:
            self._clipboard_timer = None

    def _emergency_clipboard_clear(self) -> None:
        """
        Emergency clipboard clear (called on panic or close).
        Maximum aggressive clearing.
        
        Экстренная очистка буфера обмена (вызывается при панике или закрытии).
        Максимально агрессивная очистка.
        
        Екстрене очищення буфера обміну (викликається при паніці або закритті).
        Максимально агресивне очищення.
        """
        try:
            for _ in range(3):
                try:
                    self.clipboard_clear()
                    self.clipboard_append(" " * 256)
                    self.update()
                except (tk.TclError, OSError, RuntimeError):
                    pass

            self.clipboard_clear()
            self.update()

            if is_windows():
                self._clear_clipboard_windows_api()

            logger.debug("Emergency clipboard clear performed")
        except (tk.TclError, OSError, AttributeError, RuntimeError) as e:
            logger.debug(f"Emergency clipboard clear error: {e}")

    def _copy(self) -> None:
        """Copy password to clipboard with secure clearing
        Копировать пароль в буфер обмена с безопасной очисткой
        Копіювати пароль у буфер обміну з безпечним очищенням"""
        if hasattr(self, 'btn_copy') and self.btn_copy:
            self._animate_button(self.btn_copy)

        pwd = self.entry_res.get().strip()

        if not pwd:
            CTkMessageBox.warning(self, "Warning", "No password to copy!")
            return

        L = LANGUAGES[self.current_lang]

        if hasattr(self, '_clipboard_timer') and self._clipboard_timer:
            try:
                self.after_cancel(self._clipboard_timer)
            except (tk.TclError, ValueError, RuntimeError) as e:
                logger.debug(f"Clipboard timer cancel error: {e}")

        try:
            self.clipboard_clear()
            self.clipboard_append(pwd)
            self.update()

            logger.info(f"Password copied to clipboard (length: {len(pwd)})")
            play_sound("copy", self.sound_enabled.get())

        except (tk.TclError, OSError, AttributeError, RuntimeError) as e:
            logger.error(f"Clipboard copy error: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"Could not copy: {e}")
            _clear_string(pwd)
            return

        timeout_ms = self.clipboard_timeout * 1000
        self._clipboard_timer = self.after(timeout_ms, self._clear_clipboard)

        try:
            old_text = self.btn_copy.cget("text")
            self.btn_copy.configure(text=L["copied"].format(self.clipboard_timeout))
            self.after(2000, lambda: self._safe_button_restore(old_text))
        except (tk.TclError, AttributeError, KeyError) as e:
            logger.debug(f"Button text update error: {e}")

        CTkMessageBox.info(self, L.get("dlg_title_copied", "Clipboard"), L["pwd_done"])

        _clear_string(pwd)

    def _safe_button_restore(self, old_text: str) -> None:
        """Safely restore button text / Безопасно восстанавливает текст кнопки / Безпечно відновлює текст кнопки"""
        try:
            if hasattr(self, 'btn_copy') and self.btn_copy and self.btn_copy.winfo_exists():
                self.btn_copy.configure(text=old_text)
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Button restore error: {e}")

    def _verify_pdf(self, path: str) -> bool:
        try:
            with open(path, "rb") as f:
                header = f.read(5)
                return header == b"%PDF-"
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"PDF verification error: {e}")
            return False

    def _save(self) -> None:
        """Save password to file with path validation
        Сохранить пароль в файл с проверкой пути
        Зберегти пароль у файл з перевіркою шляху"""
        L = LANGUAGES[self.current_lang]
        pwd = self.entry_res.get().strip()
        if not pwd:
            CTkMessageBox.warning(self, L.get("warn", "Warning"), L["no_pwd"])
            return

        # Validate password before saving / Проверяем пароль перед сохранением / Перевіряємо пароль перед збереженням
        is_valid, validation_msg = validate_password_strength(pwd)
        if not is_valid:
            if not CTkMessageBox.question(
                self,
                L.get("warn", "Warning"),
                f"{validation_msg}\n\n{L.get('continue_anyway', 'Continue anyway?')}"
            ):
                _clear_string(pwd)
                return

        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[
                ("Text Files", "*.txt"),
                ("Password Files", "*.key"),
                ("Log Files", "*.log"),
                ("PDF Files", "*.pdf"),
                ("All Files", "*.*")
            ]
        )

        if not path:
            _clear_string(pwd)
            return

        # Path validation / Валидация пути / Перевірка шляху
        if not self._validate_export_path(os.path.dirname(path)):
            CTkMessageBox.error(self, L.get("err_title", "Error"), L.get("err_permission", "Cannot write to selected location"))
            _clear_string(pwd)
            return

        try:
            ext = os.path.splitext(path)[1].lower()

            if ext == ".pdf":
                pdf = FPDF()
                pdf.set_author("Maxim Melnikov")
                pdf.set_creator("Secure Pass Pro v4.0")
                pdf.set_title("Secure Pass Pro Password")

                pdf_theme = self.config.get("PDF_THEME", "light")

                font_path = get_resource_path("DejaVuSans.ttf")
                pdf.add_page()

                if pdf_theme == "dark":
                    pdf.set_fill_color(30, 30, 46)
                    pdf.set_text_color(200, 200, 200)
                    pdf.set_draw_color(45, 106, 79)
                    pdf.rect(0, 0, 210, 297, 'F')
                    pdf.set_text_color(78, 201, 176)
                    pdf.set_font('Arial', 'B', 16)
                    pdf.cell(200, 10, txt="Secure Pass Pro v4.0", ln=True, align='C', border=0)
                    pdf.ln(10)
                    pdf.set_text_color(200, 200, 200)
                else:
                    pdf.set_fill_color(255, 255, 255)
                    pdf.set_text_color(0, 0, 0)
                    pdf.set_font('Arial', 'B', 16)
                    pdf.cell(200, 10, txt="Secure Pass Pro v4.0", ln=True, align='C')
                    pdf.ln(10)

                if os.path.exists(font_path):
                    pdf.add_font('DejaVu', '', font_path, uni=True)
                    pdf.set_font('DejaVu', '', 12)
                else:
                    pdf.set_font('Arial', '', 12)

                if pdf_theme == "dark":
                    pdf.set_text_color(200, 200, 200)

                pdf.cell(200, 10, txt=f"{L['pdf_date']}: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", ln=True)
                pdf.cell(200, 10, txt=f"{L['pdf_pass']}: {pwd}", ln=True)
                pdf.output(path)

                if not self._verify_pdf(path):
                    raise IOError(L["err_integrity"])
            else:
                # Sanitize content for text files / Санитизация содержимого для текстовых файлов / Санітизація вмісту для текстових файлів
                safe_content = self._sanitize_import_content(pwd)
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(safe_content)

                if not os.path.exists(path) or os.path.getsize(path) == 0:
                    raise IOError("File was not written")

            play_sound("success", self.sound_enabled.get())
            fname = os.path.basename(path)
            try:
                self.title(f"{fname}")
                self.after(3000, lambda: self.title(L["win_title"]))
            except (tk.TclError, KeyError, AttributeError) as e:
                logger.debug(f"Title update error: {e}")

        except PermissionError as e:
            logger.error(f"Permission error saving: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"No write permission: {e}")
        except (OSError, IOError) as e:
            logger.error(f"OS error saving: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"File system error: {e}")
        except (ValueError, TypeError, RuntimeError) as e:
            logger.error(f"Value error saving: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_save"].format(e))
        finally:
            _clear_string(pwd)

    def _open(self) -> None:
        """Open password from file with content validation
        Открыть пароль из файла с проверкой содержимого
        Відкрити пароль з файлу з перевіркою вмісту"""
        L = LANGUAGES[self.current_lang]

        path = filedialog.askopenfilename(
            title="Select password file",
            filetypes=[
                ("All Files", "*.*"),
                ("Text Files", "*.txt"),
                ("Password Files", "*.key"),
                ("Log Files", "*.log"),
                ("PDF Files", "*.pdf")
            ]
        )

        if not path:
            return

        try:
            ext = os.path.splitext(path)[1].lower()

            if path.lower().endswith(".sha256"):
                CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_unsupported"].format(".sha256"))
                return

            if ext == ".pdf":
                if is_windows():
                    os.startfile(path)
                elif is_macos():
                    subprocess.run(["open", path], check=False)
                else:
                    subprocess.run(["xdg-open", path], check=False)
                play_sound("success", self.sound_enabled.get())
                return

            content = None
            encodings = ['utf-8', 'cp1251', 'latin-1', 'cp866', 'koi8-r']

            for encoding in encodings:
                try:
                    with open(path, 'r', encoding=encoding) as f:
                        content = f.read().strip()
                    break
                except (UnicodeDecodeError, UnicodeError) as e:
                    logger.debug(f"Encoding {encoding} failed: {e}")
                    continue

            if content is None:
                try:
                    with open(path, 'rb') as f:
                        raw_bytes = f.read()
                        content = raw_bytes.decode('utf-8', errors='replace').strip()
                except (OSError, IOError, PermissionError) as e:
                    logger.error(f"Binary read error: {e}")
                    raise ValueError("Cannot read file") from e

            if not content:
                raise ValueError("File is empty")

            # Validate content length / Проверяем длину содержимого / Перевіряємо довжину вмісту
            if len(content) > MAX_PASSWORD_LENGTH:
                L_local = LANGUAGES[self.current_lang]
                if not CTkMessageBox.question(
                    self,
                    L_local.get("warn", "Warning"),
                    f"File contains {len(content)} characters.\n{L_local.get('truncate_question', 'Truncate to {0} characters?').format(MAX_PASSWORD_LENGTH)}"
                ):
                    _clear_string(content)
                    return
                content = content[:MAX_PASSWORD_LENGTH]

            # Sanitize imported content / Санитизация импортируемого содержимого / Санітизація імпортованого вмісту
            sanitized_content = self._sanitize_import_content(content)

            try:
                self.entry_res.delete(0, "end")
                self.entry_res.insert(0, sanitized_content)
                self._update_strength_meter(sanitized_content)
                play_sound("success", self.sound_enabled.get())
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.error(f"UI update error: {e}")

            _clear_string(content)
            _clear_string(sanitized_content)

        except PermissionError as e:
            logger.error(f"Permission error opening: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"No read permission: {e}")
        except (UnicodeDecodeError, UnicodeError) as e:
            logger.error(f"Encoding error opening: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_open"].format(f"Invalid encoding: {e}"))
        except (ValueError, OSError, IOError, TypeError, RuntimeError) as e:
            logger.error(f"Error opening: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_open"].format(str(e)))