"""
Dialogs mixin for SecurePassPro - FULLY FIXED VERSION with FULL 3-LANGUAGE SUPPORT
Исправлены: сохранение текущего пароля, экспорт данных, полная поддержка 3 языков
FIXED: Убраны все broad exceptions, добавлена корректная обработка ошибок
FIXED: Fixed: saving current password, data export, full 3-language support
FIXED: Removed all broad exceptions, added proper error handling
FIXED: Виправлено: збереження поточного пароля, експорт даних, повна підтримка 3 мов
FIXED: Прибрано всі broad exceptions, додано коректну обробку помилок
"""
import os
import webbrowser
import datetime
import subprocess
import sqlite3
import qrcode
import customtkinter as ctk
import tkinter as tk
from PIL import Image
from fpdf import FPDF
from storage.database import PasswordDB
from gui.dialogs import CTkMessageBox, CTkInputDialog
from localization.lang import LANGUAGES
from utils.helpers import set_window_icon, apply_window_rounding, is_windows, is_macos, is_linux, get_resource_path
from utils.logger import get_logger
from typing import Optional, Dict, Any, List

logger = get_logger("dialogs")


class DialogsMixin:
    """Mixin class for dialog windows (QR, History, Database, About)
    Класс-миксин для диалоговых окон (QR, История, База данных, О программе)
    Клас-міксин для діалогових вікон (QR, Історія, База даних, Про програму)"""

    def _minimize_all_windows(self) -> None:
        """Minimize main window and all open additional windows
        Сворачивает главное окно и все открытые дополнительные окна
        Згортає головне вікно та всі відкриті додаткові вікна"""
        window_attrs = ['qr_window', 'history_window', 'db_window', 'about_window']
        
        for attr in window_attrs:
            win = getattr(self, attr, None)
            if win and win.winfo_exists():
                try:
                    win.iconify()
                except tk.TclError as e:
                    logger.debug(f"Window iconify error for {attr}: {e}")

        try:
            self.iconify()
        except tk.TclError as e:
            logger.debug(f"Main window iconify error: {e}")

    def _setup_window_style(self, window) -> None:
        """Set up window style for proper taskbar minimization
        Настраивает стиль окна для правильного сворачивания в панель задач
        Налаштовує стиль вікна для правильного згортання в панель завдань"""
        if not is_windows():
            return
        
        try:
            import ctypes
            hwnd = ctypes.windll.user32.GetParent(window.winfo_id())
            if not hwnd:
                hwnd = ctypes.windll.user32.GetAncestor(window.winfo_id(), 2)
            
            if hwnd:
                GWL_EXSTYLE = -20
                current_style = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
                ctypes.windll.user32.SetWindowLongW(hwnd, GWL_EXSTYLE, current_style | 0x40000)
                ctypes.windll.user32.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x0020 | 0x0002)
        except (ImportError, AttributeError, OSError, TypeError) as e:
            logger.debug(f"Window style setup error: {e}")

    def _show_qr(self) -> None:
        """Show QR code window for password
        Показывает окно с QR-кодом для пароля
        Показує вікно з QR-кодом для пароля"""
        pwd = self.entry_res.get()
        if not pwd:
            CTkMessageBox.warning(
                self,
                LANGUAGES[self.current_lang].get("warn", "Warning"),
                LANGUAGES[self.current_lang].get("no_pwd", "No password to show QR code")
            )
            return

        if self.qr_window and self.qr_window.winfo_exists():
            try:
                self.qr_window.lift()
                self.qr_window.focus_force()
            except tk.TclError:
                self.qr_window = None
                self._show_qr()
            return

        L = LANGUAGES[self.current_lang]
        QR_TIMEOUT = 30

        self.qr_window = ctk.CTkToplevel(self)
        self.qr_window.title(L["btn_qr"])
        try:
            set_window_icon(self.qr_window)
        except (AttributeError, OSError) as e:
            logger.debug(f"Set window icon error: {e}")
        
        self.qr_window.transient(self)
        self.qr_window.attributes("-topmost", True)
        self.qr_window.after(100, lambda: self._set_topmost_false(self.qr_window))
        
        try:
            self._setup_window_style(self.qr_window)
        except (AttributeError, OSError) as e:
            logger.debug(f"Setup window style error: {e}")
        
        try:
            self._center_window_relative_to_parent(self.qr_window, 380, 500)
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Center window error: {e}")
            self.qr_window.geometry("380x500")
        
        try:
            apply_window_rounding(self.qr_window)
        except (AttributeError, OSError) as e:
            logger.debug(f"Window rounding error: {e}")
        
        self.qr_window.protocol("WM_DELETE_WINDOW", self._close_qr)

        try:
            img = qrcode.make(pwd).resize((280, 280))
            ctk_img = ctk.CTkImage(light_image=img, dark_image=img, size=(280, 280))
        except (ValueError, OSError, TypeError, ImportError) as e:
            logger.error(f"QR generation error: {e}")
            CTkMessageBox.error(
                self, 
                L.get("err_title", "Error"), 
                f"{L.get('err_qr', 'Could not create QR code')}: {e}"
            )
            self._close_qr()
            return

        f = ctk.CTkFrame(self.qr_window, fg_color="transparent")
        f.pack(expand=True, fill="both", padx=20, pady=20)
        
        try:
            ctk.CTkLabel(f, text=L["btn_qr"], font=("Segoe UI", 18, "bold")).pack()
        except (tk.TclError, KeyError) as e:
            logger.debug(f"Label creation error: {e}")

        disp = ctk.CTkFrame(f, fg_color="white", corner_radius=self.current_radius,
                            border_width=2, border_color="gray")
        disp.pack(pady=10)
        qr_label = ctk.CTkLabel(disp, image=ctk_img, text="")
        qr_label.image = ctk_img
        qr_label.pack(padx=10, pady=10)

        countdown_lbl = ctk.CTkLabel(f, text="", font=("Segoe UI", 12), text_color="#888888")
        countdown_lbl.pack(pady=(0, 4))

        def _tick(s: int) -> None:
            if not self.qr_window or not self.qr_window.winfo_exists():
                return
            if s <= 0:
                self._close_qr()
                return
            closes_in_text = L.get("qr_closes_in", "Window closes in")
            seconds_text = L.get("seconds_short", "sec")
            try:
                countdown_lbl.configure(text=f"{closes_in_text} {s} {seconds_text}")
            except tk.TclError:
                return
            self.qr_window.after(1000, lambda: _tick(s - 1))

        _tick(QR_TIMEOUT)

        try:
            ctk.CTkButton(f, text=L["ok"], command=self._close_qr,
                         corner_radius=self.current_radius).pack(pady=6)
        except (tk.TclError, KeyError) as e:
            logger.debug(f"Button creation error: {e}")

        try:
            self.qr_window.focus_force()
        except tk.TclError:
            pass

    def _set_topmost_false(self, window) -> None:
        """Safely remove topmost flag / Безопасно снимает флаг topmost / Безпечно знімає прапор topmost"""
        try:
            window.attributes("-topmost", False)
        except tk.TclError:
            pass

    def _close_qr(self) -> None:
        """Close QR code window / Закрывает окно QR-кода / Закриває вікно QR-коду"""
        if self.qr_window:
            try:
                self.qr_window.destroy()
            except tk.TclError as e:
                logger.debug(f"QR window destroy error: {e}")
            finally:
                self.qr_window = None

    def _show_history(self) -> None:
        """Show password history window / Показывает окно истории паролей / Показує вікно історії паролів"""
        if self.history_window and self.history_window.winfo_exists():
            try:
                self.history_window.lift()
                self.history_window.focus_force()
            except tk.TclError:
                self.history_window = None
                self._show_history()
            return

        L = LANGUAGES[self.current_lang]

        self.history_window = ctk.CTkToplevel(self)
        self.history_window.title(L["btn_hist"])
        try:
            set_window_icon(self.history_window)
        except (AttributeError, OSError) as e:
            logger.debug(f"Set window icon error: {e}")
        
        self.history_window.transient(self)
        self.history_window.attributes('-topmost', True)
        self.history_window.after(100, lambda: self._set_topmost_false(self.history_window))
        
        try:
            self._setup_window_style(self.history_window)
        except (AttributeError, OSError) as e:
            logger.debug(f"Setup window style error: {e}")
        
        try:
            self._center_window_relative_to_parent(self.history_window, 500, 580)
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Center window error: {e}")
            self.history_window.geometry("500x580")
        
        try:
            apply_window_rounding(self.history_window)
        except (AttributeError, OSError) as e:
            logger.debug(f"Window rounding error: {e}")
        
        self.history_window.protocol("WM_DELETE_WINDOW", self._close_history)

        f = ctk.CTkFrame(self.history_window, fg_color="transparent")
        f.pack(expand=True, fill="both", padx=20, pady=20)
        
        try:
            ctk.CTkLabel(f, text=L["btn_hist"], font=("Segoe UI", 20, "bold")).pack(pady=10)
        except (tk.TclError, KeyError) as e:
            logger.debug(f"Label creation error: {e}")
        
        txt = ctk.CTkTextbox(f, font=("Consolas", 14), corner_radius=self.current_radius)
        txt.pack(fill="both", expand=True, pady=10)

        if not self.history:
            txt.insert("1.0", L["hist_empty"])
        else:
            history_snapshot = list(reversed(self.history))
            try:
                txt.insert("1.0", "\n".join(history_snapshot))
            except (tk.TclError, UnicodeEncodeError) as e:
                logger.error(f"History insert error: {e}")
                txt.insert("1.0", L["hist_empty"])
        txt.configure(state="disabled")

        btn_f = ctk.CTkFrame(f, fg_color="transparent")
        btn_f.pack(fill="x")
        
        def clear_history():
            L_local = LANGUAGES[self.current_lang]
            if CTkMessageBox.question(self.history_window, L_local["btn_hist"], L_local.get("db_del_confirm", "Clear history?")):
                self.history.clear()
                try:
                    txt.configure(state="normal")
                    txt.delete("1.0", "end")
                    txt.insert("1.0", L_local["hist_empty"])
                    txt.configure(state="disabled")
                except tk.TclError as e:
                    logger.error(f"Clear history error: {e}")
        
        clear_btn = ctk.CTkButton(
            btn_f, text=L["btn_clear_hist"], corner_radius=self.current_radius, 
            fg_color="#d13438", command=clear_history
        )
        clear_btn.pack(side="left", padx=5)
        
        ok_btn = ctk.CTkButton(
            btn_f, text=L["ok"], corner_radius=self.current_radius,
            command=self._close_history
        )
        ok_btn.pack(side="right", padx=5)

        try:
            self.history_window.focus_force()
        except tk.TclError:
            pass
        
        self.history_textbox = txt

    def _close_history(self) -> None:
        """Close history window / Закрывает окно истории / Закриває вікно історії"""
        if self.history_window:
            try:
                self.history_window.destroy()
            except tk.TclError as e:
                logger.debug(f"History window destroy error: {e}")
            finally:
                self.history_window = None
                self.history_textbox = None

    def _clear_history_textbox(self, textbox: ctk.CTkTextbox) -> None:
        """Clear history text field / Очищает текстовое поле истории / Очищує текстове поле історії"""
        L = LANGUAGES[self.current_lang]
        self.history.clear()
        try:
            textbox.configure(state="normal")
            textbox.delete("1.0", "end")
            textbox.insert("1.0", L["hist_empty"])
            textbox.configure(state="disabled")
        except (tk.TclError, AttributeError) as e:
            logger.error(f"Clear history error: {e}")

    def _show_db_window(self) -> None:
        """Show password database window with fully working buttons
        Показывает окно базы паролей с полностью работающими кнопками
        Показує вікно бази паролів з повністю працюючими кнопками"""
        L = LANGUAGES[self.current_lang]
        colors = self._get_colors_for_theme(self._get_actual_theme())
        radius = self.current_radius

        if self.db_window and self.db_window.winfo_exists():
            try:
                self.db_window.lift()
                self.db_window.focus_force()
            except tk.TclError:
                self.db_window = None
                self._show_db_window()
            return

        self.db_window = ctk.CTkToplevel(self)
        self.db_window.title(L["db_title"])
        self.db_window.resizable(True, True)
        self.db_window.minsize(800, 500)
        
        try:
            self._setup_window_style(self.db_window)
        except (AttributeError, OSError) as e:
            logger.debug(f"Setup window style error: {e}")
        
        try:
            apply_window_rounding(self.db_window)
        except (AttributeError, OSError) as e:
            logger.debug(f"Window rounding error: {e}")
        
        try:
            self._center_window_relative_to_parent(self.db_window, 900, 700)
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Center window error: {e}")
            self.db_window.geometry("900x700")
        
        self.db_window.configure(fg_color=colors["bg"])
        self.db_window.protocol("WM_DELETE_WINDOW", self._close_db_window)

        # Header / Заголовок / Заголовок
        header_frame = ctk.CTkFrame(self.db_window, fg_color="transparent")
        header_frame.pack(fill="x", padx=20, pady=(15, 5))
        
        try:
            ctk.CTkLabel(header_frame, text=L["db_title"], font=("Segoe UI", 22, "bold"),
                        text_color=colors["label_text"]).pack(anchor="center")
        except (tk.TclError, KeyError) as e:
            logger.debug(f"Header label error: {e}")

        ctk.CTkFrame(self.db_window, height=2, fg_color="#2d6a4f").pack(fill="x", padx=20, pady=(5, 15))

        # Top panel / Верхняя панель / Верхня панель
        top_panel = ctk.CTkFrame(self.db_window, fg_color="transparent")
        top_panel.pack(fill="x", padx=20, pady=(0, 10))

        # Search / Поиск / Пошук
        search_frame = ctk.CTkFrame(top_panel, fg_color="transparent")
        search_frame.pack(side="left", fill="x", expand=True)

        try:
            ctk.CTkLabel(search_frame, text=L["db_search"] + ":", font=("Segoe UI", 13, "bold"),
                        text_color=colors["label_text"]).pack(side="left", padx=(0, 10))
        except (tk.TclError, KeyError) as e:
            logger.debug(f"Search label error: {e}")

        search_var = tk.StringVar()
        search_entry = ctk.CTkEntry(search_frame, textvariable=search_var, height=36,
                                    font=("Segoe UI", 13), fg_color=colors["entry_bg"],
                                    text_color=colors["fg"], corner_radius=radius,
                                    placeholder_text=L.get("db_search_placeholder", "Search by label, password or date..."))
        search_entry.pack(side="left", fill="x", expand=True, padx=(0, 15))

        def on_search(*args) -> None:
            try:
                refresh()
            except (tk.TclError, sqlite3.Error, RuntimeError) as e:
                logger.error(f"Search error: {e}")
        
        try:
            search_var.trace_add("write", on_search)
        except AttributeError:
            search_var.trace("w", on_search)

        def do_save_current() -> None:
            try:
                pwd = None
                
                if hasattr(self, 'entry_res') and self.entry_res:
                    try:
                        pwd = self.entry_res.get()
                    except tk.TclError:
                        pass
                
                if not pwd and hasattr(self, 'master') and hasattr(self.master, 'entry_res'):
                    try:
                        pwd = self.master.entry_res.get()
                    except (AttributeError, tk.TclError):
                        pass
                
                if not pwd and hasattr(self, 'parent') and hasattr(self.parent, 'entry_res'):
                    try:
                        pwd = self.parent.entry_res.get()
                    except (AttributeError, tk.TclError):
                        pass
                
                if not pwd:
                    try:
                        for widget in self.winfo_toplevel().winfo_children():
                            if hasattr(widget, 'entry_res'):
                                pwd = widget.entry_res.get()
                                break
                    except (tk.TclError, AttributeError):
                        pass
                
                if not pwd or pwd.strip() == "":
                    CTkMessageBox.warning(self.db_window, L["db_title"], L["db_no_pass"])
                    return
                
                label = CTkInputDialog.ask(
                    self.db_window,
                    L["db_title"],
                    L["db_label_prompt"],
                    show="",
                    theme=self._get_actual_theme(),
                    lang=self.current_lang
                )
                
                if label is None:
                    return
                
                if not label or label.strip() == "":
                    label = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                
                PasswordDB.save(label, pwd)
                CTkMessageBox.info(self.db_window, L["db_title"], L["db_saved"])
                search_var.set("")
                refresh()
                logger.info(f"Password saved with label: {label}")
                
            except sqlite3.Error as e:
                logger.error(f"Database error saving password: {e}")
                CTkMessageBox.error(self.db_window, L.get("err_title", "Error"), 
                                   f"{L.get('err_database', 'Database error')}: {e}")
            except (AttributeError, TypeError, OSError, IOError) as e:
                logger.error(f"Error saving password: {e}")
                CTkMessageBox.error(self.db_window, L.get("err_title", "Error"), 
                                   f"{L.get('err_save', 'Save error')}: {e}")

        save_btn = ctk.CTkButton(
            top_panel, 
            text=L["db_save_current"], 
            width=200, 
            height=36,
            fg_color="#1a6b5a", 
            hover_color="#2da882",
            font=("Segoe UI", 13, "bold"), 
            corner_radius=radius, 
            command=do_save_current
        )
        save_btn.pack(side="right")

        # Export/Import buttons / Кнопки экспорта/импорта / Кнопки експорту/імпорту
        buttons_row = ctk.CTkFrame(self.db_window, fg_color="transparent")
        buttons_row.pack(fill="x", padx=20, pady=(0, 15))

        def do_export() -> None:
            try:
                from utils.export import DataExporter
                passwords = PasswordDB.get_all()
                if not passwords:
                    CTkMessageBox.warning(self.db_window, L.get("export_title", "Export"),
                                         L.get("export_no_data", "No data to export"))
                    return
                DataExporter.show_export_dialog(passwords, self.db_window, self.current_lang)
            except ImportError as e:
                logger.error(f"Export module import error: {e}")
                CTkMessageBox.error(self.db_window, L.get("err_title", "Error"), 
                                   f"Export module not available: {e}")
            except (sqlite3.Error, OSError, IOError) as e:
                logger.error(f"Export error: {e}")
                CTkMessageBox.error(self.db_window, L.get("err_title", "Error"), str(e))

        def do_import() -> None:
            try:
                from utils.import_passwords import PasswordImporter
                PasswordImporter.import_all(self.db_window, self.current_lang)
            except ImportError as e:
                logger.error(f"Import module import error: {e}")
                CTkMessageBox.error(self.db_window, L.get("err_title", "Error"), 
                                   f"Import module not available: {e}")
            except (sqlite3.Error, OSError, IOError, ValueError) as e:
                logger.error(f"Import error: {e}")
                CTkMessageBox.error(self.db_window, L.get("err_title", "Error"), str(e))

        export_btn = ctk.CTkButton(
            buttons_row, 
            text=L.get("export_title", "Export"),
            command=do_export, 
            fg_color="#9C27B0",
            hover_color="#BA68C8", 
            width=160, 
            height=38,
            corner_radius=radius, 
            font=("Segoe UI", 13, "bold")
        )
        export_btn.pack(side="left", padx=(0, 15))

        import_btn = ctk.CTkButton(
            buttons_row, 
            text=L.get("import_title", "Import"),
            command=do_import, 
            fg_color="#FF9800",
            hover_color="#FFB74D", 
            width=160, 
            height=38,
            corner_radius=radius, 
            font=("Segoe UI", 13, "bold")
        )
        import_btn.pack(side="left")

        # Counter / Счетчик / Лічильник
        count_lbl = ctk.CTkLabel(self.db_window, text="", font=("Segoe UI", 12), text_color="gray")
        count_lbl.pack(anchor="w", padx=20, pady=(0, 5))

        # Scroll frame for passwords / Прокручиваемая рамка для паролей / Прокручувана рамка для паролів
        scroll_frame = ctk.CTkScrollableFrame(self.db_window, fg_color=colors["bg"], corner_radius=radius)
        scroll_frame.pack(fill="both", expand=True, padx=20, pady=(0, 10))

        # Close button / Кнопка закрытия / Кнопка закриття
        close_btn = ctk.CTkButton(
            self.db_window, 
            text=L["close"], 
            width=140, 
            height=38,
            fg_color="#ca5010", 
            hover_color="#e05a1a",
            font=("Segoe UI", 13, "bold"), 
            corner_radius=radius,
            command=self._close_db_window
        )
        close_btn.pack(pady=(0, 15))

        def open_edit_dialog(rec: Dict[str, Any]) -> None:
            dlg = ctk.CTkToplevel(self.db_window)
            dlg.title(L["db_edit_title"])
            dlg.geometry("450x320")
            dlg.resizable(False, False)
            dlg.transient(self.db_window)
            dlg.grab_set()
            dlg.attributes("-topmost", True)
            
            try:
                self._setup_window_style(dlg)
            except (AttributeError, OSError) as e:
                logger.debug(f"Setup window style error: {e}")
            
            dlg_colors = self._get_colors_for_theme(self._get_actual_theme())
            dlg.configure(fg_color=dlg_colors["bg"])
            
            try:
                self._center_window_relative_to_parent(dlg, 450, 320)
            except (tk.TclError, AttributeError) as e:
                logger.debug(f"Center window error: {e}")
                dlg.geometry("450x320")

            try:
                ctk.CTkLabel(dlg, text=L["db_edit_title"], font=("Segoe UI", 18, "bold"),
                            text_color=dlg_colors["label_text"]).pack(pady=(15, 10))
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Edit dialog label error: {e}")
            
            ctk.CTkFrame(dlg, height=2, fg_color="#2d6a4f").pack(fill="x", padx=20, pady=(0, 15))

            label_frame = ctk.CTkFrame(dlg, fg_color="transparent")
            label_frame.pack(fill="x", padx=20, pady=5)
            
            try:
                ctk.CTkLabel(label_frame, text=L["db_edit_label"] + ":", font=("Segoe UI", 13),
                            text_color=dlg_colors["label_text"], width=80).pack(side="left")
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Edit label error: {e}")
            
            lbl_var = tk.StringVar(value=rec["label"])
            lbl_entry = ctk.CTkEntry(label_frame, textvariable=lbl_var, width=280, height=35,
                                    font=("Segoe UI", 13), fg_color=dlg_colors["entry_bg"],
                                    text_color=dlg_colors["fg"], corner_radius=radius)
            lbl_entry.pack(side="left", padx=(10, 0))

            pwd_frame = ctk.CTkFrame(dlg, fg_color="transparent")
            pwd_frame.pack(fill="x", padx=20, pady=10)
            
            try:
                ctk.CTkLabel(pwd_frame, text=L["db_edit_pass"] + ":", font=("Segoe UI", 13),
                            text_color=dlg_colors["label_text"], width=80).pack(side="left")
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Edit password label error: {e}")
            
            pwd_var = tk.StringVar()
            pwd_entry = ctk.CTkEntry(pwd_frame, textvariable=pwd_var, width=280, height=35,
                                    font=("Consolas", 13), fg_color=dlg_colors["entry_bg"],
                                    text_color=dlg_colors["fg"], corner_radius=radius, show="*")
            pwd_entry.pack(side="left", padx=(10, 0))

            btn_row = ctk.CTkFrame(dlg, fg_color="transparent")
            btn_row.pack(pady=20)

            def do_save_edit() -> None:
                new_label = lbl_var.get().strip()
                new_pwd = pwd_var.get().strip()
                
                if not new_label:
                    new_label = L.get("db_no_label", "No label")
                
                try:
                    if new_pwd:
                        PasswordDB.update(rec["id"], new_label, new_pwd)
                    else:
                        PasswordDB.update(rec["id"], new_label)
                    dlg.destroy()
                    refresh()
                    CTkMessageBox.info(self.db_window, L["db_title"], L["db_save_success"])
                except sqlite3.Error as e:
                    logger.error(f"DB edit error: {e}")
                    CTkMessageBox.error(dlg, L.get("err_title", "Error"), str(e))
                except (ValueError, TypeError, OSError) as e:
                    logger.error(f"DB edit error: {e}")
                    CTkMessageBox.error(dlg, L.get("err_title", "Error"), str(e))

            ctk.CTkButton(btn_row, text=L["save"], width=110, height=34, 
                         fg_color="#2d6a4f", corner_radius=radius, 
                         command=do_save_edit).pack(side="left", padx=8)
            ctk.CTkButton(btn_row, text=L["cancel"], width=110, height=34, 
                         fg_color="#8b0000", corner_radius=radius, 
                         command=dlg.destroy).pack(side="left", padx=8)

        def refresh() -> None:
            for w in scroll_frame.winfo_children():
                try:
                    w.destroy()
                except tk.TclError:
                    pass

            query = search_var.get().strip()
            
            try:
                if query:
                    records = PasswordDB.search(query)
                else:
                    records = PasswordDB.get_all()
            except sqlite3.Error as e:
                logger.error(f"DB search error: {e}")
                count_lbl.configure(text=L["db_count"].format(0))
                ctk.CTkLabel(scroll_frame, text=f"{L.get('err_database', 'Database error')}: {e}",
                            font=("Segoe UI", 14), text_color="#E24B4A").pack(pady=30)
                return
            except (ValueError, TypeError, OSError) as e:
                logger.error(f"DB search error: {e}")
                count_lbl.configure(text=L["db_count"].format(0))
                ctk.CTkLabel(scroll_frame, text=f"{L.get('err_database', 'Database error')}: {e}",
                            font=("Segoe UI", 14), text_color="#E24B4A").pack(pady=30)
                return

            try:
                count_lbl.configure(text=L["db_count"].format(len(records)))
            except (tk.TclError, KeyError) as e:
                logger.debug(f"Count label update error: {e}")

            if not records:
                try:
                    ctk.CTkLabel(scroll_frame, text=L["db_empty"], 
                                font=("Segoe UI", 16), text_color="gray").pack(pady=50)
                except (tk.TclError, KeyError) as e:
                    logger.debug(f"Empty label error: {e}")
                return

            for rec in records:
                try:
                    card = ctk.CTkFrame(scroll_frame, fg_color=colors["entry_bg"], corner_radius=radius)
                    card.pack(fill="x", pady=6, padx=2)

                    info_frame = ctk.CTkFrame(card, fg_color="transparent")
                    info_frame.pack(side="left", fill="x", expand=True, padx=15, pady=10)

                    label_text = rec["label"] if rec["label"] else f"{L.get('db_no_label', 'No label')} #{rec['id']}"
                    label_color = "#FFD700" if query and query.lower() in label_text.lower() else colors["label_text"]
                    
                    ctk.CTkLabel(info_frame, text=label_text, font=("Segoe UI", 14, "bold"),
                                text_color=label_color).pack(anchor="w")

                    password_text = rec["password"]
                    pwd_color = "#FFD700" if query and query.lower() in password_text.lower() else "#4EC9B0"
                    
                    ctk.CTkLabel(info_frame, text=password_text, font=("Consolas", 13),
                                text_color=pwd_color).pack(anchor="w", pady=(4, 2))

                    ctk.CTkLabel(info_frame, text=rec["created"], font=("Segoe UI", 10),
                                text_color="gray").pack(anchor="w")

                    btn_frame = ctk.CTkFrame(card, fg_color="transparent")
                    btn_frame.pack(side="right", padx=10, pady=10)

                    def make_copy(p=rec["password"]) -> None:
                        try:
                            self.clipboard_clear()
                            self.clipboard_append(p)
                            self.update()
                            CTkMessageBox.info(self.db_window, L["db_title"], 
                                              L["copied"].format(self.clipboard_timeout))
                        except (tk.TclError, OSError) as e:
                            logger.error(f"Copy error: {e}")
                            CTkMessageBox.error(self.db_window, L.get("err_title", "Error"), 
                                               f"{L.get('err_copy', 'Could not copy')}: {e}")

                    def make_delete(rid=rec["id"]) -> None:
                        if CTkMessageBox.question(self.db_window, L["db_title"], L["db_del_confirm"]):
                            try:
                                PasswordDB.delete(rid)
                                refresh()
                                CTkMessageBox.info(self.db_window, L["db_title"], L["db_delete_success"])
                            except sqlite3.Error as e:
                                logger.error(f"DB delete error: {e}")
                                CTkMessageBox.error(self.db_window, L.get("err_title", "Error"), str(e))

                    def make_edit(r=rec) -> None:
                        open_edit_dialog(r)

                    ctk.CTkButton(btn_frame, text=L["db_copy"], width=90, height=30, 
                                 fg_color="#107c10", corner_radius=radius, 
                                 command=make_copy).pack(pady=3)
                    ctk.CTkButton(btn_frame, text=L["db_edit"], width=90, height=30, 
                                 fg_color="#0078d4", corner_radius=radius, 
                                 command=make_edit).pack(pady=3)
                    ctk.CTkButton(btn_frame, text=L["db_delete"], width=90, height=30, 
                                 fg_color="#8b0000", corner_radius=radius, 
                                 command=make_delete).pack(pady=3)
                except (tk.TclError, KeyError, ValueError) as e:
                    logger.error(f"Error rendering record: {e}")
                    continue

        refresh()

    def _close_db_window(self) -> None:
        """Close password database window / Закрывает окно базы паролей / Закриває вікно бази паролів"""
        if self.db_window and self.db_window.winfo_exists():
            try:
                self.db_window.grab_release()
                self.db_window.destroy()
            except tk.TclError as e:
                logger.debug(f"DB window destroy error: {e}")
            finally:
                self.db_window = None

    def _show_about(self) -> None:
        """Show 'About' program window / Показывает окно 'О программе' / Показує вікно 'Про програму'"""
        if self.about_window and self.about_window.winfo_exists():
            try:
                self.about_window.lift()
                self.about_window.focus_force()
            except tk.TclError:
                self.about_window = None
                self._show_about()
            return

        L = LANGUAGES[self.current_lang]
        wiki_url = "https://github.com/Maximka1993271/Password-Generator-Python/wiki/Security-Logic"

        self.about_window = ctk.CTkToplevel(self)
        self.about_window.title(L["btn_about"])
        self.about_window.resizable(False, False)
        self.about_window.transient(self)
        self.about_window.attributes('-topmost', True)
        self.about_window.after(100, lambda: self._set_topmost_false(self.about_window))
        
        try:
            self._center_window_relative_to_parent(self.about_window, 450, 380)
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Center window error: {e}")
            self.about_window.geometry("450x380")
        
        try:
            apply_window_rounding(self.about_window)
        except (AttributeError, OSError) as e:
            logger.debug(f"Window rounding error: {e}")
        
        self.about_window.protocol("WM_DELETE_WINDOW", self._close_about)

        main_frame = ctk.CTkFrame(self.about_window, fg_color="transparent")
        main_frame.pack(expand=True, fill="both", padx=30, pady=25)

        try:
            ctk.CTkLabel(main_frame, text="Secure Pass Pro v4.0",
                        font=("Segoe UI", 26, "bold")).pack(pady=(0, 15))
        except tk.TclError as e:
            logger.debug(f"About label error: {e}")

        try:
            about_label = ctk.CTkLabel(main_frame, text=L["about_text"],
                                        wraplength=380, font=("Segoe UI", 13),
                                        justify="center")
            about_label.pack(pady=10)
        except (tk.TclError, KeyError) as e:
            logger.debug(f"About text error: {e}")

        # OK button / Кнопка OK / Кнопка OK
        try:
            ctk.CTkButton(main_frame, text=L["ok"], width=120, height=38,
                         command=self._close_about, corner_radius=self.current_radius,
                         fg_color="#2d6a4f", hover_color="#40916c",
                         font=("Segoe UI", 14, "bold")).pack(pady=(20, 15))
        except (tk.TclError, KeyError) as e:
            logger.debug(f"OK button error: {e}")

        # Wiki button / Кнопка Wiki / Кнопка Wiki
        try:
            ctk.CTkButton(
                main_frame, 
                text=L.get("wiki_link", "Wiki"), 
                width=120, 
                height=38,
                corner_radius=self.current_radius,
                fg_color="#1f538d", 
                hover_color="#3a6ea5",
                font=("Segoe UI", 14, "bold"),
                command=lambda: webbrowser.open(wiki_url)
            ).pack(pady=(0, 5))
        except (tk.TclError, KeyError) as e:
            logger.debug(f"Wiki button error: {e}")

        try:
            self.about_window.focus_force()
        except tk.TclError:
            pass

    def _close_about(self) -> None:
        """Close 'About' window / Закрывает окно 'О программе' / Закриває вікно 'Про програму'"""
        if self.about_window:
            try:
                self.about_window.destroy()
            except tk.TclError as e:
                logger.debug(f"About window destroy error: {e}")
            finally:
                self.about_window = None

    def _center_window_relative_to_parent(self, window, width: int, height: int) -> None:
        """Center window relative to parent / Центрирует окно относительно родителя / Центрує вікно відносно батька"""
        try:
            window.update_idletasks()
            parent_x = self.winfo_x()
            parent_y = self.winfo_y()
            parent_width = self.winfo_width()
            parent_height = self.winfo_height()
            x = parent_x + (parent_width // 2) - (width // 2)
            y = parent_y + (parent_height // 2) - (height // 2)

            screen_width = self.winfo_screenwidth()
            screen_height = self.winfo_screenheight()

            if x < 0:
                x = 10
            if y < 30:
                y = 30
            if x + width > screen_width:
                x = screen_width - width - 10
            if y + height > screen_height:
                y = screen_height - height - 10

            window.geometry(f"{width}x{height}+{x}+{y}")
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Window centering error: {e}")
            try:
                screen_w = self.winfo_screenwidth()
                screen_h = self.winfo_screenheight()
                x = (screen_w - width) // 2
                y = (screen_h - height) // 2
                window.geometry(f"{width}x{height}+{x}+{y}")
            except tk.TclError:
                pass

    def _get_colors_for_theme(self, theme: str) -> dict:
        """Return colors for theme / Возвращает цвета для темы / Повертає кольори для теми"""
        if theme == "light":
            return {
                "bg": "#F3F3F3",
                "fg": "#000000",
                "entry_bg": "#FFFFFF",
                "label_text": "#000000",
                "button_fg": "#1f538d"
            }
        return {
            "bg": "#1d1e1e",
            "fg": "#FFFFFF",
            "entry_bg": "#2b2b2b",
            "label_text": "#FFFFFF",
            "button_fg": "#1f538d"
        }

    def _get_actual_theme(self) -> str:
        """Return actual theme (light/dark) / Возвращает актуальную тему (light/dark) / Повертає актуальну тему (light/dark)"""
        if hasattr(self, 'current_theme'):
            if self.current_theme == "Light":
                return "light"
            elif self.current_theme == "Dark":
                return "dark"
        return "dark"