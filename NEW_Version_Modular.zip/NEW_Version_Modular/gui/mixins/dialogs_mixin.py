"""
Dialogs mixin for SecurePassPro
"""
import os
import webbrowser
import datetime
import subprocess
import sqlite3
import qrcode
import customtkinter as ctk
import tkinter as tk
from PIL import Image
from fpdf import FPDF
from storage.database import PasswordDB
from gui.dialogs import CTkMessageBox, CTkInputDialog
from localization.lang import LANGUAGES
from utils.helpers import set_window_icon, apply_window_rounding, is_windows, is_macos, is_linux, get_resource_path
from utils.logger import get_logger

logger = get_logger("dialogs")


class DialogsMixin:
    """Mixin class for dialog windows (QR, History, Database, About)"""
    
    def _show_qr(self) -> None:
        pwd = self.entry_res.get()
        if not pwd:
            return
        
        if self.qr_window and self.qr_window.winfo_exists():
            self.qr_window.lift()
            self.qr_window.focus_force()
            return
        
        L = LANGUAGES[self.current_lang]
        
        QR_TIMEOUT = 30

        self.qr_window = ctk.CTkToplevel(self)
        self.qr_window.title(L["btn_qr"])
        set_window_icon(self.qr_window)
        self.qr_window.transient(self)
        self.qr_window.attributes("-topmost", True)
        self.qr_window.after(100, lambda: self.qr_window.attributes("-topmost", False))
        self._center_window_relative_to_parent(self.qr_window, 380, 500)
        apply_window_rounding(self.qr_window)
        self.qr_window.protocol("WM_DELETE_WINDOW", self._close_qr)

        try:
            img = qrcode.make(pwd).resize((280, 280))
            ctk_img = ctk.CTkImage(light_image=img, dark_image=img, size=(280, 280))
        except (ValueError, OSError, TypeError) as e:
            logger.error(f"QR generation error: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"Не удалось создать QR-код: {e}")
            return

        f = ctk.CTkFrame(self.qr_window, fg_color="transparent")
        f.pack(expand=True, fill="both", padx=20, pady=20)
        ctk.CTkLabel(f, text=L["btn_qr"], font=("Segoe UI", 18, "bold")).pack()

        disp = ctk.CTkFrame(f, fg_color="white", corner_radius=self.current_radius,
                             border_width=2, border_color="gray")
        disp.pack(pady=10)
        qr_label = ctk.CTkLabel(disp, image=ctk_img, text="")
        qr_label.image = ctk_img
        qr_label.pack(padx=10, pady=10)

        countdown_lbl = ctk.CTkLabel(f, text="", font=("Segoe UI", 12),
                                      text_color="#888888")
        countdown_lbl.pack(pady=(0, 4))

        def _tick(s):
            if not self.qr_window or not self.qr_window.winfo_exists():
                return
            if s <= 0:
                self._close_qr()
                return
            closes_in_text = L.get("qr_closes_in", "Window closes in")
            seconds_text = L.get("seconds_short", "sec")
            countdown_lbl.configure(text=f"⏱️ {closes_in_text} {s} {seconds_text}")
            self.qr_window.after(1000, lambda: _tick(s - 1))

        _tick(QR_TIMEOUT)

        ctk.CTkButton(f, text=L["ok"], command=self._close_qr,
                      corner_radius=self.current_radius).pack(pady=6)

        self.qr_window.focus_force()
    
    def _close_qr(self) -> None:
        if self.qr_window:
            try:
                self.qr_window.destroy()
            except tk.TclError as e:
                logger.debug(f"QR window destroy error: {e}")
            self.qr_window = None
    
    def _show_history(self) -> None:
        if self.history_window and self.history_window.winfo_exists():
            self.history_window.lift()
            self.history_window.focus_force()
            return
        
        L = LANGUAGES[self.current_lang]
        
        self.history_window = ctk.CTkToplevel(self)
        self.history_window.title(L["btn_hist"])
        set_window_icon(self.history_window)
        self.history_window.transient(self)
        self.history_window.attributes('-topmost', True)
        self.history_window.after(100, lambda: self.history_window.attributes('-topmost', False))
        self._center_window_relative_to_parent(self.history_window, 500, 580)
        apply_window_rounding(self.history_window)
        self.history_window.protocol("WM_DELETE_WINDOW", self._close_history)
        
        f = ctk.CTkFrame(self.history_window, fg_color="transparent")
        f.pack(expand=True, fill="both", padx=20, pady=20)
        ctk.CTkLabel(f, text=L["btn_hist"], font=("Segoe UI", 20, "bold")).pack(pady=10)
        txt = ctk.CTkTextbox(f, font=("Consolas", 14), corner_radius=self.current_radius)
        txt.pack(fill="both", expand=True, pady=10)
        
        if not self.history:
            txt.insert("1.0", L["hist_empty"])
        else:
            history_snapshot = list(reversed(self.history))
            txt.insert("1.0", "\n".join(history_snapshot))
        txt.configure(state="disabled")
        
        btn_f = ctk.CTkFrame(f, fg_color="transparent")
        btn_f.pack(fill="x")
        ctk.CTkButton(btn_f, text=L["btn_clear_hist"], corner_radius=self.current_radius, fg_color="#d13438", command=lambda: self._clear_history_textbox(txt)).pack(side="left", padx=5)
        ctk.CTkButton(btn_f, text=L["ok"], corner_radius=self.current_radius, command=self._close_history).pack(side="right", padx=5)
        
        self.history_window.focus_force()
        self.history_textbox = txt
    
    def _close_history(self) -> None:
        if self.history_window:
            try:
                self.history_window.destroy()
            except tk.TclError as e:
                logger.debug(f"History window destroy error: {e}")
            self.history_window = None
            self.history_textbox = None
    
    def _clear_history_textbox(self, textbox: ctk.CTkTextbox) -> None:
        L = LANGUAGES[self.current_lang]
        self.history.clear()
        try:
            textbox.configure(state="normal")
            textbox.delete("1.0", "end")
            textbox.insert("1.0", L["hist_empty"])
            textbox.configure(state="disabled")
        except (tk.TclError, AttributeError) as e:
            logger.error(f"Clear history error: {e}")
    
    def _show_db_window(self) -> None:
        L = LANGUAGES[self.current_lang]
        colors = self._get_colors_for_theme(self._get_actual_theme())
        radius = self.current_radius
        
        if self.db_window and self.db_window.winfo_exists():
            self.db_window.lift()
            self.db_window.focus_force()
            return
        
        self.db_window = ctk.CTkToplevel(self)
        self.db_window.title(L["db_title"])
        self.db_window.resizable(True, True)
        apply_window_rounding(self.db_window)
        self._center_window_relative_to_parent(self.db_window, 700, 560)
        self.db_window.configure(fg_color=colors["bg"])
        self.db_window.protocol("WM_DELETE_WINDOW", self._close_db_window)
        
        top = ctk.CTkFrame(self.db_window, fg_color="transparent")
        top.pack(fill="x", padx=16, pady=(14, 6))
        
        ctk.CTkLabel(top, text=L["db_label_prompt"], font=("Segoe UI", 13), text_color=colors["label_text"]).pack(side="left", padx=(0, 6))
        
        label_var = tk.StringVar()
        label_entry = ctk.CTkEntry(top, textvariable=label_var, width=220, height=36, font=("Segoe UI", 13), fg_color=colors["entry_bg"], text_color=colors["fg"], corner_radius=radius)
        label_entry.pack(side="left", padx=(0, 10))
        
        def do_save():
            pwd = self.entry_res.get()
            if not pwd:
                CTkMessageBox.warning(self.db_window, L["db_title"], L["db_no_pass"])
                return
            try:
                PasswordDB.save(label_var.get().strip(), pwd)
                CTkMessageBox.info(self.db_window, L["db_title"], L["db_saved"])
                label_var.set("")
                refresh()
            except (sqlite3.Error, ValueError, OSError) as exc:
                logger.error(f"DB save error: {exc}")
                CTkMessageBox.error(self.db_window, L.get("err_title", "Error"), L["err_save"].format(exc))
        
        label_entry.bind("<Return>", lambda e: do_save())
        
        save_btn = ctk.CTkButton(top, text=L["db_save_current"], width=190, height=36, fg_color="#1a6b5a", hover_color="#2da882", font=("Segoe UI", 13, "bold"), corner_radius=radius, command=do_save)
        save_btn.pack(side="left")
        
        search_var = tk.StringVar()
        search_entry = ctk.CTkEntry(self.db_window, textvariable=search_var, height=34, font=("Segoe UI", 13), fg_color=colors["entry_bg"], text_color=colors["fg"], corner_radius=radius, placeholder_text=L["db_search"])
        search_entry.pack(fill="x", padx=16, pady=(4, 2))
        
        def on_search(*args):
            refresh()
        search_var.trace_add("write", on_search)
        
        count_lbl = ctk.CTkLabel(self.db_window, text="", font=("Segoe UI", 12), text_color="gray")
        count_lbl.pack(anchor="w", padx=16)
        
        scroll_frame = ctk.CTkScrollableFrame(self.db_window, fg_color=colors["bg"], corner_radius=radius)
        scroll_frame.pack(fill="both", expand=True, padx=14, pady=(6, 10))
        
        close_btn = ctk.CTkButton(self.db_window, text=L["close"], width=140, height=38, fg_color="#ca5010", hover_color="#e05a1a", font=("Segoe UI", 13), corner_radius=radius, command=self._close_db_window)
        close_btn.pack(pady=(0, 12))
        
        def open_edit_dialog(rec):
            dlg = ctk.CTkToplevel(self.db_window)
            dlg.title(L["db_edit_title"])
            dlg.resizable(False, False)
            dlg.grab_set()
            dlg.attributes("-topmost", True)
            dlg_colors = self._get_colors_for_theme(self._get_actual_theme())
            dlg.configure(fg_color=dlg_colors["bg"])
            self._center_window_relative_to_parent(dlg, 420, 260)
            
            ctk.CTkLabel(dlg, text=L["db_edit_label"], font=("Segoe UI", 13), text_color=dlg_colors["label_text"]).pack(padx=20, pady=(18, 2), anchor="w")
            lbl_var = tk.StringVar(value=rec["label"])
            ctk.CTkEntry(dlg, textvariable=lbl_var, width=380, height=36, font=("Segoe UI", 13), fg_color=dlg_colors["entry_bg"], text_color=dlg_colors["fg"], corner_radius=radius).pack(padx=20, pady=(0, 8))
            
            ctk.CTkLabel(dlg, text=L["db_edit_pass"], font=("Segoe UI", 13), text_color=dlg_colors["label_text"]).pack(padx=20, pady=(0, 2), anchor="w")
            pwd_var = tk.StringVar()
            ctk.CTkEntry(dlg, textvariable=pwd_var, width=380, height=36, font=("Consolas", 13), fg_color=dlg_colors["entry_bg"], text_color=dlg_colors["fg"], corner_radius=radius).pack(padx=20, pady=(0, 16))
            
            def do_save_edit():
                new_label = lbl_var.get().strip()
                new_pwd = pwd_var.get().strip() or None
                try:
                    PasswordDB.update(rec["id"], new_label, new_pwd)
                    dlg.destroy()
                    refresh()
                except (sqlite3.Error, ValueError, OSError) as exc:
                    logger.error(f"DB edit error: {exc}")
                    CTkMessageBox.error(dlg, L.get("err_title", "Error"), L["err_save"].format(exc))
            
            btn_row = ctk.CTkFrame(dlg, fg_color="transparent")
            btn_row.pack()
            ctk.CTkButton(btn_row, text=L["ok"], width=110, height=34, fg_color="#1a6b5a", corner_radius=radius, command=do_save_edit).pack(side="left", padx=8)
            ctk.CTkButton(btn_row, text=L["cancel"], width=110, height=34, fg_color="#ca5010", corner_radius=radius, command=dlg.destroy).pack(side="left", padx=8)
        
        def refresh():
            for w in scroll_frame.winfo_children():
                w.destroy()
            
            query = search_var.get().strip()
            try:
                if query:
                    records = PasswordDB.search(query)
                else:
                    records = PasswordDB.get_all()
            except (sqlite3.Error, ValueError, OSError) as exc:
                logger.error(f"DB search error: {exc}")
                count_lbl.configure(text=L["db_count"].format(0))
                ctk.CTkLabel(scroll_frame, text=L["err_open"].format(exc), font=("Segoe UI", 14), text_color="#E24B4A", wraplength=620).pack(pady=30)
                return
            
            count_lbl.configure(text=L["db_count"].format(len(records)))
            
            if not records:
                ctk.CTkLabel(scroll_frame, text=L["db_empty"], font=("Segoe UI", 14), text_color="gray").pack(pady=30)
                return
            
            for rec in records:
                row = ctk.CTkFrame(scroll_frame, fg_color=colors["entry_bg"], corner_radius=radius)
                row.pack(fill="x", pady=4, padx=2)
                
                info_frame = ctk.CTkFrame(row, fg_color="transparent")
                info_frame.pack(side="left", fill="x", expand=True, padx=10, pady=6)
                
                lbl_text = rec["label"] if rec["label"] else f"#{rec['id']}"
                ctk.CTkLabel(info_frame, text=lbl_text, font=("Segoe UI", 13, "bold"), text_color=colors["label_text"]).pack(anchor="w")
                ctk.CTkLabel(info_frame, text=rec["password"], font=("Consolas", 13), text_color="#4EC9B0").pack(anchor="w")
                ctk.CTkLabel(info_frame, text=rec["created"], font=("Segoe UI", 10), text_color="gray").pack(anchor="w")
                
                btn_frame = ctk.CTkFrame(row, fg_color="transparent")
                btn_frame.pack(side="right", padx=8, pady=6)
                
                def make_copy(p=rec["password"]):
                    try:
                        self.clipboard_clear()
                        self.clipboard_append(p)
                        CTkMessageBox.info(self.db_window, L["db_title"], L["copied"].format(5))
                    except (tk.TclError, OSError) as e:
                        logger.error(f"Copy error: {e}")
                        CTkMessageBox.error(self.db_window, L.get("err_title", "Error"), f"Не удалось скопировать: {e}")
                
                def make_delete(rid=rec["id"]):
                    if CTkMessageBox.question(self.db_window, L["db_title"], L["db_del_confirm"]):
                        try:
                            PasswordDB.delete(rid)
                            refresh()
                        except (sqlite3.Error, ValueError, OSError) as exc:
                            logger.error(f"DB delete error: {exc}")
                            CTkMessageBox.error(self.db_window, L.get("err_title", "Error"), L["err_save"].format(exc))
                
                def make_edit(r=rec):
                    open_edit_dialog(r)
                
                ctk.CTkButton(btn_frame, text=L["db_copy"], width=80, height=28, fg_color="#107c10", hover_color="#20cf20", font=("Segoe UI", 12), corner_radius=radius, command=make_copy).pack(pady=2)
                ctk.CTkButton(btn_frame, text=L["db_edit"], width=80, height=28, fg_color="#0078d4", hover_color="#309FFF", font=("Segoe UI", 12), corner_radius=radius, command=make_edit).pack(pady=2)
                ctk.CTkButton(btn_frame, text=L["db_delete"], width=80, height=28, fg_color="#8b0000", hover_color="#cc0000", font=("Segoe UI", 12), corner_radius=radius, command=make_delete).pack(pady=2)
        
        refresh()
    
    def _close_db_window(self) -> None:
        if self.db_window and self.db_window.winfo_exists():
            try:
                self.db_window.destroy()
            except tk.TclError as e:
                logger.debug(f"DB window destroy error: {e}")
            self.db_window = None
    
    def _show_about(self) -> None:
        if self.about_window and self.about_window.winfo_exists():
            self.about_window.lift()
            self.about_window.focus_force()
            return
        
        L = LANGUAGES[self.current_lang]
        wiki_url = "https://github.com/Maximka1993271/Password-Generator-Python/wiki/Security-Logic"
        
        self.about_window = ctk.CTkToplevel(self)
        self.about_window.title(L["btn_about"])
        self.about_window.resizable(False, False)
        self.about_window.transient(self)
        self.about_window.attributes('-topmost', True)
        self.about_window.after(100, lambda: self.about_window.attributes('-topmost', False))
        self._center_window_relative_to_parent(self.about_window, 450, 380)
        apply_window_rounding(self.about_window)
        self.about_window.protocol("WM_DELETE_WINDOW", self._close_about)
        
        main_frame = ctk.CTkFrame(self.about_window, fg_color="transparent")
        main_frame.pack(expand=True, fill="both", padx=30, pady=25)
        
        ctk.CTkLabel(main_frame, text="Secure Pass Pro v4.0", 
                     font=("Segoe UI", 26, "bold")).pack(pady=(0, 15))
        
        about_label = ctk.CTkLabel(main_frame, text=L["about_text"], 
                                    wraplength=380, font=("Segoe UI", 13), 
                                    justify="center")
        about_label.pack(pady=10)
        
        ctk.CTkButton(main_frame, text=L["ok"], width=120, height=38, 
                      command=self._close_about, corner_radius=self.current_radius,
                      fg_color="#2d6a4f", hover_color="#40916c",
                      font=("Segoe UI", 14, "bold")).pack(pady=(20, 15))
        
        lbl_wiki = ctk.CTkLabel(main_frame, text=L.get("wiki_link", "Security Logic Wiki"), 
                                font=("Segoe UI", 12, "underline"), 
                                text_color="#1f538d", cursor="hand2")
        lbl_wiki.pack(pady=(0, 5))
        lbl_wiki.bind("<Button-1>", lambda e: webbrowser.open(wiki_url))
        
        self.about_window.focus_force()
    
    def _close_about(self) -> None:
        if self.about_window:
            try:
                self.about_window.destroy()
            except tk.TclError as e:
                logger.debug(f"About window destroy error: {e}")
            self.about_window = None