"""
GUI Mixins - grouped by functionality for better organization

Группировка миксинов по функциональности для лучшей организации
Групування міксинів за функціональністю для кращої організації

Группировка по функциональности / Grouping by functionality / Групування за функціональністю:
- UI_MIXINS: interface, settings, dialogs / интерфейс, настройки, диалоги / інтерфейс, налаштування, діалоги
- SECURITY_MIXINS: security, auto-lock, HIBP / безопасность, автоблокировка, HIBP / безпека, автоблокування, HIBP
- OPS_MIXINS: password operations, name generator / операции с паролями, генератор имён / операції з паролями, генератор імен
- VISUAL_MIXINS: RGB effects, updates / RGB эффекты, обновления / RGB ефекти, оновлення
"""

# Import groups / Импорт групп / Імпорт груп
from gui.mixins.ui_mixins import (
    UISetupMixin,
    SettingsMixin,
    SettingsWindowMixin,
    DialogsMixin
)

from gui.mixins.security_mixins import (
    MasterMixin,
    AutoLockMixin,
    HIBPMixin
)

from gui.mixins.ops_mixins import (
    PasswordOpsMixin,
    NameGeneratorMixin
)

from gui.mixins.visual_mixins import (
    RGBMixin,
    UpdaterMixin
)

# For backward compatibility - separate imports
# Для обратной совместимости - отдельные импорты
# Для зворотної сумісності - окремі імпорти
from gui.mixins.rgb_mixin import RGBMixin as _RGBMixin
from gui.mixins.auto_lock_mixin import AutoLockMixin as _AutoLockMixin
from gui.mixins.password_ops_mixin import PasswordOpsMixin as _PasswordOpsMixin
from gui.mixins.master_mixin import MasterMixin as _MasterMixin
from gui.mixins.settings_mixin import SettingsMixin as _SettingsMixin
from gui.mixins.settings_window_mixin import SettingsWindowMixin as _SettingsWindowMixin
from gui.mixins.dialogs_mixin import DialogsMixin as _DialogsMixin
from gui.mixins.hibp_mixin import HIBPMixin as _HIBPMixin
from gui.mixins.ui_setup_mixin import UISetupMixin as _UISetupMixin
from gui.mixins.updater_mixin import UpdaterMixin as _UpdaterMixin
from gui.mixins.name_generator_mixin import NameGeneratorMixin as _NameGeneratorMixin

# Export all mixins / Экспорт всех миксинов / Експорт всіх міксинів
__all__ = [
    # Groups / Группы / Групи
    'UISetupMixin',
    'SettingsMixin',
    'SettingsWindowMixin',
    'DialogsMixin',
    'MasterMixin',
    'AutoLockMixin',
    'HIBPMixin',
    'PasswordOpsMixin',
    'NameGeneratorMixin',
    'RGBMixin',
    'UpdaterMixin',
    # Aliases for backward compatibility / Псевдонимы для обратной совместимости / Псевдоніми для зворотної сумісності
    'UIMixins',
    'SecurityMixins',
    'OpsMixins',
    'VisualMixins'
]

# Container classes for composition (alternative to multiple inheritance)
# Классы-контейнеры для композиции (альтернатива множественному наследованию)
# Класи-контейнери для композиції (альтернатива множинному наслідуванню)
class UIMixins(
    UISetupMixin,
    SettingsMixin,
    SettingsWindowMixin,
    DialogsMixin
):
    """Container for all UI mixins / Контейнер для всех UI миксинов / Контейнер для всіх UI міксинів"""
    pass

class SecurityMixins(
    MasterMixin,
    AutoLockMixin,
    HIBPMixin
):
    """Container for all security mixins / Контейнер для всех миксинов безопасности / Контейнер для всіх міксинів безпеки"""
    pass

class OpsMixins(
    PasswordOpsMixin,
    NameGeneratorMixin
):
    """Container for all operations mixins / Контейнер для всех миксинов операций / Контейнер для всіх міксинів операцій"""
    pass

class VisualMixins(
    RGBMixin,
    UpdaterMixin
):
    """Container for all visual mixins / Контейнер для всех визуальных миксинов / Контейнер для всіх візуальних міксинів"""
    pass

# Main container class (alternative to inheriting 11 mixins)
# Главный класс-контейнер (альтернатива наследованию 11 миксинов)
# Головний клас-контейнер (альтернатива наслідуванню 11 міксинів)
class AllMixins(
    UIMixins,
    SecurityMixins,
    OpsMixins,
    VisualMixins
):
    """
    Container for all mixins.
    Use this class instead of inheriting 11 separate mixins.
    
    Контейнер всех миксинов.
    Используйте этот класс вместо наследования 11 отдельных миксинов.
    
    Контейнер всіх міксинів.
    Використовуйте цей клас замість наслідування 11 окремих міксинів.

    Instead of / Вместо / Замість:
        class SecurePassPro(RGBMixin, AutoLockMixin, ..., ctk.CTk):

    Use / Используйте / Використовуйте:
        class SecurePassPro(AllMixins, ctk.CTk):
    """
    pass