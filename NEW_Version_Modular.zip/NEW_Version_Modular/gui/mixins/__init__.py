"""
GUI Mixins - grouped by functionality for better organization

Группировка миксинов по функциональности:
- UI_MIXINS: интерфейс, настройки, диалоги
- SECURITY_MIXINS: безопасность, автоблокировка, HIBP
- OPS_MIXINS: операции с паролями, генератор имён
- VISUAL_MIXINS: RGB эффекты, обновления
"""

# Импорт групп
from gui.mixins.ui_mixins import (
    UISetupMixin,
    SettingsMixin,
    SettingsWindowMixin,
    DialogsMixin
)

from gui.mixins.security_mixins import (
    MasterMixin,
    AutoLockMixin,
    HIBPMixin
)

from gui.mixins.ops_mixins import (
    PasswordOpsMixin,
    NameGeneratorMixin
)

from gui.mixins.visual_mixins import (
    RGBMixin,
    UpdaterMixin
)

# Для обратной совместимости - отдельные импорты
from gui.mixins.rgb_mixin import RGBMixin as _RGBMixin
from gui.mixins.auto_lock_mixin import AutoLockMixin as _AutoLockMixin
from gui.mixins.password_ops_mixin import PasswordOpsMixin as _PasswordOpsMixin
from gui.mixins.master_mixin import MasterMixin as _MasterMixin
from gui.mixins.settings_mixin import SettingsMixin as _SettingsMixin
from gui.mixins.settings_window_mixin import SettingsWindowMixin as _SettingsWindowMixin
from gui.mixins.dialogs_mixin import DialogsMixin as _DialogsMixin
from gui.mixins.hibp_mixin import HIBPMixin as _HIBPMixin
from gui.mixins.ui_setup_mixin import UISetupMixin as _UISetupMixin
from gui.mixins.updater_mixin import UpdaterMixin as _UpdaterMixin
from gui.mixins.name_generator_mixin import NameGeneratorMixin as _NameGeneratorMixin

# Экспорт всех миксинов
__all__ = [
    # Группы
    'UISetupMixin',
    'SettingsMixin',
    'SettingsWindowMixin',
    'DialogsMixin',
    'MasterMixin',
    'AutoLockMixin',
    'HIBPMixin',
    'PasswordOpsMixin',
    'NameGeneratorMixin',
    'RGBMixin',
    'UpdaterMixin',
    # Псевдонимы для обратной совместимости
    'UIMixins',
    'SecurityMixins',
    'OpsMixins',
    'VisualMixins'
]

# Классы-контейнеры для композиции (альтернатива множественному наследованию)
class UIMixins(
    UISetupMixin,
    SettingsMixin,
    SettingsWindowMixin,
    DialogsMixin
):
    """Контейнер для всех UI миксинов"""
    pass

class SecurityMixins(
    MasterMixin,
    AutoLockMixin,
    HIBPMixin
):
    """Контейнер для всех миксинов безопасности"""
    pass

class OpsMixins(
    PasswordOpsMixin,
    NameGeneratorMixin
):
    """Контейнер для всех миксинов операций"""
    pass

class VisualMixins(
    RGBMixin,
    UpdaterMixin
):
    """Контейнер для всех визуальных миксинов"""
    pass

# Главный класс-контейнер (альтернатива наследованию 11 миксинов)
class AllMixins(
    UIMixins,
    SecurityMixins,
    OpsMixins,
    VisualMixins
):
    """
    Контейнер всех миксинов.
    Используйте этот класс вместо наследования 11 отдельных миксинов.
    
    Вместо:
        class SecurePassPro(RGBMixin, AutoLockMixin, ..., ctk.CTk):
    
    Используйте:
        class SecurePassPro(AllMixins, ctk.CTk):
    """
    pass