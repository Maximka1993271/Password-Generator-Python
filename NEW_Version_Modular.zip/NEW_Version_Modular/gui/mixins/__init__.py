"""
Mixins for SecurePassPro main window
"""
from gui.mixins.rgb_mixin import RGBMixin
from gui.mixins.auto_lock_mixin import AutoLockMixin
from gui.mixins.password_ops_mixin import PasswordOperationsMixin
from gui.mixins.master_mixin import MasterMixin
from gui.mixins.settings_mixin import SettingsMixin
from gui.mixins.settings_window_mixin import SettingsWindowMixin
from gui.mixins.dialogs_mixin import DialogsMixin
from gui.mixins.hibp_mixin import HIBPMixin
from gui.mixins.ui_setup_mixin import UISetupMixin

__all__ = [
    'RGBMixin',
    'AutoLockMixin',
    'PasswordOperationsMixin',
    'MasterMixin',
    'SettingsMixin',
    'SettingsWindowMixin',
    'DialogsMixin',
    'HIBPMixin',
    'UISetupMixin'
]