"""
HIBP (Have I Been Pwned) mixin for SecurePassPro
"""
import threading
import hashlib
import urllib.request
from gui.dialogs import CTkMessageBox
from localization.lang import LANGUAGES


class HIBPMixin:
    """Mixin class for checking passwords against Have I Been Pwned database"""
    
    def _check_hibp(self) -> None:
        """Проверяет текущий пароль через Have I Been Pwned (k-anonymity)."""
        L = LANGUAGES[self.current_lang]
        password = self.entry_res.get()
        if not password:
            CTkMessageBox.warning(self, "🔍 HIBP",
                                  L.get("hibp_no_password", "Сначала сгенерируйте пароль."))
            return

        self.btn_hibp.configure(state="disabled",
                                text=L.get("hibp_checking", "Проверка..."))

        def _worker():
            try:
                sha1 = hashlib.sha1(
                    password.encode("utf-8")).hexdigest().upper()
                prefix, suffix = sha1[:5], sha1[5:]
                url = f"https://api.pwnedpasswords.com/range/{prefix}"
                req = urllib.request.Request(
                    url, headers={"User-Agent": "SecurePassPro/4.0",
                                  "Add-Padding": "true"})
                with urllib.request.urlopen(req, timeout=6) as resp:
                    body = resp.read().decode("utf-8")
                count = 0
                for line in body.splitlines():
                    h, c = line.split(":")
                    if h.strip() == suffix:
                        count = int(c.strip())
                        break
                self.after(0, lambda: self._show_hibp_result(count))
            except Exception:
                self.after(0, lambda: self._show_hibp_result(None))

        threading.Thread(target=_worker, daemon=True).start()

    def _show_hibp_result(self, count) -> None:
        L = LANGUAGES[self.current_lang]
        self.btn_hibp.configure(
            state="normal",
            text=L.get("btn_hibp", "🔍 Проверить утечки"))
        if count is None:
            CTkMessageBox.warning(
                self, "🔍 HIBP",
                L.get("hibp_error",
                      "⚠️ Не удалось связаться с сервером.\nПроверьте интернет-соединение."))
        elif count == 0:
            CTkMessageBox.info(
                self, "🔍 Have I Been Pwned",
                L.get("hibp_safe", "✅ Пароль не найден в базах утечек.\n\nМожно использовать."))
        else:
            CTkMessageBox.warning(
                self, "⚠️ Have I Been Pwned",
                L.get("hibp_found",
                      "❌ Пароль найден {count} раз(а) в утечках!\n\nСгенерируйте новый.").format(
                          count=f"{count:,}"))