"""
HIBP (Have I Been Pwned) mixin for SecurePassPro
with rate limiting and improved error handling
"""
import threading
import hashlib
import socket
import urllib.request
import urllib.error
import time
import tkinter as tk
import customtkinter as ctk
from gui.dialogs import CTkMessageBox
from localization.lang import LANGUAGES
from utils.logger import get_logger

logger = get_logger("hibp")

# Rate limiting - защита от слишком частых запросов
_last_hibp_check = 0
HIBP_COOLDOWN = 10  # секунд между проверками
_MAX_RETRIES = 3
_RETRY_DELAY = 1  # секунд между повторами


class HIBPMixin:
    """Mixin class for checking passwords against Have I Been Pwned database"""

    def _check_hibp(self) -> None:
        """Проверяет текущий пароль через Have I Been Pwned (k-anonymity) с rate limiting."""
        global _last_hibp_check

        L = LANGUAGES[self.current_lang]
        password = self.entry_res.get()

        if not password:
            CTkMessageBox.warning(
                self,
                L.get("btn_hibp", "🔍 Проверить утечки"),
                L.get("hibp_no_password", "Сначала сгенерируйте пароль.")
            )
            return

        # Rate limiting - проверяем не слишком ли часто
        now = time.time()
        time_since_last = now - _last_hibp_check

        if time_since_last < HIBP_COOLDOWN:
            wait_seconds = int(HIBP_COOLDOWN - time_since_last) + 1
            CTkMessageBox.warning(
                self,
                L.get("btn_hibp", "🔍 Проверить утечки"),
                f"Пожалуйста, подождите {wait_seconds} секунд перед следующей проверкой.\nЭто защищает сервер от перегрузки."
            )
            return

        _last_hibp_check = now

        # Показываем окно с прогрессом
        self._show_checking_window()

        # Отключаем кнопку и меняем текст
        self.btn_hibp.configure(state="disabled", text=L.get("hibp_checking", "Проверка..."))

        def _worker():
            try:
                result = self._check_hibp_with_retry(password)
                self.after(0, lambda: self._show_hibp_result(result))
            except Exception as e:
                logger.error(f"HIBP unexpected error: {type(e).__name__}: {e}")
                self.after(0, lambda: self._show_hibp_result(None))
            finally:
                # Закрываем окно прогресса
                self.after(0, self._close_checking_window)

        threading.Thread(target=_worker, daemon=True).start()

    def _check_hibp_with_retry(self, password: str) -> Optional[int]:
        """
        Проверяет пароль с повторными попытками при ошибках.
        Возвращает количество найденных вхождений или None при ошибке.
        """
        for attempt in range(_MAX_RETRIES):
            try:
                sha1 = hashlib.sha1(password.encode("utf-8")).hexdigest().upper()
                prefix, suffix = sha1[:5], sha1[5:]
                url = f"https://api.pwnedpasswords.com/range/{prefix}"

                req = urllib.request.Request(
                    url,
                    headers={
                        "User-Agent": "SecurePassPro/4.0",
                        "Add-Padding": "true"
                    }
                )

                with urllib.request.urlopen(req, timeout=10) as resp:
                    body = resp.read().decode("utf-8")

                count = 0
                for line in body.splitlines():
                    try:
                        h, c = line.split(":")
                        if h.strip() == suffix:
                            count = int(c.strip())
                            break
                    except (ValueError, UnicodeDecodeError) as e:
                        logger.debug(f"Line parse error: {e}")
                        continue

                return count

            except urllib.error.URLError as e:
                logger.warning(f"HIBP URL error (attempt {attempt + 1}/{_MAX_RETRIES}): {e}")
                if attempt < _MAX_RETRIES - 1:
                    time.sleep(_RETRY_DELAY * (attempt + 1))  # Экспоненциальная задержка
                else:
                    return None

            except socket.timeout as e:
                logger.warning(f"HIBP timeout (attempt {attempt + 1}/{_MAX_RETRIES}): {e}")
                if attempt < _MAX_RETRIES - 1:
                    time.sleep(_RETRY_DELAY)
                else:
                    return None

            except Exception as e:
                logger.error(f"HIBP error (attempt {attempt + 1}/{_MAX_RETRIES}): {e}")
                if attempt < _MAX_RETRIES - 1:
                    time.sleep(_RETRY_DELAY)
                else:
                    return None

        return None

    def _show_checking_window(self):
        """Показывает окно с прогрессом проверки"""
        L = LANGUAGES[self.current_lang]

        self._checking_window = ctk.CTkToplevel(self)
        self._checking_window.title(L.get("hibp_checking", "Проверка..."))
        self._checking_window.geometry("350x200")
        self._checking_window.resizable(False, False)
        self._checking_window.transient(self)
        self._checking_window.grab_set()

        # Центрируем окно
        self._center_window_relative_to_parent(self._checking_window, 350, 200)

        # Основной фрейм
        main_frame = ctk.CTkFrame(self._checking_window, fg_color="transparent")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        # Иконка
        icon_label = ctk.CTkLabel(main_frame, text="🔍", font=ctk.CTkFont(size=40))
        icon_label.pack(pady=(10, 5))

        # Текст
        ctk.CTkLabel(
            main_frame,
            text=L.get("hibp_checking", "Проверка..."),
            font=ctk.CTkFont(size=14, weight="bold")
        ).pack(pady=(0, 15))

        # Прогресс бар
        self._progress_bar = ctk.CTkProgressBar(main_frame, width=280)
        self._progress_bar.pack(pady=10)
        self._progress_bar.set(0)

        # Анимация прогресса
        def animate_progress(i=0):
            if hasattr(self, '_checking_window') and self._checking_window and self._checking_window.winfo_exists():
                if i <= 100:
                    self._progress_bar.set(i / 100)
                    self._checking_window.after(20, lambda: animate_progress(i + 2))

        animate_progress()

    def _close_checking_window(self):
        """Закрывает окно прогресса"""
        if hasattr(self, '_checking_window') and self._checking_window:
            try:
                self._checking_window.destroy()
            except:
                pass
            self._checking_window = None

    def _show_hibp_result(self, count) -> None:
        """Показывает результат проверки в отдельном окне"""
        L = LANGUAGES[self.current_lang]

        # Возвращаем кнопку в нормальное состояние
        self.btn_hibp.configure(
            state="normal",
            text=L.get("btn_hibp", "🔍 Проверить утечки"))

        # Получаем текущий радиус из настроек
        radius = getattr(self, 'current_radius', 25)

        # Создаём окно с результатом
        result_window = ctk.CTkToplevel(self)
        result_window.title(L.get("btn_hibp", "🔍 Проверить утечки"))
        result_window.geometry("450x380")
        result_window.resizable(False, False)
        result_window.transient(self)
        result_window.grab_set()

        # Центрируем окно
        self._center_window_relative_to_parent(result_window, 450, 380)

        # Основной фрейм
        main_frame = ctk.CTkFrame(result_window, fg_color="transparent")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        if count is None:
            # Ошибка
            icon_label = ctk.CTkLabel(main_frame, text="⚠️", font=ctk.CTkFont(size=48), text_color="#FF9800")
            icon_label.pack(pady=(10, 5))

            title_label = ctk.CTkLabel(
                main_frame,
                text=L.get("hibp_error_title", "Ошибка проверки"),
                font=ctk.CTkFont(size=16, weight="bold"),
                text_color="#FF9800"
            )
            title_label.pack(pady=5)

            result_label = ctk.CTkLabel(
                main_frame,
                text=L.get("hibp_error", "⚠️ Не удалось связаться с сервером.\nПроверьте интернет-соединение."),
                font=ctk.CTkFont(size=13),
                justify="center"
            )
            result_label.pack(pady=10)

        elif count == 0:
            # Пароль безопасен
            icon_label = ctk.CTkLabel(main_frame, text="✅", font=ctk.CTkFont(size=48), text_color="#00C853")
            icon_label.pack(pady=(10, 5))

            title_label = ctk.CTkLabel(
                main_frame,
                text=L.get("hibp_safe_title", "Пароль безопасен"),
                font=ctk.CTkFont(size=16, weight="bold"),
                text_color="#00C853"
            )
            title_label.pack(pady=5)

            result_label = ctk.CTkLabel(
                main_frame,
                text=L.get("hibp_safe", "✅ Пароль не найден в базах утечек.\n\nМожно использовать."),
                font=ctk.CTkFont(size=13),
                justify="center"
            )
            result_label.pack(pady=10)

        else:
            # Пароль найден в утечках
            icon_label = ctk.CTkLabel(main_frame, text="❌", font=ctk.CTkFont(size=48), text_color="#FF0000")
            icon_label.pack(pady=(10, 5))

            title_label = ctk.CTkLabel(
                main_frame,
                text=L.get("hibp_found_title", "ВНИМАНИЕ! Пароль скомпрометирован"),
                font=ctk.CTkFont(size=16, weight="bold"),
                text_color="#FF0000"
            )
            title_label.pack(pady=5)

            # Форматируем число с разделителями тысяч
            count_str = f"{count:,}".replace(",", " ")

            result_label = ctk.CTkLabel(
                main_frame,
                text=L.get("hibp_found", "❌ Пароль найден {count} раз(а) в утечках!\n\nСгенерируйте новый пароль.").format(count=count_str),
                font=ctk.CTkFont(size=13),
                justify="center"
            )
            result_label.pack(pady=10)

            # Дополнительное предупреждение
            warning_label = ctk.CTkLabel(
                main_frame,
                text=L.get("hibp_warning", "⚠️ Рекомендуется немедленно сменить пароль!"),
                font=ctk.CTkFont(size=12),
                text_color="#FF9800"
            )
            warning_label.pack(pady=5)

            # Кнопка для быстрой генерации нового пароля
            def generate_new():
                result_window.destroy()
                self._generate()

            gen_btn = ctk.CTkButton(
                main_frame,
                text=L.get("btn_gen", "🎲 Сгенерировать новый пароль"),
                command=generate_new,
                height=35,
                width=200,
                corner_radius=radius,
                fg_color="#2d6a4f"
            )
            gen_btn.pack(pady=(10, 5))

        # Кнопка закрытия с закруглением из настроек
        close_btn = ctk.CTkButton(
            main_frame,
            text=L.get("close", "Закрыть"),
            command=result_window.destroy,
            height=35,
            width=120,
            corner_radius=radius
        )
        close_btn.pack(pady=15)

        # Сохраняем ссылки для обновления радиуса
        self._hibp_result_window = result_window
        self._hibp_close_btn = close_btn

    def _update_hibp_window_radius(self, radius: int):
        """Обновляет радиус кнопки в окне результата HIBP"""
        if hasattr(self, '_hibp_close_btn') and self._hibp_close_btn and self._hibp_close_btn.winfo_exists():
            try:
                self._hibp_close_btn.configure(corner_radius=radius)
            except:
                pass

    def _center_window_relative_to_parent(self, window, width: int, height: int) -> None:
        """Центрирует окно относительно родителя"""
        try:
            window.update_idletasks()
            parent_x = self.winfo_x()
            parent_y = self.winfo_y()
            parent_width = self.winfo_width()
            parent_height = self.winfo_height()
            x = parent_x + (parent_width // 2) - (width // 2)
            y = parent_y + (parent_height // 2) - (height // 2)

            screen_width = self.winfo_screenwidth()
            screen_height = self.winfo_screenheight()

            if x < 0:
                x = 10
            if y < 30:
                y = 30
            if x + width > screen_width:
                x = screen_width - width - 10
            if y + height > screen_height:
                y = screen_height - height - 10

            window.geometry(f"{width}x{height}+{x}+{y}")
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Window centering error: {e}")
            # Fallback - просто центрируем по экрану
            screen_w = self.winfo_screenwidth()
            screen_h = self.winfo_screenheight()
            x = (screen_w - width) // 2
            y = (screen_h - height) // 2
            window.geometry(f"{width}x{height}+{x}+{y}")


# Функция для сброса rate limiting (для тестирования)
def reset_hibp_rate_limit():
    """Сбрасывает ограничение частоты проверок HIBP (для тестирования)"""
    global _last_hibp_check
    _last_hibp_check = 0
