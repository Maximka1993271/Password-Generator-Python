"""
HIBP (Have I Been Pwned) mixin for SecurePassPro
with rate limiting and improved error handling

Миксин HIBP (Have I Been Pwned) для SecurePassPro
с ограничением частоты и улучшенной обработкой ошибок

Міксин HIBP (Have I Been Pwned) для SecurePassPro
з обмеженням частоти та покращеною обробкою помилок
"""
import threading
import hashlib
import socket
import urllib.request
import urllib.error
import time
import tkinter as tk
import customtkinter as ctk
from gui.dialogs import CTkMessageBox
from localization.lang import LANGUAGES
from utils.logger import get_logger
from typing import Optional

logger = get_logger("hibp")

# Rate limiting - protection against too frequent requests
# Защита от слишком частых запросов
# Захист від надто частих запитів
_last_hibp_check = 0
HIBP_COOLDOWN = 10  # seconds between checks / секунд между проверками / секунд між перевірками
_MAX_RETRIES = 3
_RETRY_DELAY = 1  # seconds between retries / секунд между повторами / секунд між повторами


class HIBPMixin:
    """Mixin class for checking passwords against Have I Been Pwned database
    Класс-миксин для проверки паролей в базе Have I Been Pwned
    Клас-міксин для перевірки паролів у базі Have I Been Pwned"""

    def _check_hibp(self) -> None:
        """Check current password against Have I Been Pwned (k-anonymity) with rate limiting.
        Проверяет текущий пароль через Have I Been Pwned (k-anonymity) с rate limiting.
        Перевіряє поточний пароль через Have I Been Pwned (k-anonymity) з rate limiting."""
        global _last_hibp_check

        L = LANGUAGES[self.current_lang]
        password = self.entry_res.get()

        if not password:
            CTkMessageBox.warning(
                self,
                L.get("btn_hibp", "Check leaks"),
                L.get("hibp_no_password", "Generate a password first.")
            )
            return

        # Rate limiting - check if too frequent / Проверяем не слишком ли часто / Перевіряємо чи не надто часто
        now = time.time()
        time_since_last = now - _last_hibp_check

        if time_since_last < HIBP_COOLDOWN:
            wait_seconds = int(HIBP_COOLDOWN - time_since_last) + 1
            CTkMessageBox.warning(
                self,
                L.get("btn_hibp", "Check leaks"),
                f"Please wait {wait_seconds} seconds before next check.\nThis protects the server from overload."
            )
            return

        _last_hibp_check = now

        # Show progress window / Показываем окно с прогрессом / Показуємо вікно з прогресом
        self._show_checking_window()

        # Disable button and change text / Отключаем кнопку и меняем текст / Вимкаємо кнопку та змінюємо текст
        try:
            self.btn_hibp.configure(state="disabled", text=L.get("hibp_checking", "Checking..."))
        except (tk.TclError, AttributeError, KeyError) as e:
            logger.debug(f"Button configure error: {e}")

        def _worker():
            try:
                result = self._check_hibp_with_retry(password)
                self.after(0, lambda: self._show_hibp_result(result))
            except (urllib.error.URLError, socket.timeout, ConnectionError, TimeoutError) as e:
                logger.error(f"HIBP network error: {type(e).__name__}: {e}")
                self.after(0, lambda: self._show_hibp_result(None))
            except (ValueError, TypeError, UnicodeDecodeError) as e:
                logger.error(f"HIBP data error: {type(e).__name__}: {e}")
                self.after(0, lambda: self._show_hibp_result(None))
            except (AttributeError, RuntimeError) as e:
                logger.error(f"HIBP unexpected error: {type(e).__name__}: {e}")
                self.after(0, lambda: self._show_hibp_result(None))
            finally:
                self.after(0, self._close_checking_window)

        threading.Thread(target=_worker, daemon=True).start()

    def _check_hibp_with_retry(self, password: str) -> Optional[int]:
        """
        Check password with retry attempts on errors.
        Returns the number of breaches found or None on error.
        
        Проверяет пароль с повторными попытками при ошибках.
        Возвращает количество найденных вхождений или None при ошибке.
        
        Перевіряє пароль з повторними спробами при помилках.
        Повертає кількість знайдених входжень або None при помилці.
        """
        for attempt in range(_MAX_RETRIES):
            try:
                sha1 = hashlib.sha1(password.encode("utf-8")).hexdigest().upper()
                prefix, suffix = sha1[:5], sha1[5:]
                url = f"https://api.pwnedpasswords.com/range/{prefix}"

                req = urllib.request.Request(
                    url,
                    headers={
                        "User-Agent": "SecurePassPro/4.0",
                        "Add-Padding": "true"
                    }
                )

                with urllib.request.urlopen(req, timeout=10) as resp:
                    body = resp.read().decode("utf-8")

                count = 0
                for line in body.splitlines():
                    try:
                        h, c = line.split(":")
                        if h.strip() == suffix:
                            count = int(c.strip())
                            break
                    except (ValueError, UnicodeDecodeError) as e:
                        logger.debug(f"Line parse error: {e}")
                        continue

                return count

            except urllib.error.URLError as e:
                logger.warning(f"HIBP URL error (attempt {attempt + 1}/{_MAX_RETRIES}): {e}")
                if attempt < _MAX_RETRIES - 1:
                    time.sleep(_RETRY_DELAY * (attempt + 1))
                else:
                    return None

            except socket.timeout as e:
                logger.warning(f"HIBP timeout (attempt {attempt + 1}/{_MAX_RETRIES}): {e}")
                if attempt < _MAX_RETRIES - 1:
                    time.sleep(_RETRY_DELAY)
                else:
                    return None

            except (ConnectionError, TimeoutError, OSError, IOError) as e:
                logger.warning(f"HIBP connection error (attempt {attempt + 1}/{_MAX_RETRIES}): {e}")
                if attempt < _MAX_RETRIES - 1:
                    time.sleep(_RETRY_DELAY)
                else:
                    return None

        return None

    def _show_checking_window(self):
        """Show progress window for checking / Показывает окно с прогрессом проверки / Показує вікно з прогресом перевірки"""
        L = LANGUAGES[self.current_lang]

        self._checking_window = ctk.CTkToplevel(self)
        try:
            self._checking_window.title(L.get("hibp_checking", "Checking..."))
            self._checking_window.geometry("350x200")
            self._checking_window.resizable(False, False)
            self._checking_window.transient(self)
            self._checking_window.grab_set()

            # Center the window / Центрируем окно / Центруємо вікно
            self._center_window_relative_to_parent(self._checking_window, 350, 200)

            # Main frame / Основной фрейм / Основний фрейм
            main_frame = ctk.CTkFrame(self._checking_window, fg_color="transparent")
            main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

            # Icon (empty, without emoji) / Иконка (пустая, без эмодзи) / Іконка (порожня, без емодзі)
            icon_label = ctk.CTkLabel(main_frame, text="", font=ctk.CTkFont(size=40))
            icon_label.pack(pady=(10, 5))

            # Text / Текст / Текст
            ctk.CTkLabel(
                main_frame,
                text=L.get("hibp_checking", "Checking..."),
                font=ctk.CTkFont(size=14, weight="bold")
            ).pack(pady=(0, 15))

            # Progress bar / Прогресс бар / Прогрес бар
            self._progress_bar = ctk.CTkProgressBar(main_frame, width=280)
            self._progress_bar.pack(pady=10)
            self._progress_bar.set(0)

            # Progress animation / Анимация прогресса / Анімація прогресу
            def animate_progress(i=0):
                if hasattr(self, '_checking_window') and self._checking_window and self._checking_window.winfo_exists():
                    if i <= 100:
                        try:
                            self._progress_bar.set(i / 100)
                        except (tk.TclError, AttributeError):
                            pass
                        self._checking_window.after(20, lambda: animate_progress(i + 2))

            animate_progress()
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Checking window creation error: {e}")

    def _close_checking_window(self):
        """Close progress window / Закрывает окно прогресса / Закриває вікно прогресу"""
        if hasattr(self, '_checking_window') and self._checking_window:
            try:
                self._checking_window.destroy()
            except (tk.TclError, AttributeError, RuntimeError):
                pass
            self._checking_window = None

    def _show_hibp_result(self, count: Optional[int]) -> None:
        """Show check result in a separate window
        Показывает результат проверки в отдельном окне
        Показує результат перевірки в окремому вікні"""
        L = LANGUAGES[self.current_lang]

        # Restore button to normal state / Возвращаем кнопку в нормальное состояние / Повертаємо кнопку в нормальний стан
        try:
            self.btn_hibp.configure(
                state="normal",
                text=L.get("btn_hibp", "Check leaks"))
        except (tk.TclError, AttributeError, KeyError) as e:
            logger.debug(f"Button restore error: {e}")

        # Get current radius from settings / Получаем текущий радиус из настроек / Отримуємо поточний радіус з налаштувань
        radius = getattr(self, 'current_radius', 25)

        # Create result window / Создаём окно с результатом / Створюємо вікно з результатом
        result_window = ctk.CTkToplevel(self)
        try:
            result_window.title(L.get("btn_hibp", "Check leaks"))
            result_window.geometry("450x380")
            result_window.resizable(False, False)
            result_window.transient(self)
            result_window.grab_set()

            # Center the window / Центрируем окно / Центруємо вікно
            self._center_window_relative_to_parent(result_window, 450, 380)

            # Main frame / Основной фрейм / Основний фрейм
            main_frame = ctk.CTkFrame(result_window, fg_color="transparent")
            main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

            if count is None:
                # Error / Ошибка / Помилка
                icon_label = ctk.CTkLabel(main_frame, text="", font=ctk.CTkFont(size=48), text_color="#FF9800")
                icon_label.pack(pady=(10, 5))

                title_label = ctk.CTkLabel(
                    main_frame,
                    text=L.get("hibp_error_title", "Check error"),
                    font=ctk.CTkFont(size=16, weight="bold"),
                    text_color="#FF9800"
                )
                title_label.pack(pady=5)

                result_label = ctk.CTkLabel(
                    main_frame,
                    text=L.get("hibp_error", "Could not connect to server.\nPlease check your internet connection."),
                    font=ctk.CTkFont(size=13),
                    justify="center"
                )
                result_label.pack(pady=10)

            elif count == 0:
                # Password is safe / Пароль безопасен / Пароль безпечний
                icon_label = ctk.CTkLabel(main_frame, text="", font=ctk.CTkFont(size=48), text_color="#00C853")
                icon_label.pack(pady=(10, 5))

                title_label = ctk.CTkLabel(
                    main_frame,
                    text=L.get("hibp_safe_title", "Password is safe"),
                    font=ctk.CTkFont(size=16, weight="bold"),
                    text_color="#00C853"
                )
                title_label.pack(pady=5)

                result_label = ctk.CTkLabel(
                    main_frame,
                    text=L.get("hibp_safe", "Password not found in breach databases.\n\nSafe to use."),
                    font=ctk.CTkFont(size=13),
                    justify="center"
                )
                result_label.pack(pady=10)

            else:
                # Password found in breaches / Пароль найден в утечках / Пароль знайдено у витоках
                icon_label = ctk.CTkLabel(main_frame, text="", font=ctk.CTkFont(size=48), text_color="#FF0000")
                icon_label.pack(pady=(10, 5))

                title_label = ctk.CTkLabel(
                    main_frame,
                    text=L.get("hibp_found_title", "WARNING! Password compromised"),
                    font=ctk.CTkFont(size=16, weight="bold"),
                    text_color="#FF0000"
                )
                title_label.pack(pady=5)

                # Format number with thousand separators / Форматируем число с разделителями тысяч / Форматуємо число з роздільниками тисяч
                count_str = f"{count:,}".replace(",", " ")

                result_label = ctk.CTkLabel(
                    main_frame,
                    text=L.get("hibp_found", "Password found {count} time(s) in breaches!\n\nGenerate a new password.").format(count=count_str),
                    font=ctk.CTkFont(size=13),
                    justify="center"
                )
                result_label.pack(pady=10)

                # Additional warning / Дополнительное предупреждение / Додаткове попередження
                warning_label = ctk.CTkLabel(
                    main_frame,
                    text=L.get("hibp_warning", "It is recommended to change your password immediately!"),
                    font=ctk.CTkFont(size=12),
                    text_color="#FF9800"
                )
                warning_label.pack(pady=5)

                # Button for quick generation of a new password / Кнопка для быстрой генерации нового пароля / Кнопка для швидкої генерації нового пароля
                def generate_new():
                    result_window.destroy()
                    self._generate()

                gen_btn = ctk.CTkButton(
                    main_frame,
                    text=L.get("btn_gen", "Generate new password"),
                    command=generate_new,
                    height=35,
                    width=200,
                    corner_radius=radius,
                    fg_color="#2d6a4f"
                )
                gen_btn.pack(pady=(10, 5))

            # Close button with rounded corners from settings / Кнопка закрытия с закруглением из настроек / Кнопка закриття із заокругленням з налаштувань
            close_btn = ctk.CTkButton(
                main_frame,
                text=L.get("close", "Close"),
                command=result_window.destroy,
                height=35,
                width=120,
                corner_radius=radius
            )
            close_btn.pack(pady=15)

            # Save references for radius update / Сохраняем ссылки для обновления радиуса / Зберігаємо посилання для оновлення радіусу
            self._hibp_result_window = result_window
            self._hibp_close_btn = close_btn
            
        except (tk.TclError, AttributeError, RuntimeError, KeyError) as e:
            logger.debug(f"Result window creation error: {e}")

    def _update_hibp_window_radius(self, radius: int):
        """Update button radius in HIBP result window
        Обновляет радиус кнопки в окне результата HIBP
        Оновлює радіус кнопки у вікні результату HIBP"""
        if hasattr(self, '_hibp_close_btn') and self._hibp_close_btn and self._hibp_close_btn.winfo_exists():
            try:
                self._hibp_close_btn.configure(corner_radius=radius)
            except (tk.TclError, AttributeError):
                pass

    def _center_window_relative_to_parent(self, window, width: int, height: int) -> None:
        """Center window relative to parent / Центрирует окно относительно родителя / Центрує вікно відносно батька"""
        try:
            window.update_idletasks()
            parent_x = self.winfo_x()
            parent_y = self.winfo_y()
            parent_width = self.winfo_width()
            parent_height = self.winfo_height()
            x = parent_x + (parent_width // 2) - (width // 2)
            y = parent_y + (parent_height // 2) - (height // 2)

            screen_width = self.winfo_screenwidth()
            screen_height = self.winfo_screenheight()

            if x < 0:
                x = 10
            if y < 30:
                y = 30
            if x + width > screen_width:
                x = screen_width - width - 10
            if y + height > screen_height:
                y = screen_height - height - 10

            window.geometry(f"{width}x{height}+{x}+{y}")
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Window centering error: {e}")
            # Fallback - just center on screen / Просто центрируем по экрану / Просто центруємо по екрану
            try:
                screen_w = self.winfo_screenwidth()
                screen_h = self.winfo_screenheight()
                x = (screen_w - width) // 2
                y = (screen_h - height) // 2
                window.geometry(f"{width}x{height}+{x}+{y}")
            except (tk.TclError, AttributeError):
                pass


# Function to reset rate limiting (for testing)
# Функция для сброса ограничения частоты проверок (для тестирования)
# Функція для скидання обмеження частоти перевірок (для тестування)
def reset_hibp_rate_limit():
    """Reset HIBP rate limit / Сбрасывает ограничение частоты проверок HIBP / Скидає обмеження частоти перевірок HIBP"""
    global _last_hibp_check
    _last_hibp_check = 0