"""
RGB effects mixin for SecurePassPro
"""
import tkinter as tk
import math
import ctypes
from utils.helpers import is_windows


class RGBMixin:
    """Mixin class for RGB border animation and titlebar coloring"""
    
    def _create_rgb_canvases(self) -> None:
        bw = 3
        self._rgb_c_top = tk.Canvas(self, height=bw, bg="#1d1e1e", highlightthickness=0)
        self._rgb_c_bottom = tk.Canvas(self, height=bw, bg="#1d1e1e", highlightthickness=0)
        self._rgb_c_left = tk.Canvas(self, width=bw, bg="#1d1e1e", highlightthickness=0)
        self._rgb_c_right = tk.Canvas(self, width=bw, bg="#1d1e1e", highlightthickness=0)
        for c in (self._rgb_c_top, self._rgb_c_bottom, self._rgb_c_left, self._rgb_c_right):
            c.place_forget()
    
    def _rgb_color(self, phase_offset: float) -> str:
        f = self._rgb_t + phase_offset
        r = int((math.sin(f) + 1) / 2 * 255)
        g = int((math.sin(f + 2.1) + 1) / 2 * 255)
        b = int((math.sin(f + 4.2) + 1) / 2 * 255)
        return f"#{r:02x}{g:02x}{b:02x}"
    
    def _set_titlebar_color(self, hex_color: str) -> None:
        if not is_windows():
            return
        try:
            h = hex_color.lstrip("#")
            r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
            colorref = r | (g << 8) | (b << 16)
            hwnd = ctypes.windll.user32.GetParent(self.winfo_id())
            DWMWA_CAPTION_COLOR = 35
            ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, ctypes.byref(ctypes.c_int(colorref)), ctypes.sizeof(ctypes.c_int(colorref)))
        except Exception:
            pass
    
    def _reset_titlebar_color(self) -> None:
        if not is_windows():
            return
        try:
            hwnd = ctypes.windll.user32.GetParent(self.winfo_id())
            DWMWA_CAPTION_COLOR = 35
            DWMWA_COLOR_DEFAULT = 0xFFFFFFFF
            ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, ctypes.byref(ctypes.c_int(DWMWA_COLOR_DEFAULT)), ctypes.sizeof(ctypes.c_int(DWMWA_COLOR_DEFAULT)))
        except Exception:
            pass
    
    def _animate_rgb(self) -> None:
        if not self.rgb_enabled.get():
            return
        if self._rgb_c_top:
            self._rgb_c_top.configure(bg=self._rgb_color(0.0))
        if self._rgb_c_right:
            self._rgb_c_right.configure(bg=self._rgb_color(0.8))
        if self._rgb_c_bottom:
            self._rgb_c_bottom.configure(bg=self._rgb_color(1.6))
        if self._rgb_c_left:
            self._rgb_c_left.configure(bg=self._rgb_color(2.4))
        self._set_titlebar_color(self._rgb_color(3.2))
        self._rgb_t = (self._rgb_t + 0.08) % (2 * math.pi)
        if self._rgb_anim_id:
            self.after_cancel(self._rgb_anim_id)
        self._rgb_anim_id = self.after(30, self._animate_rgb)
    
    def _start_rgb(self) -> None:
        if self._rgb_c_top:
            self._rgb_c_top.place(relx=0, rely=0, relwidth=1)
            self._rgb_c_bottom.place(relx=0, rely=1, anchor="sw", relwidth=1)
            self._rgb_c_left.place(relx=0, rely=0, relheight=1)
            self._rgb_c_right.place(relx=1, rely=0, anchor="ne", relheight=1)
        if not self._rgb_anim_id:
            self._animate_rgb()
    
    def _stop_rgb(self) -> None:
        if self._rgb_anim_id:
            self.after_cancel(self._rgb_anim_id)
            self._rgb_anim_id = None
        for c in (self._rgb_c_top, self._rgb_c_bottom, self._rgb_c_left, self._rgb_c_right):
            if c:
                c.place_forget()
        self._reset_titlebar_color()
    
    def _set_rgb(self, state: bool) -> None:
        if self.rgb_enabled.get() == state:
            return
        self.rgb_enabled.set(state)
        if state:
            self._start_rgb()
        else:
            self._stop_rgb()
        self._update_rgb_buttons()
        self.config.set("RGB", state)
    
    def _update_rgb_buttons(self) -> None:
        is_on = self.rgb_enabled.get()
        if self._rgb_on_btn_ref and self._rgb_on_btn_ref.winfo_exists():
            self._rgb_on_btn_ref.configure(fg_color="#2d6a4f" if is_on else "#4b4b4b", hover_color="#2d6a4f")
        if self._rgb_off_btn_ref and self._rgb_off_btn_ref.winfo_exists():
            self._rgb_off_btn_ref.configure(fg_color="#8b0000", hover_color="#8b0000")