"""
Settings mixin for SecurePassPro

Миксин настроек для SecurePassPro
Міксин налаштувань для SecurePassPro
"""
import tkinter as tk
import json
import time
import customtkinter as ctk
from localization.lang import LANGUAGES
from utils.helpers import get_global_radius, set_global_radius, play_sound
from gui.dialogs import CTkMessageBox, CTkInputDialog
from gui.widgets import ToolTip
from utils.logger import get_logger

logger = get_logger("settings")


class SettingsMixin:
    """Mixin class for application settings (theme, language, fonts, etc.)
    Класс-миксин для настроек приложения (тема, язык, шрифты и т.д.)
    Клас-міксин для налаштувань додатку (тема, мова, шрифти тощо)"""
    
    def _change_radius(self, val: int) -> None:
        rad = int(val)
        self.current_radius = rad
        set_global_radius(rad)
        
        # Update buttons in main window / Обновляем кнопки в главном окне / Оновлюємо кнопки в головному вікні
        menu_btns = [self.btn_gen, self.btn_copy, self.btn_save, self.btn_open, 
                     self.btn_qr, self.btn_hist, self.btn_db, self.btn_hibp, 
                     self.btn_upd, self.btn_settings, self.btn_about, self.btn_name_gen]
        for btn in menu_btns:
            if btn and btn.winfo_exists():
                try:
                    btn.configure(corner_radius=rad)
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Button radius error: {e}")
        
        if self.btn_eye and self.btn_eye.winfo_exists():
            try:
                self.btn_eye.configure(corner_radius=rad)
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Eye button radius error: {e}")
        
        # Update checkboxes (they have fixed radius of 6) / Обновляем чекбоксы (у них фиксированный радиус 6) / Оновлюємо чекбокси (у них фіксований радіус 6)
        CHECKBOX_RADIUS = 6
        for cb in [self.cb_upper, self.cb_lower, self.cb_digits, self.cb_symb, 
                   self.cb_ambig, self.cb_at_least, self.cb_hide, self.cb_no_repeat]:
            if cb and cb.winfo_exists():
                try:
                    cb.configure(corner_radius=CHECKBOX_RADIUS)
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Checkbox radius error: {e}")
        
        # Update frames / Обновляем фреймы / Оновлюємо фрейми
        if self.bottom_frame and self.bottom_frame.winfo_exists():
            try:
                self.bottom_frame.configure(corner_radius=rad)
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Bottom frame radius error: {e}")
        
        if self.right_panel and self.right_panel.winfo_exists():
            try:
                self.right_panel.configure(corner_radius=rad)
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Right panel radius error: {e}")
        
        if self.entry_res and self.entry_res.winfo_exists():
            try:
                self.entry_res.configure(corner_radius=rad)
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Entry radius error: {e}")
        
        if self.entry_frame and self.entry_frame.winfo_exists():
            try:
                self.entry_frame.configure(corner_radius=rad)
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Entry frame radius error: {e}")
        
        # Update radius label in settings / Обновляем метку радиуса в настройках / Оновлюємо мітку радіусу в налаштуваннях
        if hasattr(self, 'settings_radius_label') and self.settings_radius_label and self.settings_radius_label.winfo_exists():
            try:
                self.settings_radius_label.configure(text=f"{rad} px")
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Radius label error: {e}")
        
        self._update_settings_radius()
        
        # Save to config / Сохраняем в конфиг / Зберігаємо в конфіг
        try:
            self.config.set("RADIUS", rad)
        except (KeyError, ValueError, OSError, AttributeError) as e:
            logger.error(f"Failed to save radius: {e}")
    
    def _update_settings_radius(self) -> None:
        rad = self.current_radius
        # Update language buttons / Обновляем кнопки языков / Оновлюємо кнопки мов
        for btn in self.lang_buttons.values():
            if btn and btn.winfo_exists():
                try:
                    btn.configure(corner_radius=rad)
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Lang button radius error: {e}")
        
        # Update theme buttons / Обновляем кнопки темы / Оновлюємо кнопки теми
        for btn in self.theme_buttons.values():
            if btn and btn.winfo_exists():
                try:
                    btn.configure(corner_radius=rad)
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Theme button radius error: {e}")
        
        # Update other buttons / Обновляем остальные кнопки / Оновлюємо інші кнопки
        for btn in [self._sound_btn, self._close_btn, self._master_set_btn, 
                    self._rgb_on_btn_ref, self._rgb_off_btn_ref, self._auto_lock_btn, 
                    self.auto_save_btn]:
            if btn and btn.winfo_exists():
                try:
                    btn.configure(corner_radius=rad)
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Settings button radius error: {e}")
        
        # Update PDF theme buttons / Обновляем кнопки темы PDF / Оновлюємо кнопки теми PDF
        if hasattr(self, 'pdf_theme_light_btn') and self.pdf_theme_light_btn and self.pdf_theme_light_btn.winfo_exists():
            try:
                self.pdf_theme_light_btn.configure(corner_radius=rad)
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"PDF theme light button radius error: {e}")
        
        if hasattr(self, 'pdf_theme_dark_btn') and self.pdf_theme_dark_btn and self.pdf_theme_dark_btn.winfo_exists():
            try:
                self.pdf_theme_dark_btn.configure(corner_radius=rad)
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"PDF theme dark button radius error: {e}")
        
        # 2FA button / 2FA КНОПКА / 2FA КНОПКА
        if hasattr(self, '_2fa_settings_btn') and self._2fa_settings_btn and self._2fa_settings_btn.winfo_exists():
            try:
                self._2fa_settings_btn.configure(corner_radius=rad)
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"2FA button radius error: {e}")
    
    def _apply_font_size(self, size: int) -> None:
        self.current_font_size = size
        try:
            self.config.set("font_size", size)
        except (KeyError, ValueError, OSError, AttributeError) as e:
            logger.error(f"Failed to save font size: {e}")
        
        # Update menu buttons / Обновляем кнопки меню / Оновлюємо кнопки меню
        menu_btns = [self.btn_gen, self.btn_copy, self.btn_save, self.btn_open,
                     self.btn_qr, self.btn_hist, self.btn_db, self.btn_hibp,
                     self.btn_upd, self.btn_settings, self.btn_about, self.btn_name_gen]
        for btn in menu_btns:
            if btn and btn.winfo_exists():
                try:
                    btn.configure(font=("Segoe UI", size - 1, "bold"))
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Button font error: {e}")
        
        # Update headers / Обновляем заголовки / Оновлюємо заголовки
        if self.lbl_title and self.lbl_title.winfo_exists():
            try:
                self.lbl_title.configure(font=("Segoe UI", size + 6, "bold"))
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Title font error: {e}")
        
        if self.lbl_menu and self.lbl_menu.winfo_exists():
            try:
                self.lbl_menu.configure(font=("Segoe UI", size + 4, "bold"))
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Menu font error: {e}")
        
        if self.lbl_strength_text and self.lbl_strength_text.winfo_exists():
            try:
                self.lbl_strength_text.configure(font=("Segoe UI", size, "bold"))
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Strength font error: {e}")
        
        # Update password entry field / Обновляем поле ввода пароля / Оновлюємо поле введення пароля
        if self.entry_res and self.entry_res.winfo_exists():
            try:
                self.entry_res.configure(font=("Consolas", size + 8))
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Entry font error: {e}")
        
        # Update eye button / Обновляем кнопку глаза / Оновлюємо кнопку ока
        if self.btn_eye and self.btn_eye.winfo_exists():
            try:
                self.btn_eye.configure(font=("Segoe UI", size + 6))
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Eye button font error: {e}")
        
        # Update font size label in settings / Обновляем метку размера шрифта в настройках / Оновлюємо мітку розміру шрифту в налаштуваннях
        if hasattr(self, 'font_size_value') and self.font_size_value and self.font_size_value.winfo_exists():
            try:
                self.font_size_value.configure(font=("Segoe UI", size + 4, "bold"))
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Font size value label error: {e}")
    
    def _on_font_size_change(self, val: float) -> None:
        size = int(val)
        if hasattr(self, 'font_size_value') and self.font_size_value and self.font_size_value.winfo_exists():
            try:
                self.font_size_value.configure(text=f"{size}px")
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Font size label error: {e}")
        
        # Apply instantly / Применяем мгновенно / Застосовуємо миттєво
        self._apply_font_size(size)
    
    def _on_radius_change(self, val: float) -> None:
        rad = int(val)
        if hasattr(self, 'settings_radius_label') and self.settings_radius_label and self.settings_radius_label.winfo_exists():
            try:
                self.settings_radius_label.configure(text=f"{rad} px")
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Radius label error: {e}")
        
        # Apply instantly / Применяем мгновенно / Застосовуємо миттєво
        self._change_radius(rad)
    
    def _on_clip_timeout_change(self, val: float) -> None:
        seconds = int(val)
        if self._clip_timeout_label_ref and self._clip_timeout_label_ref.winfo_exists():
            L = LANGUAGES[self.current_lang]
            try:
                self._clip_timeout_label_ref.configure(text=L["clip_timeout"].format(seconds))
            except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                logger.debug(f"Clip timeout label error: {e}")
        
        # Apply instantly / Применяем мгновенно / Застосовуємо миттєво
        self._apply_clip_timeout(seconds)
    
    def _apply_clip_timeout(self, seconds: int) -> None:
        self.clipboard_timeout = seconds
        if "btn_copy" in self._tooltips and self._tooltips["btn_copy"]:
            L = LANGUAGES[self.current_lang]
            try:
                self._tooltips["btn_copy"].set_text(L["tt_copy"].format(seconds))
            except (AttributeError, KeyError, RuntimeError) as e:
                logger.debug(f"Tooltip error: {e}")
        try:
            self.config.set("CLIP_TIMEOUT", seconds)
        except (KeyError, ValueError, OSError, AttributeError) as e:
            logger.error(f"Failed to save clip timeout: {e}")
    
    def _on_auto_lock_timeout_change(self, val: float) -> None:
        minutes = int(val)
        if self._auto_lock_label_ref and self._auto_lock_label_ref.winfo_exists():
            L = LANGUAGES[self.current_lang]
            try:
                self._auto_lock_label_ref.configure(text=L["auto_lock_timeout"].format(minutes))
            except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                logger.debug(f"Auto lock label error: {e}")
        
        # Apply instantly / Применяем мгновенно / Застосовуємо миттєво
        self._apply_auto_timeout(minutes)
    
    def _apply_auto_timeout(self, minutes: int) -> None:
        self.auto_lock_timeout = minutes
        try:
            self.config.set("AUTO_LOCK_TIMEOUT", minutes)
        except (KeyError, ValueError, OSError, AttributeError) as e:
            logger.error(f"Failed to save auto lock timeout: {e}")
    
    def _toggle_sound_settings(self) -> None:
        self.sound_enabled.set(not self.sound_enabled.get())
        if self._sound_btn and self._sound_btn.winfo_exists():
            L = LANGUAGES[self.current_lang]
            if self.sound_enabled.get():
                try:
                    self._sound_btn.configure(
                        text=L["sound_on"],
                        fg_color="#2d6a4f",
                        hover_color="#2d6a4f"
                    )
                except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                    logger.debug(f"Sound button error: {e}")
            else:
                try:
                    self._sound_btn.configure(
                        text=L["sound_off"],
                        fg_color="#8b0000",
                        hover_color="#8b0000"
                    )
                except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                    logger.debug(f"Sound button error: {e}")
        play_sound("click", self.sound_enabled.get())
        try:
            self.config.set("SOUND", self.sound_enabled.get())
        except (KeyError, ValueError, OSError, AttributeError) as e:
            logger.error(f"Failed to save sound setting: {e}")
    
    def _toggle_auto_save(self) -> None:
        new_value = not self.auto_save_var.get()
        self.auto_save_var.set(new_value)
        try:
            self.config.set("auto_save", new_value)
        except (KeyError, ValueError, OSError, AttributeError) as e:
            logger.error(f"Failed to save auto save setting: {e}")
        
        L = LANGUAGES[self.current_lang]
        if new_value:
            if self.auto_save_btn and self.auto_save_btn.winfo_exists():
                try:
                    self.auto_save_btn.configure(
                        text=L["auto_save_on"],
                        fg_color="#2d6a4f",
                        hover_color="#2d6a4f"
                    )
                except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                    logger.debug(f"Auto save button error: {e}")
            CTkMessageBox.info(self, L["auto_save"], L["auto_save_enabled"])
        else:
            if self.auto_save_btn and self.auto_save_btn.winfo_exists():
                try:
                    self.auto_save_btn.configure(
                        text=L["auto_save_off"],
                        fg_color="#8b0000",
                        hover_color="#8b0000"
                    )
                except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                    logger.debug(f"Auto save button error: {e}")
            CTkMessageBox.info(self, L["auto_save"], L["auto_save_disabled"])
    
    def _change_theme(self, mode: str) -> None:
        self.current_theme = mode
        try:
            self.config.set("THEME", mode)
        except (KeyError, ValueError, OSError, AttributeError) as e:
            logger.error(f"Failed to save theme: {e}")

        for name, btn in self.theme_buttons.items():
            if btn and btn.winfo_exists():
                try:
                    btn.configure(fg_color="#2d6a4f" if name == mode else "#4b4b4b")
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Theme button error: {e}")

        # FIXED: Close and reopen settings window with new theme
        self._reopen_settings_window()

        try:
            ctk.set_appearance_mode(mode)
        except (ValueError, AttributeError, RuntimeError) as e:
            logger.error(f"Failed to set appearance mode: {e}")

        self.after(50, self._sync_theme_colors)
    
    def _reopen_settings_window(self) -> None:
        """Close and reopen settings window to refresh all UI elements
        Закрывает и переоткрывает окно настроек для полного обновления
        Закриває та перевідкриває вікно налаштувань для повного оновлення"""
        # Save current state - which tab was open
        current_tab = None
        if hasattr(self, 'category_buttons') and self.category_buttons:
            for key, btn in self.category_buttons.items():
                if btn and btn.winfo_exists():
                    try:
                        if btn.cget("fg_color") != "transparent":
                            current_tab = key
                            break
                    except (tk.TclError, AttributeError):
                        pass
        
        # Close settings window if open
        if hasattr(self, 'settings_window') and self.settings_window and self.settings_window.winfo_exists():
            try:
                self.settings_window.destroy()
            except (tk.TclError, AttributeError, RuntimeError):
                pass
            self.settings_window = None
        
        # Reopen settings window
        self._show_settings()
        
        # Restore selected tab if possible
        if current_tab and hasattr(self, '_switch_category'):
            try:
                self._switch_category(current_tab)
            except (tk.TclError, AttributeError, RuntimeError):
                pass
    
    def _sync_theme_colors(self) -> None:
        actual_theme = self._get_actual_theme()
        self._apply_theme_colors(actual_theme)
        bg = "#F3F3F3" if actual_theme == "light" else "#1d1e1e"
        try:
            self.configure(fg_color=bg)
            self.update_idletasks()
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Theme sync error: {e}")
    
    def _change_language(self, lang: str) -> None:
        """Change language and reopen settings window to apply changes
        Сменить язык и переоткрыть окно настроек для применения изменений
        Змінити мову та перевідкрити вікно налаштувань для застосування змін"""
        self.current_lang = lang
        self._apply_lang(lang)
        try:
            self.config.set("LANG", lang)
        except (KeyError, ValueError, OSError, AttributeError) as e:
            logger.error(f"Failed to save language: {e}")
        
        for l, btn in self.lang_buttons.items():
            if btn and btn.winfo_exists():
                try:
                    btn.configure(fg_color="#2d6a4f" if l == lang else "#4b4b4b")
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Language button error: {e}")
        
        # FIXED: Close and reopen settings window to fully update language
        if self.settings_window and self.settings_window.winfo_exists():
            self._reopen_settings_window()
        
        # Update main window UI elements
        if self.entry_res.get():
            self._update_strength_meter(self.entry_res.get())
        self._update_master_status_label()
        self._update_auto_lock_label()
        
        if hasattr(self, 'font_size_value') and self.font_size_value and self.font_size_value.winfo_exists():
            try:
                self.font_size_value.configure(text=f"{self.current_font_size}px")
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"Font size label error: {e}")
        
        # 2FA UPDATE WHEN CHANGING LANGUAGE
        self._update_2fa_status_in_settings()
        
        # Update 2FA button text in settings (will be updated when window reopens)
        if hasattr(self, '_2fa_settings_btn') and self._2fa_settings_btn and self._2fa_settings_btn.winfo_exists():
            try:
                L = LANGUAGES[self.current_lang]
                self._2fa_settings_btn.configure(text=L.get("2fa_settings_title", "2FA Settings"))
            except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                logger.debug(f"2FA settings button language update error: {e}")
        
        # Update 2FA info text
        if hasattr(self, '_2fa_info_label') and self._2fa_info_label and self._2fa_info_label.winfo_exists():
            try:
                L = LANGUAGES[self.current_lang]
                self._2fa_info_label.configure(text=L.get("2fa_description", ""))
            except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                logger.debug(f"2FA info label language update error: {e}")
    
    def _toggle_auto_lock(self) -> None:
        self.auto_lock_enabled.set(not self.auto_lock_enabled.get())
        if self._auto_lock_btn and self._auto_lock_btn.winfo_exists():
            L = LANGUAGES[self.current_lang]
            if self.auto_lock_enabled.get():
                try:
                    self._auto_lock_btn.configure(
                        text=L["auto_lock"],
                        fg_color="#2d6a4f",
                        hover_color="#2d6a4f"
                    )
                except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                    logger.debug(f"Auto lock button error: {e}")
            else:
                try:
                    self._auto_lock_btn.configure(
                        text=L["auto_lock"],
                        fg_color="#8b0000",
                        hover_color="#8b0000"
                    )
                except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                    logger.debug(f"Auto lock button error: {e}")
        try:
            self.config.set("AUTO_LOCK", self.auto_lock_enabled.get())
        except (KeyError, ValueError, OSError, AttributeError) as e:
            logger.error(f"Failed to save auto lock: {e}")
        if self.auto_lock_enabled.get():
            self._last_activity_time = time.time()
    
    def _update_auto_lock_label(self) -> None:
        if self._auto_lock_label_ref and self._auto_lock_label_ref.winfo_exists():
            L = LANGUAGES[self.current_lang]
            try:
                self._auto_lock_label_ref.configure(text=L["auto_lock_timeout"].format(self.auto_lock_timeout))
            except (tk.TclError, AttributeError, KeyError, RuntimeError) as e:
                logger.debug(f"Auto lock label error: {e}")
    
    def _set_pdf_theme(self, theme: str) -> None:
        """Set PDF theme (light/dark) / Установить тему PDF (светлая/тёмная) / Встановити тему PDF (світла/темна)"""
        if theme not in ["light", "dark"]:
            return
        
        try:
            self.config.set("PDF_THEME", theme)
        except (KeyError, ValueError, OSError, AttributeError) as e:
            logger.error(f"Failed to save PDF theme: {e}")
        
        # Update button colors / Обновляем цвета кнопок / Оновлюємо кольори кнопок
        if hasattr(self, 'pdf_theme_light_btn') and self.pdf_theme_light_btn and self.pdf_theme_light_btn.winfo_exists():
            try:
                self.pdf_theme_light_btn.configure(fg_color="#2d6a4f" if theme == "light" else "#4b4b4b")
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"PDF theme light button update error: {e}")
        
        if hasattr(self, 'pdf_theme_dark_btn') and self.pdf_theme_dark_btn and self.pdf_theme_dark_btn.winfo_exists():
            try:
                self.pdf_theme_dark_btn.configure(fg_color="#2d6a4f" if theme == "dark" else "#4b4b4b")
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.debug(f"PDF theme dark button update error: {e}")
        
        logger.info(f"PDF theme set to: {theme}")
    
    def _change_radius_instant(self, val: int) -> None:
        """Instant radius change (for slider) / Мгновенное изменение радиуса (для слайдера) / Миттєва зміна радіусу (для слайдера)"""
        rad = int(val)
        self.current_radius = rad
        set_global_radius(rad)
        
        # Update all buttons in main window / Обновляем все кнопки в главном окне / Оновлюємо всі кнопки в головному вікні
        menu_btns = [self.btn_gen, self.btn_copy, self.btn_save, self.btn_open, 
                     self.btn_qr, self.btn_hist, self.btn_db, self.btn_hibp, 
                     self.btn_upd, self.btn_settings, self.btn_about, self.btn_name_gen]
        for btn in menu_btns:
            if btn and btn.winfo_exists():
                try:
                    btn.configure(corner_radius=rad)
                except (tk.TclError, AttributeError, RuntimeError):
                    pass
        
        if self.btn_eye and self.btn_eye.winfo_exists():
            try:
                self.btn_eye.configure(corner_radius=rad)
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        if self.entry_res and self.entry_res.winfo_exists():
            try:
                self.entry_res.configure(corner_radius=rad)
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        if self.bottom_frame and self.bottom_frame.winfo_exists():
            try:
                self.bottom_frame.configure(corner_radius=rad)
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        if self.right_panel and self.right_panel.winfo_exists():
            try:
                self.right_panel.configure(corner_radius=rad)
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        # Save to config / Сохраняем в конфиг / Зберігаємо в конфіг
        try:
            self.config.set("RADIUS", rad)
        except (KeyError, ValueError, OSError, AttributeError):
            pass
    
    def _apply_font_size_instant(self, size: int) -> None:
        """Instant font size change (for slider) / Мгновенное изменение размера шрифта (для слайдера) / Миттєва зміна розміру шрифту (для слайдера)"""
        self.current_font_size = size
        
        # Update menu buttons / Обновляем кнопки меню / Оновлюємо кнопки меню
        menu_btns = [self.btn_gen, self.btn_copy, self.btn_save, self.btn_open,
                     self.btn_qr, self.btn_hist, self.btn_db, self.btn_hibp,
                     self.btn_upd, self.btn_settings, self.btn_about, self.btn_name_gen]
        for btn in menu_btns:
            if btn and btn.winfo_exists():
                try:
                    btn.configure(font=("Segoe UI", size - 1, "bold"))
                except (tk.TclError, AttributeError, RuntimeError):
                    pass
        
        # Update headers / Обновляем заголовки / Оновлюємо заголовки
        if self.lbl_title and self.lbl_title.winfo_exists():
            try:
                self.lbl_title.configure(font=("Segoe UI", size + 6, "bold"))
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        if self.lbl_menu and self.lbl_menu.winfo_exists():
            try:
                self.lbl_menu.configure(font=("Segoe UI", size + 4, "bold"))
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        if self.lbl_strength_text and self.lbl_strength_text.winfo_exists():
            try:
                self.lbl_strength_text.configure(font=("Segoe UI", size, "bold"))
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        # Update password entry field / Обновляем поле ввода пароля / Оновлюємо поле введення пароля
        if self.entry_res and self.entry_res.winfo_exists():
            try:
                self.entry_res.configure(font=("Consolas", size + 8))
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        # Update eye button / Обновляем кнопку глаза / Оновлюємо кнопку ока
        if self.btn_eye and self.btn_eye.winfo_exists():
            try:
                self.btn_eye.configure(font=("Segoe UI", size + 6))
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        # Save to config / Сохраняем в конфиг / Зберігаємо в конфіг
        try:
            self.config.set("font_size", size)
        except (KeyError, ValueError, OSError, AttributeError):
            pass