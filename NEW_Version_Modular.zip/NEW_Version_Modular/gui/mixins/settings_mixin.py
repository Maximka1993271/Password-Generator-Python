"""
Settings mixin for SecurePassPro
"""
import tkinter as tk
import customtkinter as ctk
from localization.lang import LANGUAGES
from utils.helpers import get_global_radius, set_global_radius, play_sound
from gui.dialogs import CTkMessageBox, CTkInputDialog
from gui.widgets import ToolTip
import time


class SettingsMixin:
    """Mixin class for application settings (theme, language, fonts, etc.)"""
    
    def _change_radius(self, val: int) -> None:
        rad = int(val)
        self.current_radius = rad
        set_global_radius(rad)
        
        menu_btns = [self.btn_gen, self.btn_copy, self.btn_save, self.btn_open, self.btn_qr, self.btn_hist, self.btn_db, self.btn_hibp, self.btn_upd, self.btn_settings, self.btn_about]
        for btn in menu_btns:
            btn.configure(corner_radius=rad)
        
        self.btn_eye.configure(corner_radius=rad)
        
        cb_rad = max(rad // 2, 0)
        for cb in [self.cb_upper, self.cb_lower, self.cb_digits, self.cb_symb, self.cb_ambig, self.cb_unambig, self.cb_at_least, self.cb_hide, self.cb_no_repeat]:
            cb.configure(corner_radius=cb_rad)
        
        self.bottom_frame.configure(corner_radius=rad)
        self.right_panel.configure(corner_radius=rad)
        self.entry_res.configure(corner_radius=rad)
        self.entry_frame.configure(corner_radius=rad)
        
        if hasattr(self, 'settings_radius_label') and self.settings_radius_label and self.settings_radius_label.winfo_exists():
            self.settings_radius_label.configure(text=f"{rad} px")
        
        self._update_settings_radius()
        self.config.set("RADIUS", rad)
    
    def _update_settings_radius(self) -> None:
        rad = self.current_radius
        for btn in self.lang_buttons.values():
            if btn and btn.winfo_exists():
                btn.configure(corner_radius=rad)
        for btn in self.theme_buttons.values():
            if btn and btn.winfo_exists():
                btn.configure(corner_radius=rad)
        for btn in [self._sound_btn, self._close_btn, self._master_set_btn, self._rgb_on_btn_ref, self._rgb_off_btn_ref, self._auto_lock_btn, self.auto_save_btn]:
            if btn and btn.winfo_exists():
                btn.configure(corner_radius=rad)
    
    def _apply_font_size(self, size: int) -> None:
        self.current_font_size = size
        self.config.set("font_size", size)
        
        menu_btns = [self.btn_gen, self.btn_copy, self.btn_save, self.btn_open,
                     self.btn_qr, self.btn_hist, self.btn_db, self.btn_hibp,
                     self.btn_upd, self.btn_settings, self.btn_about]
        for btn in menu_btns:
            btn.configure(font=("Segoe UI", size - 1, "bold"))
        
        self.lbl_title.configure(font=("Segoe UI", size + 6, "bold"))
        self.lbl_menu.configure(font=("Segoe UI", size + 4, "bold"))
        self.lbl_strength_text.configure(font=("Segoe UI", size, "bold"))
        self.entry_res.configure(font=("Consolas", size + 8))
        self.btn_eye.configure(font=("Segoe UI", size + 6))
    
    def _on_font_size_change(self, val: float) -> None:
        size = int(val)
        if hasattr(self, 'font_size_value') and self.font_size_value:
            self.font_size_value.configure(text=f"{size}px")
        
        if self._font_timer:
            self.after_cancel(self._font_timer)
        self._font_timer = self.after(50, lambda: self._apply_font_size(size))
    
    def _on_radius_change(self, val: float) -> None:
        rad = int(val)
        if self.settings_radius_label and self.settings_radius_label.winfo_exists():
            self.settings_radius_label.configure(text=f"{rad} px")
        
        if self._radius_timer:
            self.after_cancel(self._radius_timer)
        self._radius_timer = self.after(50, lambda: self._change_radius(rad))
    
    def _on_clip_timeout_change(self, val: float) -> None:
        seconds = int(val)
        if self._clip_timeout_label_ref and self._clip_timeout_label_ref.winfo_exists():
            L = LANGUAGES[self.current_lang]
            self._clip_timeout_label_ref.configure(text=L["clip_timeout"].format(seconds))
        
        if self._clip_timer:
            self.after_cancel(self._clip_timer)
        self._clip_timer = self.after(50, lambda: self._apply_clip_timeout(seconds))
    
    def _apply_clip_timeout(self, seconds: int) -> None:
        self.clipboard_timeout = seconds
        if "btn_copy" in self._tooltips:
            L = LANGUAGES[self.current_lang]
            self._tooltips["btn_copy"].set_text(L["tt_copy"].format(seconds))
        self.config.set("CLIP_TIMEOUT", seconds)
    
    def _on_auto_lock_timeout_change(self, val: float) -> None:
        minutes = int(val)
        if self._auto_lock_label_ref and self._auto_lock_label_ref.winfo_exists():
            L = LANGUAGES[self.current_lang]
            self._auto_lock_label_ref.configure(text=L["auto_lock_timeout"].format(minutes))
        
        if self._auto_timer:
            self.after_cancel(self._auto_timer)
        self._auto_timer = self.after(50, lambda: self._apply_auto_timeout(minutes))
    
    def _apply_auto_timeout(self, minutes: int) -> None:
        self.auto_lock_timeout = minutes
        self.config.set("AUTO_LOCK_TIMEOUT", minutes)
    
    def _toggle_sound_settings(self) -> None:
        self.sound_enabled.set(not self.sound_enabled.get())
        if self._sound_btn and self._sound_btn.winfo_exists():
            L = LANGUAGES[self.current_lang]
            if self.sound_enabled.get():
                self._sound_btn.configure(
                    text=L["sound_on"],
                    fg_color="#2d6a4f",
                    hover_color="#2d6a4f"
                )
            else:
                self._sound_btn.configure(
                    text=L["sound_off"],
                    fg_color="#8b0000",
                    hover_color="#8b0000"
                )
        play_sound("click", self.sound_enabled.get())
        self.config.set("SOUND", self.sound_enabled.get())
    
    def _toggle_auto_save(self) -> None:
        new_value = not self.auto_save_var.get()
        self.auto_save_var.set(new_value)
        self.config.set("auto_save", new_value)
        
        L = LANGUAGES[self.current_lang]
        if new_value:
            self.auto_save_btn.configure(
                text=L["auto_save_on"],
                fg_color="#2d6a4f",
                hover_color="#2d6a4f"
            )
            CTkMessageBox.info(self, L["auto_save"], L["auto_save_enabled"])
        else:
            self.auto_save_btn.configure(
                text=L["auto_save_off"],
                fg_color="#8b0000",
                hover_color="#8b0000"
            )
            CTkMessageBox.info(self, L["auto_save"], L["auto_save_disabled"])
    
    def _change_theme(self, mode: str) -> None:
        self.current_theme = mode
        self.config.set("THEME", mode)

        for name, btn in self.theme_buttons.items():
            if btn and btn.winfo_exists():
                btn.configure(fg_color="#2d6a4f" if name == mode else "#4b4b4b")

        if self.settings_window and self.settings_window.winfo_exists():
            self._close_settings()

        try:
            ctk.set_appearance_mode(mode)
        except Exception:
            pass

        self.after(50, self._sync_theme_colors)
    
    def _sync_theme_colors(self) -> None:
        actual_theme = self._get_actual_theme()
        self._apply_theme_colors(actual_theme)
        bg = "#F3F3F3" if actual_theme == "light" else "#1d1e1e"
        self.configure(fg_color=bg)
        self.update_idletasks()
    
    def _change_language(self, lang: str) -> None:
        self.current_lang = lang
        self._apply_lang(lang)
        self.config.set("LANG", lang)
        
        for l, btn in self.lang_buttons.items():
            if btn and btn.winfo_exists():
                btn.configure(fg_color="#2d6a4f" if l == lang else "#4b4b4b")
        
        if self.settings_window and self.settings_window.winfo_exists():
            self._close_settings()
        
        if self.entry_res.get():
            self._update_strength_meter(self.entry_res.get())
        self._update_master_status_label()
        self._update_auto_lock_label()
        
        if hasattr(self, 'font_size_value') and self.font_size_value:
            self.font_size_value.configure(text=f"{self.current_font_size}px")
    
    def _toggle_auto_lock(self) -> None:
        self.auto_lock_enabled.set(not self.auto_lock_enabled.get())
        if self._auto_lock_btn and self._auto_lock_btn.winfo_exists():
            L = LANGUAGES[self.current_lang]
            if self.auto_lock_enabled.get():
                self._auto_lock_btn.configure(
                    text=L["auto_lock"] + " ✅",
                    fg_color="#2d6a4f",
                    hover_color="#2d6a4f"
                )
            else:
                self._auto_lock_btn.configure(
                    text=L["auto_lock"] + " ❌",
                    fg_color="#8b0000",
                    hover_color="#8b0000"
                )
        self.config.set("AUTO_LOCK", self.auto_lock_enabled.get())
        if self.auto_lock_enabled.get():
            self._last_activity_time = time.time()
    
    def _update_auto_lock_label(self) -> None:
        if self._auto_lock_label_ref and self._auto_lock_label_ref.winfo_exists():
            L = LANGUAGES[self.current_lang]
            self._auto_lock_label_ref.configure(text=L["auto_lock_timeout"].format(self.auto_lock_timeout))