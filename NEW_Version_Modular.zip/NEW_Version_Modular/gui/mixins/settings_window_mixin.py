"""
Settings window mixin for SecurePassPro
"""
import customtkinter as ctk
from localization.lang import LANGUAGES
from utils.helpers import set_window_icon, apply_window_rounding
from gui.widgets import ToolTip


class SettingsWindowMixin:
    """Mixin class for settings window"""
    
    def _show_settings(self) -> None:
        if self.settings_window and self.settings_window.winfo_exists():
            self.settings_window.lift()
            self.settings_window.focus_force()
            return

        L = LANGUAGES[self.current_lang]
        actual_theme = self._get_actual_theme()
        is_dark = actual_theme == "dark"
        bg_win      = "#1d1e1e" if is_dark else "#F3F3F3"
        bg_tab      = "#2b2b2b" if is_dark else "#d0d0d0"
        tab_active  = "#2d6a4f"
        tab_inactive= "#3a3a3a" if is_dark else "#b0b0b0"
        text_col    = "#ffffff" if is_dark else "#111111"

        self.settings_window = ctk.CTkToplevel(self)
        self.settings_window.configure(fg_color=bg_win)
        self.settings_window.title(L["settings_title"])
        self.settings_window.resizable(False, False)
        set_window_icon(self.settings_window)
        self.settings_window.transient(self)
        self.settings_window.grab_set()
        self._center_window_relative_to_parent(self.settings_window, 520, 680)
        apply_window_rounding(self.settings_window)
        self.settings_window.attributes("-topmost", True)
        self.settings_window.after(100, lambda: self.settings_window.attributes("-topmost", False))
        self.settings_window.focus_force()
        self.settings_window.protocol("WM_DELETE_WINDOW", self._close_settings)

        rad = self.current_radius

        # Tab bar
        tab_bar = ctk.CTkFrame(self.settings_window, fg_color=bg_tab, corner_radius=0, height=44)
        tab_bar.pack(fill="x", side="top")
        tab_bar.pack_propagate(False)

        content_area = ctk.CTkFrame(self.settings_window, fg_color=bg_win, corner_radius=0)
        content_area.pack(fill="both", expand=True)

        pages = {}
        for name in ("design", "security", "general"):
            p = ctk.CTkScrollableFrame(content_area, fg_color="transparent")
            pages[name] = p

        active_tab = {"current": "design"}
        self._settings_tab_btns = {}

        def show_tab(name):
            active_tab["current"] = name
            for k, p in pages.items():
                if k == name:
                    p.pack(fill="both", expand=True, padx=12, pady=10)
                else:
                    p.pack_forget()
            for k, b in self._settings_tab_btns.items():
                b.configure(fg_color=tab_active if k == name else tab_inactive)

        tab_keys = {
            "design": "tab_design",
            "security": "tab_security", 
            "general": "tab_general"
        }
        
        for key, lang_key in tab_keys.items():
            btn_text = L.get(lang_key, "Дизайн" if key == "design" else "Безопасность" if key == "security" else "Общие")
            b = ctk.CTkButton(
                tab_bar, text=btn_text, width=160, height=36,
                corner_radius=0, fg_color=tab_active if key == "design" else tab_inactive,
                hover_color=tab_active, text_color="#ffffff",
                font=("Segoe UI", 13, "bold"), command=lambda k=key: show_tab(k),
            )
            b.pack(side="left", padx=1, pady=4)
            self._settings_tab_btns[key] = b

        # ========== TAB 1 — ДИЗАЙН ==========
        dp = pages["design"]

        lang_label = ctk.CTkLabel(dp, text=L["settings_lang"], font=("Segoe UI", 15, "bold"), text_color=text_col)
        lang_label.pack(pady=(14, 6))
        lang_frame = ctk.CTkFrame(dp, fg_color="transparent")
        lang_frame.pack(pady=(0, 10))
        self.lang_buttons.clear()
        for lang in ["RU", "EN", "UA"]:
            btn = ctk.CTkButton(lang_frame, text=lang, width=82, height=34,
                command=lambda l=lang: self._change_language(l),
                fg_color="#2d6a4f" if self.current_lang == lang else "#4b4b4b",
                font=("Segoe UI", 13, "bold"), corner_radius=rad)
            btn.pack(side="left", padx=5)
            self.lang_buttons[lang] = btn

        self._add_separator(dp)

        theme_label = ctk.CTkLabel(dp, text=L["settings_theme"], font=("Segoe UI", 15, "bold"), text_color=text_col)
        theme_label.pack(pady=(8, 6))
        theme_frame = ctk.CTkFrame(dp, fg_color="transparent")
        theme_frame.pack(pady=(0, 10))
        
        sys_btn = ctk.CTkButton(theme_frame, text=L["theme_sys"], width=100, height=34,
            command=lambda: self._change_theme("System"),
            fg_color="#2d6a4f" if self.current_theme == "System" else "#4b4b4b",
            font=("Segoe UI", 12), corner_radius=rad)
        light_btn = ctk.CTkButton(theme_frame, text=L["theme_light"], width=100, height=34,
            command=lambda: self._change_theme("Light"),
            fg_color="#2d6a4f" if self.current_theme == "Light" else "#4b4b4b",
            font=("Segoe UI", 12), corner_radius=rad)
        dark_btn = ctk.CTkButton(theme_frame, text=L["theme_dark"], width=100, height=34,
            command=lambda: self._change_theme("Dark"),
            fg_color="#2d6a4f" if self.current_theme == "Dark" else "#4b4b4b",
            font=("Segoe UI", 12), corner_radius=rad)
        for b in (sys_btn, light_btn, dark_btn):
            b.pack(side="left", padx=4)
        self.theme_buttons = {"System": sys_btn, "Light": light_btn, "Dark": dark_btn}

        self._add_separator(dp)

        rgb_label = ctk.CTkLabel(dp, text=L["rgb_label"], font=("Segoe UI", 15, "bold"), text_color=text_col)
        rgb_label.pack(pady=(8, 6))
        rgb_frame = ctk.CTkFrame(dp, fg_color="transparent")
        rgb_frame.pack(pady=(0, 10))
        is_rgb_on = self.rgb_enabled.get()
        self._rgb_on_btn_ref = ctk.CTkButton(rgb_frame, text=L["rgb_on"], width=110, height=34,
            command=lambda: self._set_rgb(True),
            fg_color="#2d6a4f" if is_rgb_on else "#4b4b4b",
            hover_color="#2d6a4f", font=("Segoe UI", 13), corner_radius=rad)
        self._rgb_off_btn_ref = ctk.CTkButton(rgb_frame, text=L["rgb_off"], width=110, height=34,
            command=lambda: self._set_rgb(False),
            fg_color="#8b0000", hover_color="#8b0000",
            font=("Segoe UI", 13), corner_radius=rad)
        self._rgb_on_btn_ref.pack(side="left", padx=5)
        self._rgb_off_btn_ref.pack(side="left", padx=5)

        self._add_separator(dp)

        rgb_speed_label = ctk.CTkLabel(dp, text=L.get("rgb_speed", "Скорость RGB"), font=("Segoe UI", 15, "bold"), text_color=text_col)
        rgb_speed_label.pack(pady=(8, 4))
        rgb_speed_frame = ctk.CTkFrame(dp, fg_color="transparent")
        rgb_speed_frame.pack(pady=(0, 12))
        
        self._rgb_speed_btn_slow = ctk.CTkButton(rgb_speed_frame, text=L.get("rgb_speed_slow", "Медленная"), width=100, height=34,
            command=lambda: self._set_rgb_speed("slow"),
            fg_color="#2d6a4f" if getattr(self, 'rgb_speed_setting', 'normal') == "slow" else "#4b4b4b",
            font=("Segoe UI", 12), corner_radius=rad)
        self._rgb_speed_btn_slow.pack(side="left", padx=4)
        
        self._rgb_speed_btn_normal = ctk.CTkButton(rgb_speed_frame, text=L.get("rgb_speed_normal", "Нормальная"), width=100, height=34,
            command=lambda: self._set_rgb_speed("normal"),
            fg_color="#2d6a4f" if getattr(self, 'rgb_speed_setting', 'normal') == "normal" else "#4b4b4b",
            font=("Segoe UI", 12), corner_radius=rad)
        self._rgb_speed_btn_normal.pack(side="left", padx=4)
        
        self._rgb_speed_btn_fast = ctk.CTkButton(rgb_speed_frame, text=L.get("rgb_speed_fast", "Быстрая"), width=100, height=34,
            command=lambda: self._set_rgb_speed("fast"),
            fg_color="#2d6a4f" if getattr(self, 'rgb_speed_setting', 'normal') == "fast" else "#4b4b4b",
            font=("Segoe UI", 12), corner_radius=rad)
        self._rgb_speed_btn_fast.pack(side="left", padx=4)

        self._add_separator(dp)

        rgb_width_label = ctk.CTkLabel(dp, text=L.get("rgb_width", "Толщина RGB"), font=("Segoe UI", 15, "bold"), text_color=text_col)
        rgb_width_label.pack(pady=(8, 4))
        rgb_width_frame = ctk.CTkFrame(dp, fg_color="transparent")
        rgb_width_frame.pack(pady=(0, 12))
        
        self._rgb_width_btn_thin = ctk.CTkButton(rgb_width_frame, text=L.get("rgb_width_thin", "Тонкая"), width=100, height=34,
            command=lambda: self._set_rgb_width("thin"),
            fg_color="#2d6a4f" if getattr(self, 'rgb_width_setting', 'normal') == "thin" else "#4b4b4b",
            font=("Segoe UI", 12), corner_radius=rad)
        self._rgb_width_btn_thin.pack(side="left", padx=4)
        
        self._rgb_width_btn_normal = ctk.CTkButton(rgb_width_frame, text=L.get("rgb_width_normal", "Средняя"), width=100, height=34,
            command=lambda: self._set_rgb_width("normal"),
            fg_color="#2d6a4f" if getattr(self, 'rgb_width_setting', 'normal') == "normal" else "#4b4b4b",
            font=("Segoe UI", 12), corner_radius=rad)
        self._rgb_width_btn_normal.pack(side="left", padx=4)
        
        self._rgb_width_btn_thick = ctk.CTkButton(rgb_width_frame, text=L.get("rgb_width_thick", "Толстая"), width=100, height=34,
            command=lambda: self._set_rgb_width("thick"),
            fg_color="#2d6a4f" if getattr(self, 'rgb_width_setting', 'normal') == "thick" else "#4b4b4b",
            font=("Segoe UI", 12), corner_radius=rad)
        self._rgb_width_btn_thick.pack(side="left", padx=4)

        self._add_separator(dp)

        font_lbl = ctk.CTkLabel(dp, text=L.get("font_size", "Размер шрифта"), font=("Segoe UI", 15, "bold"), text_color=text_col)
        font_lbl.pack(pady=(8, 4))
        self.font_size_value = ctk.CTkLabel(dp, text=f"{self.current_font_size}px", font=("Segoe UI", 18, "bold"), text_color=text_col)
        self.font_size_value.pack(pady=(0, 4))
        self.font_size_slider = ctk.CTkSlider(dp, from_=10, to=20, number_of_steps=10,
            command=self._on_font_size_change, width=300)
        self.font_size_slider.set(self.current_font_size)
        self.font_size_slider.pack(pady=(0, 10))

        self._add_separator(dp)

        radius_label = ctk.CTkLabel(dp, text=f"{L['settings_radius']}: {self.current_radius}", font=("Segoe UI", 15, "bold"), text_color=text_col)
        radius_label.pack(pady=(8, 4))
        self.settings_radius_label = radius_label
        radius_slider = ctk.CTkSlider(dp, from_=0, to=25, command=self._on_radius_change, width=300)
        radius_slider.set(self.current_radius)
        radius_slider.pack(pady=(0, 16))

        ctk.CTkButton(dp, text=L["close"], command=self._close_settings,
            fg_color="#8b0000", hover_color="#8b0000", width=150, height=40, 
            font=("Segoe UI", 14), corner_radius=rad).pack(pady=(4, 14))

        # ========== TAB 2 — БЕЗОПАСНОСТЬ ==========
        sp = pages["security"]

        master_lbl = ctk.CTkLabel(sp, text="🔐 " + L["master_title"], font=("Segoe UI", 15, "bold"), text_color=text_col)
        master_lbl.pack(pady=(14, 4))
        
        self._master_status_label = ctk.CTkLabel(sp, text="", font=("Segoe UI", 12))
        self._master_status_label.pack(pady=(0, 6))
        self._update_master_status_label()
        
        self._master_set_btn = ctk.CTkButton(sp, text="", width=220, height=40,
            font=("Segoe UI", 13, "bold"), corner_radius=rad)
        self._master_set_btn.pack(pady=(5, 15))
        self._update_master_buttons()

        self._add_separator(sp)

        al_lbl = ctk.CTkLabel(sp, text=L["auto_lock"], font=("Segoe UI", 15, "bold"), text_color=text_col)
        al_lbl.pack(pady=(8, 4))
        al_text = L["auto_lock"] + (" ✅" if self.auto_lock_enabled.get() else " ❌")
        self._auto_lock_btn = ctk.CTkButton(sp, text=al_text, width=160, height=40,
            command=self._toggle_auto_lock,
            fg_color="#2d6a4f" if self.auto_lock_enabled.get() else "#8b0000",
            font=("Segoe UI", 13), corner_radius=rad)
        self._auto_lock_btn.pack(pady=(4, 4))
        
        self._auto_lock_label_ref = ctk.CTkLabel(sp, text=L["auto_lock_timeout"].format(self.auto_lock_timeout),
            font=("Segoe UI", 13), text_color=text_col)
        self._auto_lock_label_ref.pack(pady=(4, 0))
        self._auto_lock_slider = ctk.CTkSlider(sp, from_=1, to=30, number_of_steps=29,
            width=300, command=self._on_auto_lock_timeout_change)
        self._auto_lock_slider.set(self.auto_lock_timeout)
        self._auto_lock_slider.pack(pady=(4, 14))

        self._add_separator(sp)

        clip_lbl = ctk.CTkLabel(sp, text=L["clip_timeout"].format(self.clipboard_timeout),
            font=("Segoe UI", 15, "bold"), text_color=text_col)
        clip_lbl.pack(pady=(8, 4))
        self._clip_timeout_label_ref = clip_lbl
        clip_slider = ctk.CTkSlider(sp, from_=10, to=120, number_of_steps=110,
            width=300, command=self._on_clip_timeout_change)
        clip_slider.set(self.clipboard_timeout)
        clip_slider.pack(pady=(0, 16))

        ctk.CTkButton(sp, text=L["close"], command=self._close_settings,
            fg_color="#8b0000", hover_color="#8b0000", width=150, height=40,
            font=("Segoe UI", 14), corner_radius=rad).pack(pady=(4, 14))

        # ========== TAB 3 — ОБЩИЕ ==========
        gp = pages["general"]

        sound_label = ctk.CTkLabel(gp, text=L["settings_sound"], font=("Segoe UI", 15, "bold"), text_color=text_col)
        sound_label.pack(pady=(14, 6))
        sound_text = L["sound_on"] if self.sound_enabled.get() else L["sound_off"]
        self._sound_btn = ctk.CTkButton(gp, text=sound_text, width=160, height=40,
            command=self._toggle_sound_settings,
            fg_color="#2d6a4f" if self.sound_enabled.get() else "#8b0000",
            font=("Segoe UI", 14), corner_radius=rad)
        self._sound_btn.pack(pady=(0, 14))

        self._add_separator(gp)

        auto_save_lbl = ctk.CTkLabel(gp, text=L.get("auto_save_label", "📁 Автосохранение"),
            font=("Segoe UI", 15, "bold"), text_color=text_col)
        auto_save_lbl.pack(pady=(8, 6))
        self.auto_save_btn = ctk.CTkButton(gp,
            text=L["auto_save_on"] if self.auto_save_var.get() else L["auto_save_off"],
            width=160, height=40, command=self._toggle_auto_save,
            fg_color="#2d6a4f" if self.auto_save_var.get() else "#8b0000",
            corner_radius=rad)
        self.auto_save_btn.pack(pady=(0, 14))

        self._close_btn = ctk.CTkButton(gp, text=L["close"], command=self._close_settings,
            fg_color="#8b0000", hover_color="#8b0000", width=150, height=40,
            font=("Segoe UI", 14), corner_radius=rad)
        self._close_btn.pack(pady=(10, 14))

        show_tab("design")

        self.settings_labels = {
            "lang": lang_label, "theme": theme_label, "sound": sound_label,
            "close_btn": self._close_btn, "sound_btn": self._sound_btn,
            "radius_slider": radius_slider,
        }
    
    def _refresh_settings_tabs_language(self) -> None:
        if not hasattr(self, '_settings_tab_btns') or not self._settings_tab_btns:
            return
        L = LANGUAGES[self.current_lang]
        tab_keys = {"design": "tab_design", "security": "tab_security", "general": "tab_general"}
        for key, lang_key in tab_keys.items():
            if key in self._settings_tab_btns and self._settings_tab_btns[key].winfo_exists():
                btn_text = L.get(lang_key, "Дизайн" if key == "design" else "Безопасность" if key == "security" else "Общие")
                self._settings_tab_btns[key].configure(text=btn_text)
    
    def _add_separator(self, parent) -> None:
        sep = ctk.CTkFrame(parent, height=2, fg_color="gray")
        sep.pack(fill="x", pady=8)
    
    def _close_settings(self) -> None:
        if self.settings_window:
            self.settings_window.grab_release()
            self.settings_window.destroy()
            self.settings_window = None
            self.settings_labels = {}
            self.lang_buttons = {}
            self.theme_buttons = {}
            self._master_set_btn = None
            self._master_status_label = None
            self._sound_btn = None
            self._close_btn = None
            self._rgb_on_btn_ref = None
            self._rgb_off_btn_ref = None
            self._rgb_speed_btn_slow = None
            self._rgb_speed_btn_normal = None
            self._rgb_speed_btn_fast = None
            self._rgb_width_btn_thin = None
            self._rgb_width_btn_normal = None
            self._rgb_width_btn_thick = None
            self.settings_radius_label = None
            self._clip_timeout_label_ref = None
            self._auto_lock_btn = None
            self._auto_lock_slider = None
            self._auto_lock_label_ref = None
            self._radius_timer = None
            self._clip_timer = None
            self._auto_timer = None
            self._font_timer = None
            if hasattr(self, '_settings_tab_btns'):
                self._settings_tab_btns = {}