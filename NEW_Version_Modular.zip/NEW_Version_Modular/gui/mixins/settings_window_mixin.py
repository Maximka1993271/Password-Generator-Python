"""
Settings window mixin for SecurePassPro - MODERN DESIGN like Microsoft Edge

Миксин окна настроек для SecurePassPro - СОВРЕМЕННЫЙ ДИЗАЙН как в Microsoft Edge
Міксин вікна налаштувань для SecurePassPro - СУЧАСНИЙ ДИЗАЙН як у Microsoft Edge
"""
import customtkinter as ctk
import tkinter as tk
import datetime
from localization.lang import LANGUAGES
from utils.helpers import set_window_icon, apply_window_rounding
from gui.widgets import ToolTip
from utils.radius_manager import update_all_buttons_radius, set_global_radius
from utils.logger import get_logger

logger = get_logger("settings_window")


class SettingsWindowMixin:
    """Mixin class for settings window - MODERN CARD DESIGN
    Класс-миксин для окна настроек - СОВРЕМЕННЫЙ КАРТОЧНЫЙ ДИЗАЙН
    Клас-міксин для вікна налаштувань - СУЧАСНИЙ КАРТКОВИЙ ДИЗАЙН"""
    
    def _show_settings(self) -> None:
        if self.settings_window and self.settings_window.winfo_exists():
            self.settings_window.lift()
            self.settings_window.focus_force()
            return

        L = LANGUAGES[self.current_lang]
        actual_theme = self._get_actual_theme()
        is_dark = actual_theme == "dark"
        
        # Colors for modern design / Цвета для современного дизайна / Кольори для сучасного дизайну
        if is_dark:
            bg_win = "#202020"
            bg_card = "#2d2d2d"
            bg_card_hover = "#383838"
            text_primary = "#ffffff"
            text_secondary = "#a0a0a0"
            border_color = "#3d3d3d"
            accent_color = "#2d6a4f"
            accent_hover = "#40916c"
            icon_bg = "#383838"
        else:
            bg_win = "#f0f0f0"
            bg_card = "#ffffff"
            bg_card_hover = "#f8f8f8"
            text_primary = "#202020"
            text_secondary = "#606060"
            border_color = "#e0e0e0"
            accent_color = "#2d6a4f"
            accent_hover = "#40916c"
            icon_bg = "#f0f0f0"

        try:
            self.settings_window = ctk.CTkToplevel(self)
            self.settings_window.configure(fg_color=bg_win)
            self.settings_window.title(L["settings_title"])
            self.settings_window.geometry("850x650")
            self.settings_window.minsize(750, 500)
            set_window_icon(self.settings_window)
            self.settings_window.transient(self)
            self.settings_window.grab_set()
            self.settings_window.attributes("-topmost", True)
            self.settings_window.after(100, lambda: self.settings_window.attributes("-topmost", False))
            self._center_window_relative_to_parent(self.settings_window, 850, 650)
            apply_window_rounding(self.settings_window)
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.error(f"Failed to create settings window: {e}")
            return
        
        rad = self.current_radius

        # ========== MAIN CONTAINER / ОСНОВНОЙ КОНТЕЙНЕР / ОСНОВНИЙ КОНТЕЙНЕР ==========
        main_container = ctk.CTkFrame(self.settings_window, fg_color="transparent")
        main_container.pack(fill="both", expand=True, padx=20, pady=20)
        
        # ========== HEADER WITH SEARCH ==========
        header_frame = ctk.CTkFrame(main_container, fg_color="transparent")
        header_frame.pack(fill="x", pady=(0, 20))
        
        title_label = ctk.CTkLabel(header_frame, text=L["settings_title"], 
                    font=("Segoe UI", 24, "bold"), text_color=text_primary)
        title_label.pack(anchor="w")
        
        subtitle_label = ctk.CTkLabel(header_frame, text=L.get("settings_subtitle", "Configure the app to your needs"),
                    font=("Segoe UI", 12), text_color=text_secondary)
        subtitle_label.pack(anchor="w", pady=(5, 0))
        
        # Search bar for settings / Строка поиска настроек / Рядок пошуку налаштувань
        search_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        search_frame.pack(fill="x", pady=(15, 0))
        
        search_entry = ctk.CTkEntry(
            search_frame,
            placeholder_text=" " + L.get("settings_search", "Search settings..."),  # Убран эмодзи
            height=40,
            corner_radius=rad,
            fg_color=bg_card,
            text_color=text_primary
        )
        search_entry.pack(fill="x")
        
        # ========== SIDEBAR (TABS LIKE IN EDGE) / ВКЛАДКИ КАК В EDGE / ВКЛАДКИ ЯК У EDGE ==========
        content_frame = ctk.CTkFrame(main_container, fg_color="transparent")
        content_frame.pack(fill="both", expand=True)
        
        # Left panel with categories / Левая панель с категориями / Ліва панель з категоріями
        sidebar = ctk.CTkFrame(content_frame, width=200, fg_color="transparent")
        sidebar.pack(side="left", fill="y", padx=(0, 20))
        sidebar.pack_propagate(False)
        
        # Right panel with content / Правая панель с содержимым / Права панель з вмістом
        right_panel = ctk.CTkFrame(content_frame, fg_color="transparent")
        right_panel.pack(side="left", fill="both", expand=True)
        
        # ========== CATEGORIES IN SIDEBAR / КАТЕГОРИИ В САЙДБАРЕ / КАТЕГОРІЇ В САЙДБАРІ ==========
        categories = [
            ("design", "tab_design", L.get("tab_design", "Дизайн")),
            ("security", "tab_security", L.get("tab_security", "Безопасность")),
            ("general", "tab_general", L.get("tab_general", "Общие")),
        ]
        
        self.category_buttons = {}
        self.category_frames = {}
        
        for key, lang_key, display_text in categories:
            content_frame_inner = ctk.CTkScrollableFrame(right_panel, fg_color="transparent")
            self.category_frames[key] = content_frame_inner
            
            btn_frame = ctk.CTkFrame(sidebar, fg_color="transparent", height=50)
            btn_frame.pack(fill="x", pady=3)
            btn_frame.pack_propagate(False)
            
            btn = ctk.CTkButton(
                btn_frame,
                text=display_text,
                anchor="w",
                font=("Segoe UI", 14),
                fg_color="transparent",
                text_color=text_primary,
                hover_color=bg_card_hover,
                corner_radius=rad,
                height=45,
                command=lambda k=key: self._switch_category(k)
            )
            btn.pack(fill="both", expand=True, padx=5, pady=2)
            self.category_buttons[key] = btn
        
        self._switch_category("design")
        
        # Search functionality / Функция поиска / Функція пошуку
        def on_search(*args):
            query = search_entry.get().lower()
            if not query:
                for frame in self.category_frames.values():
                    for child in frame.winfo_children():
                        if isinstance(child, ctk.CTkFrame):
                            try:
                                child.pack(fill="x", pady=10)
                            except (tk.TclError, RuntimeError):
                                pass
                return
            
            for category_key, frame in self.category_frames.items():
                visible_count = 0
                for child in frame.winfo_children():
                    if isinstance(child, ctk.CTkFrame):
                        card_text = ""
                        for label in child.winfo_children():
                            if isinstance(label, ctk.CTkLabel):
                                try:
                                    card_text += label.cget("text").lower() + " "
                                except (tk.TclError, AttributeError):
                                    pass
                        
                        if query in card_text:
                            try:
                                child.pack(fill="x", pady=10)
                                visible_count += 1
                            except (tk.TclError):
                                pass
                        else:
                            try:
                                child.pack_forget()
                            except (tk.TclError):
                                pass
                
                if visible_count == 0:
                    try:
                        frame.pack_forget()
                    except (tk.TclError):
                        pass
                else:
                    try:
                        frame.pack(fill="both", expand=True)
                    except (tk.TclError):
                        pass
        
        search_entry.bind("<KeyRelease>", on_search)
        
        # ========== FILL CATEGORIES / ЗАПОЛНЕНИЕ КАТЕГОРИЙ / ЗАПОВНЕННЯ КАТЕГОРІЙ ==========
        
        # ----- CATEGORY: DESIGN / КАТЕГОРИЯ: ДИЗАЙН / КАТЕГОРІЯ: ДИЗАЙН -----
        design_frame = self.category_frames["design"]
        
        # Card: Language / Карточка: Язык / Картка: Мова
        self._add_settings_card(design_frame, "settings_lang", L.get("settings_lang_desc", "Choose interface language"))
        lang_frame = ctk.CTkFrame(design_frame, fg_color="transparent")
        lang_frame.pack(fill="x", pady=(0, 20))
        
        self.lang_buttons.clear()
        for lang in ["RU", "EN", "UA"]:
            btn = ctk.CTkButton(
                lang_frame,
                text=lang,
                width=80,
                height=36,
                command=lambda l=lang: self._change_language(l),
                fg_color=accent_color if self.current_lang == lang else bg_card,
                text_color=text_primary if self.current_lang == lang else text_secondary,
                hover_color=accent_hover,
                font=("Segoe UI", 13, "bold"),
                corner_radius=rad
            )
            btn.pack(side="left", padx=8)
            self.lang_buttons[lang] = btn
        
        # Card: Theme / Карточка: Тема / Картка: Тема
        self._add_settings_card(design_frame, "settings_theme", L.get("settings_theme_desc", "Choose application appearance"))
        theme_frame = ctk.CTkFrame(design_frame, fg_color="transparent")
        theme_frame.pack(fill="x", pady=(0, 20))
        
        theme_btn = ctk.CTkButton(
            theme_frame,
            text=L["theme_light"],
            width=100,
            height=36,
            command=lambda: self._change_theme("Light"),
            fg_color=accent_color if self.current_theme == "Light" else bg_card,
            text_color=text_primary if self.current_theme == "Light" else text_secondary,
            corner_radius=rad
        )
        theme_btn.pack(side="left", padx=8)
        
        theme_btn2 = ctk.CTkButton(
            theme_frame,
            text=L["theme_dark"],
            width=100,
            height=36,
            command=lambda: self._change_theme("Dark"),
            fg_color=accent_color if self.current_theme == "Dark" else bg_card,
            text_color=text_primary if self.current_theme == "Dark" else text_secondary,
            corner_radius=rad
        )
        theme_btn2.pack(side="left", padx=8)
        
        theme_btn3 = ctk.CTkButton(
            theme_frame,
            text=L["theme_sys"],
            width=100,
            height=36,
            command=lambda: self._change_theme("System"),
            fg_color=accent_color if self.current_theme == "System" else bg_card,
            text_color=text_primary if self.current_theme == "System" else text_secondary,
            corner_radius=rad
        )
        theme_btn3.pack(side="left", padx=8)
        
        self.theme_buttons = {"Light": theme_btn, "Dark": theme_btn2, "System": theme_btn3}
        
        # Card: RGB / Карточка: RGB / Картка: RGB
        self._add_settings_card(design_frame, "rgb_label", L.get("rgb_label_desc", "Colorful border animation"))
        rgb_frame = ctk.CTkFrame(design_frame, fg_color="transparent")
        rgb_frame.pack(fill="x", pady=(0, 20))
        
        self._rgb_on_btn_ref = ctk.CTkButton(
            rgb_frame, text=L["rgb_on"], width=100, height=36,
            command=lambda: self._set_rgb(True),
            fg_color=accent_color if self.rgb_enabled.get() else bg_card,
            text_color=text_primary if self.rgb_enabled.get() else text_secondary,
            corner_radius=rad
        )
        self._rgb_on_btn_ref.pack(side="left", padx=8)
        
        self._rgb_off_btn_ref = ctk.CTkButton(
            rgb_frame, text=L["rgb_off"], width=100, height=36,
            command=lambda: self._set_rgb(False),
            fg_color=accent_color if not self.rgb_enabled.get() else bg_card,
            text_color=text_primary if not self.rgb_enabled.get() else text_secondary,
            corner_radius=rad
        )
        self._rgb_off_btn_ref.pack(side="left", padx=8)
        
        # Card: RGB Speed / Карточка: Скорость RGB / Картка: Швидкість RGB
        self._add_settings_card(design_frame, "rgb_speed", L.get("rgb_speed_desc", "RGB animation speed"))
        speed_frame = ctk.CTkFrame(design_frame, fg_color="transparent")
        speed_frame.pack(fill="x", pady=(0, 20))
        
        speeds = [("slow", L.get("rgb_speed_slow", "Slow")), 
                  ("normal", L.get("rgb_speed_normal", "Normal")), 
                  ("fast", L.get("rgb_speed_fast", "Fast"))]
        for speed_val, speed_name in speeds:
            btn = ctk.CTkButton(
                speed_frame, text=speed_name, width=100, height=36,
                command=lambda s=speed_val: self._set_rgb_speed(s),
                fg_color=accent_color if getattr(self, 'rgb_speed_setting', 'normal') == speed_val else bg_card,
                text_color=text_primary if getattr(self, 'rgb_speed_setting', 'normal') == speed_val else text_secondary,
                corner_radius=rad
            )
            btn.pack(side="left", padx=8)
            if speed_val == "slow":
                self._rgb_speed_btn_slow = btn
            elif speed_val == "normal":
                self._rgb_speed_btn_normal = btn
            else:
                self._rgb_speed_btn_fast = btn
        
        # Card: RGB Width / Карточка: Толщина RGB / Картка: Товщина RGB
        self._add_settings_card(design_frame, "rgb_width", L.get("rgb_width_desc", "RGB border thickness"))
        width_frame = ctk.CTkFrame(design_frame, fg_color="transparent")
        width_frame.pack(fill="x", pady=(0, 20))
        
        widths = [("thin", L.get("rgb_width_thin", "Thin")), 
                  ("normal", L.get("rgb_width_normal", "Normal")), 
                  ("thick", L.get("rgb_width_thick", "Thick"))]
        for width_val, width_name in widths:
            btn = ctk.CTkButton(
                width_frame, text=width_name, width=100, height=36,
                command=lambda w=width_val: self._set_rgb_width(w),
                fg_color=accent_color if getattr(self, 'rgb_width_setting', 'normal') == width_val else bg_card,
                text_color=text_primary if getattr(self, 'rgb_width_setting', 'normal') == width_val else text_secondary,
                corner_radius=rad
            )
            btn.pack(side="left", padx=8)
            if width_val == "thin":
                self._rgb_width_btn_thin = btn
            elif width_val == "normal":
                self._rgb_width_btn_normal = btn
            else:
                self._rgb_width_btn_thick = btn
        
        # Card: Font size / Карточка: Размер шрифта / Картка: Розмір шрифту
        self._add_settings_card(design_frame, "font_size", L.get("font_size_desc", "Interface text size"))
        font_frame = ctk.CTkFrame(design_frame, fg_color="transparent")
        font_frame.pack(fill="x", pady=(0, 20))
        
        self.font_size_value = ctk.CTkLabel(font_frame, text=f"{self.current_font_size}px", 
                                           font=("Segoe UI", 18, "bold"), text_color=accent_color)
        self.font_size_value.pack(pady=(0, 5))
        
        self._font_update_timer = None
        def on_font_size_change(val):
            size = int(float(val))
            self.font_size_value.configure(text=f"{size}px")
            if self._font_update_timer:
                self.after_cancel(self._font_update_timer)
            self._font_update_timer = self.after(150, lambda: self._apply_font_size(size))
        
        self.font_size_slider = ctk.CTkSlider(font_frame, from_=10, to=20, number_of_steps=10,
                                             command=on_font_size_change, width=300)
        self.font_size_slider.set(self.current_font_size)
        self.font_size_slider.pack()
        
        # Card: Corner radius / Карточка: Закругление углов / Картка: Закруглення кутів
        self._add_settings_card(design_frame, "settings_radius", L.get("radius_desc", "Corner rounding of elements"))
        radius_frame = ctk.CTkFrame(design_frame, fg_color="transparent")
        radius_frame.pack(fill="x", pady=(0, 20))
        
        self.settings_radius_label = ctk.CTkLabel(radius_frame, text=f"{self.current_radius} px", 
                                                 font=("Segoe UI", 14), text_color=accent_color)
        self.settings_radius_label.pack(pady=(0, 5))
        
        self._radius_update_timer = None
        def on_radius_change(val):
            new_radius = int(float(val))
            self.settings_radius_label.configure(text=f"{new_radius} px")
            if self._radius_update_timer:
                self.after_cancel(self._radius_update_timer)
            self._radius_update_timer = self.after(200, lambda: self._apply_radius_smooth(new_radius))
        
        radius_slider = ctk.CTkSlider(radius_frame, from_=0, to=25, command=on_radius_change, width=300)
        radius_slider.set(self.current_radius)
        radius_slider.pack()
        
        # Card: PDF Theme / Карточка: Тема PDF / Картка: Тема PDF
        self._add_settings_card(design_frame, "pdf_theme", L.get("pdf_theme_desc", "PDF export appearance"))
        pdf_theme_frame = ctk.CTkFrame(design_frame, fg_color="transparent")
        pdf_theme_frame.pack(fill="x", pady=(0, 20))
        
        current_pdf_theme = self.config.get("PDF_THEME", "light")
        
        self.pdf_theme_light_btn = ctk.CTkButton(
            pdf_theme_frame, text=L.get("pdf_theme_light", "Light"), width=120, height=36,
            command=lambda: self._set_pdf_theme("light"),
            fg_color=accent_color if current_pdf_theme == "light" else bg_card,
            text_color=text_primary if current_pdf_theme == "light" else text_secondary,
            corner_radius=rad
        )
        self.pdf_theme_light_btn.pack(side="left", padx=8)
        
        self.pdf_theme_dark_btn = ctk.CTkButton(
            pdf_theme_frame, text=L.get("pdf_theme_dark", "Dark"), width=120, height=36,
            command=lambda: self._set_pdf_theme("dark"),
            fg_color=accent_color if current_pdf_theme == "dark" else bg_card,
            text_color=text_primary if current_pdf_theme == "dark" else text_secondary,
            corner_radius=rad
        )
        self.pdf_theme_dark_btn.pack(side="left", padx=8)
        
        # ----- CATEGORY: SECURITY / КАТЕГОРИЯ: БЕЗОПАСНОСТЬ / КАТЕГОРІЯ: БЕЗПЕКА -----
        security_frame = self.category_frames["security"]
        
        # Card: Master password / Карточка: Мастер-пароль / Картка: Майстер-пароль
        self._add_settings_card(security_frame, "master_title", L.get("master_desc", "Program access protection"))
        master_frame = ctk.CTkFrame(security_frame, fg_color="transparent")
        master_frame.pack(fill="x", pady=(0, 20))
        
        self._master_status_label = ctk.CTkLabel(master_frame, text="", font=("Segoe UI", 12))
        self._master_status_label.pack(pady=(0, 10))
        self._update_master_status_label()
        
        self._master_set_btn = ctk.CTkButton(
            master_frame, text="", width=200, height=40,
            font=("Segoe UI", 13, "bold"), corner_radius=rad
        )
        self._master_set_btn.pack()
        self._update_master_buttons()
        
        # Card: 2FA / Карточка: 2FA / Картка: 2FA
        self._add_settings_card(security_frame, "2fa_title", L.get("2fa_description", "Two-Factor Authentication"))
        twofa_frame = ctk.CTkFrame(security_frame, fg_color="transparent")
        twofa_frame.pack(fill="x", pady=(0, 20))
        
        self._2fa_status_label = ctk.CTkLabel(
            twofa_frame, 
            text=self._get_2fa_status_text(),
            font=("Segoe UI", 12, "bold"),
            text_color=self._get_2fa_status_color()
        )
        self._2fa_status_label.pack(pady=(0, 10))
        
        self._2fa_settings_btn = ctk.CTkButton(
            twofa_frame,
            text=L.get("2fa_settings_title", "2FA Settings"),
            width=200,
            height=40,
            command=self._show_2fa_settings,
            fg_color=accent_color,
            hover_color=accent_hover,
            font=("Segoe UI", 13, "bold"),
            corner_radius=rad
        )
        self._2fa_settings_btn.pack()
        
        # Card: Auto-lock / Карточка: Автоблокировка / Картка: Автоблокування
        self._add_settings_card(security_frame, "auto_lock", L.get("auto_lock_desc", "Auto lock on inactivity"))
        auto_frame = ctk.CTkFrame(security_frame, fg_color="transparent")
        auto_frame.pack(fill="x", pady=(0, 20))
        
        self._auto_lock_btn = ctk.CTkButton(
            auto_frame, text="", width=160, height=40,
            command=self._toggle_auto_lock,
            fg_color=accent_color if self.auto_lock_enabled.get() else bg_card,
            corner_radius=rad
        )
        self._auto_lock_btn.pack(pady=(0, 10))
        self._update_auto_lock_button()
        
        self._auto_lock_label_ref = ctk.CTkLabel(auto_frame, text="", font=("Segoe UI", 12))
        self._auto_lock_label_ref.pack()
        self._update_auto_lock_label()
        
        self._auto_timer = None
        def on_auto_timeout_change(val):
            minutes = int(float(val))
            L_local = LANGUAGES[self.current_lang]
            self._auto_lock_label_ref.configure(text=L_local["auto_lock_timeout"].format(minutes))
            if self._auto_timer:
                self.after_cancel(self._auto_timer)
            self._auto_timer = self.after(100, lambda: self._apply_auto_timeout(minutes))
        
        self._auto_lock_slider = ctk.CTkSlider(auto_frame, from_=1, to=30, number_of_steps=29,
                                              width=300, command=on_auto_timeout_change)
        self._auto_lock_slider.set(self.auto_lock_timeout)
        self._auto_lock_slider.pack(pady=(10, 0))
        
        # Card: Clipboard / Карточка: Буфер обмена / Картка: Буфер обміну
        self._add_settings_card(security_frame, "clip_timeout", L.get("clip_timeout_desc", "Auto clear clipboard"))
        clip_frame = ctk.CTkFrame(security_frame, fg_color="transparent")
        clip_frame.pack(fill="x", pady=(0, 20))
        
        self._clip_timeout_label_ref = ctk.CTkLabel(clip_frame, text="", font=("Segoe UI", 12))
        self._clip_timeout_label_ref.pack(pady=(0, 10))
        
        self._clip_timer = None
        def on_clip_timeout_change(val):
            seconds = int(float(val))
            L_local = LANGUAGES[self.current_lang]
            self._clip_timeout_label_ref.configure(text=L_local["clip_timeout"].format(seconds))
            if self._clip_timer:
                self.after_cancel(self._clip_timer)
            self._clip_timer = self.after(100, lambda: self._apply_clip_timeout(seconds))
        
        clip_slider = ctk.CTkSlider(clip_frame, from_=10, to=120, number_of_steps=110,
                                   width=300, command=on_clip_timeout_change)
        clip_slider.set(self.clipboard_timeout)
        clip_slider.pack()
        
        # ----- CATEGORY: GENERAL / КАТЕГОРИЯ: ОБЩИЕ / КАТЕГОРІЯ: ЗАГАЛЬНІ -----
        general_frame = self.category_frames["general"]
        
        # Card: Sound / Карточка: Звук / Картка: Звук
        self._add_settings_card(general_frame, "settings_sound", L.get("sound_desc", "Sound effects for actions"))
        sound_frame = ctk.CTkFrame(general_frame, fg_color="transparent")
        sound_frame.pack(fill="x", pady=(0, 20))
        
        self._sound_btn = ctk.CTkButton(
            sound_frame, text="", width=160, height=40,
            command=self._toggle_sound_settings,
            fg_color=accent_color if self.sound_enabled.get() else bg_card,
            corner_radius=rad
        )
        self._sound_btn.pack()
        self._update_sound_button()
        
        # Card: Auto save / Карточка: Автосохранение / Картка: Автозбереження
        self._add_settings_card(general_frame, "auto_save_label", L.get("auto_save_desc", "Automatically save passwords"))
        autosave_frame = ctk.CTkFrame(general_frame, fg_color="transparent")
        autosave_frame.pack(fill="x", pady=(0, 20))
        
        self.auto_save_btn = ctk.CTkButton(
            autosave_frame, text="", width=160, height=40,
            command=self._toggle_auto_save,
            fg_color=accent_color if self.auto_save_var.get() else bg_card,
            corner_radius=rad
        )
        self.auto_save_btn.pack()
        self._update_auto_save_button()
        
        # Settings Profiles / Профили настроек / Профілі налаштувань
        self._add_settings_card(general_frame, "settings_profiles", L.get("settings_profiles_desc", "Save and load settings profiles"))
        profiles_frame = ctk.CTkFrame(general_frame, fg_color="transparent")
        profiles_frame.pack(fill="x", pady=(0, 20))
        
        profile_btn_frame = ctk.CTkFrame(profiles_frame, fg_color="transparent")
        profile_btn_frame.pack()
        
        self.save_profile_btn = ctk.CTkButton(
            profile_btn_frame, text=L.get("save_profile", "Save Profile"),
            command=self._save_settings_profile, width=140, height=36,
            fg_color="#2d6a4f", corner_radius=rad, font=("Segoe UI", 12)
        )
        self.save_profile_btn.pack(side="left", padx=5)
        
        self.load_profile_btn = ctk.CTkButton(
            profile_btn_frame, text=L.get("load_profile", "Load Profile"),
            command=self._load_settings_profile, width=140, height=36,
            fg_color="#1f538d", corner_radius=rad, font=("Segoe UI", 12)
        )
        self.load_profile_btn.pack(side="left", padx=5)
        
        self.reset_profile_btn = ctk.CTkButton(
            profile_btn_frame, text=L.get("reset_profile", "Reset"),
            command=self._reset_settings_profile, width=140, height=36,
            fg_color="#8b0000", corner_radius=rad, font=("Segoe UI", 12)
        )
        self.reset_profile_btn.pack(side="left", padx=5)
        
        # Close button / Кнопка Закрыть / Кнопка Закрити
        close_btn = ctk.CTkButton(
            general_frame, text=L["close"], width=160, height=40,
            command=self._close_settings,
            fg_color="#8b0000", hover_color="#aa0000",
            font=("Segoe UI", 13, "bold"), corner_radius=rad
        )
        close_btn.pack(pady=(20, 0))
        
        # Save references / Сохраняем ссылки / Зберігаємо посилання
        self._radius_slider = radius_slider
        self._clip_slider = clip_slider
        self._font_slider = self.font_size_slider
        self._auto_lock_slider_ref = self._auto_lock_slider
        self._close_btn = close_btn
        self._search_entry = search_entry
        
        def on_close():
            try:
                self.config.save()
            except (OSError, IOError, AttributeError, TypeError) as e:
                logger.debug(f"Config save error on close: {e}")
            self._close_settings()
        
        self.settings_window.protocol("WM_DELETE_WINDOW", on_close)
    
    def _save_settings_profile(self) -> None:
        """Save current settings as a profile / Сохранить текущие настройки как профиль / Зберегти поточні налаштування як профіль"""
        from storage.config import Config
        import json
        import os
        from tkinter import filedialog
        
        L = LANGUAGES[self.current_lang]
        
        file_path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("Profile files", "*.json"), ("All files", "*.*")],
            title=L.get("save_profile", "Save Settings Profile")
        )
        
        if not file_path:
            return
        
        try:
            config = Config()
            all_config = config.get_all()
            
            # Remove sensitive data / Удаляем чувствительные данные / Видаляємо чутливі дані
            sensitive_keys = ['2fa_secret', '2fa_backup_hashes', '_schema_version']
            for key in sensitive_keys:
                if key in all_config:
                    del all_config[key]
            
            # Add metadata / Добавляем метаданные / Додаємо метадані
            profile_data = {
                "profile_version": 1,
                "created": datetime.datetime.now().isoformat(),
                "settings": all_config
            }
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(profile_data, f, indent=2, ensure_ascii=False)
            
            CTkMessageBox.info(self.settings_window, L.get("save_profile", "Save Profile"),
                              L.get("profile_saved", "Settings profile saved successfully!"))
        except (OSError, IOError, PermissionError, TypeError) as e:
            logger.error(f"Failed to save profile: {e}")
            CTkMessageBox.error(self.settings_window, L.get("err_title", "Error"),
                               f"Failed to save profile: {e}")
    
    def _load_settings_profile(self) -> None:
        """Load settings from a profile / Загрузить настройки из профиля / Завантажити налаштування з профілю"""
        from storage.config import Config
        import json
        import os
        from tkinter import filedialog
        
        L = LANGUAGES[self.current_lang]
        
        file_path = filedialog.askopenfilename(
            filetypes=[("Profile files", "*.json"), ("All files", "*.*")],
            title=L.get("load_profile", "Load Settings Profile")
        )
        
        if not file_path:
            return
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                profile_data = json.load(f)
            
            settings = profile_data.get("settings", {})
            
            # Apply settings / Применяем настройки / Застосовуємо налаштування
            for key, value in settings.items():
                self.config.set(key, value)
            
            # Reload UI / Перезагружаем UI / Перезавантажуємо UI
            self._load_all_settings()
            
            CTkMessageBox.info(self.settings_window, L.get("load_profile", "Load Profile"),
                              L.get("profile_loaded", "Settings profile loaded successfully!"))
        except (OSError, IOError, json.JSONDecodeError, KeyError, ValueError, TypeError) as e:
            logger.error(f"Failed to load profile: {e}")
            CTkMessageBox.error(self.settings_window, L.get("err_title", "Error"),
                               f"Failed to load profile: {e}")
    
    def _reset_settings_profile(self) -> None:
        """Reset settings to defaults / Сбросить настройки к значениям по умолчанию / Скинути налаштування до значень за замовчуванням"""
        L = LANGUAGES[self.current_lang]
        
        if CTkMessageBox.question(self.settings_window, L.get("reset_profile", "Reset"),
                                  L.get("reset_profile_confirm", "Reset all settings to defaults?")):
            self.config.reset_to_defaults()
            self._load_all_settings()
            CTkMessageBox.info(self.settings_window, L.get("reset_profile", "Reset"),
                              L.get("profile_reset", "Settings reset to defaults!"))

    def _apply_radius_smooth(self, new_radius: int):
        try:
            self.current_radius = new_radius
            set_global_radius(new_radius)
            
            menu_btns = [self.btn_gen, self.btn_copy, self.btn_save, self.btn_open, 
                         self.btn_qr, self.btn_hist, self.btn_db, self.btn_hibp, 
                         self.btn_upd, self.btn_settings, self.btn_about, self.btn_name_gen]
            for btn in menu_btns:
                if btn and btn.winfo_exists():
                    try:
                        btn.configure(corner_radius=new_radius)
                    except (tk.TclError, AttributeError, RuntimeError):
                        pass
            
            if self.btn_eye and self.btn_eye.winfo_exists():
                try:
                    self.btn_eye.configure(corner_radius=new_radius)
                except (tk.TclError, AttributeError, RuntimeError):
                    pass
            
            if self.entry_res and self.entry_res.winfo_exists():
                try:
                    self.entry_res.configure(corner_radius=new_radius)
                except (tk.TclError, AttributeError, RuntimeError):
                    pass
            
            for btn in self.category_buttons.values():
                if btn and btn.winfo_exists():
                    try:
                        btn.configure(corner_radius=new_radius)
                    except (tk.TclError, AttributeError, RuntimeError):
                        pass
            
            for btn in self.lang_buttons.values():
                if btn and btn.winfo_exists():
                    try:
                        btn.configure(corner_radius=new_radius)
                    except (tk.TclError, AttributeError, RuntimeError):
                        pass
            
            for btn in self.theme_buttons.values():
                if btn and btn.winfo_exists():
                    try:
                        btn.configure(corner_radius=new_radius)
                    except (tk.TclError, AttributeError, RuntimeError):
                        pass
            
            rgb_btns = [self._rgb_on_btn_ref, self._rgb_off_btn_ref,
                        self._rgb_speed_btn_slow, self._rgb_speed_btn_normal, self._rgb_speed_btn_fast,
                        self._rgb_width_btn_thin, self._rgb_width_btn_normal, self._rgb_width_btn_thick]
            for btn in rgb_btns:
                if btn and btn.winfo_exists():
                    try:
                        btn.configure(corner_radius=new_radius)
                    except (tk.TclError, AttributeError, RuntimeError):
                        pass
            
            other_btns = [self._master_set_btn, self._auto_lock_btn, self._sound_btn, 
                          self.auto_save_btn, self._close_btn, self._2fa_settings_btn,
                          self.save_profile_btn, self.load_profile_btn, self.reset_profile_btn]
            for btn in other_btns:
                if btn and btn.winfo_exists():
                    try:
                        btn.configure(corner_radius=new_radius)
                    except (tk.TclError, AttributeError, RuntimeError):
                        pass
            
            if self.pdf_theme_light_btn and self.pdf_theme_light_btn.winfo_exists():
                try:
                    self.pdf_theme_light_btn.configure(corner_radius=new_radius)
                except (tk.TclError, AttributeError, RuntimeError):
                    pass
            
            if self.pdf_theme_dark_btn and self.pdf_theme_dark_btn.winfo_exists():
                try:
                    self.pdf_theme_dark_btn.configure(corner_radius=new_radius)
                except (tk.TclError, AttributeError, RuntimeError):
                    pass
            
            self.config.set("RADIUS", new_radius)
            self.config.save()
            
        except (tk.TclError, AttributeError, OSError, TypeError, ValueError, RuntimeError) as e:
            logger.debug(f"Apply radius error: {e}")
    
    def _switch_category(self, category_key: str):
        actual_theme = self._get_actual_theme()
        is_dark = actual_theme == "dark"
        bg_card_hover = "#383838" if is_dark else "#f8f8f8"
        
        for key, frame in self.category_frames.items():
            try:
                frame.pack_forget()
            except (tk.TclError, RuntimeError):
                pass
        
        try:
            self.category_frames[category_key].pack(fill="both", expand=True)
        except (tk.TclError, RuntimeError):
            pass
        
        for key, btn in self.category_buttons.items():
            if key == category_key:
                btn.configure(fg_color=bg_card_hover)
            else:
                btn.configure(fg_color="transparent")
    
    def _add_settings_card(self, parent, title_key: str, description: str):
        L = LANGUAGES[self.current_lang]
        actual_theme = self._get_actual_theme()
        is_dark = actual_theme == "dark"
        
        if is_dark:
            bg_card = "#2d2d2d"
            text_primary = "#ffffff"
            text_secondary = "#a0a0a0"
            border_color = "#3d3d3d"
        else:
            bg_card = "#ffffff"
            text_primary = "#202020"
            text_secondary = "#606060"
            border_color = "#e0e0e0"
        
        card = ctk.CTkFrame(parent, fg_color=bg_card, corner_radius=12, border_width=1, border_color=border_color)
        card.pack(fill="x", pady=10)
        
        content = ctk.CTkFrame(card, fg_color="transparent")
        content.pack(fill="x", padx=20, pady=15)
        
        title_frame = ctk.CTkFrame(content, fg_color="transparent")
        title_frame.pack(fill="x")
        
        ctk.CTkLabel(title_frame, text=L.get(title_key, title_key), font=("Segoe UI", 16, "bold"), 
                    text_color=text_primary).pack(anchor="w")
        
        ctk.CTkLabel(content, text=description, font=("Segoe UI", 11), 
                    text_color=text_secondary).pack(anchor="w", pady=(5, 10))
        
        return content
    
    def _update_auto_lock_button(self):
        L = LANGUAGES[self.current_lang]
        if self.auto_lock_enabled.get():
            self._auto_lock_btn.configure(text=L["auto_lock"], fg_color="#2d6a4f")
        else:
            self._auto_lock_btn.configure(text=L["auto_lock"], fg_color="#8b0000")
    
    def _update_sound_button(self):
        L = LANGUAGES[self.current_lang]
        if self.sound_enabled.get():
            self._sound_btn.configure(text=L["sound_on"], fg_color="#2d6a4f")
        else:
            self._sound_btn.configure(text=L["sound_off"], fg_color="#8b0000")
    
    def _update_auto_save_button(self):
        L = LANGUAGES[self.current_lang]
        if self.auto_save_var.get():
            self.auto_save_btn.configure(text=L.get("auto_save_on", "On"), fg_color="#2d6a4f")
        else:
            self.auto_save_btn.configure(text=L.get("auto_save_off", "Off"), fg_color="#8b0000")
    
    def _update_clip_timeout_label(self):
        L = LANGUAGES[self.current_lang]
        self._clip_timeout_label_ref.configure(text=L["clip_timeout"].format(self.clipboard_timeout))
    
    def _refresh_settings_tabs_language(self) -> None:
        if not hasattr(self, 'category_buttons') or not self.category_buttons:
            return
            
        L = LANGUAGES[self.current_lang]
        
        categories = [
            ("design", "tab_design", L.get("tab_design", "Дизайн")),
            ("security", "tab_security", L.get("tab_security", "Безопасность")),
            ("general", "tab_general", L.get("tab_general", "Общие")),
        ]
        
        for key, lang_key, display_text in categories:
            if key in self.category_buttons:
                self.category_buttons[key].configure(text=display_text)
        
        self._update_auto_lock_button()
        self._update_sound_button()
        self._update_auto_save_button()
        self._update_clip_timeout_label()
        
        if hasattr(self, '_2fa_status_label') and self._2fa_status_label:
            try:
                self._2fa_status_label.configure(
                    text=self._get_2fa_status_text(),
                    text_color=self._get_2fa_status_color()
                )
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        if hasattr(self, '_2fa_settings_btn') and self._2fa_settings_btn:
            try:
                self._2fa_settings_btn.configure(text=L.get("2fa_settings_title", "2FA Settings"))
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        # Update search placeholder / Обновляем плейсхолдер поиска / Оновлюємо плейсхолдер пошуку
        if hasattr(self, '_search_entry') and self._search_entry:
            try:
                self._search_entry.configure(placeholder_text=" " + L.get("settings_search", "Search settings..."))
            except (tk.TclError, AttributeError, RuntimeError):
                pass
        
        for widget in self.settings_window.winfo_children():
            if isinstance(widget, ctk.CTkFrame):
                for child in widget.winfo_children():
                    if isinstance(child, ctk.CTkLabel):
                        try:
                            current_text = child.cget("text")
                            if current_text == "Настройки" or current_text == "Settings":
                                child.configure(text=L["settings_title"])
                            elif current_text == "Настройте приложение под свои потребности":
                                child.configure(text=L.get("settings_subtitle", "Configure the app to your needs"))
                        except (tk.TclError, AttributeError, RuntimeError):
                            pass
    
    def _add_separator(self, parent) -> None:
        pass
    
    def _close_settings(self) -> None:
        if self.settings_window:
            try:
                self.settings_window.grab_release()
                self.settings_window.destroy()
            except (tk.TclError, AttributeError, RuntimeError):
                pass
            self.settings_window = None
            self.category_buttons = {}
            self.category_frames = {}
            self._master_set_btn = None
            self._master_status_label = None
            self._sound_btn = None
            self._rgb_on_btn_ref = None
            self._rgb_off_btn_ref = None
            self._rgb_speed_btn_slow = None
            self._rgb_speed_btn_normal = None
            self._rgb_speed_btn_fast = None
            self._rgb_width_btn_thin = None
            self._rgb_width_btn_normal = None
            self._rgb_width_btn_thick = None
            self.pdf_theme_light_btn = None
            self.pdf_theme_dark_btn = None
            self.settings_radius_label = None
            self._clip_timeout_label_ref = None
            self._auto_lock_btn = None
            self._auto_lock_slider = None
            self._auto_lock_label_ref = None
            self._radius_slider = None
            self._clip_slider = None
            self._font_slider = None
            self._auto_lock_slider_ref = None
            self._close_btn = None
            self._radius_timer = None
            self._clip_timer = None
            self._auto_timer = None
            self._font_timer = None
            self._2fa_status_label = None
            self._2fa_settings_btn = None
            self._2fa_info_label = None
            self.save_profile_btn = None
            self.load_profile_btn = None
            self.reset_profile_btn = None
            self._search_entry = None