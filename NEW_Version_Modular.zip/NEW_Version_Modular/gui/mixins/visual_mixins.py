"""
Visual effects mixins grouped together
"""
from gui.mixins.rgb_mixin import RGBMixin
from gui.mixins.updater_mixin import UpdaterMixin

__all__ = [
    'RGBMixin',
    'UpdaterMixin'
]
