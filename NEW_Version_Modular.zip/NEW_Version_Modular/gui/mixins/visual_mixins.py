"""
Visual effects mixins for SecurePassPro (RGBMixin, UpdaterMixin)
"""
import tkinter as tk
import math
import ctypes
from utils.helpers import is_windows
from utils.logger import get_logger

logger = get_logger("visual_mixins")


class RGBMixin:
    """Mixin class for RGB border animation and titlebar coloring"""
    
    # Скорость анимации (задержка между кадрами в мс)
    RGB_SPEEDS = {
        "slow": 50,
        "normal": 30,
        "fast": 15,
    }
    
    # Толщина RGB подсветки в пикселях
    RGB_WIDTHS = {
        "thin": 1,
        "normal": 3,
        "thick": 5,
    }
    
    def _create_rgb_canvases(self) -> None:
        """Создаёт canvas для всех 4 сторон с начальной толщиной 3px"""
        try:
            self._rgb_c_top = tk.Canvas(self, height=3, bg="#1d1e1e", highlightthickness=0)
            self._rgb_c_bottom = tk.Canvas(self, height=3, bg="#1d1e1e", highlightthickness=0)
            self._rgb_c_left = tk.Canvas(self, width=3, bg="#1d1e1e", highlightthickness=0)
            self._rgb_c_right = tk.Canvas(self, width=3, bg="#1d1e1e", highlightthickness=0)
            for c in (self._rgb_c_top, self._rgb_c_bottom, self._rgb_c_left, self._rgb_c_right):
                c.place_forget()
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Create RGB canvases error: {e}")
    
    def _update_rgb_width(self) -> None:
        """Обновить толщину RGB подсветки"""
        width_setting = getattr(self, 'rgb_width_setting', 'normal')
        width = self.RGB_WIDTHS.get(width_setting, 3)
        
        try:
            if self._rgb_c_top:
                self._rgb_c_top.configure(height=width)
            if self._rgb_c_bottom:
                self._rgb_c_bottom.configure(height=width)
            if self._rgb_c_left:
                self._rgb_c_left.configure(width=width)
            if self._rgb_c_right:
                self._rgb_c_right.configure(width=width)
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Update RGB width error: {e}")
    
    def _rgb_color(self, phase_offset: float) -> str:
        f = self._rgb_t + phase_offset
        r = int((math.sin(f) + 1) / 2 * 255)
        g = int((math.sin(f + 2.1) + 1) / 2 * 255)
        b = int((math.sin(f + 4.2) + 1) / 2 * 255)
        return f"#{r:02x}{g:02x}{b:02x}"
    
    def _set_titlebar_color(self, hex_color: str) -> None:
        if not is_windows():
            return
        try:
            h = hex_color.lstrip("#")
            r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
            colorref = r | (g << 8) | (b << 16)
            hwnd = ctypes.windll.user32.GetParent(self.winfo_id())
            DWMWA_CAPTION_COLOR = 35
            ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, DWMWA_CAPTION_COLOR, 
                ctypes.byref(ctypes.c_int(colorref)), 
                ctypes.sizeof(ctypes.c_int(colorref))
            )
        except (AttributeError, OSError, TypeError, ValueError) as e:
            logger.debug(f"Titlebar color error: {e}")
        except RuntimeError as e:
            logger.debug(f"Titlebar color runtime error: {e}")
    
    def _reset_titlebar_color(self) -> None:
        if not is_windows():
            return
        try:
            hwnd = ctypes.windll.user32.GetParent(self.winfo_id())
            DWMWA_CAPTION_COLOR = 35
            DWMWA_COLOR_DEFAULT = 0xFFFFFFFF
            ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, DWMWA_CAPTION_COLOR, 
                ctypes.byref(ctypes.c_int(DWMWA_COLOR_DEFAULT)), 
                ctypes.sizeof(ctypes.c_int(DWMWA_COLOR_DEFAULT))
            )
        except (AttributeError, OSError, TypeError, ValueError) as e:
            logger.debug(f"Titlebar reset error: {e}")
    
    def _get_rgb_speed(self) -> int:
        speed_setting = getattr(self, 'rgb_speed_setting', 'normal')
        return self.RGB_SPEEDS.get(speed_setting, 30)
    
    def _animate_rgb(self) -> None:
        if not self.rgb_enabled.get():
            return
        try:
            if self._rgb_c_top:
                self._rgb_c_top.configure(bg=self._rgb_color(0.0))
            if self._rgb_c_right:
                self._rgb_c_right.configure(bg=self._rgb_color(0.8))
            if self._rgb_c_bottom:
                self._rgb_c_bottom.configure(bg=self._rgb_color(1.6))
            if self._rgb_c_left:
                self._rgb_c_left.configure(bg=self._rgb_color(2.4))
            self._set_titlebar_color(self._rgb_color(3.2))
            self._rgb_t = (self._rgb_t + 0.08) % (2 * math.pi)
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"RGB animation frame error: {e}")
            return
        
        if self._rgb_anim_id:
            try:
                self.after_cancel(self._rgb_anim_id)
            except (tk.TclError, ValueError) as e:
                logger.debug(f"Cancel animation error: {e}")
        
        speed = self._get_rgb_speed()
        self._rgb_anim_id = self.after(speed, self._animate_rgb)
    
    def _start_rgb(self) -> None:
        """Запустить RGB анимацию"""
        try:
            self._update_rgb_width()
            
            if self._rgb_c_top:
                self._rgb_c_top.place(relx=0, rely=0, relwidth=1)
                self._rgb_c_bottom.place(relx=0, rely=1, anchor="sw", relwidth=1)
                self._rgb_c_left.place(relx=0, rely=0, relheight=1)
                self._rgb_c_right.place(relx=1, rely=0, anchor="ne", relheight=1)
            if not self._rgb_anim_id:
                self._animate_rgb()
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Start RGB error: {e}")
    
    def _stop_rgb(self) -> None:
        """Остановить RGB анимацию"""
        if self._rgb_anim_id:
            try:
                self.after_cancel(self._rgb_anim_id)
            except (tk.TclError, ValueError) as e:
                logger.debug(f"Cancel RGB animation error: {e}")
            self._rgb_anim_id = None
        try:
            for c in (self._rgb_c_top, self._rgb_c_bottom, self._rgb_c_left, self._rgb_c_right):
                if c:
                    c.place_forget()
            self._reset_titlebar_color()
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Stop RGB cleanup error: {e}")
    
    def _set_rgb(self, state: bool) -> None:
        """Включить/выключить RGB подсветку"""
        if self.rgb_enabled.get() == state:
            return
        self.rgb_enabled.set(state)
        if state:
            self._start_rgb()
        else:
            self._stop_rgb()
        self._update_rgb_buttons()
        try:
            self.config.set("RGB", state)
        except (KeyError, ValueError, OSError) as e:
            logger.debug(f"Save RGB setting error: {e}")
    
    def _set_rgb_speed(self, speed: str) -> None:
        """Установить скорость RGB анимации"""
        if speed not in self.RGB_SPEEDS:
            return
        self.rgb_speed_setting = speed
        rgb_was_on = self.rgb_enabled.get()
        if rgb_was_on:
            self._stop_rgb()
            self._start_rgb()
        try:
            self.config.set("RGB_SPEED", speed)
        except (KeyError, ValueError, OSError) as e:
            logger.debug(f"Save RGB speed error: {e}")
        self._update_rgb_speed_buttons()
    
    def _set_rgb_width(self, width: str) -> None:
        """Установить толщину RGB подсветки"""
        if width not in self.RGB_WIDTHS:
            return
        self.rgb_width_setting = width
        self._update_rgb_width()
        if self.rgb_enabled.get():
            self._stop_rgb()
            self._start_rgb()
        try:
            self.config.set("RGB_WIDTH", width)
        except (KeyError, ValueError, OSError) as e:
            logger.debug(f"Save RGB width error: {e}")
        self._update_rgb_width_buttons()
    
    def _update_rgb_speed_buttons(self) -> None:
        """Обновить состояние кнопок скорости RGB"""
        current_speed = getattr(self, 'rgb_speed_setting', 'normal')
        try:
            if hasattr(self, '_rgb_speed_btn_slow') and self._rgb_speed_btn_slow:
                self._rgb_speed_btn_slow.configure(
                    fg_color="#2d6a4f" if current_speed == "slow" else "#4b4b4b"
                )
            if hasattr(self, '_rgb_speed_btn_normal') and self._rgb_speed_btn_normal:
                self._rgb_speed_btn_normal.configure(
                    fg_color="#2d6a4f" if current_speed == "normal" else "#4b4b4b"
                )
            if hasattr(self, '_rgb_speed_btn_fast') and self._rgb_speed_btn_fast:
                self._rgb_speed_btn_fast.configure(
                    fg_color="#2d6a4f" if current_speed == "fast" else "#4b4b4b"
                )
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Speed button update error: {e}")
    
    def _update_rgb_width_buttons(self) -> None:
        """Обновить состояние кнопок толщины RGB"""
        current_width = getattr(self, 'rgb_width_setting', 'normal')
        try:
            if hasattr(self, '_rgb_width_btn_thin') and self._rgb_width_btn_thin:
                self._rgb_width_btn_thin.configure(
                    fg_color="#2d6a4f" if current_width == "thin" else "#4b4b4b"
                )
            if hasattr(self, '_rgb_width_btn_normal') and self._rgb_width_btn_normal:
                self._rgb_width_btn_normal.configure(
                    fg_color="#2d6a4f" if current_width == "normal" else "#4b4b4b"
                )
            if hasattr(self, '_rgb_width_btn_thick') and self._rgb_width_btn_thick:
                self._rgb_width_btn_thick.configure(
                    fg_color="#2d6a4f" if current_width == "thick" else "#4b4b4b"
                )
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Width button update error: {e}")
    
    def _update_rgb_buttons(self) -> None:
        """Обновить состояние кнопок Вкл/Выкл RGB подсветки"""
        is_on = self.rgb_enabled.get()
        try:
            if self._rgb_on_btn_ref and self._rgb_on_btn_ref.winfo_exists():
                self._rgb_on_btn_ref.configure(fg_color="#2d6a4f" if is_on else "#4b4b4b")
            if self._rgb_off_btn_ref and self._rgb_off_btn_ref.winfo_exists():
                self._rgb_off_btn_ref.configure(fg_color="#8b0000" if not is_on else "#4b4b4b")
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"RGB button update error: {e}")


class UpdaterMixin:
    """Mixin class for update checking functionality"""
    
    def _check_for_updates(self) -> None:
        """Проверить наличие обновлений (асинхронно)"""
        import threading
        
        L = LANGUAGES[self.current_lang]
        
        if hasattr(self, 'btn_upd') and self.btn_upd:
            old_text = self.btn_upd.cget("text")
            self.btn_upd.configure(state="disabled", text=L.get("hibp_checking", "Проверка..."))
        
        def _worker():
            try:
                from utils.updater import check_for_updates
                release = check_for_updates(self)
                self.after(0, lambda: self._on_update_check_result(release))
            except (ImportError, AttributeError, OSError) as e:
                logger.error(f"Update check error: {e}")
                self.after(0, lambda: self._on_update_check_result(None))
            except RuntimeError as e:
                logger.error(f"Update check runtime error: {e}")
            finally:
                self.after(0, self._restore_update_button)
        
        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()
    
    def _on_update_check_result(self, release) -> None:
        """Обработать результат проверки обновлений"""
        from gui.dialogs import CTkMessageBox
        L = LANGUAGES[self.current_lang]
        
        if release is None:
            CTkMessageBox.info(
                self,
                L.get("update_check", "Проверка обновлений"),
                L.get("update_not_available", "Нет доступных обновлений.\n\nУ вас установлена последняя версия.")
            )
        else:
            message = L.get("update_available", "Доступна новая версия {0}").format(release.version)
            if CTkMessageBox.question(
                self,
                L.get("update_available_title", "Доступно обновление"),
                message + "\n\nУстановить сейчас?"
            ):
                self._perform_update()
    
    def _restore_update_button(self) -> None:
        """Восстановить кнопку обновления"""
        L = LANGUAGES[self.current_lang]
        if hasattr(self, 'btn_upd') and self.btn_upd:
            self.btn_upd.configure(state="normal", text=L.get("btn_upd", "🔄 Обновить программу"))
    
    def _perform_update(self) -> None:
        """Выполнить обновление программы"""
        import threading
        from utils.updater import perform_update
        from gui.dialogs import CTkMessageBox
        
        L = LANGUAGES[self.current_lang]
        
        if hasattr(self, 'btn_upd') and self.btn_upd:
            self.btn_upd.configure(state="disabled", text=L.get("please_wait", "Пожалуйста, подождите..."))
        
        def _worker():
            try:
                success = perform_update(self)
                
                if not success:
                    self.after(0, lambda: CTkMessageBox.error(
                        self,
                        L.get("err_title", "Ошибка"),
                        L.get("update_error", "Не удалось установить обновление.")
                    ))
            except (ImportError, AttributeError, OSError, ValueError) as e:
                logger.error(f"Update error: {e}")
                self.after(0, lambda: CTkMessageBox.error(
                    self,
                    L.get("err_title", "Ошибка"),
                    f"Не удалось установить обновление: {e}"
                ))
            except RuntimeError as e:
                logger.error(f"Update runtime error: {e}")
            finally:
                self.after(0, self._restore_update_button)
        
        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()


# Для импорта LANGUAGES в UpdaterMixin
from localization.lang import LANGUAGES