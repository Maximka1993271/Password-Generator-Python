# gui/mixins/name_generator_mixin.py
"""
Name Generator Mixin for SecurePassPro - Optimized UI Version
"""
import random
import time
import tkinter as tk
import customtkinter as ctk
from utils.helpers import play_sound
from utils.logger import get_logger
from localization.lang import LANGUAGES

logger = get_logger("name_generator")

# БАЗА ДАННЫХ
RUSSIAN_NAMES_MALE = [
    "Александр", "Дмитрий", "Максим", "Сергей", "Андрей", "Алексей", "Владимир", "Николай",
    "Иван", "Михаил", "Евгений", "Павел", "Артём", "Даниил", "Илья", "Кирилл", "Тимофей"
]
RUSSIAN_NAMES_FEMALE = [
    "Анна", "Мария", "Елена", "Ольга", "Татьяна", "Наталья", "Ирина", "Светлана", "Екатерина",
    "Юлия", "Анастасия", "Дарья", "Алина", "Виктория", "Ксения", "Полина", "Валерия"
]
RUSSIAN_LASTNAMES = [
    "Иванов", "Петров", "Сидоров", "Кузнецов", "Соколов", "Попов", "Лебедев", "Козлов",
    "Новиков", "Морозов", "Волков", "Соловьёв", "Васильев", "Зайцев", "Павлов", "Семёнов"
]

ENGLISH_NAMES_MALE = [
    "James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Thomas",
    "Charles", "Christopher", "Daniel", "Matthew", "Anthony", "Donald", "Mark", "Paul"
]
ENGLISH_NAMES_FEMALE = [
    "Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica",
    "Sarah", "Karen", "Nancy", "Margaret", "Lisa", "Betty", "Dorothy", "Sandra"
]
ENGLISH_LASTNAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez",
    "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor"
]

GAME_WORDS = ["Killer", "Slayer", "Hunter", "Warrior", "Knight", "Lord", "King", "Queen",
              "Beast", "Demon", "Angel", "Ghost", "Shadow", "Night", "Dark", "Light",
              "Storm", "Dragon", "Tiger", "Wolf", "Hawk", "Phoenix", "Legend", "Master"]

COOL_PREFIXES = ["Xx", "xX", "Ultra", "Mega", "Super", "Pro", "Elite", "Master", "Legend",
                 "Dark", "Shadow", "Night", "Ghost", "Phantom", "Frost", "Flame", "Storm"]

BEAUTY_WORDS = ["Luna", "Stella", "Aurora", "Iris", "Lily", "Rose", "Violet", "Summer", 
                "Autumn", "Winter", "Spring", "Snow", "Rain", "Sky", "Ocean", "Forest"]

SHORT_NAMES = ["Max", "Alex", "Sam", "Tom", "Bob", "Jim", "Leo", "Ian", "Eva", "Ann", "Jay", "Ray"]

LONG_NAMES = ["Alexander", "Maximilian", "Christopher", "Benjamin", "Jonathan", "Nathaniel",
              "Sebastian", "Theodore", "Elizabeth", "Victoria", "Alexandra", "Katherine"]

NUMBERS = [str(i) for i in range(1, 100)]
EMAIL_DOMAINS = ["@gmail.com", "@outlook.com", "@hotmail.com", "@yahoo.com", "@protonmail.com", "@icloud.com"]


class NameGeneratorMixin:
    
    def _open_name_generator(self):
        if hasattr(self, '_name_window') and self._name_window and self._name_window.winfo_exists():
            self._name_window.lift()
            self._name_window.focus()
            return
        
        L = LANGUAGES[self.current_lang]
        
        self._name_window = ctk.CTkToplevel(self)
        self._name_window.title(L.get("name_gen_title", "Генератор имён"))
        self._name_window.geometry("950x920")
        self._name_window.minsize(900, 880)
        self._name_window.resizable(True, True)
        self._center_window_relative_to_parent(self._name_window, 950, 920)
        self._name_window.transient(self)
        self._name_window.grab_set()
        
        radius = getattr(self, 'current_radius', 25)
        
        # Основной фрейм
        main_frame = ctk.CTkFrame(self._name_window, fg_color="transparent")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=25, pady=25)
        
        # ==================== ВЕРХНЯЯ ЧАСТЬ (СКРОЛЛ) ====================
        scroll_frame = ctk.CTkScrollableFrame(main_frame, fg_color="transparent")
        scroll_frame.pack(fill=tk.BOTH, expand=True)
        
        # ==================== ЗАГОЛОВОК ====================
        title_frame = ctk.CTkFrame(scroll_frame, fg_color="transparent")
        title_frame.pack(fill=tk.X, pady=(0, 10))
        
        title = ctk.CTkLabel(
            title_frame, 
            text=L.get("name_gen_title", "Генератор имён"), 
            font=ctk.CTkFont(size=28, weight="bold")
        )
        title.pack(anchor=tk.CENTER)
        
        # Декоративная линия
        line_frame = ctk.CTkFrame(scroll_frame, height=3, fg_color="#4EC9B0", corner_radius=5)
        line_frame.pack(fill=tk.X, pady=(0, 20))
        
        # ==================== ТИП ГЕНЕРАЦИИ С НЕОНОВОЙ РАМКОЙ ====================
        type_neon_frame = ctk.CTkFrame(scroll_frame, corner_radius=radius, border_width=3, border_color="#4EC9B0")
        type_neon_frame.pack(fill=tk.X, pady=8)
        
        type_frame = ctk.CTkFrame(type_neon_frame, corner_radius=radius-2, fg_color=("#F8F9FA", "#2d2d3d"))
        type_frame.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        
        ctk.CTkLabel(
            type_frame, 
            text=L.get("name_gen_type_label", "Тип генерации"), 
            font=ctk.CTkFont(size=17, weight="bold")
        ).pack(anchor=tk.CENTER, pady=(15, 5))
        
        # Сетка для типов генерации (структурировано вместо кучи внутренних фреймов)
        types_grid = ctk.CTkFrame(type_frame, fg_color="transparent")
        types_grid.pack(pady=(5, 15), padx=25, fill=tk.X)
        for i in range(4):
            types_grid.columnconfigure(i, weight=1)
        
        self.gen_type = tk.StringVar(value="samp")
        
        all_types = [
            ("samp", L.get("name_gen_samp", "SAMP RP"), 0, 0),
            ("email", L.get("name_gen_email", "Email адрес"), 0, 1),
            ("game", L.get("name_gen_game", "Игровой ник"), 0, 2),
            ("cool", L.get("name_gen_cool", "Крутой ник"), 0, 3),
            ("beauty", L.get("name_gen_beauty", "Красивый ник"), 1, 0),
            ("short", L.get("name_gen_short", "Короткий (3-5)"), 1, 1),
            ("long", L.get("name_gen_long", "Длинный (8+)"), 1, 2),
            ("random", L.get("name_gen_random", "Случайный"), 1, 3),
        ]
        
        for val, text, row, col in all_types:
            rb = ctk.CTkRadioButton(types_grid, text=text, variable=self.gen_type, value=val, font=ctk.CTkFont(size=13))
            rb.grid(row=row, column=col, padx=15, pady=10, sticky="w")
        
        # ==================== НАСТРОЙКИ С НЕОНОВОЙ РАМКОЙ ====================
        settings_neon_frame = ctk.CTkFrame(scroll_frame, corner_radius=radius, border_width=3, border_color="#4EC9B0")
        settings_neon_frame.pack(fill=tk.X, pady=15)
        
        settings_frame = ctk.CTkFrame(settings_neon_frame, corner_radius=radius-2, fg_color=("#F8F9FA", "#2d2d3d"))
        settings_frame.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        
        ctk.CTkLabel(
            settings_frame, 
            text=L.get("name_gen_settings_label", "Настройки"), 
            font=ctk.CTkFont(size=17, weight="bold")
        ).pack(anchor=tk.CENTER, pady=(15, 5))
        
        settings_grid = ctk.CTkFrame(settings_frame, fg_color="transparent")
        settings_grid.pack(pady=(5, 15), padx=25, fill=tk.X)
        settings_grid.columnconfigure((0, 1), weight=1)
        
        # Колонка 1 (Пол и Язык)
        col1 = ctk.CTkFrame(settings_grid, fg_color="transparent")
        col1.grid(row=0, column=0, sticky="nsew", padx=(0, 20))
        
        # Пол
        gender_container = ctk.CTkFrame(col1, fg_color="transparent")
        gender_container.pack(fill=tk.X, pady=8)
        ctk.CTkLabel(gender_container, text=L.get("name_gen_gender", "Пол:"), font=ctk.CTkFont(size=14, weight="bold"), width=90, anchor="w").pack(side=tk.LEFT)
        
        self.gen_gender = tk.StringVar(value="random")
        gender_buttons = ctk.CTkFrame(gender_container, fg_color="transparent")
        gender_buttons.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ctk.CTkRadioButton(gender_buttons, text=L.get("name_gen_male", "Мужской"), variable=self.gen_gender, value="male", font=ctk.CTkFont(size=13)).pack(side=tk.LEFT, padx=(0, 15))
        ctk.CTkRadioButton(gender_buttons, text=L.get("name_gen_female", "Женский"), variable=self.gen_gender, value="female", font=ctk.CTkFont(size=13)).pack(side=tk.LEFT, padx=15)
        ctk.CTkRadioButton(gender_buttons, text=L.get("name_gen_random_gender", "Случайный"), variable=self.gen_gender, value="random", font=ctk.CTkFont(size=13)).pack(side=tk.LEFT, padx=15)
        
        # Язык
        lang_container = ctk.CTkFrame(col1, fg_color="transparent")
        lang_container.pack(fill=tk.X, pady=8)
        ctk.CTkLabel(lang_container, text=L.get("name_gen_lang", "Язык:"), font=ctk.CTkFont(size=14, weight="bold"), width=90, anchor="w").pack(side=tk.LEFT)
        
        self.gen_lang = tk.StringVar(value="russian")
        lang_buttons = ctk.CTkFrame(lang_container, fg_color="transparent")
        lang_buttons.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ctk.CTkRadioButton(lang_buttons, text=L.get("name_gen_russian", "Русский"), variable=self.gen_lang, value="russian", font=ctk.CTkFont(size=13)).pack(side=tk.LEFT, padx=(0, 15))
        ctk.CTkRadioButton(lang_buttons, text=L.get("name_gen_english", "English"), variable=self.gen_lang, value="english", font=ctk.CTkFont(size=13)).pack(side=tk.LEFT, padx=15)
        
        # Колонка 2 (Разделитель и Количество)
        col2 = ctk.CTkFrame(settings_grid, fg_color="transparent")
        col2.grid(row=0, column=1, sticky="nsew", padx=(20, 0))
        
        # Разделитель
        sep_container = ctk.CTkFrame(col2, fg_color="transparent")
        sep_container.pack(fill=tk.X, pady=8)
        ctk.CTkLabel(sep_container, text=L.get("name_gen_separator", "Разделитель:"), font=ctk.CTkFont(size=14, weight="bold"), width=110, anchor="w").pack(side=tk.LEFT)
        
        self.gen_separator_value = tk.StringVar(value="_")
        sep_values = [L.get("name_gen_separator_yes", "ДА (_)"), L.get("name_gen_separator_no", "НЕТ")]
        
        self.sep_menu = ctk.CTkOptionMenu(
            sep_container,
            values=sep_values,
            width=140,
            font=ctk.CTkFont(size=13),
            corner_radius=radius,
            command=self._on_separator_change
        )
        self.sep_menu.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.sep_menu.set(sep_values[0])
        
        # Количество
        count_container = ctk.CTkFrame(col2, fg_color="transparent")
        count_container.pack(fill=tk.X, pady=8)
        ctk.CTkLabel(count_container, text=L.get("name_gen_count", "Количество:"), font=ctk.CTkFont(size=14, weight="bold"), width=110, anchor="w").pack(side=tk.LEFT)
        
        self.gen_count = tk.StringVar(value="1")
        count_menu = ctk.CTkOptionMenu(
            count_container, 
            values=["1", "2", "3", "4", "5", "10"], 
            variable=self.gen_count, 
            width=140, 
            font=ctk.CTkFont(size=13),
            corner_radius=radius
        )
        count_menu.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # ==================== ПОЛЕ РЕЗУЛЬТАТА С НЕОНОВОЙ РАМКОЙ ====================
        result_neon_frame = ctk.CTkFrame(scroll_frame, corner_radius=radius, border_width=3, border_color="#4EC9B0")
        result_neon_frame.pack(fill=tk.BOTH, expand=True, pady=15)
        
        result_frame = ctk.CTkFrame(result_neon_frame, corner_radius=radius-2, fg_color=("#F8F9FA", "#2d2d3d"))
        result_frame.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        
        ctk.CTkLabel(
            result_frame, 
            text=L.get("name_gen_result_label", "Результат"), 
            font=ctk.CTkFont(size=17, weight="bold")
        ).pack(anchor=tk.CENTER, pady=(15, 8))
        
        self.result_text = ctk.CTkTextbox(
            result_frame, 
            height=280, 
            font=ctk.CTkFont(family="Consolas", size=15), 
            corner_radius=radius-4,
            border_spacing=12,
            fg_color=("#FFFFFF", "#1a1a2e")
        )
        self.result_text.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))
        
        # ==================== КНОПКИ УПРАВЛЕНИЯ (ВНИЗУ, НЕ В СКРОЛЛЕ) ====================
        controls = ctk.CTkFrame(main_frame, fg_color="transparent")
        controls.pack(fill=tk.X, pady=(10, 0))
        
        self.gen_btn = ctk.CTkButton(
            controls, 
            text=L.get("name_gen_generate_btn", "Сгенерировать"), 
            fg_color="#00C853", 
            hover_color="#00E676",
            height=52, 
            font=ctk.CTkFont(size=16, weight="bold"), 
            corner_radius=radius, 
            command=self._generate_name
        )
        self.gen_btn.pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)
        
        self.clear_btn = ctk.CTkButton(
            controls, 
            text=L.get("name_gen_clear_btn", "Очистить"), 
            fg_color="#FF9800", 
            hover_color="#FFB74D",
            height=52, 
            font=ctk.CTkFont(size=16), 
            corner_radius=radius, 
            command=self._clear_result
        )
        self.clear_btn.pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)
        
        self.copy_btn = ctk.CTkButton(
            controls, 
            text=L.get("name_gen_copy_btn", "Копировать всё"), 
            fg_color="#2196F3", 
            hover_color="#64B5F6",
            height=52, 
            font=ctk.CTkFont(size=16), 
            corner_radius=radius, 
            command=self._copy_all
        )
        self.copy_btn.pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)
        
        self.close_btn = ctk.CTkButton(
            controls, 
            text=L.get("close", "Закрыть"), 
            fg_color="#607D8B", 
            hover_color="#90A4AE",
            height=52, 
            font=ctk.CTkFont(size=16), 
            corner_radius=radius, 
            command=self._close_window
        )
        self.close_btn.pack(side=tk.RIGHT, padx=10)
        
        # Анимация неоновых рамок
        self._neon_frames = [type_neon_frame, settings_neon_frame, result_neon_frame]
        self._neon_active = True
        self._animate_neon_border()
        
        # Сохраняем ссылки для радиус-менеджера
        self._name_window_buttons = [self.gen_btn, self.clear_btn, self.copy_btn, self.close_btn]
        self._name_window_textbox = self.result_text
        
        from utils.radius_manager import register_window
        register_window(self._name_window)
        
        self._name_window.protocol("WM_DELETE_WINDOW", self._close_window)
    
    def _animate_neon_border(self, step=0):
        if not hasattr(self, '_name_window') or not self._name_window or not self._name_window.winfo_exists():
            return
        
        colors = ["#4EC9B0", "#00C853", "#00E676", "#4EC9B0", "#00BFA5", "#4EC9B0"]
        next_color = colors[step % len(colors)]
        
        try:
            for frame in self._neon_frames:
                if frame and frame.winfo_exists():
                    frame.configure(border_color=next_color)
        except:
            pass
        
        if hasattr(self, '_neon_active') and self._neon_active:
            self._name_window.after(600, lambda: self._animate_neon_border(step + 1))
    
    def _on_separator_change(self, choice):
        L = LANGUAGES[self.current_lang]
        yes_text = L.get("name_gen_separator_yes", "ДА (_)")
        if choice == yes_text:
            self.gen_separator_value.set("_")
        else:
            self.gen_separator_value.set("")
    
    def _update_name_window_radius(self, radius: int):
        if hasattr(self, '_name_window') and self._name_window and self._name_window.winfo_exists():
            try:
                for btn in self._name_window_buttons:
                    if btn and btn.winfo_exists():
                        btn.configure(corner_radius=radius)
                if self._name_window_textbox and self._name_window_textbox.winfo_exists():
                    self._name_window_textbox.configure(corner_radius=radius)
                for frame in self._neon_frames:
                    if frame and frame.winfo_exists():
                        frame.configure(corner_radius=radius)
                if hasattr(self, 'sep_menu') and self.sep_menu:
                    self.sep_menu.configure(corner_radius=radius)
            except Exception as e:
                logger.debug(f"Error updating name window radius: {e}")
    
    def _close_window(self):
        self._neon_active = False
        if hasattr(self, '_name_window') and self._name_window:
            from utils.radius_manager import unregister_window
            unregister_window(self._name_window)
            self._name_window.grab_release()
            self._name_window.destroy()
            self._name_window = None
            self._name_window_buttons = []
            self._name_window_textbox = None
            self._neon_frames = []
    
    def _clear_result(self):
        self.result_text.delete("1.0", tk.END)
    
    def _copy_all(self):
        text = self.result_text.get("1.0", tk.END).strip()
        if text:
            self.clipboard_clear()
            self.clipboard_append(text)
            play_sound("copy", self.sound_enabled.get())
    
    def _get_name_data(self):
        lang = self.gen_lang.get()
        gender = self.gen_gender.get()
        if gender == "random":
            gender = random.choice(["male", "female"])
        if lang == "russian":
            first = RUSSIAN_NAMES_MALE if gender == "male" else RUSSIAN_NAMES_FEMALE
            last = RUSSIAN_LASTNAMES
        else:
            first = ENGLISH_NAMES_MALE if gender == "male" else ENGLISH_NAMES_FEMALE
            last = ENGLISH_LASTNAMES
        return random.choice(first), random.choice(last)
    
    def _generate_samp(self):
        first, last = self._get_name_data()
        sep = self.gen_separator_value.get()
        if sep == "":
            return f"{first} {last}"
        return f"{first}_{last}"
    
    def _generate_email(self):
        first, last = self._get_name_data()
        sep = self.gen_separator_value.get()
        lang = self.gen_lang.get()
        
        email_sep = sep if sep != "" else "."
        
        if lang == "russian":
            translit = {'а':'a','б':'b','в':'v','г':'g','д':'d','е':'e','ё':'e','ж':'zh','з':'z',
                       'и':'i','й':'y','к':'k','л':'l','м':'m','н':'n','о':'o','п':'p','р':'r',
                       'с':'s','т':'t','у':'u','ф':'f','х':'h','ц':'ts','ч':'ch','ш':'sh','щ':'sch',
                       'ъ':'','ы':'y','ь':'','э':'e','ю':'yu','я':'ya'}
            first = ''.join(translit.get(c, c) for c in first.lower())
            last = ''.join(translit.get(c, c) for c in last.lower())
        else:
            first = first.lower()
            last = last.lower()
        num = random.choice(NUMBERS)
        username = f"{first}{email_sep}{last}{num}"
        domain = random.choice(EMAIL_DOMAINS)
        return f"{username}{domain}"
    
    def _generate_game(self):
        word1 = random.choice(GAME_WORDS)
        word2 = random.choice(GAME_WORDS) if random.choice([True, False]) else ""
        sep = self.gen_separator_value.get()
        game_sep = sep if sep != "" else "_"
        name = f"{word1}{game_sep}{word2}" if word2 else word1
        if random.choice([True, False]):
            name += random.choice(NUMBERS)
        prefix = random.choice(["", "xX_", "Xx_"])
        suffix = random.choice(["", "_xX", "_Xx"])
        return f"{prefix}{name}{suffix}"
    
    def _generate_cool(self):
        prefix = random.choice(COOL_PREFIXES)
        word = random.choice(GAME_WORDS)
        sep = self.gen_separator_value.get()
        cool_sep = sep if sep != "" else "_"
        name = f"{prefix}{cool_sep}{word}"
        if random.choice([True, False]):
            name += random.choice(NUMBERS)
        return name
    
    def _generate_beauty(self):
        word = random.choice(BEAUTY_WORDS)
        if random.choice([True, False]):
            word += random.choice(NUMBERS[:50])
        return word
    
    def _generate_short(self):
        name = random.choice(SHORT_NAMES)
        if random.choice([True, False]):
            name += random.choice(NUMBERS[:9])
        return name
    
    def _generate_long(self):
        name = random.choice(LONG_NAMES)
        if random.choice([True, False]):
            name += random.choice(NUMBERS)
        return name
    
    def _generate_random(self):
        types = ["samp", "email", "game", "cool", "beauty", "short", "long"]
        funcs = {
            "samp": self._generate_samp,
            "email": self._generate_email,
            "game": self._generate_game,
            "cool": self._generate_cool,
            "beauty": self._generate_beauty,
            "short": self._generate_short,
            "long": self._generate_long
        }
        t = random.choice(types)
        return funcs[t]()
    
    def _generate_name(self):
        gen_type = self.gen_type.get()
        count = int(self.gen_count.get())
        
        self.result_text.delete("1.0", tk.END)
        
        for _ in range(count):
            if gen_type == "samp":
                name = self._generate_samp()
            elif gen_type == "email":
                name = self._generate_email()
            elif gen_type == "game":
                name = self._generate_game()
            elif gen_type == "cool":
                name = self._generate_cool()
            elif gen_type == "beauty":
                name = self._generate_beauty()
            elif gen_type == "short":
                name = self._generate_short()
            elif gen_type == "long":
                name = self._generate_long()
            elif gen_type == "random":
                name = self._generate_random()
            else:
                name = self._generate_samp()
            
            if count == 1:
                self.result_text.insert(tk.END, f"{name}")
            else:
                self.result_text.insert(tk.END, f"{name}\n")
        
        self.result_text.see(tk.END)
        play_sound("generate", self.sound_enabled.get())