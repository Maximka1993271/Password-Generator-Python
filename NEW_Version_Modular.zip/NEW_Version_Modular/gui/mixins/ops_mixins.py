"""
Operation-related mixins grouped together

Миксины, связанные с операциями, сгруппированные вместе
Міксини, пов'язані з операціями, згруповані разом
"""
from gui.mixins.password_ops_mixin import PasswordOpsMixin
from gui.mixins.name_generator_mixin import NameGeneratorMixin

__all__ = [
    'PasswordOpsMixin',
    'NameGeneratorMixin'
]