"""
Custom dialog windows (MessageBox, InputDialog) with proper centering
Кастомные диалоговые окна (MessageBox, InputDialog) с правильным центрированием
Кастомні діалогові вікна (MessageBox, InputDialog) з правильним центруванням
"""
import tkinter as tk
import customtkinter as ctk
import webbrowser
from localization.lang import LANGUAGES
from utils.helpers import get_global_radius, center_screen, apply_window_rounding, set_window_icon
from utils.logger import get_logger

logger = get_logger("dialogs")


class CTkMessageBox:
    """Custom message box with theming and centering
    Кастомное окно сообщений с темой и центрированием
    Кастомне вікно повідомлень з темою та центруванням"""

    _current_theme = "dark"
    _current_lang = "RU"

    @classmethod
    def set_theme(cls, theme: str) -> None:
        cls._current_theme = theme

    @classmethod
    def set_lang(cls, lang: str) -> None:
        cls._current_lang = lang

    @staticmethod
    def _get_colors(theme: str) -> dict:
        if theme == "light":
            return {
                "bg": "#F3F3F3", "fg": "#000000", "button_fg": "#1f538d",
                "button_text": "#FFFFFF", "label_text": "#000000", "entry_bg": "#FFFFFF"
            }
        return {
            "bg": "#1d1e1e", "fg": "#FFFFFF", "button_fg": "#1f538d",
            "button_text": "#FFFFFF", "label_text": "#FFFFFF", "entry_bg": "#2b2b2b"
        }

    @staticmethod
    def _center_window(win, parent, width: int, height: int) -> None:
        """Center window relative to parent / Центрировать окно относительно родительского / Центрувати вікно відносно батьківського"""
        try:
            parent.update_idletasks()
            parent_x = parent.winfo_x()
            parent_y = parent.winfo_y()
            parent_width = parent.winfo_width()
            parent_height = parent.winfo_height()

            x = parent_x + (parent_width // 2) - (width // 2)
            y = parent_y + (parent_height // 2) - (height // 2)

            screen_width = win.winfo_screenwidth()
            screen_height = win.winfo_screenheight()

            if x < 0:
                x = 10
            if y < 0:
                y = 30
            if x + width > screen_width:
                x = screen_width - width - 10
            if y + height > screen_height:
                y = screen_height - height - 10

            win.geometry(f"{width}x{height}+{x}+{y}")
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Center window error: {e}")
            center_screen(win, width, height)

    @staticmethod
    def _show(parent, title: str, message: str, button_text: str = "OK",
              icon: str = "", icon_color: str = "#4EC9B0",
              button_color: str = "#1f538d", is_question: bool = False):

        win = ctk.CTkToplevel(parent)
        win.title(title)
        win.resizable(False, False)
        win.grab_set()
        win.attributes("-topmost", True)

        colors = CTkMessageBox._get_colors(CTkMessageBox._current_theme)
        L = LANGUAGES.get(CTkMessageBox._current_lang, LANGUAGES["RU"])
        radius = get_global_radius()

        w, h = (420, 220) if is_question else (420, 200)

        CTkMessageBox._center_window(win, parent, w, h)

        win.configure(fg_color=colors["bg"])

        if icon:
            ctk.CTkLabel(win, text=icon, font=("Segoe UI", 40),
                        text_color=icon_color).pack(pady=(20, 5))
        else:
            # Empty placeholder to preserve margins / Пустой placeholder для сохранения отступов / Порожній placeholder для збереження відступів
            ctk.CTkLabel(win, text="", font=("Segoe UI", 40)).pack(pady=(20, 5))

        ctk.CTkLabel(win, text=message, font=("Segoe UI", 13),
                    wraplength=360, justify="center",
                    text_color=colors["label_text"]).pack(pady=(0, 15))

        btn_frame = ctk.CTkFrame(win, fg_color="transparent")
        btn_frame.pack()

        result = [None]

        if is_question:
            def on_yes(): result[0] = "yes"; win.destroy()
            def on_no(): result[0] = "no"; win.destroy()
            ctk.CTkButton(btn_frame, text=L.get("yes", "Yes"), width=100, height=35,
                         command=on_yes, fg_color="#2d6a4f", corner_radius=radius).pack(side="left", padx=8)
            ctk.CTkButton(btn_frame, text=L.get("no", "No"), width=100, height=35,
                         command=on_no, fg_color="#8b0000", corner_radius=radius).pack(side="left", padx=8)
        else:
            def on_ok(): result[0] = "ok"; win.destroy()
            btn_text = button_text if button_text != "OK" else L.get("ok", "OK")
            ctk.CTkButton(btn_frame, text=btn_text, width=120, height=35,
                         command=on_ok, fg_color=colors["button_fg"],
                         corner_radius=radius).pack()

        win.after(100, lambda: win.attributes("-topmost", False))
        parent.wait_window(win)
        return result[0]

    @classmethod
    def info(cls, parent, title: str, message: str) -> None:
        cls._show(parent, title, message, icon="", icon_color="#2ECC71")

    @classmethod
    def warning(cls, parent, title: str, message: str) -> None:
        cls._show(parent, title, message, icon="", icon_color="#FFA500")

    @classmethod
    def error(cls, parent, title: str, message: str) -> None:
        cls._show(parent, title, message, icon="", icon_color="#FF4444")

    @classmethod
    def question(cls, parent, title: str, message: str) -> bool:
        result = cls._show(parent, title, message, is_question=True)
        return result == "yes"


class CTkInputDialog:
    """Custom input dialog with proper centering
    Кастомный диалог ввода с правильным центрированием
    Кастомний діалог введення з правильним центруванням"""

    def __init__(self, parent, title: str, prompt: str, show: str = "",
                 theme: str = "dark", lang: str = "RU"):
        self.result = None
        self.parent = parent
        self.win = ctk.CTkToplevel(parent)
        self.win.title(title)
        self.win.resizable(False, False)
        self.win.grab_set()
        self.win.attributes("-topmost", True)

        L = LANGUAGES.get(lang, LANGUAGES["RU"])
        radius = get_global_radius()

        if theme == "light":
            bg_color, fg_color, entry_bg, btn_fg = "#F3F3F3", "#000000", "#FFFFFF", "#1f538d"
        else:
            bg_color, fg_color, entry_bg, btn_fg = "#1d1e1e", "#FFFFFF", "#2b2b2b", "#1f538d"

        self._center_relative_to_parent()

        self.win.configure(fg_color=bg_color)

        ctk.CTkLabel(self.win, text=prompt, font=("Segoe UI", 13),
                    wraplength=360, text_color=fg_color).pack(padx=20, pady=(20, 8))

        self.entry = ctk.CTkEntry(self.win, width=360, height=40, font=("Segoe UI", 14),
                                  show=show, fg_color=entry_bg, text_color=fg_color,
                                  corner_radius=radius)
        self.entry.pack(padx=20, pady=(0, 12))
        self.entry.focus_set()
        self.entry.bind("<Return>", lambda e: self._ok())
        self.entry.bind("<Escape>", lambda e: self._cancel())

        btn_frame = ctk.CTkFrame(self.win, fg_color="transparent")
        btn_frame.pack()
        ctk.CTkButton(btn_frame, text=L["ok"], width=110, height=36,
                     command=self._ok, fg_color=btn_fg, corner_radius=radius).pack(side="left", padx=8)
        ctk.CTkButton(btn_frame, text=L["cancel"], width=110, height=36,
                     command=self._cancel, fg_color="#ca5010", corner_radius=radius).pack(side="left", padx=8)

        self.win.protocol("WM_DELETE_WINDOW", self._cancel)
        parent.wait_window(self.win)

    def _center_relative_to_parent(self) -> None:
        """Center window relative to parent / Центрировать окно относительно родительского / Центрувати вікно відносно батьківського"""
        try:
            self.parent.update_idletasks()
            parent_x = self.parent.winfo_x()
            parent_y = self.parent.winfo_y()
            parent_width = self.parent.winfo_width()
            parent_height = self.parent.winfo_height()

            width = 420
            height = 220

            x = parent_x + (parent_width // 2) - (width // 2)
            y = parent_y + (parent_height // 2) - (height // 2)

            screen_width = self.win.winfo_screenwidth()
            screen_height = self.win.winfo_screenheight()

            if x < 0:
                x = 10
            if y < 0:
                y = 30
            if x + width > screen_width:
                x = screen_width - width - 10
            if y + height > screen_height:
                y = screen_height - height - 10

            self.win.geometry(f"{width}x{height}+{x}+{y}")
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Center input dialog error: {e}")
            center_screen(self.win, 420, 220)

    def _ok(self) -> None:
        self.result = self.entry.get()
        self.win.destroy()

    def _cancel(self) -> None:
        self.result = None
        self.win.destroy()

    @staticmethod
    def ask(parent, title: str, prompt: str, show: str = "",
            theme: str = "dark", lang: str = "RU"):
        """Static method for quick dialog call
        Статический метод для быстрого вызова диалога
        Статичний метод для швидкого виклику діалогу"""
        return CTkInputDialog(parent, title, prompt, show, theme, lang).result


def create_about_dialog(parent, lang: str, radius: int, theme: str, on_close_callback=None):
    """Creates 'About' program window
    Создаёт окно 'О программе'
    Створює вікно 'Про програму'"""
    L = LANGUAGES.get(lang, LANGUAGES["RU"])
    wiki_url = "https://github.com/Maximka1993271/Password-Generator-Python/wiki/Security-Logic"

    about_window = ctk.CTkToplevel(parent)
    about_window.title(L["btn_about"])
    about_window.resizable(False, False)
    about_window.transient(parent)
    about_window.attributes('-topmost', True)
    about_window.after(100, lambda: about_window.attributes('-topmost', False))

    # Center the window / Центрируем окно / Центруємо вікно
    try:
        parent.update_idletasks()
        parent_x = parent.winfo_x()
        parent_y = parent.winfo_y()
        parent_width = parent.winfo_width()
        parent_height = parent.winfo_height()

        width, height = 400, 320
        x = parent_x + (parent_width // 2) - (width // 2)
        y = parent_y + (parent_height // 2) - (height // 2)

        screen_width = about_window.winfo_screenwidth()
        screen_height = about_window.winfo_screenheight()

        if x < 0:
            x = 10
        if y < 0:
            y = 30
        if x + width > screen_width:
            x = screen_width - width - 10
        if y + height > screen_height:
            y = screen_height - height - 10

        about_window.geometry(f"{width}x{height}+{x}+{y}")
    except (tk.TclError, AttributeError, RuntimeError) as e:
        logger.debug(f"About window centering error: {e}")
        center_screen(about_window, 400, 320)

    apply_window_rounding(about_window)

    # Main frame / Основной фрейм / Основний фрейм
    main_frame = ctk.CTkFrame(about_window, fg_color="transparent")
    main_frame.pack(expand=True, fill="both", padx=30, pady=25)

    # Title / Заголовок / Заголовок
    ctk.CTkLabel(main_frame, text="Secure Pass Pro v4.0",
                 font=("Segoe UI", 26, "bold")).pack(pady=(0, 15))

    # Text - only basic information / Текст - только основная информация / Текст - тільки основна інформація
    ctk.CTkLabel(main_frame, text=L.get("about_text_simple", "Professional password generator\n\nMaxim Melnikov\nMIT License"),
                 wraplength=380, font=("Segoe UI", 13),
                 justify="center").pack(pady=10)

    # Buttons / Кнопки / Кнопки
    btn_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
    btn_frame.pack(pady=(20, 10))

    def close():
        about_window.destroy()
        if on_close_callback:
            on_close_callback()

    ctk.CTkButton(btn_frame, text=L.get("ok", "OK"), width=100, height=35,
                  command=close, corner_radius=radius,
                  fg_color="#2d6a4f", hover_color="#40916c",
                  font=("Segoe UI", 13, "bold")).pack(side="left", padx=10)

    ctk.CTkButton(btn_frame, text=L.get("wiki_link", "Wiki"), width=100, height=35,
                  command=lambda: webbrowser.open(wiki_url), corner_radius=radius,
                  fg_color="#1f538d", hover_color="#2d6a4f",
                  font=("Segoe UI", 13)).pack(side="left", padx=10)

    about_window.focus_force()
    return about_window