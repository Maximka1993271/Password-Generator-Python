"""
Custom GUI widgets with accessibility support
"""
import tkinter as tk
import customtkinter as ctk
from typing import Optional
from utils.logger import get_logger

logger = get_logger("widgets")


# ==================== УЛУЧШЕННЫЙ TOOLTIP ====================

class ToolTip:
    """Enhanced tooltip with accessibility support"""

    def __init__(self, widget, text: str = "", delay: int = 500):
        self.widget = widget
        self.text = text
        self.delay = delay
        self.tip_window = None
        self._after_id = None
        widget.bind("<Enter>", self._on_enter)
        widget.bind("<Leave>", self._on_leave)
        widget.bind("<FocusIn>", self._on_focus_in)
        widget.bind("<FocusOut>", self._on_focus_out)

    def set_text(self, text: str) -> None:
        """Set tooltip text"""
        self.text = text

    def _on_enter(self, event=None) -> None:
        if self._after_id:
            try:
                self.widget.after_cancel(self._after_id)
            except (tk.TclError, ValueError):
                pass
        self._after_id = self.widget.after(self.delay, self._show_tip)

    def _on_leave(self, event=None) -> None:
        if self._after_id:
            try:
                self.widget.after_cancel(self._after_id)
            except (tk.TclError, ValueError):
                pass
            self._after_id = None
        self._hide_tip()

    def _on_focus_in(self, event=None) -> None:
        self._show_tip()

    def _on_focus_out(self, event=None) -> None:
        self._hide_tip()

    def _show_tip(self) -> None:
        if self.tip_window or not self.text:
            return
        try:
            if not self.widget.winfo_exists():
                return
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Tooltip show error: {e}")
            return

        try:
            x = self.widget.winfo_rootx() + 25
            y = self.widget.winfo_rooty() + self.widget.winfo_height() + 5
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Tooltip position error: {e}")
            return

        self.tip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")

        try:
            tk.Label(tw, text=self.text, justify='left', background="#ffffe0",
                    relief='solid', borderwidth=1, font=("Segoe UI", 9, "normal")).pack(ipadx=1)
        except tk.TclError as e:
            logger.debug(f"Tooltip label error: {e}")
            self._hide_tip()

    def _hide_tip(self) -> None:
        if self.tip_window:
            try:
                self.tip_window.destroy()
            except tk.TclError as e:
                logger.debug(f"Tooltip destroy error: {e}")
            except AttributeError as e:
                logger.debug(f"Tooltip attribute error: {e}")
            finally:
                self.tip_window = None


# ==================== КАСТОМНАЯ КНОПКА ====================

class CustomButton(ctk.CTkButton):
    """Custom button with tooltip support"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._tooltip: Optional[ToolTip] = None

    def set_tooltip(self, text: str, delay: int = 500) -> None:
        """Set tooltip for the button"""
        self._tooltip = ToolTip(self, text, delay)


# ==================== КАСТОМНЫЙ ЧЕКБОКС ====================

class CustomCheckBox(ctk.CTkCheckBox):
    """Custom checkbox with tooltip support"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._tooltip: Optional[ToolTip] = None

    def set_tooltip(self, text: str, delay: int = 500) -> None:
        """Set tooltip for the checkbox"""
        self._tooltip = ToolTip(self, text, delay)


# ==================== КАСТОМНОЕ ПОЛЕ ВВОДА ====================

class CustomEntry(ctk.CTkEntry):
    """Custom entry with tooltip and password toggle"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._tooltip: Optional[ToolTip] = None
        self._show_password = False
        self._original_show = kwargs.get("show", "")

    def set_tooltip(self, text: str, delay: int = 500) -> None:
        """Set tooltip for the entry"""
        self._tooltip = ToolTip(self, text, delay)

    def toggle_password_visibility(self) -> None:
        """Toggle password visibility"""
        self._show_password = not self._show_password
        if self._show_password:
            self.configure(show="")
        else:
            self.configure(show="*")


# ==================== КАСТОМНАЯ МЕТКА ====================

class CustomLabel(ctk.CTkLabel):
    """Custom label with tooltip support"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._tooltip: Optional[ToolTip] = None

    def set_tooltip(self, text: str, delay: int = 500) -> None:
        """Set tooltip for the label"""
        self._tooltip = ToolTip(self, text, delay)


# ==================== КАСТОМНЫЙ СЛАЙДЕР ====================

class CustomSlider(ctk.CTkSlider):
    """Custom slider with tooltip and value label"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._tooltip: Optional[ToolTip] = None
        self._value_label: Optional[CustomLabel] = None

    def set_tooltip(self, text: str, delay: int = 500) -> None:
        """Set tooltip for the slider"""
        self._tooltip = ToolTip(self, text, delay)

    def attach_value_label(self, label: CustomLabel, format_str: str = "{}") -> None:
        """Attach a label to display current value"""
        self._value_label = label
        self._format_str = format_str
        self.configure(command=self._on_value_change)
        self._on_value_change(self.get())

    def _on_value_change(self, value: float) -> None:
        """Update value label when slider changes"""
        if self._value_label:
            self._value_label.configure(text=self._format_str.format(int(value)))


# ==================== ОБРАТНАЯ СОВМЕСТИМОСТЬ ====================

# Сохраняем старый класс ToolTip для обратной совместимости
ToolTip = ToolTip