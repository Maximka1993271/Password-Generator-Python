#!/usr/bin/env python3
"""
Тестирование всех исправлений Secure Pass Pro v4.0
ВСЕ ТЕСТЫ ВО ВРЕМЕННОЙ ПАПКЕ - НЕ ТРОГАЕТ РЕАЛЬНЫЕ ДАННЫЕ

Запуск: python test_all_fixes.py
"""

import os
import sys
import time
import tempfile
import shutil
import atexit
from pathlib import Path

# ==================== НАСТРОЙКА ТЕСТОВОГО ОКРУЖЕНИЯ ====================

# Создаём временную папку для тестов
TEST_DIR = tempfile.mkdtemp(prefix="SecurePassPro_Test_")
print(f"📁 Тестовая папка: {TEST_DIR}")

# Устанавливаем переменные окружения для тестового режима
os.environ['SECUREPASSPRO_TEST_MODE'] = '1'
os.environ['SECUREPASSPRO_SKIP_DB_INIT'] = '1'
os.environ['SECUREPASSPRO_DATA_DIR'] = TEST_DIR
os.environ['SECUREPASSPRO_CONFIG_DIR'] = TEST_DIR

# Функция очистки
def cleanup_test_dir():
    """Удаляет временную папку после тестов"""
    try:
        if os.path.exists(TEST_DIR):
            shutil.rmtree(TEST_DIR, ignore_errors=True)
            print(f"🧹 Очищена временная папка: {TEST_DIR}")
    except Exception as e:
        print(f"⚠️ Ошибка очистки: {e}")

# Регистрируем очистку при выходе
atexit.register(cleanup_test_dir)

# Патчим пути перед импортом модулей
def patch_paths():
    """Перенаправляем все пути во временную папку"""
    try:
        import utils.paths

        # Сохраняем оригинальные функции
        original_get_config_dir = utils.paths.get_config_dir
        original_get_db_file = utils.paths.get_db_file
        original_get_salt_file = utils.paths.get_salt_file
        original_get_master_file = utils.paths.get_master_file
        original_get_uuid_file = utils.paths.get_uuid_file

        def patched_get_config_dir():
            return TEST_DIR

        def patched_get_db_file():
            return os.path.join(TEST_DIR, "passwords.db")

        def patched_get_salt_file():
            return os.path.join(TEST_DIR, "db.salt")

        def patched_get_master_file():
            return os.path.join(TEST_DIR, "master.key")

        def patched_get_uuid_file():
            return os.path.join(TEST_DIR, "machine.id")

        # Применяем патчи
        utils.paths.get_config_dir = patched_get_config_dir
        utils.paths.get_db_file = patched_get_db_file
        utils.paths.get_salt_file = patched_get_salt_file
        utils.paths.get_master_file = patched_get_master_file
        utils.paths.get_uuid_file = patched_get_uuid_file

        print("✅ Пути перенаправлены во временную папку")

    except Exception as e:
        print(f"⚠️ Ошибка патчинга путей: {e}")

# Применяем патчи до импорта модулей
patch_paths()

# Добавляем путь к проекту
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ==================== ИМПОРТЫ ====================

# Цвета для вывода в консоль
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    MAGENTA = '\033[95m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def print_header(text):
    print(f"\n{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}{text:^60}{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*60}{Colors.RESET}\n")

def print_test(name, status, details=""):
    icon = f"{Colors.GREEN}✅{Colors.RESET}" if status else f"{Colors.RED}❌{Colors.RESET}"
    print(f"{icon} {name:40} ", end="")
    if details:
        color = Colors.GREEN if status else Colors.RED
        print(f"{color}{details}{Colors.RESET}")
    else:
        print()

def print_warning(text):
    print(f"{Colors.YELLOW}⚠️  {text}{Colors.RESET}")

def print_info(text):
    print(f"{Colors.BLUE}ℹ️  {text}{Colors.RESET}")

def print_success(text):
    print(f"{Colors.GREEN}✅ {text}{Colors.RESET}")

def print_error(text):
    print(f"{Colors.RED}❌ {text}{Colors.RESET}")


# ==================== ТЕСТ 1: ГЕНЕРАЦИЯ КЛЮЧЕЙ UPDATER ====================
def test_updater_keys():
    print_header("ТЕСТ 1: Генерация ключей updater.py")

    try:
        # Пробуем импортировать из разных мест
        _ensure_keys_exist = None
        _get_resources_dir = None
        _get_public_key_path = None

        # Попытка 1: из корня
        try:
            from updater import _ensure_keys_exist, _get_resources_dir, _get_public_key_path
            print_info("Импорт updater из корня")
        except ImportError:
            # Попытка 2: из utils
            try:
                from utils.updater import _ensure_keys_exist, _get_resources_dir, _get_public_key_path
                print_info("Импорт updater из utils.updater")
            except ImportError:
                # Попытка 3: динамический импорт
                import importlib.util

                # Ищем файл updater.py
                possible_paths = [
                    os.path.join(os.path.dirname(__file__), "updater.py"),
                    os.path.join(os.path.dirname(__file__), "utils", "updater.py"),
                ]

                for path in possible_paths:
                    if os.path.exists(path):
                        spec = importlib.util.spec_from_file_location("updater", path)
                        updater_module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(updater_module)
                        _ensure_keys_exist = updater_module._ensure_keys_exist
                        _get_resources_dir = updater_module._get_resources_dir
                        _get_public_key_path = updater_module._get_public_key_path
                        print_info(f"Импорт updater из {path}")
                        break

        if _ensure_keys_exist is None:
            # Не удалось импортировать, проверяем файлы вручную
            print_warning("Модуль updater не найден, проверяем файлы вручную")

            resources_dir = os.path.join(os.path.dirname(__file__), "resources")
            key_path = os.path.join(resources_dir, "public_key.pem")
            key_exists = os.path.exists(key_path)
            print_test("Файл public_key.pem существует (ручная проверка)", key_exists)

            if key_exists:
                size = os.path.getsize(key_path)
                print_test("Размер ключа > 400 байт", size > 400, f"({size} байт)")

                with open(key_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    has_begin = "BEGIN PUBLIC KEY" in content
                    has_end = "END PUBLIC KEY" in content
                    print_test("Ключ в правильном формате PEM", has_begin and has_end)

            return key_exists

        # Если импорт удался
        result = _ensure_keys_exist()
        print_test("Создание папки resources", result)

        resources_dir = _get_resources_dir()
        exists = os.path.exists(resources_dir)
        print_test("Папка resources существует", exists, f"({resources_dir})")

        key_path = _get_public_key_path()
        key_exists = os.path.exists(key_path)
        print_test("Файл public_key.pem создан", key_exists)

        if key_exists:
            size = os.path.getsize(key_path)
            print_test("Размер ключа > 400 байт", size > 400, f"({size} байт)")

            with open(key_path, 'r', encoding='utf-8') as f:
                content = f.read()
                has_begin = "BEGIN PUBLIC KEY" in content
                has_end = "END PUBLIC KEY" in content
                print_test("Ключ в правильном формате PEM", has_begin and has_end)

        return result and key_exists
    except Exception as e:
        print_error(f"Ошибка: {e}")
        return False


# ==================== ТЕСТ 2: БЕЗОПАСНАЯ ЗАПИСЬ ФАЙЛОВ ====================
def test_secure_file_ops():
    print_header("ТЕСТ 2: Безопасная запись файлов (secure_file_ops)")

    try:
        from utils.secure_file_ops import secure_write, secure_read, secure_delete

        # Создаём временный файл в тестовой папке
        tmp_path = os.path.join(TEST_DIR, "test_secure_file.tmp")

        # Тест записи
        test_data = b"Hello, Secure World! This is a test of the secure file operations."
        result_write = secure_write(tmp_path, test_data, make_hidden=False)
        print_test("Безопасная запись файла", result_write)

        # Тест чтения
        read_data = secure_read(tmp_path)
        result_read = read_data == test_data
        print_test("Безопасное чтение файла", result_read, f"({len(read_data or b'')} байт)")

        # Тест удаления
        result_delete = secure_delete(tmp_path)
        print_test("Безопасное удаление файла", result_delete)
        print_test("Файл действительно удалён", not os.path.exists(tmp_path))

        return result_write and result_read and result_delete
    except Exception as e:
        print_error(f"Ошибка: {e}")
        return False


# ==================== ТЕСТ 3: БЕЗОПАСНАЯ СТРОКА ====================
def test_secure_string():
    print_header("ТЕСТ 3: Безопасная строка (SecureString)")

    try:
        from core.generator import SecureString, SecurePasswordContext, _clear_string

        # Тест создания (тестовый пароль, не настоящий)
        test_pwd = "TestPassword123!"
        ss = SecureString(test_pwd)
        print_test("Создание SecureString", ss is not None)

        # Тест получения строки
        retrieved = ss.get()
        print_test("Получение строки", retrieved == test_pwd)

        # Тест очистки
        ss.clear()
        retrieved_after = ss.get()
        print_test("Очистка строки", retrieved_after == "")

        # Тест контекстного менеджера
        with SecurePasswordContext() as ctx:
            ctx.set_password(test_pwd)
            pwd = ctx.get()
            print_test("Контекстный менеджер", pwd == test_pwd)

        # Тест очистки строки функцией
        test_str = "AnotherTestSecret"
        _clear_string(test_str)
        print_test("Функция _clear_string не падает", True)

        return True
    except Exception as e:
        print_error(f"Ошибка: {e}")
        return False


# ==================== ТЕСТ 4: SQLCipher БЕЗОПАСНЫЙ КЛЮЧ ====================
def test_sqlcipher_key():
    print_header("ТЕСТ 4: Безопасная установка SQLCipher ключа")

    try:
        from security.encryption import set_sqlcipher_key, clear_sqlcipher_key, is_sqlcipher_available

        # Тест установки ключа (тестовый пароль)
        test_password = "TestMasterKey123!"
        set_sqlcipher_key(test_password)
        print_test("Установка SQLCipher ключа", True)

        # Тест очистки
        clear_sqlcipher_key()
        print_test("Очистка SQLCipher ключа", True)

        # Проверка доступности
        available = is_sqlcipher_available()
        print_test("SQLCipher доступен", available)

        return True
    except Exception as e:
        print_warning(f"SQLCipher не установлен: {e}")
        return True


# ==================== ТЕСТ 5: ГЕНЕРАЦИЯ ПАРОЛЕЙ ====================
def test_password_generation():
    print_header("ТЕСТ 5: Генерация паролей")

    try:
        from core.generator import PasswordGenerator

        gen = PasswordGenerator()

        # Тест обычной генерации
        pwd1 = gen.generate()
        print_test("Генерация пароля", pwd1 is not None and len(pwd1) > 0, f"({len(pwd1)} символов)")

        # Тест безопасной генерации
        secure_pwd = gen.generate_secure()
        print_test("Безопасная генерация", secure_pwd is not None)

        if secure_pwd:
            pwd2 = secure_pwd.get_string()
            print_test("Получение строки из SecurePassword", len(pwd2) > 0)
            secure_pwd.clear()

        # Тест разных настроек
        gen.use_upper = True
        gen.use_lower = False
        gen.use_digits = False
        gen.use_special = False
        pwd3 = gen.generate()
        has_upper = pwd3 and any(c.isupper() for c in pwd3)
        print_test("Только заглавные буквы", has_upper)

        gen.use_upper = False
        gen.use_lower = True
        pwd4 = gen.generate()
        has_lower = pwd4 and any(c.islower() for c in pwd4)
        print_test("Только строчные буквы", has_lower)

        gen.use_lower = False
        gen.use_digits = True
        pwd5 = gen.generate()
        has_digits = pwd5 and any(c.isdigit() for c in pwd5)
        print_test("Только цифры", has_digits)

        # Тест исключения похожих символов
        gen.use_upper = True
        gen.use_lower = True
        gen.use_digits = True
        gen.exclude_ambiguous = True
        pwd6 = gen.generate()
        ambiguous_chars = "il1Lo0O"
        has_no_ambiguous = pwd6 and not any(c in ambiguous_chars for c in pwd6)
        print_test("Исключение похожих символов", has_no_ambiguous)

        # Тест без повторов
        gen.exclude_ambiguous = False
        gen.no_repeat = True
        pwd7 = gen.generate()
        has_no_repeats = pwd7 and not any(pwd7[i] == pwd7[i+1] for i in range(len(pwd7)-1))
        print_test("Без повторов символов", has_no_repeats)

        # Сброс настроек
        gen.use_upper = True
        gen.use_lower = True
        gen.use_digits = True
        gen.use_special = False
        gen.exclude_ambiguous = False
        gen.no_repeat = False

        return True
    except Exception as e:
        print_error(f"Ошибка: {e}")
        return False


# ==================== ТЕСТ 6: ФИЛЬТРАЦИЯ ЛОГОВ ====================
def test_log_filtering():
    print_header("ТЕСТ 6: Фильтрация чувствительных данных в логах")

    try:
        from utils.logger import SensitiveDataFilter

        filter_obj = SensitiveDataFilter()

        # Тест фильтрации пароля
        test_message = "User entered password: MySecret123"
        filtered = filter_obj._filter_string(test_message)
        contains_filtered = "FILTERED" in filtered or "MySecret123" not in filtered
        print_test("Фильтрация пароля в строке", contains_filtered)

        # Тест фильтрации traceback
        tb_text = '''Traceback (most recent call last):
  File "test.py", line 10, in <module>
    password = "MySecret123"
    result = check_password(password)'''
        filtered_tb = filter_obj._filter_traceback(tb_text)
        contains_removed = "SENSITIVE LINE REMOVED" in filtered_tb or "MySecret123" not in filtered_tb
        print_test("Фильтрация traceback", contains_removed)

        return True
    except Exception as e:
        print_error(f"Ошибка: {e}")
        return False


# ==================== ТЕСТ 7: ЗВУКОВОЙ ФАЙЛ ====================
def test_sound():
    print_header("ТЕСТ 7: Поиск звукового файла")

    try:
        from utils.helpers import _get_sound_path

        sound_path = _get_sound_path()
        if sound_path:
            print_test("Звуковой файл найден", True, f"({os.path.basename(sound_path)})")
            print_test("Файл существует", os.path.exists(sound_path))
            print_test("Размер файла > 0", os.path.getsize(sound_path) > 0)
        else:
            print_warning("Звуковой файл не найден - звук будет отключён")
            print_test("Звуковой файл найден", False, "Файл Computer Mouse Click.mp3 отсутствует")

        return True
    except Exception as e:
        print_error(f"Ошибка: {e}")
        return False


# ==================== ТЕСТ 8: ЦЕЛОСТНОСТЬ ПРОГРАММЫ ====================
def test_integrity():
    print_header("ТЕСТ 8: Проверка целостности программы")

    try:
        from utils.integrity_check import IntegrityChecker

        # Генерация файла целостности
        result = IntegrityChecker.generate_integrity_file()
        print_test("Генерация файла integrity.json", result)

        # Проверка целостности
        is_valid, errors = IntegrityChecker.verify_integrity(auto_repair=False)
        print_test("Проверка целостности", is_valid)

        # Статус файлов
        status = IntegrityChecker.get_file_status()
        files_checked = len(status)
        print_test("Количество проверенных файлов", files_checked > 0, f"({files_checked})")

        return True
    except Exception as e:
        print_warning(f"Integrity check тест пропущен: {e}")
        return True


# ==================== ТЕСТ 9: БАЗА ДАННЫХ ====================
def test_database():
    print_header("ТЕСТ 9: Работа с базой данных")

    try:
        # Используем тестовую БД во временной папке
        from storage.database import PasswordDB

        # Тест инициализации
        PasswordDB._init_db()
        print_test("Инициализация БД", True)

        # Тест сохранения (тестовые данные)
        test_label = "Test Password"
        test_password = "TestPwd123!"

        record_id = PasswordDB.save(test_label, test_password)
        print_test("Сохранение пароля", record_id > 0, f"(ID: {record_id})")

        # Тест получения
        records = PasswordDB.get_all()
        print_test("Получение всех записей", len(records) > 0)

        found = any(r["label"] == test_label for r in records)
        print_test("Сохранённый пароль найден", found)

        # Тест поиска
        search_results = PasswordDB.search("Test")
        print_test("Поиск по метке", len(search_results) > 0)

        # Тест удаления
        if record_id:
            PasswordDB.delete(record_id)
            records_after = PasswordDB.get_all()
            not_found = not any(r["id"] == record_id for r in records_after)
            print_test("Удаление записи", not_found)

        return True
    except Exception as e:
        print_warning(f"Тест БД пропущен: {e}")
        return True


# ==================== ТЕСТ 10: МИКСИНЫ ====================
def test_mixins():
    print_header("ТЕСТ 10: Проверка импорта миксинов")

    try:
        from gui.mixins import UIMixins, SecurityMixins, OpsMixins, VisualMixins, AllMixins
        print_test("Импорт UIMixins", True)
        print_test("Импорт SecurityMixins", True)
        print_test("Импорт OpsMixins", True)
        print_test("Импорт VisualMixins", True)
        print_test("Импорт AllMixins", True)

        has_attrs = all([
            hasattr(UIMixins, '__bases__'),
            hasattr(SecurityMixins, '__bases__'),
            hasattr(OpsMixins, '__bases__'),
            hasattr(VisualMixins, '__bases__'),
        ])
        print_test("Миксины корректно сгруппированы", has_attrs)

        return True
    except Exception as e:
        print_error(f"Ошибка импорта: {e}")
        return False


# ==================== ТЕСТ 11: HIBP RATE LIMITING ====================
def test_hibp_rate_limit():
    print_header("ТЕСТ 11: Rate limiting для HIBP")

    try:
        from gui.mixins.hibp_mixin import HIBP_COOLDOWN, _MAX_RETRIES

        print_test("HIBP_COOLDOWN = 10 секунд", HIBP_COOLDOWN == 10, f"(={HIBP_COOLDOWN})")
        print_test("_MAX_RETRIES = 3", _MAX_RETRIES == 3, f"(={_MAX_RETRIES})")

        return True
    except Exception as e:
        print_warning(f"HIBP тест пропущен: {e}")
        return True


# ==================== ТЕСТ 12: ЭКСПОРТ ДАННЫХ ====================
def test_export():
    print_header("ТЕСТ 12: Экспорт данных (JSON, CSV, HTML)")

    try:
        from utils.export import DataExporter
        import json

        # Создаём тестовые данные
        test_data = [
            {"id": 1, "label": "Test1", "password": "Pass123", "created": "2026-05-21 10:00:00"},
            {"id": 2, "label": "Test2", "password": "Pass456", "created": "2026-05-21 10:00:00"},
        ]

        # Тест JSON экспорта
        json_path = os.path.join(TEST_DIR, "test_export.json")
        result_json = DataExporter.export_json(test_data, json_path)
        print_test("Экспорт в JSON", result_json)

        if result_json and os.path.exists(json_path):
            with open(json_path, 'r', encoding='utf-8') as f:
                loaded = json.load(f)
                print_test("JSON содержит данные", loaded.get('count') == 2)

        # Тест CSV экспорта
        csv_path = os.path.join(TEST_DIR, "test_export.csv")
        result_csv = DataExporter.export_csv(test_data, csv_path)
        print_test("Экспорт в CSV", result_csv)

        # Тест HTML экспорта
        html_path = os.path.join(TEST_DIR, "test_export.html")
        result_html = DataExporter.export_html(test_data, html_path, "RU")
        print_test("Экспорт в HTML", result_html)

        return result_json and result_csv and result_html
    except Exception as e:
        print_error(f"Ошибка: {e}")
        return False


# ==================== ТЕСТ 13: ИМПОРТ ДАННЫХ ====================
def test_import():
    print_header("ТЕСТ 13: Импорт данных")

    try:
        from utils.import_passwords import PasswordImporter

        # Создаём тестовый JSON файл
        json_path = os.path.join(TEST_DIR, "test_import.json")
        test_data = {
            "passwords": [
                {"label": "Imported1", "password": "ImpPass123"},
                {"label": "Imported2", "password": "ImpPass456"},
            ]
        }

        import json
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(test_data, f)

        # Тест импорта JSON
        imported = PasswordImporter.import_from_json(json_path)
        print_test("Импорт из JSON", len(imported) == 2, f"({len(imported)} записей)")

        # Тест импорта CSV
        csv_path = os.path.join(TEST_DIR, "test_import.csv")
        with open(csv_path, 'w', encoding='utf-8-sig') as f:
            f.write("label,password\nTest1,Pass123\nTest2,Pass456")

        imported_csv = PasswordImporter.import_from_csv(csv_path)
        print_test("Импорт из CSV", len(imported_csv) >= 2, f"({len(imported_csv)} записей)")

        return True
    except Exception as e:
        print_warning(f"Тест импорта пропущен: {e}")
        return True


# ==================== ТЕСТ 14: КОНФИГУРАЦИЯ ====================
def test_config():
    print_header("ТЕСТ 14: Работа с конфигурацией")

    try:
        from storage.config import Config

        config = Config()

        # Тест получения настроек
        theme = config.get("THEME")
        print_test("Получение настройки THEME", theme is not None, f"({theme})")

        # Тест установки настройки
        result = config.set("TEST_SETTING", "test_value")
        print_test("Установка настройки", result)

        # Тест PDF темы
        pdf_theme = config.get("PDF_THEME")
        print_test("Настройка PDF_THEME", pdf_theme in ["light", "dark"], f"({pdf_theme})")

        return True
    except Exception as e:
        print_warning(f"Тест конфигурации пропущен: {e}")
        return True


# ==================== ОЧИСТКА ВРЕМЕННОЙ ПАПКИ ====================
def show_test_files():
    """Показывает какие файлы были созданы во временной папке"""
    if os.path.exists(TEST_DIR):
        files = os.listdir(TEST_DIR)
        if files:
            print_info(f"Файлы во временной папке ({len(files)}): {', '.join(files)}")


# ==================== ГЛАВНАЯ ФУНКЦИЯ ====================
def main():
    print_header("🧪 ТЕСТИРОВАНИЕ ИСПРАВЛЕНИЙ SECURE PASS PRO v4.0")

    print_info(f"Python: {sys.version}")
    print_info(f"Platform: {sys.platform}")
    print_info(f"Тестовая папка: {TEST_DIR}")
    print_info("Все тесты выполняются во временной папке - реальные данные не затрагиваются\n")

    tests = [
        ("Генерация ключей updater.py", test_updater_keys),
        ("Безопасная запись файлов", test_secure_file_ops),
        ("Безопасная строка (SecureString)", test_secure_string),
        ("SQLCipher безопасный ключ", test_sqlcipher_key),
        ("Генерация паролей", test_password_generation),
        ("Фильтрация логов", test_log_filtering),
        ("Поиск звукового файла", test_sound),
        ("Целостность программы", test_integrity),
        ("База данных", test_database),
        ("Импорт миксинов", test_mixins),
        ("HIBP Rate limiting", test_hibp_rate_limit),
        ("Экспорт данных", test_export),
        ("Импорт данных", test_import),
        ("Конфигурация", test_config),
    ]

    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print_error(f"Ошибка при тестировании '{name}': {e}")
            results.append((name, False))

    # Итоги
    print_header("📊 РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ")

    passed = sum(1 for _, r in results if r)
    total = len(results)

    for name, result in results:
        status = f"{Colors.GREEN}ПРОЙДЕН{Colors.RESET}" if result else f"{Colors.RED}НЕ ПРОЙДЕН{Colors.RESET}"
        print(f"{' ' * 2}{status} | {name}")

    print()
    print(f"{Colors.CYAN}{'─' * 60}{Colors.RESET}")
    print(f"{Colors.BOLD}Итого: {passed}/{total} тестов пройдено{Colors.RESET}")

    if passed == total:
        print_success("\n🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ! Программа готова к работе.")
    elif passed >= total - 2:
        print_success(f"\n✅ Пройдено {passed}/{total} тестов. Основные проблемы исправлены!")
        print_info("Небольшие предупреждения не влияют на работу программы.")
    else:
        print_error(f"\n❌ Пройдено только {passed}/{total} тестов. Требуется доработка.")

    # Показываем созданные файлы
    show_test_files()

    print()
    print_info("Тестовая папка будет автоматически удалена при выходе")
    print_info("Нажмите Enter для выхода...")
    input()


if __name__ == "__main__":
    try:
        main()
    finally:
        # Принудительная очистка
        cleanup_test_dir()