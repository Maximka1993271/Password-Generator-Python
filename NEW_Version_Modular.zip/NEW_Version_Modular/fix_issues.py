#!/usr/bin/env python3
"""
Скрипт для автоматического исправления найденных проблем
Запуск: python fix_issues.py
"""

import os
import re
import shutil
from pathlib import Path
from typing import List, Tuple


class IssueFixer:
    """Класс для исправления проблем в коде"""

    def __init__(self):
        self.root_dir = Path.cwd()
        self.fixed_count = 0
        self.skipped_count = 0

    def print_header(self, text: str):
        print(f"\n{'='*60}")
        print(f"🔧 {text}")
        print(f"{'='*60}")

    def print_success(self, text: str):
        print(f"✅ {text}")
        self.fixed_count += 1

    def print_warning(self, text: str):
        print(f"⚠️ {text}")
        self.skipped_count += 1

    def print_info(self, text: str):
        print(f"ℹ️ {text}")

    def fix_database_key_issue(self) -> bool:
        """Исправляет опасную передачу SQLCipher ключа"""
        db_path = self.root_dir / "storage" / "database.py"
        if not db_path.exists():
            self.print_warning("database.py not found")
            return False

        with open(db_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Проверяем разные варианты опасной передачи ключа
        patterns = [
            (r'conn\.execute\(f"PRAGMA key = \'\{_sqlcipher_key_hex\}\'"\)',
             'conn.execute("PRAGMA key = ?", (_sqlcipher_key,))'),
            (r'conn\.execute\(f"PRAGMA key = \'\{_sqlcipher_key_hex\.decode\(\)\}\'"\)',
             'conn.execute("PRAGMA key = ?", (_sqlcipher_key,))'),
            (r'conn\.execute\("PRAGMA key = ' + "'" + r'\{_sqlcipher_key_hex\}' + "'" + r'"\)',
             'conn.execute("PRAGMA key = ?", (_sqlcipher_key,))'),
        ]

        modified = False
        for pattern, replacement in patterns:
            if re.search(pattern, content):
                content = re.sub(pattern, replacement, content)
                modified = True

        if modified:
            with open(db_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.print_success("Исправлена опасная передача SQLCipher ключа в database.py")
            return True
        else:
            self.print_info("Проблема не найдена или уже исправлена")
            return True

    def fix_too_broad_except(self, file_path: Path) -> bool:
        """Исправляет слишком широкие except Exception"""
        if not file_path.exists():
            return False

        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Список замен для конкретных файлов
        replacements = [
            # В encryption.py
            (r'except Exception:', 'except (ValueError, TypeError, OSError):'),
            # В database.py
            (r'except Exception as e:', 'except (sqlite3.Error, ValueError, OSError) as e:'),
            # В master.py
            (r'except Exception:', 'except (ValueError, OSError, IOError):'),
        ]

        modified = False
        for pattern, replacement in replacements:
            if re.search(pattern, content):
                content = re.sub(pattern, replacement, content)
                modified = True

        if modified:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.print_success(f"Исправлены широкие except в {file_path.name}")
            return True
        return False

    def fix_test_passwords(self) -> bool:
        """Добавляет комментарии к тестовым паролям"""
        test_path = self.root_dir / "test_all_fixes.py"
        if not test_path.exists():
            self.print_warning("test_all_fixes.py not found")
            return False

        with open(test_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        # Добавляем комментарий в начало файла
        if lines and not any(line.startswith('# TEST FILE') for line in lines[:5]):
            header = [
                '# TEST FILE - Contains test passwords for automated testing\n',
                '# These are NOT real passwords, only for testing purposes\n',
                '# WARNING: Do not use these passwords in production!\n',
                '\n'
            ]
            lines = header + lines

            with open(test_path, 'w', encoding='utf-8') as f:
                f.writelines(lines)
            self.print_success("Добавлен комментарий к тестовым паролям")
            return True

        self.print_info("Комментарий уже есть")
        return True

    def fix_trailing_whitespace(self, file_path: Path) -> bool:
        """Удаляет пробелы в конце строк"""
        if not file_path.exists():
            return False

        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        new_lines = [line.rstrip() + '\n' for line in lines]

        if new_lines != lines:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.writelines(new_lines)
            return True
        return False

    def create_example_config(self) -> bool:
        """Создаёт example конфиг если нет"""
        example_path = self.root_dir / "config.example.json"
        if not example_path.exists():
            example_content = '''{
    "_comment": "Пример конфигурации - скопируйте в data/config.json",
    "_warning": "НЕ ИСПОЛЬЗУЙТЕ этот файл как реальный конфиг!",
    "THEME": "Dark",
    "LANG": "RU",
    "SOUND": true,
    "RGB": true,
    "RGB_SPEED": "normal",
    "RGB_WIDTH": "normal",
    "RADIUS": 25,
    "font_size": 14,
    "CLIP_TIMEOUT": 60,
    "AUTO_LOCK": false,
    "AUTO_LOCK_TIMEOUT": 5,
    "auto_save": false,
    "PDF_THEME": "light"
}'''
            with open(example_path, 'w', encoding='utf-8') as f:
                f.write(example_content)
            self.print_success("Создан config.example.json")
            return True
        return False

    def create_requirements(self) -> bool:
        """Создаёт requirements.txt если нет"""
        req_path = self.root_dir / "requirements.txt"
        if not req_path.exists():
            requirements = '''# Secure Pass Pro v4.0 Dependencies
# Установка: pip install -r requirements.txt

# Core dependencies
customtkinter>=5.2.0
cryptography>=41.0.0
Pillow>=10.0.0
qrcode>=7.4.0
fpdf>=1.7.2
requests>=2.31.0
argon2-cffi>=21.3.0

# Optional dependencies
# sqlcipher3 - for full database encryption
# pip install sqlcipher3

# Development dependencies (optional)
# pytest>=7.0.0
# black>=23.0.0
# flake8>=6.0.0
'''
            with open(req_path, 'w', encoding='utf-8') as f:
                f.write(requirements)
            self.print_success("Создан requirements.txt")
            return True
        return False

    def create_gitignore(self) -> bool:
        """Создаёт .gitignore если нет"""
        gitignore_path = self.root_dir / ".gitignore"
        if not gitignore_path.exists():
            gitignore_content = '''# Python
__pycache__/
*.py[cod]
*.so
.Python
env/
venv/
ENV/
.venv/

# Distribution
build/
dist/
*.egg-info/
*.egg

# IDE
.vscode/
.idea/
*.swp
*.swo
.DS_Store

# Secure Pass Pro specific
data/
logs/
*.log
*.db
*.key
*.salt
*.id
updates/

# Sensitive data
*.pem
*.crt
*.p12
.env
.secrets
config.local.json

# Test files
.pytest_cache/
.coverage
htmlcov/
.tox/

# Temporary files
*.tmp
*.backup
*.corrupted
*.old
*.lock
'''
            with open(gitignore_path, 'w', encoding='utf-8') as f:
                f.write(gitignore_content)
            self.print_success("Создан .gitignore")
            return True
        return False

    def fix_all_files(self) -> None:
        """Проходит по всем файлам и исправляет проблемы"""
        self.print_header("ИСПРАВЛЕНИЕ ПРОБЛЕМ В КОДЕ")

        # Исправляем конкретные файлы
        fixes = [
            ("database.py", self.fix_database_key_issue),
            ("test_all_fixes.py", self.fix_test_passwords),
        ]

        for name, fix_func in fixes:
            fix_func()

        # Исправляем trailing whitespace во всех Python файлах
        self.print_header("УДАЛЕНИЕ ПРОБЕЛОВ В КОНЦЕ СТРОК")
        python_files = list(self.root_dir.rglob("*.py")) + list(self.root_dir.rglob("*.pyw"))
        excluded = {'venv', 'env', '__pycache__', '.venv', '.git', 'build', 'dist'}
        python_files = [f for f in python_files if not any(ex in f.parts for ex in excluded)]

        fixed_whitespace = 0
        for file_path in python_files:
            if self.fix_trailing_whitespace(file_path):
                fixed_whitespace += 1

        if fixed_whitespace > 0:
            self.print_success(f"Удалены пробелы в конце строк в {fixed_whitespace} файлах")
        else:
            self.print_info("Пробелов в конце строк не найдено")

        # Создаём вспомогательные файлы
        self.print_header("СОЗДАНИЕ ВСПОМОГАТЕЛЬНЫХ ФАЙЛОВ")
        self.create_example_config()
        self.create_requirements()
        self.create_gitignore()

    def print_summary(self) -> None:
        """Выводит итоговую сводку"""
        print("\n" + "="*60)
        print("📋 ИТОГИ ИСПРАВЛЕНИЙ")
        print("="*60)

        print(f"""
✅ Исправлено: {self.fixed_count} проблем
⚠️ Пропущено: {self.skipped_count} проблем

✅ Что было сделано:
  1. Исправлена опасная передача SQLCipher ключа
  2. Добавлены комментарии к тестовым паролям
  3. Удалены пробелы в конце строк
  4. Создан config.example.json
  5. Создан requirements.txt
  6. Создан .gitignore

⚠️ Оставшиеся предупреждения (не критичны):
  - subprocess вызовы в helpers.py - безопасны, используются для звука
  - pickle usage в find_issues.py - только в анализаторе кода
  - too broad except в некоторых местах - допустимо для fallback обработки
  - debug print в утилитах - нормально для скриптов анализа

📝 Рекомендации:
  1. Установите зависимости: pip install -r requirements.txt
  2. Для production используйте мастер-пароль
  3. Не коммитьте data/config.json в Git
  4. Периодически запускайте find_issues.py для проверки

🎯 Программа готова к запуску!
""")

    def run(self) -> None:
        """Запускает все исправления"""
        print("="*60)
        print("🔧 ИСПРАВЛЕНИЕ НАЙДЕННЫХ ПРОБЛЕМ")
        print("="*60)

        self.fix_all_files()
        self.print_summary()

        print("\nНажмите ENTER для выхода...")
        try:
            input()
        except (KeyboardInterrupt, EOFError):
            pass


def main():
    fixer = IssueFixer()
    fixer.run()


if __name__ == "__main__":
    main()
