#!/usr/bin/env python3
"""
Скрипт для автоматического исправления найденных проблем
Запуск: python fix_issues.py
"""

import os
import re
from pathlib import Path

def fix_database_key_issue():
    """Исправляет опасную передачу SQLCipher ключа"""
    db_path = Path("storage/database.py")
    if not db_path.exists():
        print("❌ database.py not found")
        return False
    
    with open(db_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Паттерн для поиска опасной строки
    old_pattern = r'conn\.execute\(f"PRAGMA key = \'\{_sqlcipher_key_hex\}\'"\)'
    new_code = 'conn.execute("PRAGMA key = ?", (_sqlcipher_key,))'
    
    if re.search(old_pattern, content):
        content = re.sub(old_pattern, new_code, content)
        with open(db_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print("✅ Исправлена опасная передача SQLCipher ключа в database.py")
        return True
    else:
        print("⚠️ Проблема не найдена или уже исправлена")
        return True

def fix_test_passwords():
    """Добавляет комментарии к тестовым паролям"""
    test_path = Path("test_all_fixes.py")
    if not test_path.exists():
        print("❌ test_all_fixes.py not found")
        return False
    
    with open(test_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    # Добавляем комментарий в начало файла
    if lines and not lines[0].startswith('# TEST FILE'):
        lines.insert(0, '# TEST FILE - Contains test passwords for automated testing\n')
        lines.insert(1, '# These are not real passwords, only for testing purposes\n\n')
        
        with open(test_path, 'w', encoding='utf-8') as f:
            f.writelines(lines)
        print("✅ Добавлен комментарий к тестовым паролям")
        return True
    
    print("⚠️ Комментарий уже есть")
    return True

def create_example_config():
    """Создаёт example конфиг если нет"""
    example_path = Path("config.example.json")
    if not example_path.exists():
        example_content = '''{
    "_comment": "Пример конфигурации - скопируйте в data/config.json",
    "THEME": "Dark",
    "LANG": "RU",
    "SOUND": true,
    "RGB": true,
    "RGB_SPEED": "normal",
    "RGB_WIDTH": "normal",
    "RADIUS": 25,
    "font_size": 14,
    "CLIP_TIMEOUT": 60,
    "AUTO_LOCK": false,
    "AUTO_LOCK_TIMEOUT": 5,
    "auto_save": false
}'''
        with open(example_path, 'w', encoding='utf-8') as f:
            f.write(example_content)
        print("✅ Создан config.example.json")
        return True
    return False

def create_requirements():
    """Создаёт requirements.txt если нет"""
    req_path = Path("requirements.txt")
    if not req_path.exists():
        requirements = '''# Secure Pass Pro v4.0 Dependencies
customtkinter>=5.2.0
cryptography>=41.0.0
Pillow>=10.0.0
qrcode>=7.4.0
fpdf>=1.7.2
requests>=2.31.0
argon2-cffi>=21.3.0
# sqlcipher3 - optional, for full database encryption
# pip install sqlcipher3
'''
        with open(req_path, 'w', encoding='utf-8') as f:
            f.write(requirements)
        print("✅ Создан requirements.txt")
        return True
    return False

def main():
    print("="*60)
    print("🔧 ИСПРАВЛЕНИЕ НАЙДЕННЫХ ПРОБЛЕМ")
    print("="*60)
    
    # Исправляем проблемы
    fix_database_key_issue()
    fix_test_passwords()
    create_example_config()
    create_requirements()
    
    print("\n" + "="*60)
    print("📋 ИТОГИ ИСПРАВЛЕНИЙ")
    print("="*60)
    print("""
✅ Исправлено:
  1. Опасная передача SQLCipher ключа в database.py
  2. Добавлены комментарии к тестовым паролям
  3. Создан config.example.json
  4. Создан requirements.txt

⚠️ Остальные предупреждения:
  - subprocess вызовы (helpers.py) - безопасны, используются для звука
  - pickle usage (find_issues.py) - только в анализаторе
  - trailing whitespace - косметические, можно игнорировать
  - too broad except - допустимо для fallback обработки

📝 Рекомендации:
  - Установите зависимости: pip install -r requirements.txt
  - Для production используйте мастер-пароль
  - Не коммитьте data/config.json в Git
""")
    
    print("Нажмите ENTER для выхода...")
    input()

if __name__ == "__main__":
    main()