#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Secure Pass Pro v4.0 — Cryptographically secure password generator
Author: Maxim Melnikov
"""

import sys
import os
import json
import traceback

# Setup logging early
from utils.logger import get_logger, log_crash_report
logger = get_logger("launcher")

# Anti-debugging protection (must be early)
try:
    from security.antidebug import init_anti_debug
    init_anti_debug()
    logger.debug("Anti-debugging initialized")
except ImportError:
    logger.warning("Anti-debug module not available")
except Exception as e:
    logger.error(f"Anti-debug error: {e}")

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    try:
        from gui.main_window import SecurePassPro, CONFIG_FILE
        from security.master import MasterPassword
        import customtkinter as ctk

        logger.info("Starting Secure Pass Pro v4.0")

        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")

        startup_lang = "RU"
        startup_theme = "dark"
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
                if cfg.get("LANG") in ("RU", "EN", "UA"):
                    startup_lang = cfg["LANG"]
                if cfg.get("THEME") == "Light":
                    startup_theme = "light"
                elif cfg.get("THEME") == "Dark":
                    startup_theme = "dark"
                logger.info(f"Loaded config: lang={startup_lang}, theme={startup_theme}")
        except json.JSONDecodeError as e:
            logger.error(f"Config JSON error: {e}")
        except Exception as e:
            logger.error(f"Config load error: {e}")

        if not MasterPassword.prompt_on_startup(startup_lang, startup_theme):
            logger.info("Exit on master password cancel")
            sys.exit(0)

        app = SecurePassPro()
        logger.info("Application started successfully")
        app.mainloop()

    except ImportError as e:
        logger.critical(f"Import error: {e}")
        log_crash_report(e, {"stage": "import"})
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Error", f"Required modules missing!\n\n{str(e)}\n\nMake sure all modules are in place.")
        sys.exit(1)
    except Exception as e:
        logger.critical(f"Unexpected error: {e}")
        log_crash_report(e, {"stage": "main"})
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Critical Error", f"Unexpected error:\n\n{str(e)}\n\nCheck logs for details.")
        sys.exit(1)
