#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Secure Pass Pro v4.0 — Cryptographically secure password generator
Author: Maxim Melnikov
"""

import sys
import os
import json

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    try:
        from gui.main_window import SecurePassPro, CONFIG_FILE
        from security.master import MasterPassword
        import customtkinter as ctk
        
        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")

        startup_lang = "RU"
        startup_theme = "dark"
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
                if cfg.get("LANG") in ("RU", "EN", "UA"):
                    startup_lang = cfg["LANG"]
                if cfg.get("THEME") == "Light":
                    startup_theme = "light"
                elif cfg.get("THEME") == "Dark":
                    startup_theme = "dark"
        except Exception:
            pass

        if not MasterPassword.prompt_on_startup(startup_lang, startup_theme):
            sys.exit(0)
        
        app = SecurePassPro()
        app.mainloop()
    except ImportError as e:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Error", f"Required modules missing!\n\n{str(e)}\n\nMake sure all modules are in place.")
        sys.exit(1)
