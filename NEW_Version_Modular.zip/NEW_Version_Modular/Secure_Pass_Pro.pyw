#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Secure Pass Pro v4.0 — Cryptographically secure password generator
Author: Maxim Melnikov

Secure Pass Pro v4.0 — Криптографически безопасный генератор паролей
Secure Pass Pro v4.0 — Криптографічно безпечний генератор паролів
"""

import sys
import os
import json
import traceback

# Setup logging early / Настройка логирования / Налаштування логування
from utils.logger import get_logger, log_crash_report
logger = get_logger("launcher")

# Anti-debugging protection (must be early) / Анти-отладочная защита / Анти-відлагоджувальний захист
try:
    from security.antidebug import init_anti_debug
    init_anti_debug()
    logger.debug("Anti-debugging initialized")
except ImportError:
    logger.warning("Anti-debug module not available")
except Exception as e:
    logger.error(f"Anti-debug error: {e}")

# Add current directory to path for imports / Добавляем текущую директорию в путь / Додаємо поточну директорію до шляху
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    try:
        from gui.main_window import SecurePassPro, CONFIG_FILE
        from security.master import MasterPassword
        import customtkinter as ctk

        logger.info("Starting Secure Pass Pro v4.0")

        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")

        startup_lang = "RU"
        startup_theme = "dark"
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
                if cfg.get("LANG") in ("RU", "EN", "UA"):
                    startup_lang = cfg["LANG"]
                if cfg.get("THEME") == "Light":
                    startup_theme = "light"
                elif cfg.get("THEME") == "Dark":
                    startup_theme = "dark"
                logger.info(f"Loaded config: lang={startup_lang}, theme={startup_theme}")
        except json.JSONDecodeError as e:
            logger.error(f"Config JSON error: {e}")
        except Exception as e:
            logger.error(f"Config load error: {e}")

        if not MasterPassword.prompt_on_startup(startup_lang, startup_theme):
            logger.info("Exit on master password cancel")
            sys.exit(0)

        app = SecurePassPro()
        logger.info("Application started successfully")
        app.mainloop()

    except ImportError as e:
        logger.critical(f"Import error: {e}")
        log_crash_report(e, {"stage": "import"})
        import tkinter as tk
        from tkinter import messagebox
        
        # Get language for error message / Получаем язык для сообщения об ошибке / Отримуємо мову для повідомлення про помилку
        _error_lang = "RU"
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, "r", encoding="utf-8") as _f:
                    _cfg = json.load(_f)
                if _cfg.get("LANG") in ("RU", "EN", "UA"):
                    _error_lang = _cfg["LANG"]
        except:
            pass
        
        # Error messages in 3 languages / Сообщения об ошибках на 3 языках / Повідомлення про помилки 3 мовами
        if _error_lang == "EN":
            error_title = "Error"
            error_message = f"Required modules missing!\n\n{str(e)}\n\nMake sure all modules are in place."
        elif _error_lang == "UA":
            error_title = "Помилка"
            error_message = f"Відсутні необхідні модулі!\n\n{str(e)}\n\nПереконайтеся, що всі модулі на місці."
        else:  # RU
            error_title = "Ошибка"
            error_message = f"Отсутствуют необходимые модули!\n\n{str(e)}\n\nУбедитесь, что все модули на месте."
        
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(error_title, error_message)
        sys.exit(1)
    except Exception as e:
        logger.critical(f"Unexpected error: {e}")
        log_crash_report(e, {"stage": "main"})
        import tkinter as tk
        from tkinter import messagebox
        
        # Get language for error message / Получаем язык для сообщения об ошибке / Отримуємо мову для повідомлення про помилку
        _error_lang = "RU"
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, "r", encoding="utf-8") as _f:
                    _cfg = json.load(_f)
                if _cfg.get("LANG") in ("RU", "EN", "UA"):
                    _error_lang = _cfg["LANG"]
        except:
            pass
        
        # Error messages in 3 languages / Сообщения об ошибках на 3 языках / Повідомлення про помилки 3 мовами
        if _error_lang == "EN":
            error_title = "Critical Error"
            error_message = f"Unexpected error:\n\n{str(e)}\n\nCheck logs for details."
        elif _error_lang == "UA":
            error_title = "Критична помилка"
            error_message = f"Неочікувана помилка:\n\n{str(e)}\n\nПеревірте логи для деталей."
        else:  # RU
            error_title = "Критическая ошибка"
            error_message = f"Неожиданная ошибка:\n\n{str(e)}\n\nПроверьте логи для деталей."
        
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(error_title, error_message)
        sys.exit(1)