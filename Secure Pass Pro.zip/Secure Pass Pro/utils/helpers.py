"""
Helper functions and utilities with cross-platform support (Windows, Linux, macOS)
Вспомогательные функции и утилиты с кроссплатформенной поддержкой
Допоміжні функції та утиліти з кросплатформеною підтримкою
"""
import os
import sys
import math
import platform
import ctypes
import subprocess
import shutil
import tkinter as tk
import threading
import time
from typing import Optional, Tuple, Dict, Any, List
from functools import lru_cache

_IS_WINDOWS = platform.system() == "Windows"
_IS_MACOS = platform.system() == "Darwin"
_IS_LINUX = platform.system() == "Linux"
_global_radius = 10

# Cache for sound file path
_SOUND_CACHE = None
_SOUND_CACHE_LOCK = threading.Lock()


# ==================== PLATFORM DETECTION ====================

def is_windows() -> bool:
    return _IS_WINDOWS


def is_macos() -> bool:
    return _IS_MACOS


def is_linux() -> bool:
    return _IS_LINUX


def get_platform() -> str:
    """Get platform name / Получить имя платформы / Отримати ім'я платформи"""
    if _IS_WINDOWS:
        return "windows"
    elif _IS_MACOS:
        return "macos"
    else:
        return "linux"


# ==================== RADIUS MANAGEMENT ====================

def get_global_radius() -> int:
    """Get global corner radius"""
    return _global_radius


def set_global_radius(radius: int) -> None:
    """Set global corner radius"""
    global _global_radius
    if radius < 0:
        radius = 0
    if radius > 50:
        radius = 50
    _global_radius = radius


# ==================== WINDOW CENTERING (Cross-platform) ====================

def center_screen(win: tk.Tk, width: int, height: int) -> None:
    """Center window on screen (works on all platforms)"""
    try:
        screen_w = win.winfo_screenwidth()
        screen_h = win.winfo_screenheight()
        x = max(0, (screen_w - width) // 2)
        y = max(0, (screen_h - height) // 2)
        win.geometry(f"{width}x{height}+{x}+{y}")
    except (tk.TclError, AttributeError, RuntimeError) as e:
        print(f"[Helpers] Center screen error: {e}")
        try:
            win.geometry(f"{width}x{height}")
        except (tk.TclError, AttributeError):
            pass


def center_window_relative(parent, child, width: int, height: int) -> None:
    """Center child window relative to parent (cross-platform)
    Центрирует дочернее окно относительно родительского
    Центрує дочірнє вікно відносно батьківського"""
    try:
        # FIXED #33: Force parent to update its layout before getting geometry
        # Исправлено #33: Принудительно обновляем layout родителя перед получением геометрии
        # Виправлено #33: Примусово оновлюємо layout батька перед отриманням геометрії
        parent.update_idletasks()
        
        parent_x = parent.winfo_x()
        parent_y = parent.winfo_y()
        parent_width = parent.winfo_width()
        parent_height = parent.winfo_height()
        x = parent_x + (parent_width - width) // 2
        y = parent_y + (parent_height - height) // 2
        
        screen_width = child.winfo_screenwidth()
        screen_height = child.winfo_screenheight()
        
        if x < 0:
            x = 10
        if y < 30:
            y = 30
        if x + width > screen_width:
            x = screen_width - width - 10
        if y + height > screen_height:
            y = screen_height - height - 10
        
        child.geometry(f"{width}x{height}+{x}+{y}")
    except (tk.TclError, AttributeError, RuntimeError) as e:
        print(f"[Helpers] Center relative error: {e}")
        center_screen(child, width, height)


# ==================== PATHS AND RESOURCES (Cross-platform) ====================

# FIXED #42: Use shared get_base_dir from utils.paths instead of duplicate
# Исправлено #42: Используем общий get_base_dir из utils.paths вместо дублирования
# Виправлено #42: Використовуємо спільний get_base_dir з utils.paths замість дублювання
from utils.paths import get_base_dir


# FIXED #58: Improved get_resource_path with validation and cache invalidation
# Исправлено #58: Улучшен get_resource_path с валидацией и инвалидацией кэша
# Виправлено #58: Покращено get_resource_path з валідацією та інвалідацією кешу
_resource_path_cache = {}
_resource_cache_lock = threading.Lock()


def get_resource_path(filename: str, force_recheck: bool = False) -> str:
    """
    Get path to resource file (works for PyInstaller on all platforms)
    With improved caching that invalidates when file is created.
    
    Получить путь к файлу ресурса (работает для PyInstaller на всех платформах)
    С улучшенным кэшированием, которое инвалидируется при создании файла.
    
    Отримати шлях до файлу ресурсу (працює для PyInstaller на всіх платформах)
    З покращеним кешуванням, яке інвалідується при створенні файлу.
    
    Args:
        filename: Name of the resource file / Имя файла ресурса / Ім'я файлу ресурсу
        force_recheck: Force re-check even if cached / Принудительная перепроверка даже если в кэше / Примусова перевірка навіть якщо в кеші
    
    Returns:
        Path to resource file / Путь к файлу ресурса / Шлях до файлу ресурсу
    """
    global _resource_path_cache
    
    # FIXED #58: Check cache with lock
    # Исправлено #58: Проверяем кэш с блокировкой
    # Виправлено #58: Перевіряємо кеш з блокуванням
    if not force_recheck:
        with _resource_cache_lock:
            if filename in _resource_path_cache:
                cached_path = _resource_path_cache[filename]
                # Validate that cached path still exists
                if os.path.exists(cached_path):
                    return cached_path
                # Cache entry invalid, remove it
                del _resource_path_cache[filename]
    
    try:
        if hasattr(sys, '_MEIPASS'):
            base_dir = sys._MEIPASS
        else:
            base_dir = get_base_dir()
        
        possible_paths = [
            os.path.join(base_dir, filename),
            os.path.join(base_dir, 'resources', filename),
            os.path.join(os.getcwd(), filename),
            os.path.join(os.getcwd(), 'resources', filename),
        ]
        
        # Also check parent directory (for frozen apps)
        if hasattr(sys, '_MEIPASS'):
            parent_dir = os.path.dirname(base_dir)
            possible_paths.append(os.path.join(parent_dir, filename))
            possible_paths.append(os.path.join(parent_dir, 'resources', filename))
        
        for path in possible_paths:
            if os.path.exists(path) and os.path.isfile(path):
                # Cache the valid path
                with _resource_cache_lock:
                    _resource_path_cache[filename] = path
                return path
        
        # Return default path even if not exists
        result = os.path.join(base_dir, filename)
        with _resource_cache_lock:
            _resource_path_cache[filename] = result
        return result
        
    except (AttributeError, TypeError, OSError) as e:
        print(f"[Helpers] Resource path error: {e}")
        return filename


def clear_resource_cache() -> None:
    """Clear the resource path cache (useful during development)
    Очищает кэш путей ресурсов (полезно во время разработки)
    Очищує кеш шляхів ресурсів (корисно під час розробки)"""
    global _resource_path_cache
    with _resource_cache_lock:
        _resource_path_cache.clear()
    print("[Helpers] Resource cache cleared")


# ==================== CROSS-PLATFORM SOUND ====================

def _get_sound_path() -> str:
    """Get sound file path with caching (cross-platform)"""
    global _SOUND_CACHE
    
    with _SOUND_CACHE_LOCK:
        if _SOUND_CACHE is not None:
            return _SOUND_CACHE
        
        possible_paths = []
        base_dir = get_base_dir()
        
        possible_paths.append(get_resource_path("Computer Mouse Click.mp3"))
        possible_paths.append(os.path.join(base_dir, "Computer Mouse Click.mp3"))
        possible_paths.append(os.path.join(base_dir, "resources", "Computer Mouse Click.mp3"))
        possible_paths.append(os.path.join(os.getcwd(), "Computer Mouse Click.mp3"))
        
        if hasattr(sys, '_MEIPASS'):
            possible_paths.append(os.path.join(sys._MEIPASS, "Computer Mouse Click.mp3"))
        
        for path in possible_paths:
            if path and os.path.exists(path) and os.path.isfile(path):
                _SOUND_CACHE = path
                print(f"[Helpers] Sound file found: {path}")
                return path
        
        _SOUND_CACHE = ""
        print("[Helpers] Sound file not found in any location")
        return ""


def play_sound(sound_type: str = "click", sound_enabled: bool = True, 
               base_path: str = None) -> None:
    """Play sound effect (cross-platform: Windows, macOS, Linux)"""
    if not sound_enabled:
        return
    
    file_path = _get_sound_path()
    if not file_path:
        return
    
    try:
        if _IS_WINDOWS:
            _play_sound_windows(file_path)
        elif _IS_MACOS:
            _play_sound_macos(file_path)
        else:
            _play_sound_linux(file_path)
    except (OSError, IOError, subprocess.SubprocessError, RuntimeError) as e:
        print(f"[Helpers] Play sound error: {e}")


def _play_sound_windows(file_path: str) -> None:
    """Play sound on Windows"""
    try:
        winmm = ctypes.windll.winmm
        alias = "app_click"
        
        winmm.mciSendStringW(f'close {alias}', None, 0, 0)
        
        result = winmm.mciSendStringW(
            f'open "{file_path}" type mpegvideo alias {alias}', 
            None, 0, 0
        )
        
        if result == 0:
            winmm.mciSendStringW(f'play {alias} from 0', None, 0, 0)
            
            def close_sound():
                try:
                    winmm.mciSendStringW(f'close {alias}', None, 0, 0)
                except (AttributeError, OSError, TypeError):
                    pass
            
            threading.Timer(1.0, close_sound).start()
            
    except (AttributeError, OSError, TypeError, ValueError) as e:
        print(f"[Helpers] Windows sound error: {e}")


def _play_sound_macos(file_path: str) -> None:
    """Play sound on macOS using afplay"""
    try:
        if shutil.which("afplay"):
            subprocess.Popen(
                ["afplay", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
    except (OSError, subprocess.SubprocessError, FileNotFoundError) as e:
        print(f"[Helpers] macOS sound error: {e}")


def _play_sound_linux(file_path: str) -> None:
    """Play sound on Linux using available players"""
    try:
        if shutil.which("mpg123"):
            subprocess.Popen(
                ["mpg123", "-q", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
        elif shutil.which("ffplay"):
            subprocess.Popen(
                ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
        elif shutil.which("paplay"):
            subprocess.Popen(
                ["paplay", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
        elif shutil.which("aplay"):
            subprocess.Popen(
                ["aplay", file_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
    except (OSError, subprocess.SubprocessError, FileNotFoundError) as e:
        print(f"[Helpers] Linux sound error: {e}")


# ==================== CROSS-PLATFORM WINDOW ROUNDING ====================

def apply_window_rounding(window) -> None:
    """Apply rounded corners (Windows only, no effect on other platforms)"""
    if not _IS_WINDOWS:
        return
    try:
        window.update()
        hwnd = ctypes.windll.user32.GetParent(window.winfo_id())
        if not hwnd:
            hwnd = ctypes.windll.user32.GetAncestor(window.winfo_id(), 2)
        DWMWA_WINDOW_CORNER_PREFERENCE = 33
        DWMWCP_ROUND = 2
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            hwnd,
            DWMWA_WINDOW_CORNER_PREFERENCE,
            ctypes.byref(ctypes.c_int(DWMWCP_ROUND)),
            ctypes.sizeof(ctypes.c_int(DWMWCP_ROUND))
        )
    except (AttributeError, OSError, TypeError, ValueError, tk.TclError) as e:
        print(f"[Helpers] Window rounding error: {e}")


def set_window_icon(window, icon_path: str = None) -> None:
    """Set window icon (cross-platform)"""
    if icon_path is None:
        icon_path = get_resource_path("icon.ico")
    
    if not os.path.exists(icon_path):
        alt_paths = [
            os.path.join(get_base_dir(), "icon.ico"),
            os.path.join(get_base_dir(), "resources", "icon.ico"),
            os.path.join(os.getcwd(), "icon.ico"),
            "icon.ico"
        ]
        for path in alt_paths:
            if os.path.exists(path):
                icon_path = path
                break
        else:
            return
    
    try:
        if _IS_WINDOWS:
            window.iconbitmap(icon_path)
        else:
            try:
                from PIL import Image, ImageTk
                img = Image.open(icon_path)
                if img.width > 256 or img.height > 256:
                    img.thumbnail((256, 256), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(img)
                window.iconphoto(True, photo)
                if hasattr(window, '_icon_image'):
                    window._icon_image = photo
                else:
                    window._icon_image = photo
            except ImportError:
                try:
                    img = tk.PhotoImage(file=icon_path)
                    window.iconphoto(True, img)
                    if hasattr(window, '_icon_image'):
                        window._icon_image = img
                    else:
                        window._icon_image = img
                except (tk.TclError, AttributeError) as e:
                    print(f"[Helpers] Icon photo error: {e}")
    except (tk.TclError, AttributeError, OSError, IOError) as e:
        print(f"[Helpers] Set window icon error: {e}")


# ==================== LINUX/MACOS SPECIFIC FUNCTIONS ====================

def get_system_scaling() -> float:
    """Get system recommended scaling factor (Linux/macOS)"""
    if _IS_WINDOWS:
        return 1.0
    
    try:
        if _IS_MACOS:
            result = subprocess.run(
                ['system_profiler', 'SPDisplaysDataType'],
                capture_output=True, text=True, timeout=2
            )
            if 'Resolution' in result.stdout:
                import re
                match = re.search(r'Resolution: (\d+) x', result.stdout)
                if match:
                    width = int(match.group(1))
                    if width >= 3840:
                        return 2.0
                    elif width >= 2560:
                        return 1.5
                    elif width >= 1920:
                        return 1.25
        
        elif _IS_LINUX:
            result = subprocess.run(
                ['xdpyinfo'],
                capture_output=True, text=True, timeout=2
            )
            if result.returncode == 0:
                import re
                dimensions_line = next(
                    (line for line in result.stdout.splitlines() if 'dimensions:' in line),
                    result.stdout
                )
                match = re.search(r'(\d+)x(\d+)', dimensions_line)
                if match:
                    width = int(match.group(1))
                    if width >= 3840:
                        return 2.0
                    elif width >= 2560:
                        return 1.5
                    elif width >= 1920:
                        return 1.25
    except (subprocess.SubprocessError, FileNotFoundError, TimeoutError, OSError, AttributeError) as e:
        print(f"[Helpers] Scaling detection error: {e}")
    
    try:
        gdk_scale = os.environ.get('GDK_SCALE', '1')
        scale = float(gdk_scale)
        if scale > 0:
            return scale
    except (ValueError, TypeError) as e:
        print(f"[Helpers] GDK scale error: {e}")
    
    return 1.0


def get_linux_desktop_environment() -> str:
    """Get Linux desktop environment name"""
    if not _IS_LINUX:
        return "unknown"
    
    de = os.environ.get('XDG_CURRENT_DESKTOP', '')
    if de:
        return de.lower()
    
    de = os.environ.get('DESKTOP_SESSION', '')
    if de:
        return de.lower()
    
    return "unknown"


def is_wayland() -> bool:
    """Check if running under Wayland (Linux)"""
    if not _IS_LINUX:
        return False
    
    xdg_session_type = os.environ.get('XDG_SESSION_TYPE', '').lower()
    if xdg_session_type == 'wayland':
        return True
    
    wayland_display = os.environ.get('WAYLAND_DISPLAY', '')
    if wayland_display:
        return True
    
    return False


def apply_linux_theme(window) -> None:
    """Apply Linux-specific theme optimizations"""
    if not _IS_LINUX:
        return
    
    try:
        window.attributes('-type', 'dialog')
        
        if is_wayland():
            try:
                window.attributes('-type', 'normal')
            except (tk.TclError, AttributeError):
                pass
        
        de = get_linux_desktop_environment()
        try:
            import customtkinter as ctk
            if 'gnome' in de or 'unity' in de:
                ctk.set_widget_scaling(1.05)
            elif 'kde' in de or 'plasma' in de:
                ctk.set_widget_scaling(1.0)
            else:
                ctk.set_widget_scaling(1.05)
            
            scaling = get_system_scaling()
            if scaling > 1.0:
                ctk.set_widget_scaling(scaling * 0.95)
        except ImportError:
            pass
            
    except (tk.TclError, AttributeError, RuntimeError) as e:
        print(f"[Helpers] Linux theme error: {e}")


def apply_macos_theme(window) -> None:
    """Apply macOS-specific theme optimizations"""
    if not _IS_MACOS:
        return
    
    try:
        import customtkinter as ctk
        scaling = get_system_scaling()
        if scaling > 1.0:
            ctk.set_widget_scaling(scaling)
            ctk.set_window_scaling(scaling)
    except (ImportError, AttributeError, RuntimeError) as e:
        print(f"[Helpers] macOS theme error: {e}")


# ==================== SYSTEM FUNCTIONS (Cross-platform) ====================

def get_screen_size() -> Tuple[int, int]:
    """Get screen size (width, height) - cross-platform"""
    try:
        root = tk.Tk()
        root.withdraw()
        width = root.winfo_screenwidth()
        height = root.winfo_screenheight()
        root.destroy()
        return (width, height)
    except (tk.TclError, RuntimeError, AttributeError) as e:
        print(f"[Helpers] Get screen size error: {e}")
        return (1920, 1080)


def is_admin() -> bool:
    """Check if running as administrator (Windows only)"""
    if not _IS_WINDOWS:
        return False
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except (AttributeError, OSError, TypeError) as e:
        print(f"[Helpers] Admin check error: {e}")
        return False


def get_platform_info() -> Dict[str, Any]:
    """Get detailed platform information (cross-platform)"""
    info = {
        'system': platform.system(),
        'release': platform.release(),
        'version': platform.version(),
        'machine': platform.machine(),
        'processor': platform.processor(),
        'python_version': sys.version,
        'is_admin': is_admin() if _IS_WINDOWS else False,
        'is_64bit': sys.maxsize > 2**32,
    }
    
    if _IS_LINUX:
        info['desktop_environment'] = get_linux_desktop_environment()
        info['is_wayland'] = is_wayland()
        info['scaling'] = get_system_scaling()
    elif _IS_MACOS:
        info['scaling'] = get_system_scaling()
    elif _IS_WINDOWS:
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion")
            info['windows_version'] = winreg.QueryValueEx(key, "ProductName")[0]
            winreg.CloseKey(key)
        except (ImportError, OSError, WindowsError, TypeError) as e:
            print(f"[Helpers] Windows version detection error: {e}")
    
    return info


# ==================== HELPER UTILITIES ====================

def format_time(seconds: int) -> str:
    """Format seconds into human readable string"""
    if seconds < 0:
        return "0 сек"
    elif seconds < 60:
        return f"{seconds} сек"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes} мин"
    elif seconds < 86400:
        hours = seconds // 3600
        return f"{hours} ч"
    else:
        days = seconds // 86400
        return f"{days} дн"


def truncate_string(text: str, max_length: int = 50, suffix: str = "...") -> str:
    """Truncate string to max length"""
    if not text:
        return ""
    if len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix


def is_valid_filename(filename: str) -> bool:
    """Check if filename is valid (cross-platform)"""
    if not filename:
        return False
    # Invalid characters across platforms
    invalid_chars = '<>:"/\\|?*'
    return not any(c in invalid_chars for c in filename)


def ensure_dir(path: str) -> bool:
    """Ensure directory exists, create if not (cross-platform)"""
    try:
        os.makedirs(path, exist_ok=True)
        # On Unix, set secure permissions
        if not _IS_WINDOWS:
            os.chmod(path, 0o700)
        return True
    except (PermissionError, OSError, IOError) as e:
        print(f"[Helpers] Failed to create directory {path}: {e}")
        return False


def get_file_size_mb(file_path: str) -> float:
    """Get file size in megabytes"""
    try:
        size = os.path.getsize(file_path)
        return size / (1024 * 1024)
    except (OSError, IOError, PermissionError) as e:
        print(f"[Helpers] File size error: {e}")
        return 0.0


def safe_remove_file(file_path: str, max_attempts: int = 3) -> bool:
    """Safely remove file with retries (cross-platform)"""
    for attempt in range(max_attempts):
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
            return True
        except (PermissionError, OSError, IOError) as e:
            if attempt == max_attempts - 1:
                print(f"[Helpers] Failed to remove file {file_path}: {e}")
                return False
            time.sleep(0.1 * (attempt + 1))
    return False


# FIXED #43: Shared center_window_relative function
# Исправлено #43: Общая функция center_window_relative
# Виправлено #43: Спільна функція center_window_relative
# (Already defined above)


# Export main functions
__all__ = [
    'get_global_radius',
    'set_global_radius',
    'center_screen',
    'center_window_relative',
    'get_resource_path',
    'clear_resource_cache',
    'play_sound',
    'is_windows',
    'is_macos',
    'is_linux',
    'get_platform',
    'apply_window_rounding',
    'set_window_icon',
    'get_screen_size',
    'is_admin',
    'get_platform_info',
    'get_system_scaling',
    'get_linux_desktop_environment',
    'is_wayland',
    'apply_linux_theme',
    'apply_macos_theme',
    'format_time',
    'truncate_string',
    'is_valid_filename',
    'ensure_dir',
    'get_file_size_mb',
    'safe_remove_file',
    'get_base_dir',  # Re-export for convenience
]