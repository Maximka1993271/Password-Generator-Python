"""
Logging subsystem for SecurePassPro with sensitive data filtering
FIXED: Полная фильтрация конфиденциальных данных, JSON logs, structured logging
FIXED: Устранён циклический импорт путей
FIXED #40: Fixed overly aggressive base64 regex pattern
FIXED #41: Centralized logging - all modules now use this unified logger

Подсистема логирования для SecurePassPro с фильтрацией конфиденциальных данных
FIXED: Полная фильтрация конфиденциальных данных, JSON logs, structured logging
FIXED: Устранён циклический импорт путей
FIXED #40: Исправлен слишком агрессивный regex-паттерн для base64
FIXED #41: Централизованное логирование - все модули теперь используют этот унифицированный логгер

Підсистема логування для SecurePassPro з фільтрацією конфіденційних даних
FIXED: Повна фільтрація конфіденційних даних, JSON logs, structured logging
FIXED: Усунуто циклічний імпорт шляхів
FIXED #40: Виправлено надто агресивний regex-патерн для base64
FIXED #41: Централізоване логування - всі модулі тепер використовують цей уніфікований логер
"""
import os
import sys
import logging
import logging.handlers
import re
import tempfile
import json
from datetime import datetime
from typing import Optional, List, Pattern, Dict, Any, Union
from enum import Enum

# ==================== PATTERNS FOR FILTERING / ПАТТЕРНЫ ДЛЯ ФИЛЬТРАЦИИ / ПАТЕРНИ ДЛЯ ФІЛЬТРАЦІЇ ====================

# Patterns for searching confidential data
# Паттерны для поиска конфиденциальных данных
# Патерни для пошуку конфіденційних даних
SENSITIVE_PATTERNS: List[tuple] = [
    # Master password / Мастер-пароль / Майстер-пароль
    (r'(master["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[MASTER_PASSWORD_FILTERED]\3'),
    (r'(master_password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[MASTER_PASSWORD_FILTERED]\3'),
    (r'(master_pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[MASTER_PASSWORD_FILTERED]\3'),
    
    # Password (general) / Пароль (общий) / Пароль (загальний)
    (r'(password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(pass["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(new_pwd["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(new_password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    (r'(old_password["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PASSWORD_FILTERED]\3'),
    
    # Encryption keys / Ключи шифрования / Ключі шифрування
    (r'(key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[KEY_FILTERED]\3'),
    (r'(encryption_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[ENCRYPTION_KEY_FILTERED]\3'),
    (r'(private_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PRIVATE_KEY_FILTERED]\3'),
    (r'(secret_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[SECRET_KEY_FILTERED]\3'),
    (r'(api_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[API_KEY_FILTERED]\3'),
    (r'(token["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[TOKEN_FILTERED]\3'),
    (r'(_sqlcipher_key["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[SQLCIPHER_KEY_FILTERED]\3'),
    
    # TOTP secrets / Секреты TOTP / Секрети TOTP
    (r'(totp_secret["\s]*[:=][\s]*["\']?)([A-Z2-7]{10,})(["\']?)', r'\1[TOTP_SECRET_FILTERED]\3'),
    (r'(2fa_secret["\s]*[:=][\s]*["\']?)([A-Z2-7]{10,})(["\']?)', r'\1[TOTP_SECRET_FILTERED]\3'),
    (r'(backup_code["\s]*[:=][\s]*["\']?)([A-Z0-9\-]{8,})(["\']?)', r'\1[BACKUP_CODE_FILTERED]\3'),
    
    # Secrets / Секреты / Секрети
    (r'(secret["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[SECRET_FILTERED]\3'),
    
    # Salt / Соль / Сіль
    (r'(salt["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[SALT_FILTERED]\3'),
    
    # FIXED #40: More specific base64 detection - only for actual base64-looking data
    # Исправлено #40: Более специфичное определение base64 - только для данных похожих на base64
    # Виправлено #40: Більш специфічне визначення base64 - тільки для даних схожих на base64
    # Pattern for base64 encoded data (common in tokens, keys)
    # Паттерн для base64 данных (обычно в токенах, ключах)
    # Патерн для base64 даних (зазвичай в токенах, ключах)
    (r'([A-Za-z0-9+/]{40,}={0,2})', '[BASE64_DATA_FILTERED]', re.IGNORECASE),
    
    # FIXED #40: More specific hash detection - only for actual hash-looking strings
    # Исправлено #40: Более специфичное определение хешей - только для строк похожих на хеши
    # Виправлено #40: Більш специфічне визначення хешів - тільки для рядків схожих на хеші
    # Pattern for SHA-256 hashes (64 hex characters) - very specific
    # Паттерн для SHA-256 хешей (64 hex символа) - очень специфичный
    # Патерн для SHA-256 хешів (64 hex символи) - дуже специфічний
    (r'\b[0-9a-f]{64}\b', '[HASH_DATA_FILTERED]', re.IGNORECASE),
    # Pattern for SHA-1 hashes (40 hex characters)
    # Паттерн для SHA-1 хешей (40 hex символов)
    # Патерн для SHA-1 хешів (40 hex символів)
    (r'\b[0-9a-f]{40}\b', '[HASH_DATA_FILTERED]', re.IGNORECASE),
    
    # Private keys PEM / Приватные ключи PEM / Приватні ключі PEM
    (r'(-----BEGIN[^-]+PRIVATE KEY-----.*?-----END[^-]+PRIVATE KEY-----)', '[PRIVATE_KEY_BLOCK_FILTERED]', re.DOTALL),
    (r'(-----BEGIN[^-]+RSA PRIVATE KEY-----.*?-----END[^-]+RSA PRIVATE KEY-----)', '[RSA_KEY_BLOCK_FILTERED]', re.DOTALL),
    
    # Login data / Данные для входа / Дані для входу
    (r'(login["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[LOGIN_FILTERED]\3'),
    (r'(username["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[USERNAME_FILTERED]\3'),
    (r'(user["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[USERNAME_FILTERED]\3'),
    (r'(email["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[EMAIL_FILTERED]\3'),
    
    # Decrypted content / Расшифрованный контент / Розшифрований вміст
    (r'(decrypted["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[DECRYPTED_FILTERED]\3'),
    (r'(plaintext["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[PLAINTEXT_FILTERED]\3'),
    
    # Authorization tokens / Токены авторизации / Токени авторизації
    (r'(Bearer\s+)([A-Za-z0-9\-_]+)', r'\1[BEARER_TOKEN_FILTERED]'),
    (r'(Authorization["\s]*[:=][\s]*["\']?)([^"\'\s]{4,})(["\']?)', r'\1[AUTH_TOKEN_FILTERED]\3'),
    
    # Credit card data / Данные кредитных карт / Дані кредитних карток
    (r'\b(?:\d[ -]*?){13,16}\b', '[CREDIT_CARD_FILTERED]'),
    
    # Session IDs / Сессионные ID / Сесійні ID
    (r'(session["\s]*[:=][\s]*["\']?)([a-f0-9]{32,})(["\']?)', r'\1[SESSION_ID_FILTERED]\3'),
    (r'(session_id["\s]*[:=][\s]*["\']?)([a-f0-9]{32,})(["\']?)', r'\1[SESSION_ID_FILTERED]\3'),
]


class LogLevel(Enum):
    """Logging levels / Уровни логирования / Рівні логування"""
    DEBUG = logging.DEBUG
    INFO = logging.INFO
    WARNING = logging.WARNING
    ERROR = logging.ERROR
    CRITICAL = logging.CRITICAL


class SensitiveDataFilter(logging.Filter):
    """Filter to remove confidential data from logs
    Фильтр для удаления конфиденциальных данных из логов
    Фільтр для видалення конфіденційних даних з логів"""
    
    _compiled_patterns: List[tuple] = None
    _max_string_length = 2000
    
    @classmethod
    def _get_patterns(cls) -> List[tuple]:
        if cls._compiled_patterns is None:
            cls._compiled_patterns = []
            for pattern_tuple in SENSITIVE_PATTERNS:
                try:
                    # Check if pattern has 3 elements (including flags) or 2
                    if len(pattern_tuple) == 3:
                        pattern, replacement, flags = pattern_tuple
                        cls._compiled_patterns.append((
                            re.compile(pattern, flags | re.IGNORECASE),
                            replacement
                        ))
                    else:
                        pattern, replacement = pattern_tuple
                        cls._compiled_patterns.append((
                            re.compile(pattern, re.IGNORECASE | re.DOTALL),
                            replacement
                        ))
                except re.error as e:
                    print(f"[Logger] Invalid regex pattern: {e}")
        return cls._compiled_patterns
    
    def _filter_string(self, text: str) -> str:
        if not text or len(text) < 4:
            return text
        
        if len(text) > self._max_string_length:
            text = text[:self._max_string_length] + "...[TRUNCATED]"
        
        result = text
        for pattern, replacement in self._get_patterns():
            try:
                result = pattern.sub(replacement, result)
            except (re.error, TypeError, AttributeError) as e:
                continue
        return result
    
    def _filter_traceback(self, text: str) -> str:
        if not text:
            return text
        
        lines = text.split('\n')
        filtered_lines = []
        
        for line in lines:
            skip = False
            dangerous_patterns = [
                r'password\s*=',
                r'pwd\s*=',
                r'master\s*=',
                r'key\s*=',
                r'secret\s*=',
                r'token\s*=',
                r'decrypt',
                r'plaintext',
                r'totp',
                r'2fa',
            ]
            for pattern in dangerous_patterns:
                try:
                    if re.search(pattern, line, re.IGNORECASE):
                        skip = True
                        filtered_lines.append('[SENSITIVE_LINE_REMOVED]')
                        break
                except re.error:
                    continue
            
            if not skip:
                filtered_lines.append(self._filter_string(line))
        
        return '\n'.join(filtered_lines)
    
    def filter(self, record: logging.LogRecord) -> bool:
        if hasattr(record, 'msg') and record.msg:
            if isinstance(record.msg, str):
                if 'Traceback' in record.msg or 'File "' in record.msg:
                    record.msg = self._filter_traceback(record.msg)
                else:
                    record.msg = self._filter_string(record.msg)
            elif isinstance(record.msg, Exception):
                record.msg = type(record.msg).__name__
        
        # Filter arguments / Фильтрация аргументов / Фільтрація аргументів
        if hasattr(record, 'args') and record.args:
            try:
                filtered_args = []
                for arg in record.args:
                    if isinstance(arg, str):
                        filtered_args.append(self._filter_string(arg))
                    else:
                        filtered_args.append(arg)
                record.args = tuple(filtered_args)
            except (TypeError, AttributeError):
                pass
        
        return True


class SensitiveDataFormatter(logging.Formatter):
    """Formatter with sensitive data filtering
    Форматтер с фильтрацией конфиденциальных данных
    Форматер з фільтрацією конфіденційних даних"""
    
    def __init__(self, fmt=None, datefmt=None, style='%'):
        super().__init__(fmt, datefmt, style)
        self.filter_obj = SensitiveDataFilter()
    
    def format(self, record: logging.LogRecord) -> str:
        try:
            self.filter_obj.filter(record)
            return super().format(record)
        except (TypeError, ValueError, AttributeError) as e:
            return f"[FORMATTER_ERROR: {e}]"


class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logs
    JSON форматер для структурированных логов
    JSON форматер для структурованих логів"""
    
    def __init__(self, include_extra: bool = True):
        super().__init__()
        self.include_extra = include_extra
        self.filter_obj = SensitiveDataFilter()
    
    def format(self, record: logging.LogRecord) -> str:
        try:
            log_entry = {
                "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S.%fZ"),
                "level": record.levelname,
                "logger": record.name,
                "message": record.getMessage(),
                "module": record.module,
                "function": record.funcName,
                "line": record.lineno,
            }
            
            # Filter message / Фильтрация сообщения / Фільтрація повідомлення
            if "message" in log_entry:
                log_entry["message"] = self.filter_obj._filter_string(log_entry["message"])
            
            if self.include_extra and hasattr(record, 'extra'):
                extra = getattr(record, 'extra', {})
                if isinstance(extra, dict):
                    filtered_extra = {}
                    for key, value in extra.items():
                        if isinstance(value, str):
                            filtered_extra[key] = self.filter_obj._filter_string(value)
                        else:
                            filtered_extra[key] = value
                    log_entry["extra"] = filtered_extra
            
            if hasattr(record, 'exc_info') and record.exc_info:
                import traceback
                tb = traceback.format_exception(*record.exc_info)
                log_entry["exception"] = self.filter_obj._filter_traceback(''.join(tb))
            
            return json.dumps(log_entry, ensure_ascii=False)
        except (TypeError, ValueError, AttributeError) as e:
            return f'{{"error": "JSON formatting failed: {e}"}}'


class SecureLogger:
    """
    Centralized logger manager for the entire application.
    All modules should use get_logger() from this module.
    
    Централизованный менеджер логгера для всего приложения.
    Все модули должны использовать get_logger() из этого модуля.
    
    Централізований менеджер логера для всього додатку.
    Всі модулі повинні використовувати get_logger() з цього модуля.
    """
    
    _instance = None
    _initialized = False
    
    LOG_DIR = "logs"
    MAX_LOG_SIZE = 5 * 1024 * 1024
    BACKUP_COUNT = 5
    
    # Logging modes / Режимы логирования / Режими логування
    _json_mode = False
    _debug_mode = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._setup_logging()
        self._initialized = True
    
    @classmethod
    def set_json_mode(cls, enabled: bool) -> None:
        """Enable/disable JSON log format / Включить/выключить JSON формат логов / Увімкнути/вимкнути JSON формат логів"""
        cls._json_mode = enabled
        if cls._instance:
            cls._instance._reconfigure_handlers()
    
    @classmethod
    def set_debug_mode(cls, enabled: bool) -> None:
        """Enable/disable DEBUG level / Включить/выключить DEBUG уровень / Увімкнути/вимкнути DEBUG рівень"""
        cls._debug_mode = enabled
        if cls._instance:
            cls._instance._reconfigure_handlers()
    
    def _reconfigure_handlers(self) -> None:
        """Reconfigure handlers when mode changes
        Перенастраивает обработчики при изменении режима
        Переналаштовує обробники при зміні режиму"""
        root_logger = logging.getLogger()
        for handler in root_logger.handlers:
            if isinstance(handler, logging.Handler):
                if self._json_mode and isinstance(handler, logging.handlers.RotatingFileHandler):
                    handler.setFormatter(JSONFormatter())
                elif not self._json_mode and isinstance(handler, logging.handlers.RotatingFileHandler):
                    handler.setFormatter(SensitiveDataFormatter(
                        '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S'
                    ))
                
                if self._debug_mode:
                    handler.setLevel(logging.DEBUG)
                else:
                    handler.setLevel(logging.INFO)
    
    def _get_log_path(self) -> str:
        """Get path to log file without circular import
        Получить путь к лог-файлу без циклического импорта
        Отримати шлях до лог-файлу без циклічного імпорту"""
        # Determine base directory manually / Определяем базовую директорию вручную / Визначаємо базову директорію вручну
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
        log_dir = os.path.join(base_dir, "logs")
        
        if sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.kernel32.SetFileAttributesW(log_dir, 0x02)
            except (ImportError, AttributeError, OSError) as e:
                pass
        
        return os.path.join(log_dir, "securepasspro.log")
    
    def _setup_logging(self) -> None:
        """Setup logging with file rotation and console output
        Настройка логирования с ротацией файлов и выводом в консоль
        Налаштування логування з ротацією файлів та виведенням у консоль"""
        log_path = self._get_log_path()
        
        try:
            file_handler = logging.handlers.RotatingFileHandler(
                log_path,
                maxBytes=self.MAX_LOG_SIZE,
                backupCount=self.BACKUP_COUNT,
                encoding='utf-8'
            )
            
            if self._json_mode:
                file_handler.setFormatter(JSONFormatter())
            else:
                file_handler.setFormatter(SensitiveDataFormatter(
                    '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S'
                ))
            
            file_handler.setLevel(logging.DEBUG if self._debug_mode else logging.INFO)
            
        except (PermissionError, OSError, IOError) as e:
            temp_log = os.path.join(tempfile.gettempdir(), "securepasspro.log")
            try:
                file_handler = logging.handlers.RotatingFileHandler(
                    temp_log,
                    maxBytes=self.MAX_LOG_SIZE,
                    backupCount=self.BACKUP_COUNT,
                    encoding='utf-8'
                )
                file_handler.setFormatter(SensitiveDataFormatter(
                    '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S'
                ))
                file_handler.setLevel(logging.DEBUG if self._debug_mode else logging.INFO)
                print(f"[Logger] Using fallback log: {temp_log}")
            except (PermissionError, OSError, IOError) as e2:
                print(f"[Logger] Cannot create log file: {e2}")
                return
        
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.WARNING)
        console_handler.setFormatter(SensitiveDataFormatter(
            '%(levelname)s | %(name)s | %(message)s'
        ))
        
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.DEBUG if self._debug_mode else logging.INFO)
        
        # Remove existing handlers to avoid duplicates
        # Удаляем существующие обработчики, чтобы избежать дублирования
        # Видаляємо існуючі обробники, щоб уникнути дублювання
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)
        
        root_logger.addHandler(file_handler)
        
        # Add console handler only in development mode (non-frozen)
        # Добавляем консольный обработчик только в режиме разработки (не frozen)
        # Додаємо консольний обробник тільки в режимі розробки (не frozen)
        if not getattr(sys, 'frozen', False):
            root_logger.addHandler(console_handler)
        
        # Initial log entry / Начальная запись в лог / Початковий запис у лог
        logging.info("=" * 50)
        logging.info("Secure Pass Pro v4.0 starting")
        logging.info(f"Log file: {log_path}")
        logging.info(f"JSON mode: {self._json_mode}")
        logging.info(f"Debug mode: {self._debug_mode}")
        logging.info(f"Python version: {sys.version}")
        logging.info(f"Platform: {sys.platform}")
        logging.info(f"Frozen: {getattr(sys, 'frozen', False)}")
        logging.info("=" * 50)
    
    def get_logger(self, name: str) -> logging.Logger:
        """Get a logger instance for the given module name
        Получить экземпляр логгера для указанного имени модуля
        Отримати екземпляр логера для вказаної назви модуля"""
        return logging.getLogger(name)


# ==================== GLOBAL LOGGER INSTANCE / ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР ЛОГГЕРА / ГЛОБАЛЬНИЙ ЕКЗЕМПЛЯР ЛОГЕРА ====================

_logger_instance = None


def get_logger(name: str) -> logging.Logger:
    """
    Return configured logger for any module.
    This is the SINGLE entry point for all logging in the application.
    
    Возвращает настроенный логгер для любого модуля.
    Это ЕДИНСТВЕННАЯ точка входа для всего логирования в приложении.
    
    Повертає налаштований логер для будь-якого модуля.
    Це ЄДИНА точка входу для всього логування в додатку.
    
    Args:
        name: Module name (usually __name__) / Имя модуля (обычно __name__) / Ім'я модуля (зазвичай __name__)
    
    Returns:
        Configured logger instance / Настроенный экземпляр логгера / Налаштований екземпляр логера
    """
    global _logger_instance
    if _logger_instance is None:
        _logger_instance = SecureLogger()
    return _logger_instance.get_logger(name)


def log_exception(logger: logging.Logger, e: Exception, context: str = "") -> None:
    """
    Log exception with filtering.
    Логирует исключение с фильтрацией.
    Логує виняток з фільтрацією.
    
    Args:
        logger: Logger instance / Экземпляр логгера / Екземпляр логера
        e: Exception to log / Исключение для логирования / Виняток для логування
        context: Additional context information / Дополнительная информация / Додаткова інформація
    """
    import traceback
    error_msg = str(e)
    filter_obj = SensitiveDataFilter()
    filtered_msg = filter_obj._filter_string(error_msg[:500])
    logger.error(f"Exception in {context}: {type(e).__name__}: {filtered_msg}")
    tb = traceback.format_exc()
    filtered_tb = filter_obj._filter_traceback(tb)
    logger.debug(filtered_tb[:2000])


def log_crash_report(error: Exception, context: dict = None) -> None:
    """
    Create crash report file.
    
    Создаёт отчёт о краше.
    Створює звіт про краш.
    
    Args:
        error: Exception that caused the crash / Исключение, вызвавшее краш / Виняток, що викликав краш
        context: Additional context dictionary / Дополнительный контекст / Додатковий контекст
    """
    # Determine logs folder manually / Определяем папку логов вручную / Визначаємо папку логів вручну
    if getattr(sys, 'frozen', False):
        base_dir = os.path.dirname(sys.executable)
    else:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    crash_dir = os.path.join(base_dir, "logs")
    
    try:
        os.makedirs(crash_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        crash_file = os.path.join(crash_dir, f"crash_{timestamp}.log")
        
        import traceback
        filter_obj = SensitiveDataFilter()
        
        with open(crash_file, 'w', encoding='utf-8') as f:
            f.write("=" * 60 + "\n")
            f.write("SECURE PASS PRO - CRASH REPORT\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"Time: {datetime.now().isoformat()}\n")
            f.write(f"Python: {sys.version}\n")
            f.write(f"Platform: {sys.platform}\n\n")
            
            if context:
                f.write("CONTEXT:\n")
                sensitive_keys = ['password', 'master', 'key', 'secret', 'token', 
                                  'pwd', 'pass', 'decrypted', 'plaintext', 'salt',
                                  'totp', '2fa', 'backup_code']
                for key, value in context.items():
                    if key.lower() not in sensitive_keys:
                        if isinstance(value, str):
                            value = filter_obj._filter_string(value[:200])
                        f.write(f"  {key}: {value}\n")
                f.write("\n")
            
            f.write("ERROR:\n")
            error_msg = str(error)[:500]
            filtered_error = filter_obj._filter_string(error_msg)
            f.write(f"  {type(error).__name__}: {filtered_error}\n\n")
            
            f.write("TRACEBACK:\n")
            tb = traceback.format_exc()
            filtered_tb = filter_obj._filter_traceback(tb)
            if len(filtered_tb) > 5000:
                filtered_tb = filtered_tb[:5000] + "\n... [TRUNCATED]"
            f.write(filtered_tb)
            f.write("\n")
            f.write("=" * 60 + "\n")
        
        # Log via standard logger / Логируем через стандартный логгер / Логуємо через стандартний логер
        try:
            logging.error(f"Crash report saved to: {crash_file}")
        except (NameError, RuntimeError):
            print(f"Crash report saved to: {crash_file}")
        
    except (OSError, IOError, PermissionError) as e:
        try:
            logging.error(f"Failed to create crash report: {e}")
        except (NameError, RuntimeError):
            print(f"Failed to create crash report: {e}")


def is_sensitive_string(text: str) -> bool:
    """
    Check if string contains sensitive data.
    
    Проверяет, содержит ли строка чувствительные данные.
    Перевіряє, чи містить рядок чутливі дані.
    
    Args:
        text: String to check / Строка для проверки / Рядок для перевірки
    
    Returns:
        True if sensitive data detected / True если обнаружены чувствительные данные / True якщо виявлено чутливі дані
    """
    if not text or len(text) < 4:
        return False
    
    for pattern_tuple in SENSITIVE_PATTERNS:
        try:
            if len(pattern_tuple) == 3:
                pattern, _, flags = pattern_tuple
                if re.search(pattern, text, flags | re.IGNORECASE):
                    return True
            else:
                pattern, _ = pattern_tuple
                if re.search(pattern, text, re.IGNORECASE):
                    return True
        except re.error:
            continue
    
    return False


def redact_sensitive(text: str) -> str:
    """
    Remove sensitive data from string.
    
    Удаляет чувствительные данные из строки.
    Видаляє чутливі дані з рядка.
    
    Args:
        text: String to redact / Строка для редактирования / Рядок для редагування
    
    Returns:
        Redacted string / Отредактированная строка / Відредагований рядок
    """
    if not text:
        return text
    
    filter_obj = SensitiveDataFilter()
    return filter_obj._filter_string(text)


def sanitize_log_message(message: str) -> str:
    """
    Clean log message from sensitive data (simplified version).
    
    Очищает сообщение лога от чувствительных данных (упрощённая версия).
    Очищує повідомлення логу від чутливих даних (спрощена версія).
    
    Args:
        message: Log message / Сообщение лога / Повідомлення логу
    
    Returns:
        Sanitized message / Очищенное сообщение / Очищене повідомлення
    """
    if not message:
        return message
    
    try:
        message = re.sub(r'(password|pwd|pass)[\s]*[:=][\s]*["\']?[^"\'\s]{2,}["\']?', 
                         r'\1=[REDACTED]', message, flags=re.IGNORECASE)
        message = re.sub(r'(key|secret|token)[\s]*[:=][\s]*["\']?[^"\'\s]{4,}["\']?', 
                         r'\1=[REDACTED]', message, flags=re.IGNORECASE)
        message = re.sub(r'master[\s]*[:=][\s]*["\']?[^"\'\s]{2,}["\']?', 
                         r'master=[REDACTED]', message, flags=re.IGNORECASE)
        message = re.sub(r'(totp|2fa)[\s]*[:=][\s]*["\']?[A-Z2-7]{10,}["\']?', 
                         r'\1=[REDACTED]', message, flags=re.IGNORECASE)
    except re.error as e:
        pass
    
    return message


def enable_json_logs() -> None:
    """Enable JSON log format / Включает JSON формат логов / Увімкнює JSON формат логів"""
    SecureLogger.set_json_mode(True)


def enable_debug_logs() -> None:
    """Enable DEBUG log level / Включает DEBUG уровень логов / Увімкнює DEBUG рівень логів"""
    SecureLogger.set_debug_mode(True)


def disable_json_logs() -> None:
    """Disable JSON log format / Выключает JSON формат логов / Вимкає JSON формат логів"""
    SecureLogger.set_json_mode(False)


def disable_debug_logs() -> None:
    """Disable DEBUG log level / Выключает DEBUG уровень логов / Вимкає DEBUG рівень логів"""
    SecureLogger.set_debug_mode(False)


def get_log_level() -> LogLevel:
    """Return current log level / Возвращает текущий уровень логирования / Повертає поточний рівень логування"""
    root_logger = logging.getLogger()
    level = root_logger.getEffectiveLevel()
    for lvl in LogLevel:
        if lvl.value == level:
            return lvl
    return LogLevel.INFO


def get_logger_status() -> Dict[str, Any]:
    """Get current logger status for debugging
    Получить текущий статус логгера для отладки
    Отримати поточний статус логера для налагодження"""
    root_logger = logging.getLogger()
    return {
        "json_mode": SecureLogger._json_mode,
        "debug_mode": SecureLogger._debug_mode,
        "log_level": get_log_level().name,
        "handlers": [str(h) for h in root_logger.handlers],
        "log_file": SecureLogger()._get_log_path() if SecureLogger._instance else "Not initialized"
    }


# ==================== EXPORTS / ЭКСПОРТЫ / ЕКСПОРТИ ====================

__all__ = [
    # Main logging functions
    'get_logger',
    'log_exception',
    'log_crash_report',
    # Sensitive data helpers
    'is_sensitive_string',
    'redact_sensitive',
    'sanitize_log_message',
    # Classes
    'SecureLogger',
    'SensitiveDataFilter',
    'SensitiveDataFormatter',
    'JSONFormatter',
    'LogLevel',
    # Configuration functions
    'enable_json_logs',
    'enable_debug_logs',
    'disable_json_logs',
    'disable_debug_logs',
    'get_log_level',
    'get_logger_status',
]