"""
Password database storage with SQLite
PORTABLE VERSION - database is stored in the program's folder
Works from any location: USB flash drive, C:\\, D:\\, desktop
3 LANGUAGE SUPPORT: RU, EN, UA

FIXED #41: Use unified logger from utils.logger
FIXED #23: Added localization support for "No label" text
FIXED #24: DB_PATH computed lazily, not at module import
FIXED #25: Added WAL mode for better concurrency

Хранилище паролей с SQLite
ПОРТАТИВНАЯ ВЕРСИЯ - база данных хранится в папке с программой
Работает с любого места: флешка, диск C:\\, D:\\, рабочий стол
ПОДДЕРЖКА 3 ЯЗЫКОВ: RU, EN, UA

Исправлено #41: Используем унифицированный логгер из utils.logger
Исправлено #23: Добавлена поддержка локализации для текста "Без метки"
Исправлено #24: DB_PATH вычисляется лениво, не при импорте модуля
Исправлено #25: Добавлен WAL режим для лучшей конкурентности

Сховище паролів з SQLite
ПОРТАТИВНА ВЕРСІЯ - база даних зберігається в папці з програмою
Працює з будь-якого місця: флешка, диск C:\\, D:\\, робочий стіл
ПІДТРИМКА 3 МОВ: RU, EN, UA

Виправлено #41: Використовуємо уніфікований логер з utils.logger
Виправлено #23: Додано підтримку локалізації для тексту "Без мітки"
Виправлено #24: DB_PATH обчислюється ліниво, не при імпорті модуля
Виправлено #25: Додано WAL режим для кращої конкурентності
"""
import os
import sys
import sqlite3
import datetime
import threading
import shutil
import json
import time
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, asdict

# ==================== UNIFIED LOGGER / УНИФИЦИРОВАННЫЙ ЛОГГЕР / УНІФІКОВАНИЙ ЛОГЕР ====================
# FIXED #41: Use unified logger from utils.logger with fallback
# Исправлено #41: Используем унифицированный логгер из utils.logger с fallback
# Виправлено #41: Використовуємо уніфікований логер з utils.logger з fallback
try:
    from utils.logger import get_logger
except ImportError:
    # Fallback logger for when utils.logger is not available
    # Fallback логгер для случаев, когда utils.logger недоступен
    # Fallback логер для випадків, коли utils.logger недоступний
    import logging
    logging.basicConfig(level=logging.WARNING)
    def get_logger(name):
        return logging.getLogger(name)

logger = get_logger("database")

# ==================== PORTABLE PATHS LOGIC / ПОРТАТИВНАЯ ЛОГИКА ПУТЕЙ / ПОРТАТИВНА ЛОГІКА ШЛЯХІВ ====================
def _get_base_dir() -> str:
    """
    Get the directory where the application is running
    
    Получить папку, где запущено приложение
    
    Отримати папку, де запущено додаток
    """
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# FIXED #24: DB_PATH computed lazily, not at module import
# Исправлено #24: DB_PATH вычисляется лениво, не при импорте модуля
# Виправлено #24: DB_PATH обчислюється ліниво, не при імпорті модуля
def _get_db_path() -> str:
    """
    Get database file path inside application directory
    Computed on each call to avoid timing issues with directory creation.
    
    Получить путь к файлу БД в папке приложения
    Вычисляется при каждом вызове для избежания проблем с созданием директории.
    
    Отримати шлях до файлу БД в папці додатку
    Обчислюється при кожному виклику для уникнення проблем зі створенням директорії.
    """
    base_dir = _get_base_dir()
    
    # Check for data directory (standard location)
    data_dir = os.path.join(base_dir, "data")
    
    # Create data directory if it doesn't exist (first run)
    # Создаём директорию данных если её нет (первый запуск)
    # Створюємо директорію даних якщо її немає (перший запуск)
    if not os.path.exists(data_dir):
        try:
            os.makedirs(data_dir, exist_ok=True)
            logger.debug(f"Data directory created: {data_dir}")
        except (OSError, IOError, PermissionError) as e:
            logger.warning(f"Could not create data directory: {e}")
            # Fallback to base directory
            return os.path.join(base_dir, "passwords.db")
    
    # Check if data directory is writable
    # Проверяем, доступна ли директория для записи
    # Перевіряємо, чи доступна директорія для запису
    if os.access(data_dir, os.W_OK):
        return os.path.join(data_dir, "passwords.db")
    else:
        logger.warning(f"Data directory not writable: {data_dir}, using base directory")
        return os.path.join(base_dir, "passwords.db")


def get_db_path() -> str:
    """Public function to get database path
    Публичная функция для получения пути к БД
    Публічна функція для отримання шляху до БД"""
    return _get_db_path()


DB_PATH = None  # Will be initialized on first connection
DB_FILE = None  # Will be initialized on first connection

# Lock for thread-safe operations
_db_lock = threading.RLock()
_sensitive_migration_complete = False


# ==================== DATABASE INITIALIZATION ====================

def _get_connection() -> sqlite3.Connection:
    """
    Open a standalone SQLite connection with proper timeout configuration
    and WAL mode enabled for better concurrency and crash resilience.
    
    Открывает соединение SQLite с правильной настройкой таймаута
    и включает WAL режим для лучшей конкурентности и устойчивости к сбоям.
    
    Відкриває з'єднання SQLite з правильним налаштуванням таймауту
    та вмикає WAL режим для кращої конкурентності та стійкості до збоїв.
    """
    db_path = _get_db_path()
    db_dir = os.path.dirname(db_path)
    
    try:
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir, exist_ok=True)
    except (OSError, IOError, PermissionError) as e:
        logger.debug(f"Directory creation skipped or failed: {e}")
    
    conn = sqlite3.connect(db_path, timeout=20.0)
    conn.row_factory = sqlite3.Row
    
    # FIXED #25: Enable WAL mode for better concurrency and crash resilience
    # Исправлено #25: Включаем WAL режим для лучшей конкурентности и устойчивости к сбоям
    # Виправлено #25: Вмикаємо WAL режим для кращої конкурентності та стійкості до збоїв
    try:
        cursor = conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA cache_size=-20000")  # 20MB cache
        cursor.execute("PRAGMA temp_store=MEMORY")
        logger.debug("WAL mode enabled for database")
    except sqlite3.Error as e:
        logger.warning(f"Failed to enable WAL mode: {e}")
    
    return conn


def _init_db() -> None:
    """
    Initialize database and create table if it doesn't exist
    
    Инициализирует базу данных и создает таблицу, если она не существует
    
    Ініціалізує базу даних та створює таблицю, якщо вона не існує
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            
            # Create table with correct schema for the application
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS passwords (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    label TEXT NOT NULL,
                    password TEXT NOT NULL,
                    created TEXT NOT NULL,
                    updated TEXT,
                    notes TEXT
                )
            """)
            
            # Create indexes for better performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_label ON passwords(label)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_created ON passwords(created)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_updated ON passwords(updated)")
            
            conn.commit()
            _migrate_plaintext_sensitive_fields(conn)
            logger.info(f"Database initialized at: {_get_db_path()}")
        except sqlite3.Error as e:
            logger.error(f"Database initialization error: {e}")
            raise
        finally:
            conn.close()


# ==================== CORE DATABASE OPERATIONS ====================

def _get_no_label_text() -> str:
    """
    Get localized "No label" text.
    Returns Russian by default (will be overridden by UI layer).
    
    Получить локализованный текст "Без метки".
    Возвращает русский по умолчанию (будет переопределён UI слоем).
    
    Отримати локалізований текст "Без мітки".
    Повертає російську за замовчуванням (буде перевизначений UI шаром).
    
    FIXED #23: This is a placeholder. The UI layer should pass the correct language.
    Исправлено #23: Это заглушка. UI слой должен передавать правильный язык.
    Виправлено #23: Це заглушка. UI шар повинен передавати правильну мову.
    """
    # Try to get language from config
    try:
        from storage.config import Config
        config = Config()
        lang = config.get("LANG", "RU")
        from localization.lang import LANGUAGES
        return LANGUAGES.get(lang, LANGUAGES["RU"]).get("db_no_label", "No label")
    except (ImportError, AttributeError, KeyError, RuntimeError):
        # Fallback to Russian
        return "Без метки"



def _is_encrypted_value(value: str) -> bool:
    return isinstance(value, str) and value.startswith(("enc1:", "enc2:", "enc3:"))


def _is_encrypted_password(value: str) -> bool:
    return _is_encrypted_value(value)


def _encrypt_value_for_storage(value: str, field_name: str) -> str:
    if value is None:
        return ""
    if _is_encrypted_value(value):
        return value
    try:
        from security.encryption import encrypt
        return encrypt(str(value))
    except Exception as e:
        logger.error(f"{field_name} encryption failed: {e}")
        raise


def _decrypt_value_from_storage(value: str, field_name: str) -> str:
    if value is None:
        return ""
    try:
        from security.encryption import decrypt
        return decrypt(str(value))
    except Exception as e:
        logger.error(f"{field_name} decryption failed: {e}")
        return "[decryption failed]"


def _encrypt_password_for_storage(password: str) -> str:
    return _encrypt_value_for_storage(password, "Password")


def _decrypt_password_from_storage(password: str) -> str:
    return _decrypt_value_from_storage(password, "Password")


def _decrypt_record(row: sqlite3.Row) -> Dict[str, Any]:
    record = dict(row)
    record["label"] = _decrypt_value_from_storage(record.get("label", ""), "Label")
    record["password"] = _decrypt_password_from_storage(record.get("password", ""))
    record["notes"] = _decrypt_value_from_storage(record.get("notes", ""), "Notes")
    return record


def _can_migrate_sensitive_fields() -> bool:
    try:
        from security.master import MasterPassword
        from security.encryption import has_active_master_key
        if MasterPassword.is_set() and not has_active_master_key():
            logger.info("Skipping legacy DB encryption until master key is active")
            return False
    except (ImportError, AttributeError, RuntimeError, OSError) as e:
        logger.debug(f"Legacy DB encryption guard unavailable: {e}")
    return True


def _migrate_plaintext_sensitive_fields(conn: sqlite3.Connection) -> None:
    """Encrypt legacy plaintext label/password/notes rows in place."""
    global _sensitive_migration_complete
    if not _can_migrate_sensitive_fields():
        return

    try:
        cursor = conn.cursor()
        cursor.execute("SELECT id, label, password, notes FROM passwords")
        rows = cursor.fetchall()
        migrated = 0
        for row in rows:
            label = row["label"] or ""
            password = row["password"] or ""
            notes = row["notes"] or ""
            needs_update = (
                (label and not _is_encrypted_value(label)) or
                (password and not _is_encrypted_value(password)) or
                (notes and not _is_encrypted_value(notes))
            )
            if not needs_update:
                continue
            cursor.execute(
                "UPDATE passwords SET label = ?, password = ?, notes = ? WHERE id = ?",
                (
                    _encrypt_value_for_storage(label, "Label"),
                    _encrypt_password_for_storage(password),
                    _encrypt_value_for_storage(notes, "Notes") if notes else "",
                    row["id"],
                )
            )
            migrated += 1
        if migrated:
            conn.commit()
            logger.info(f"Encrypted {migrated} legacy password records")
        _sensitive_migration_complete = True
    except Exception as e:
        conn.rollback()
        logger.error(f"Legacy password record encryption failed: {e}")
        raise


def _run_sensitive_migration() -> None:
    with _db_lock:
        conn = _get_connection()
        try:
            _migrate_plaintext_sensitive_fields(conn)
        finally:
            conn.close()


def _save_password(label: str, password: str, notes: str = "", lang: str = None) -> int:
    """Save encrypted password to database."""
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            if not label or label.strip() == "":
                if lang:
                    try:
                        from localization.lang import LANGUAGES
                        label = LANGUAGES.get(lang, LANGUAGES["RU"]).get("db_no_label", "No label")
                    except (ImportError, KeyError):
                        label = _get_no_label_text()
                else:
                    label = _get_no_label_text()
            label = str(label)[:200]

            if notes and len(notes) > 500:
                notes = notes[:500]

            encrypted_label = _encrypt_value_for_storage(label, "Label")
            encrypted_password = _encrypt_password_for_storage(password)
            encrypted_notes = _encrypt_value_for_storage(notes, "Notes") if notes else ""
            cursor.execute(
                "INSERT INTO passwords (label, password, created, updated, notes) VALUES (?, ?, ?, ?, ?)",
                (encrypted_label, encrypted_password, now, now, encrypted_notes)
            )
            conn.commit()
            record_id = cursor.lastrowid
            logger.info(f"Password saved with ID: {record_id}")
            return record_id
        except sqlite3.Error as e:
            conn.rollback()
            logger.error(f"Failed to save password: {e}")
            raise Exception(f"Error saving password: {e}")
        finally:
            conn.close()


def _get_all_passwords() -> List[Dict[str, Any]]:
    """Get all passwords from database with password values decrypted for the GUI layer."""
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id, label, password, created, updated, notes FROM passwords ORDER BY id DESC")
            rows = cursor.fetchall()
            return [_decrypt_record(row) for row in rows]
        except sqlite3.Error as e:
            logger.error(f"Failed to get passwords: {e}")
            return []
        finally:
            conn.close()


def _search_passwords(query: str) -> List[Dict[str, Any]]:
    """Search passwords by label, decrypted password, date, or notes."""
    query_text = (query or "").casefold()
    if not query_text:
        return _get_all_passwords()

    results = []
    for record in _get_all_passwords():
        haystack = " ".join(str(record.get(field, "")) for field in ("label", "password", "created", "updated", "notes")).casefold()
        if query_text in haystack:
            results.append(record)
    return results


def _get_password_by_id(record_id: int) -> Optional[Dict[str, Any]]:
    """Get password by ID with decrypted password value."""
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, label, password, created, updated, notes FROM passwords WHERE id = ?",
                (record_id,)
            )
            row = cursor.fetchone()
            return _decrypt_record(row) if row else None
        except sqlite3.Error as e:
            logger.error(f"Failed to get password by ID: {e}")
            return None
        finally:
            conn.close()


def _update_password(record_id: int, label: str, password: Optional[str] = None, notes: Optional[str] = None, lang: str = None) -> bool:
    """Update password record, encrypting password values before storage."""
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            if not label or label.strip() == "":
                if lang:
                    try:
                        from localization.lang import LANGUAGES
                        label = LANGUAGES.get(lang, LANGUAGES["RU"]).get("db_no_label", "No label")
                    except (ImportError, KeyError):
                        label = _get_no_label_text()
                else:
                    label = _get_no_label_text()
            label = str(label)[:200]

            if notes and len(notes) > 500:
                notes = notes[:500]

            encrypted_label = _encrypt_value_for_storage(label, "Label")
            encrypted_password = _encrypt_password_for_storage(password) if password is not None else None
            encrypted_notes = _encrypt_value_for_storage(notes, "Notes") if notes is not None else None
            if encrypted_password is not None and encrypted_notes is not None:
                cursor.execute(
                    "UPDATE passwords SET label = ?, password = ?, updated = ?, notes = ? WHERE id = ?",
                    (encrypted_label, encrypted_password, now, encrypted_notes, record_id)
                )
            elif encrypted_password is not None:
                cursor.execute(
                    "UPDATE passwords SET label = ?, password = ?, updated = ? WHERE id = ?",
                    (encrypted_label, encrypted_password, now, record_id)
                )
            elif encrypted_notes is not None:
                cursor.execute(
                    "UPDATE passwords SET label = ?, updated = ?, notes = ? WHERE id = ?",
                    (encrypted_label, now, encrypted_notes, record_id)
                )
            else:
                cursor.execute(
                    "UPDATE passwords SET label = ?, updated = ? WHERE id = ?",
                    (encrypted_label, now, record_id)
                )
            conn.commit()
            logger.info(f"Password updated with ID: {record_id}")
            return cursor.rowcount > 0
        except sqlite3.Error as e:
            conn.rollback()
            logger.error(f"Failed to update password: {e}")
            return False
        finally:
            conn.close()


def _delete_password(record_id: int) -> bool:
    """
    Delete password record
    
    Удаляет запись
    
    Видаляє запис
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM passwords WHERE id = ?", (record_id,))
            conn.commit()
            logger.info(f"Password deleted with ID: {record_id}")
            return cursor.rowcount > 0
        except sqlite3.Error as e:
            conn.rollback()
            logger.error(f"Failed to delete password: {e}")
            return False
        finally:
            conn.close()


def _count_passwords() -> int:
    """
    Count passwords in database
    
    Считает количество записей
    
    Рахує кількість записів
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM passwords")
            return cursor.fetchone()[0]
        except sqlite3.Error as e:
            logger.error(f"Failed to count passwords: {e}")
            return 0
        finally:
            conn.close()


def _clear_all_passwords() -> bool:
    """
    Delete all passwords
    
    Удаляет все пароли
    
    Видаляє всі паролі
    """
    with _db_lock:
        conn = _get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM passwords")
            cursor.execute("DELETE FROM sqlite_sequence WHERE name='passwords'")
            conn.commit()
            logger.info("All passwords cleared")
            return True
        except sqlite3.Error as e:
            conn.rollback()
            logger.error(f"Failed to clear passwords: {e}")
            return False
        finally:
            conn.close()


def _create_backup() -> Optional[str]:
    """
    Create database backup
    
    Создает резервную копию
    
    Створює резервну копію
    """
    try:
        db_path = _get_db_path()
        if not os.path.exists(db_path):
            return None
            
        base_dir = _get_base_dir()
        backup_dir = os.path.join(base_dir, "backups")
        os.makedirs(backup_dir, exist_ok=True)
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"passwords_backup_{timestamp}.db"
        backup_path = os.path.join(backup_dir, backup_filename)
        
        with _db_lock:
            shutil.copy2(db_path, backup_path)
            
        logger.info(f"Database backed up successfully to: {backup_path}")
        return backup_path
    except (OSError, IOError, sqlite3.Error, shutil.Error) as e:
        logger.error(f"Failed to generate database backup: {e}")
        return None


def _vacuum_database() -> None:
    """
    Optimize database
    
    Оптимизирует базу данных
    
    Оптимізує базу даних
    """
    with _db_lock:
        conn = _get_connection()
        try:
            conn.execute("VACUUM")
            logger.info("Database vacuum completed")
        except sqlite3.Error as e:
            logger.error(f"Vacuum error: {e}")
        finally:
            conn.close()


# ==================== PASSWORDDB CLASS (COMPATIBLE WITH GUI) ====================

class PasswordDB:
    """
    Password database class with CRUD operations for GUI compatibility
    
    Класс для работы с базой паролей (совместимый с GUI)
    
    Клас для роботи з базою паролів (сумісний з GUI)
    """
    
    _initialized = False
    
    @classmethod
    def _ensure_initialized(cls) -> None:
        """
        Ensure database is initialized
        
        Инициализирует БД если нужно
        
        Ініціалізує БД якщо потрібно
        """
        if not cls._initialized:
            _init_db()
            cls._initialized = True
        elif not _sensitive_migration_complete:
            _run_sensitive_migration()
    
    @classmethod
    def save(cls, label: str, password: str, notes: str = "", lang: str = None) -> int:
        """
        Save password to database
        
        Сохраняет пароль в базу данных
        
        Зберігає пароль у базу даних
        """
        cls._ensure_initialized()
        return _save_password(label, password, notes, lang)
    
    @classmethod
    def get_all(cls) -> List[Dict[str, Any]]:
        """
        Get all passwords
        
        Возвращает все пароли
        
        Повертає всі паролі
        """
        cls._ensure_initialized()
        return _get_all_passwords()
    
    @classmethod
    def search(cls, query: str) -> List[Dict[str, Any]]:
        """
        Search passwords
        
        Ищет пароли
        
        Шукає паролі
        """
        cls._ensure_initialized()
        return _search_passwords(query)
    
    @classmethod
    def get_by_id(cls, record_id: int) -> Optional[Dict[str, Any]]:
        """
        Get password by ID
        
        Возвращает пароль по ID
        
        Повертає пароль за ID
        """
        cls._ensure_initialized()
        return _get_password_by_id(record_id)
    
    @classmethod
    def update(cls, record_id: int, label: str, password: Optional[str] = None, notes: Optional[str] = None, lang: str = None) -> bool:
        """
        Update password record
        
        Обновляет запись
        
        Оновлює запис
        """
        cls._ensure_initialized()
        return _update_password(record_id, label, password, notes, lang)
    
    @classmethod
    def delete(cls, record_id: int) -> bool:
        """
        Delete password record
        
        Удаляет запись
        
        Видаляє запис
        """
        cls._ensure_initialized()
        return _delete_password(record_id)
    
    @classmethod
    def count(cls) -> int:
        """
        Count passwords
        
        Считает количество записей
        
        Рахує кількість записів
        """
        cls._ensure_initialized()
        return _count_passwords()
    
    @classmethod
    def clear_all(cls) -> bool:
        """
        Delete all passwords
        
        Удаляет все пароли
        
        Видаляє всі паролі
        """
        cls._ensure_initialized()
        return _clear_all_passwords()
    
    @classmethod
    def create_backup(cls) -> Optional[str]:
        """
        Create database backup
        
        Создает резервную копию
        
        Створює резервну копію
        """
        cls._ensure_initialized()
        return _create_backup()
    
    @classmethod
    def vacuum(cls) -> None:
        """
        Optimize database
        
        Оптимизирует базу данных
        
        Оптимізує базу даних
        """
        cls._ensure_initialized()
        _vacuum_database()
    
    @classmethod
    def get_db_path(cls) -> str:
        """
        Get database file path
        
        Возвращает путь к БД
        
        Повертає шлях до БД
        """
        return _get_db_path()
    
    @classmethod
    def get_db_size(cls) -> int:
        """
        Get database file size in bytes
        
        Размер файла БД в байтах
        
        Розмір файлу БД у байтах
        """
        try:
            db_path = _get_db_path()
            if os.path.exists(db_path):
                return os.path.getsize(db_path)
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"Failed to get DB size: {e}")
        return 0
    
    @classmethod
    def close_connection(cls) -> None:
        """
        Close database connection (no-op for SQLite, connections are closed per operation)
        
        Закрывает соединение с БД (для SQLite не требуется, соединения закрываются после каждой операции)
        
        Закриває з'єднання з БД (для SQLite не потрібно, з'єднання закриваються після кожної операції)
        """
        logger.debug("Database connection closed (no-op for SQLite)")
    
    @classmethod
    def close_all_connections(cls) -> None:
        """
        Close all database connections
        
        Закрыть все соединения с БД
        
        Закрити всі з'єднання з БД
        """
        logger.debug("All database connections closed")
    
    @classmethod
    def checkpoint_wal(cls) -> bool:
        """
        Force WAL checkpoint to truncate WAL file.
        
        Принудительный WAL checkpoint для усечения WAL файла.
        
        Примусовий WAL checkpoint для усічення WAL файлу.
        """
        try:
            conn = _get_connection()
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            conn.close()
            logger.debug("WAL checkpoint completed")
            return True
        except sqlite3.Error as e:
            logger.error(f"WAL checkpoint failed: {e}")
            return False


# ==================== ALIAS FOR BACKWARD COMPATIBILITY ====================
Database = PasswordDB

# Export
__all__ = ['PasswordDB', 'Database', 'DB_FILE', 'DB_PATH', 'get_db_path']