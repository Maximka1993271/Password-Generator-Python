"""
Configuration manager with schema validation, corruption recovery, and backup
PORTABLE VERSION - all data is stored in the program's folder
DESIGN AND MENU UNTOUCHED
3 LANGUAGE SUPPORT: RU, EN, UA

FIXED #38: secure_write now uses atomic replace with os.replace()
FIXED #39: 2FA secret is now encrypted before storage in config

Менеджер конфигурации с проверкой схемы, восстановлением после повреждений и резервным копированием
ПОРТАТИВНАЯ ВЕРСИЯ - все данные хранятся в папке с программой
ДИЗАЙН И МЕНЮ НЕ ТРОНУТЫ
ПОДДЕРЖКА 3 ЯЗЫКОВ: RU, EN, UA

Исправлено #38: secure_write теперь использует атомарную замену через os.replace()
Исправлено #39: Секрет 2FA теперь шифруется перед хранением в конфиге

Менеджер конфігурації з перевіркою схеми, відновленням після пошкоджень та резервним копіюванням
ПОРТАТИВНА ВЕРСІЯ - всі дані зберігаються в папці з програмою
ДИЗАЙН ТА МЕНЮ НЕ ТОРКНУТО
ПІДТРИМКА 3 МОВ: RU, EN, UA

Виправлено #38: secure_write тепер використовує атомарну заміну через os.replace()
Виправлено #39: Секрет 2FA тепер шифрується перед зберіганням у конфізі
"""
import os
import sys
import json
import shutil
import re
import time
import threading
import tempfile
import copy
from typing import Dict, Any, Optional, List, Tuple, Callable
from datetime import datetime
from dataclasses import dataclass, asdict

# ==================== PORTABLE PATHS (BUILT-IN) / ПОРТАТИВНЫЕ ПУТИ (ВСТРОЕННЫЕ) / ПОРТАТИВНІ ШЛЯХИ (ВБУДОВАНІ) ====================

def get_program_dir() -> str:
    """Return the directory where the EXE or script is located
    Возвращает директорию, где находится EXE или скрипт
    Повертає директорію, де знаходиться EXE або скрипт"""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def get_config_dir() -> str:
    """Return the directory for storing configs (next to the program)
    Возвращает директорию для хранения конфигов (рядом с программой)
    Повертає директорію для зберігання конфігів (поруч з програмою)"""
    program_dir = get_program_dir()
    config_dir = os.path.join(program_dir, '.securepass')
    os.makedirs(config_dir, exist_ok=True)
    return config_dir


def get_config_file() -> str:
    """Return the path to the configuration file
    Возвращает путь к файлу конфигурации
    Повертає шлях до файлу конфігурації"""
    return os.path.join(get_config_dir(), 'config.json')


def hide_dir(directory: str) -> None:
    """Hide directory on Windows / Скрывает директорию на Windows / Ховає директорію на Windows"""
    if sys.platform == 'win32' and os.path.exists(directory):
        try:
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(directory, 2)
        except (ImportError, AttributeError, OSError) as e:
            pass


# ==================== SECURE FILE OPERATIONS (BUILT-IN) / БЕЗОПАСНЫЕ ОПЕРАЦИИ С ФАЙЛАМИ (ВСТРОЕННЫЕ) / БЕЗПЕЧНІ ОПЕРАЦІЇ З ФАЙЛАМИ (ВБУДОВАНІ) ====================

def secure_write(path: str, content: bytes, make_hidden: bool = True) -> bool:
    """
    Secure file write with atomic replacement.
    FIXED #38: Uses os.replace for atomic operation instead of remove+rename.
    
    Безопасная запись файла с атомарной заменой.
    Исправлено #38: Использует os.replace для атомарной операции вместо remove+rename.
    
    Безпечний запис файлу з атомарною заміною.
    Виправлено #38: Використовує os.replace для атомарної операції замість remove+rename.
    """
    try:
        directory = os.path.dirname(path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        
        # Create temporary file in same directory for atomic replace
        # Создаём временный файл в той же директории для атомарной замены
        # Створюємо тимчасовий файл у тій же директорії для атомарної заміни
        fd, temp_path = tempfile.mkstemp(
            dir=directory,
            prefix='.config_tmp_',
            suffix='.json'
        )
        os.close(fd)
        
        try:
            # Write content to temp file
            # Записываем содержимое во временный файл
            # Записуємо вміст у тимчасовий файл
            with open(temp_path, 'wb') as f:
                f.write(content)
                f.flush()
                os.fsync(f.fileno())
            
            # FIXED #38: Use os.replace for atomic operation (works on all platforms)
            # Исправлено #38: Используем os.replace для атомарной операции (работает на всех платформах)
            # Виправлено #38: Використовуємо os.replace для атомарної операції (працює на всіх платформах)
            os.replace(temp_path, path)
            
            if make_hidden and sys.platform == 'win32':
                try:
                    import ctypes
                    ctypes.windll.kernel32.SetFileAttributesW(path, 2)
                except (ImportError, AttributeError, OSError) as e:
                    pass
            
            return True
            
        except (OSError, IOError, PermissionError) as e:
            # Clean up temp file on error
            # Очищаем временный файл при ошибке
            # Очищуємо тимчасовий файл при помилці
            try:
                if os.path.exists(temp_path):
                    os.remove(temp_path)
            except (OSError, IOError, PermissionError):
                pass
            raise e
            
    except (OSError, IOError, PermissionError, TypeError) as e:
        print(f"Secure write failed: {e}")
        return False


def secure_read(path: str) -> Optional[bytes]:
    """Secure file read / Безопасное чтение файла / Безпечне читання файлу"""
    try:
        if not os.path.exists(path):
            return None
        with open(path, 'rb') as f:
            return f.read()
    except (OSError, IOError, PermissionError, TypeError) as e:
        print(f"Secure read failed: {e}")
        return None


# ==================== LOGGER (BUILT-IN) / ЛОГГЕР (ВСТРОЕННЫЙ) / ЛОГЕР (ВБУДОВАНИЙ) ====================

def get_logger(name):
    """Simple logger without external dependencies
    Простой логгер без внешних зависимостей
    Простий логер без зовнішніх залежностей"""
    import logging
    logger = logging.getLogger(name)
    logger.setLevel(logging.WARNING)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        logger.addHandler(handler)
    return logger


logger = get_logger("config")

SCHEMA_VERSION = 5

CONFIG_SCHEMA = {
    "THEME": {"type": str, "default": "Dark", "allowed": ["Dark", "Light", "System"]},
    "LANG": {"type": str, "default": "RU", "allowed": ["RU", "EN", "UA"]},
    "SOUND": {"type": bool, "default": True},
    "RGB": {"type": bool, "default": True},
    "RGB_SPEED": {"type": str, "default": "normal", "allowed": ["slow", "normal", "fast"]},
    "RGB_WIDTH": {"type": str, "default": "normal", "allowed": ["thin", "normal", "thick"]},
    "RADIUS": {"type": int, "default": 25, "min": 0, "max": 50},
    "font_size": {"type": int, "default": 14, "min": 10, "max": 28},
    "CLIP_TIMEOUT": {"type": int, "default": 60, "min": 5, "max": 300},
    "AUTO_LOCK": {"type": bool, "default": False},
    "AUTO_LOCK_TIMEOUT": {"type": int, "default": 5, "min": 1, "max": 30},
    "auto_save": {"type": bool, "default": False},
    "PDF_THEME": {"type": str, "default": "light", "allowed": ["light", "dark"]},
    "MAX_ATTEMPTS": {"type": int, "default": 5, "min": 3, "max": 10},
    "2fa_enabled": {"type": bool, "default": False},
    "2fa_secret": {"type": str, "default": "", "encrypted": True},
    "2fa_backup_hashes": {"type": list, "default": [], "sensitive": True},
    "2fa_account_name": {"type": str, "default": "SecurePassPro_User"},
    "2fa_setup_completed": {"type": bool, "default": False},
    "2fa_last_verified": {"type": str, "default": ""},
}

SENSITIVE_CONFIG_KEYS = {
    "2fa_secret",
    "2fa_backup_hashes",
}


def _is_sensitive_config_key(key: str) -> bool:
    key_lower = str(key).lower()
    if key in SENSITIVE_CONFIG_KEYS:
        return True
    return any(marker in key_lower for marker in ("password", "secret", "token", "backup", "hash", "master"))

# ==================== ENCRYPTION FOR 2FA SECRET / ШИФРОВАНИЕ ДЛЯ 2FA СЕКРЕТА / ШИФРУВАННЯ ДЛЯ 2FA СЕКРЕТУ ====================
# FIXED #39: Add encryption for 2FA secret stored in config
# Исправлено #39: Добавляем шифрование для секрета 2FA, хранящегося в конфиге
# Виправлено #39: Додаємо шифрування для секрету 2FA, що зберігається в конфізі

# Simple XOR encryption for config values (not for master password)
# This is just to obfuscate the secret in the config file, not for cryptographic security
# The master password provides the actual security layer
# Простое XOR шифрование для значений конфига (не для мастер-пароля)
# Это только для обфускации секрета в файле конфига, не для криптографической безопасности
# Мастер-пароль обеспечивает реальный уровень безопасности
# Просте XOR шифрування для значень конфіга (не для майстер-пароля)
# Це тільки для обфускації секрету у файлі конфіга, не для криптографічної безпеки
# Майстер-пароль забезпечує реальний рівень безпеки

# FIXED #39: Use a device-specific key for encryption to make config portable yet secure
# Исправлено #39: Используем устройственно-специфичный ключ для шифрования, чтобы конфиг был портативным и защищённым
# Виправлено #39: Використовуємо пристрійно-специфічний ключ для шифрування, щоб конфіг був портативним та захищеним

def _get_config_encryption_key() -> bytes:
    """
    Get a device-specific key for config value encryption.
    Uses machine UUID and platform info to generate a unique key per installation.
    
    Получить устройственно-специфичный ключ для шифрования значений конфига.
    Использует UUID машины и информацию о платформе для генерации уникального ключа для каждой установки.
    
    Отримати пристрійно-специфічний ключ для шифрування значень конфіга.
    Використовує UUID машини та інформацію про платформу для генерації унікального ключа для кожного встановлення.
    """
    try:
        # Try to get machine UUID from encryption module
        # Пытаемся получить UUID машины из модуля шифрования
        # Намагаємося отримати UUID машини з модуля шифрування
        from security.encryption import _get_machine_uuid
        machine_uuid = _get_machine_uuid()
    except (ImportError, AttributeError):
        # Fallback: generate a random key stored in a separate file
        # Запасной вариант: генерируем случайный ключ, хранящийся в отдельном файле
        # Запасний варіант: генеруємо випадковий ключ, що зберігається в окремому файлі
        key_file = os.path.join(get_config_dir(), ".config_key")
        if os.path.exists(key_file):
            try:
                with open(key_file, 'rb') as f:
                    return f.read(32)
            except (OSError, IOError, PermissionError):
                pass
        
        # Generate new random key
        # Генерируем новый случайный ключ
        # Генеруємо новий випадковий ключ
        import secrets
        new_key = secrets.token_bytes(32)
        try:
            with open(key_file, 'wb') as f:
                f.write(new_key)
            hide_dir(os.path.dirname(key_file))
        except (OSError, IOError, PermissionError):
            pass
        return new_key
    
    # Derive 32-byte key from UUID using SHA-256
    # Получаем 32-байтовый ключ из UUID через SHA-256
    # Отримуємо 32-байтовий ключ з UUID через SHA-256
    import hashlib
    return hashlib.sha256(machine_uuid.encode('utf-8')).digest()


def _encrypt_config_value(value: str) -> str:
    """
    Encrypt a config value with AES-256-GCM when cryptography is available.
    Falls back to the legacy obfuscation format only when the dependency is missing.
    """
    if not value:
        return ""

    try:
        import base64
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        key = _get_config_encryption_key()
        nonce = os.urandom(12)
        ciphertext = AESGCM(key).encrypt(nonce, value.encode("utf-8"), b"secure-pass-pro-config-v2")
        return "[enc2]" + base64.b64encode(nonce + ciphertext).decode("ascii")
    except ImportError:
        logger.warning("cryptography is unavailable; using legacy config obfuscation")
    except Exception as e:
        logger.error(f"Failed to encrypt config value with AES-GCM: {e}")
        raise

    try:
        key = _get_config_encryption_key()
        value_bytes = value.encode('utf-8')
        encrypted = bytearray()
        for i, b in enumerate(value_bytes):
            encrypted.append(b ^ key[i % len(key)])
        import base64
        return f"[enc]{base64.b64encode(encrypted).decode('ascii')}"
    except Exception as e:
        logger.error(f"Failed to encrypt config value: {e}")
        raise


def _decrypt_config_value(encrypted_value: str) -> str:
    """Decrypt a config value, supporting both AES-GCM [enc2] and legacy [enc] values."""
    if not encrypted_value or not encrypted_value.startswith("[enc"):
        return encrypted_value

    if encrypted_value.startswith("[enc2]"):
        try:
            import base64
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            raw = base64.b64decode(encrypted_value[6:], validate=True)
            if len(raw) < 29:
                raise ValueError("Encrypted config value is too short")
            nonce, ciphertext = raw[:12], raw[12:]
            plaintext = AESGCM(_get_config_encryption_key()).decrypt(
                nonce,
                ciphertext,
                b"secure-pass-pro-config-v2"
            )
            return plaintext.decode("utf-8")
        except Exception as e:
            logger.error(f"Failed to decrypt AES-GCM config value: {e}")
            return ""

    try:
        import base64
        encrypted_data = base64.b64decode(encrypted_value[5:])
        key = _get_config_encryption_key()
        decrypted = bytearray()
        for i, b in enumerate(encrypted_data):
            decrypted.append(b ^ key[i % len(key)])
        return decrypted.decode('utf-8')
    except Exception as e:
        logger.error(f"Failed to decrypt legacy config value: {e}")
        return ""


@dataclass
class ConfigBackup:
    """Configuration backup metadata / Метаданные резервной копии конфига / Метадані резервної копії конфігу"""
    path: str
    timestamp: float
    version: int
    size: int
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class ConfigError(Exception):
    """Exception for configuration errors / Исключение для ошибок конфигурации / Виняток для помилок конфігурації"""
    pass


class ConfigCorruptionError(ConfigError):
    """Exception for configuration corruption / Исключение для повреждения конфигурации / Виняток для пошкодження конфігурації"""
    pass


class ConfigMigrationError(ConfigError):
    """Exception for migration errors / Исключение для ошибок миграции / Виняток для помилок міграції"""
    pass


class ConfigValidationError(ConfigError):
    """Exception for validation errors / Исключение для ошибок валидации / Виняток для помилок валідації"""
    pass


def _atomic_write_json(path: str, data: Dict[str, Any]) -> bool:
    """Atomic JSON write with integrity check
    Атомарная запись JSON с проверкой целостности
    Атомарний запис JSON з перевіркою цілісності"""
    directory = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(directory, exist_ok=True)
    hide_dir(directory)
    
    try:
        content = json.dumps(data, indent=2, ensure_ascii=False).encode('utf-8')
        
        if not secure_write(path, content, make_hidden=True):
            return False
        
        read_content = secure_read(path)
        if read_content:
            test_data = json.loads(read_content.decode('utf-8'))
            if test_data != data:
                logger.error("JSON integrity check failed - data mismatch")
                return False
        
        return True
    except (OSError, IOError, TypeError, json.JSONDecodeError, UnicodeDecodeError) as e:
        logger.error(f"Atomic write failed: {e}")
        return False


def _create_backup(config_path: str) -> Optional[ConfigBackup]:
    """Create backup of config file / Создаёт резервную копию конфига / Створює резервну копію конфігу"""
    if not os.path.exists(config_path):
        return None
    
    backup_dir = os.path.join(get_config_dir(), "config_backups")
    os.makedirs(backup_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(backup_dir, f"config_backup_{timestamp}.json")
    
    try:
        shutil.copy2(config_path, backup_path)
        logger.debug(f"Config backup created: {backup_path}")
        
        # Get config version from backup / Получаем версию конфига из бэкапа / Отримуємо версію конфігу з бекапу
        version = 1
        try:
            with open(backup_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                version = data.get("_schema_version", 1)
        except (OSError, IOError, json.JSONDecodeError) as e:
            logger.debug(f"Failed to read backup version: {e}")
        
        return ConfigBackup(
            path=backup_path,
            timestamp=time.time(),
            version=version,
            size=os.path.getsize(backup_path)
        )
    except (OSError, IOError, PermissionError, shutil.Error) as e:
        logger.error(f"Failed to create config backup: {e}")
        return None


def _cleanup_old_backups(backup_dir: str, max_backups: int = 10) -> None:
    """Clean up old backups / Очищает старые резервные копии / Очищує старі резервні копії"""
    try:
        if not os.path.exists(backup_dir):
            return
        
        backups = []
        for f in os.listdir(backup_dir):
            if f.startswith("config_backup_") and f.endswith(".json"):
                f_path = os.path.join(backup_dir, f)
                backups.append((f_path, os.path.getmtime(f_path)))
        
        backups.sort(key=lambda x: x[1])
        
        while len(backups) > max_backups:
            old_file = backups.pop(0)[0]
            try:
                os.remove(old_file)
                logger.debug(f"Removed old backup: {old_file}")
            except (OSError, IOError, PermissionError) as e:
                logger.warning(f"Failed to remove old backup: {e}")
    except (OSError, IOError) as e:
        logger.debug(f"Backup cleanup error: {e}")


def _get_available_backups() -> List[ConfigBackup]:
    """Get list of available backups / Получить список доступных резервных копий / Отримати список доступних резервних копій"""
    backup_dir = os.path.join(get_config_dir(), "config_backups")
    backups = []
    
    if not os.path.exists(backup_dir):
        return backups
    
    try:
        for f in os.listdir(backup_dir):
            if f.startswith("config_backup_") and f.endswith(".json"):
                f_path = os.path.join(backup_dir, f)
                try:
                    with open(f_path, 'r', encoding='utf-8') as bf:
                        data = json.load(bf)
                        version = data.get("_schema_version", 1)
                    
                    backups.append(ConfigBackup(
                        path=f_path,
                        timestamp=os.path.getmtime(f_path),
                        version=version,
                        size=os.path.getsize(f_path)
                    ))
                except (OSError, IOError, json.JSONDecodeError) as e:
                    logger.debug(f"Failed to read backup {f}: {e}")
    except (OSError, IOError) as e:
        logger.debug(f"Failed to list backups: {e}")
    
    backups.sort(key=lambda x: x.timestamp, reverse=True)
    return backups


def _validate_config(config: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    """Validate configuration by schema / Валидация конфигурации по схеме / Валідація конфігурації за схемою"""
    validated = {}
    errors = []
    
    for key, schema in CONFIG_SCHEMA.items():
        value = config.get(key, copy.deepcopy(schema["default"]))
        
        # Type validation / Проверка типа / Перевірка типу
        if not isinstance(value, schema["type"]):
            errors.append(f"Config key '{key}' has wrong type {type(value).__name__}, expected {schema['type'].__name__}")
            logger.warning(f"Config key '{key}' has wrong type, using default: {schema['default']}")
            value = copy.deepcopy(schema["default"])
        
        # Allowed values validation / Проверка допустимых значений / Перевірка допустимих значень
        if "allowed" in schema and value not in schema["allowed"]:
            errors.append(f"Config key '{key}' value '{value}' not allowed. Allowed: {schema['allowed']}")
            logger.warning(f"Config key '{key}' value '{value}' not allowed, using default: {schema['default']}")
            value = copy.deepcopy(schema["default"])
        
        # Minimum value validation / Проверка минимального значения / Перевірка мінімального значення
        if "min" in schema and isinstance(value, (int, float)) and value < schema["min"]:
            errors.append(f"Config key '{key}' value {value} below minimum {schema['min']}")
            logger.warning(f"Config key '{key}' value {value} below min {schema['min']}, using default: {schema['default']}")
            value = copy.deepcopy(schema["default"])
        
        # Maximum value validation / Проверка максимального значения / Перевірка максимального значення
        if "max" in schema and isinstance(value, (int, float)) and value > schema["max"]:
            errors.append(f"Config key '{key}' value {value} above maximum {schema['max']}")
            logger.warning(f"Config key '{key}' value {value} above max {schema['max']}, using default: {schema['default']}")
            value = copy.deepcopy(schema["default"])
        
        validated[key] = value
    
    # Preserve unknown keys for forward compatibility / Сохраняем неизвестные ключи для прямой совместимости / Зберігаємо невідомі ключі для прямої сумісності
    for key, value in config.items():
        if key not in validated and not key.startswith("_"):
            validated[key] = value
    
    return validated, errors


def _migrate_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Migrate config from older versions / Миграция конфигурации из старых версий / Міграція конфігурації зі старих версій"""
    version = config.get("_schema_version", 1)
    
    if version >= SCHEMA_VERSION:
        return config
    
    logger.info(f"Migrating config from version {version} to {SCHEMA_VERSION}")
    
    # Create backup before migration / Создаём бэкап перед миграцией / Створюємо бекап перед міграцією
    _create_backup(get_config_file())
    
    try:
        # Apply custom migrations if defined / Применяем пользовательские миграции если определены / Застосовуємо користувацькі міграції якщо визначені
        for v in range(version + 1, SCHEMA_VERSION + 1):
            if v in SCHEMA_MIGRATIONS:
                config = SCHEMA_MIGRATIONS[v](config)
        
        # Version 1 to 2 migration / Миграция с версии 1 на 2 / Міграція з версії 1 на 2
        if version == 1:
            for key, schema in CONFIG_SCHEMA.items():
                if key not in config:
                    config[key] = schema["default"]
            if "PDF_THEME" not in config:
                config["PDF_THEME"] = "light"
            config["_schema_version"] = 2
        
        # Version 2 to 3 migration / Миграция с версии 2 на 3 / Міграція з версії 2 на 3
        if version <= 2:
            for key, schema in CONFIG_SCHEMA.items():
                if key in config:
                    value = config[key]
                    if "allowed" in schema and value not in schema["allowed"]:
                        config[key] = schema["default"]
                        logger.warning(f"Migrated invalid value for {key} to default: {schema['default']}")
            config["_schema_version"] = 3
        
        # Version 3 to 4 migration (2FA) / Миграция с версии 3 на 4 (2FA) / Міграція з версії 3 на 4 (2FA)
        if version <= 3:
            for key in ["2fa_enabled", "2fa_secret", "2fa_backup_hashes", 
                        "2fa_account_name", "2fa_setup_completed", "2fa_last_verified"]:
                if key not in config:
                    config[key] = CONFIG_SCHEMA.get(key, {"default": None})["default"]
            config["_schema_version"] = 4
            logger.info("Added 2FA configuration fields during migration")
        
        # FIXED #39: Version 4 to 5 migration - encrypt existing 2fa_secret
        # Исправлено #39: Миграция с версии 4 на 5 - шифруем существующий 2fa_secret
        # Виправлено #39: Міграція з версії 4 на 5 - шифруємо існуючий 2fa_secret
        if version <= 4:
            secret = config.get("2fa_secret", "")
            if secret and not secret.startswith("[enc]"):
                config["2fa_secret"] = _encrypt_config_value(secret)
                logger.info("Encrypted existing 2FA secret during migration")
            config["_schema_version"] = 5
        
        logger.info(f"Config migrated to version {SCHEMA_VERSION}")
    except (KeyError, ValueError, TypeError) as e:
        logger.error(f"Migration error: {e}")
        raise ConfigMigrationError(f"Failed to migrate config: {e}")
    
    return config


def _repair_config(file_path: str) -> Optional[Dict[str, Any]]:
    """Attempt to repair corrupted config / Попытка восстановить повреждённый конфиг / Спроба відновити пошкоджений конфіг"""
    logger.warning(f"Attempting to repair config: {file_path}")
    
    # Backup corrupted file / Бэкап повреждённого файла / Бекап пошкодженого файлу
    backup_path = file_path + ".corrupted"
    try:
        shutil.copy2(file_path, backup_path)
        logger.info(f"Backup of corrupted config saved to: {backup_path}")
    except (OSError, IOError, PermissionError, shutil.Error) as e:
        logger.warning(f"Failed to backup corrupted config: {e}")
    
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Remove non-printable characters / Удаляем непечатаемые символы / Видаляємо недруковані символи
        clean_content = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', content)
        
        # Try to extract JSON object / Пытаемся извлечь JSON объект / Намагаємося витягти JSON об'єкт
        json_match = re.search(r'\{.*\}', clean_content, re.DOTALL)
        if json_match:
            clean_content = json_match.group()
        
        # Try to parse / Пытаемся распарсить / Намагаємося розпарсити
        try:
            repaired = json.loads(clean_content)
            logger.info("Config successfully repaired")
            return repaired
        except json.JSONDecodeError:
            # Replace single quotes with double quotes / Заменяем одинарные кавычки на двойные / Замінюємо одинарні лапки на подвійні
            clean_content = clean_content.replace("'", '"')
            # Remove comments / Удаляем комментарии / Видаляємо коментарі
            clean_content = re.sub(r'//.*?$', '', clean_content, flags=re.MULTILINE)
            clean_content = re.sub(r'/\*.*?\*/', '', clean_content, flags=re.DOTALL)
            try:
                repaired = json.loads(clean_content)
                logger.info("Config successfully repaired (aggressive mode)")
                return repaired
            except json.JSONDecodeError:
                return _restore_from_backup()
    except (OSError, IOError) as e:
        logger.error(f"Config repair failed: {e}")
    
    return _restore_from_backup()


def _restore_from_backup() -> Optional[Dict[str, Any]]:
    """Restore config from latest backup / Восстанавливает конфиг из последнего бэкапа / Відновлює конфіг з останнього бекапу"""
    backups = _get_available_backups()
    
    if not backups:
        logger.warning("No backups found for recovery")
        return None
    
    latest_backup = backups[0].path
    
    try:
        with open(latest_backup, 'r', encoding='utf-8') as f:
            restored = json.load(f)
        logger.info(f"Config restored from backup: {latest_backup}")
        return restored
    except (OSError, IOError, json.JSONDecodeError) as e:
        logger.error(f"Backup restore failed: {e}")
        return None


class Config:
    """Application settings manager with schema validation, recovery, and backup
    Менеджер настроек приложения с проверкой схемы, восстановлением и резервным копированием
    Менеджер налаштувань додатку з перевіркою схеми, відновленням та резервним копіюванням"""

    _instance = None
    _lock = threading.RLock()
    _data: Dict[str, Any] = {}
    _backup_path: Optional[str] = None
    _config_file: Optional[str] = None
    _last_save_time: float = 0
    _save_cooldown: float = 0.5
    _validation_errors: List[str] = []

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._config_file = get_config_file()
                    cls._instance._backup_path = cls._instance._config_file + ".backup"
                    cls._instance._load()
        return cls._instance

    def _load(self) -> None:
        """Load config from file with validation, recovery, and migration
        Загрузить конфиг из файла с валидацией, восстановлением и миграцией
        Завантажити конфіг з файлу з валідацією, відновленням та міграцією"""
        config_file = self._config_file
        
        if not os.path.exists(config_file):
            logger.info("Config file not found, creating default")
            self._data = self._get_default_config()
            self._data["_schema_version"] = SCHEMA_VERSION
            self.save()
            return

        try:
            content = secure_read(config_file)
            if content:
                raw_data = json.loads(content.decode('utf-8'))
            else:
                raise ConfigCorruptionError("Empty config file")
            
            # Migrate if needed / Мигрируем если нужно / Мігруємо якщо потрібно
            if raw_data.get("_schema_version", 1) < SCHEMA_VERSION:
                raw_data = _migrate_config(raw_data)
            
            validated_data, errors = _validate_config(raw_data)
            self._validation_errors = errors
            
            if errors:
                logger.warning(f"Config validation had {len(errors)} errors: {errors[:3]}...")
            
            self._data = validated_data
            self._data["_schema_version"] = SCHEMA_VERSION
            
            if validated_data != raw_data:
                logger.info("Config normalized, saving changes")
                self.save()
                
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            repaired = _repair_config(config_file)
            if repaired:
                validated_data, errors = _validate_config(repaired)
                self._data = validated_data
                self._data["_schema_version"] = SCHEMA_VERSION
                self.save()
                logger.info("Config restored after corruption")
            else:
                logger.warning("Using default config")
                self._data = self._get_default_config()
                self._data["_schema_version"] = SCHEMA_VERSION
        except ConfigCorruptionError as e:
            logger.error(f"Config corruption: {e}")
            self._data = self._get_default_config()
            self._data["_schema_version"] = SCHEMA_VERSION
        except (PermissionError, OSError, ValueError) as e:
            logger.error(f"Error reading config: {e}")
            self._data = self._get_default_config()
            self._data["_schema_version"] = SCHEMA_VERSION
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration / Получить конфигурацию по умолчанию / Отримати конфігурацію за замовчуванням"""
        return {key: copy.deepcopy(schema["default"]) for key, schema in CONFIG_SCHEMA.items()}

    def save(self) -> bool:
        """Save config to file with atomic write, backup, and cooldown
        Сохранить конфиг в файл с атомарной записью, резервным копированием и задержкой
        Зберегти конфіг у файл з атомарним записом, резервним копіюванням та затримкою"""
        config_file = self._config_file
        
        current_time = time.time()
        
        if os.path.exists(config_file):
            _create_backup(config_file)
        
        save_data = self._data.copy()
        save_data["_schema_version"] = SCHEMA_VERSION
        
        success = _atomic_write_json(config_file, save_data)
        if success:
            self._last_save_time = current_time
            backup_dir = os.path.join(get_config_dir(), "config_backups")
            _cleanup_old_backups(backup_dir, max_backups=10)
            logger.debug(f"Config saved successfully to {config_file}")
        else:
            logger.error("Failed to save config")
            restored = _restore_from_backup()
            if restored:
                self._data = restored
                return self.save()
        
        return success

    def get(self, key: str, default=None):
        """Get config value with type validation and decryption for sensitive keys
        Получить значение конфигурации с проверкой типа и дешифрованием для чувствительных ключей
        Отримати значення конфігурації з перевіркою типу та дешифруванням для чутливих ключів"""
        value = self._data.get(key, default)
        
        if key in CONFIG_SCHEMA and value is not None:
            expected_type = CONFIG_SCHEMA[key]["type"]
            if not isinstance(value, expected_type):
                logger.warning(f"Config key '{key}' has wrong type, returning default")
                return CONFIG_SCHEMA[key]["default"]
        
        # FIXED #39: Decrypt sensitive values when reading
        # Исправлено #39: Дешифруем чувствительные значения при чтении
        # Виправлено #39: Дешифруємо чутливі значення при читанні
        if key == "2fa_secret" and isinstance(value, str) and value.startswith("[enc"):
            return _decrypt_config_value(value)
        
        return value

    def set(self, key: str, value) -> bool:
        """Set config value with validation and encryption for sensitive keys. Returns success status.
        Установить значение конфигурации с валидацией и шифрованием для чувствительных ключей. Возвращает статус успеха.
        Встановити значення конфігурації з валідацією та шифруванням для чутливих ключів. Повертає статус успіху."""
        with self._lock:
            if key in CONFIG_SCHEMA:
                schema = CONFIG_SCHEMA[key]
                
                if not isinstance(value, schema["type"]):
                    logger.error(f"Config key '{key}' expects type {schema['type'].__name__}, got {type(value).__name__}")
                    return False
                
                if "allowed" in schema and value not in schema["allowed"]:
                    logger.error(f"Config key '{key}' value '{value}' not allowed. Allowed: {schema['allowed']}")
                    return False
                
                if "min" in schema and isinstance(value, (int, float)) and value < schema["min"]:
                    logger.error(f"Config key '{key}' value {value} below minimum {schema['min']}")
                    return False
                if "max" in schema and isinstance(value, (int, float)) and value > schema["max"]:
                    logger.error(f"Config key '{key}' value {value} above maximum {schema['max']}")
                    return False
            
            # FIXED #39: Encrypt sensitive values before storing
            # Исправлено #39: Шифруем чувствительные значения перед хранением
            # Виправлено #39: Шифруємо чутливі значення перед зберіганням
            if key == "2fa_secret" and isinstance(value, str) and value and not value.startswith("[enc"):
                value = _encrypt_config_value(value)
            
            old_value = self._data.get(key)
            self._data[key] = value
            result = self.save()
            
            if result:
                if _is_sensitive_config_key(key):
                    logger.info(f"Config key '{key}' changed")
                else:
                    logger.info(f"Config key '{key}' changed from '{old_value}' to '{value}'")
            else:
                logger.error(f"Failed to save config key '{key}'")
            
            return result

    def update(self, updates: Dict[str, Any]) -> int:
        """Update multiple config values. Returns number of successful updates.
        Обновить несколько значений конфигурации. Возвращает количество успешных обновлений.
        Оновити кілька значень конфігурації. Повертає кількість успішних оновлень."""
        success_count = 0
        for key, value in updates.items():
            if self.set(key, value):
                success_count += 1
            else:
                logger.error(f"Failed to update config key '{key}'")
        
        if success_count > 0:
            self.save()
        
        return success_count
    
    def reset_to_defaults(self) -> bool:
        """Reset all settings to defaults / Сбросить все настройки к значениям по умолчанию / Скинути всі налаштування до значень за замовчуванням"""
        with self._lock:
            self._data = self._get_default_config()
            self._data["_schema_version"] = SCHEMA_VERSION
            return self.save()
    
    def export(self, file_path: str) -> bool:
        """Export config to another file / Экспортировать конфиг в другой файл / Експортувати конфіг в інший файл"""
        try:
            content = json.dumps(self._data, indent=2, ensure_ascii=False).encode('utf-8')
            return secure_write(file_path, content, make_hidden=False)
        except (OSError, IOError, TypeError) as e:
            logger.error(f"Config export failed: {e}")
            return False
    
    def import_from(self, file_path: str) -> bool:
        """Import config from another file with validation
        Импортировать конфиг из другого файла с валидацией
        Імпортувати конфіг з іншого файлу з валідацією"""
        try:
            content = secure_read(file_path)
            if not content:
                return False
            
            raw_data = json.loads(content.decode('utf-8'))
            validated_data, errors = _validate_config(raw_data)
            if errors:
                logger.warning(f"Import config has {len(errors)} errors, but imported anyway")
            
            self._data = validated_data
            self._data["_schema_version"] = SCHEMA_VERSION
            return self.save()
        except (OSError, IOError, json.JSONDecodeError, UnicodeDecodeError) as e:
            logger.error(f"Config import failed: {e}")
            return False
    
    def get_backup_available(self) -> bool:
        """Check if backup config is available / Проверить, доступен ли резервный конфиг / Перевірити, чи доступний резервний конфіг"""
        backups = _get_available_backups()
        return len(backups) > 0
    
    def restore_from_backup(self, backup_index: int = 0) -> bool:
        """Restore config from backup / Восстановить конфиг из резервной копии / Відновити конфіг з резервної копії"""
        backups = _get_available_backups()
        
        if backup_index >= len(backups):
            logger.warning(f"Backup index {backup_index} out of range")
            return False
        
        backup = backups[backup_index]
        
        try:
            with open(backup.path, 'r', encoding='utf-8') as f:
                backup_data = json.load(f)
            
            validated_data, errors = _validate_config(backup_data)
            self._data = validated_data
            self._data["_schema_version"] = SCHEMA_VERSION
            logger.info(f"Config restored from backup: {backup.path}")
            return self.save()
        except (OSError, IOError, json.JSONDecodeError, KeyError) as e:
            logger.error(f"Backup restore failed: {e}")
            return False
    
    def list_backups(self) -> List[Dict[str, Any]]:
        """List available backups / Список доступных резервных копий / Список доступних резервних копій"""
        return [b.to_dict() for b in _get_available_backups()]
    
    def validate_all(self) -> Tuple[bool, List[str]]:
        """Validate entire config. Returns (is_valid, list_of_errors)
        Проверить весь конфиг. Возвращает (is_valid, list_of_errors)
        Перевірити весь конфіг. Повертає (is_valid, list_of_errors)"""
        _, errors = _validate_config(self._data)
        return len(errors) == 0, errors
    
    def get_validation_errors(self) -> List[str]:
        """Get last validation errors / Получить последние ошибки валидации / Отримати останні помилки валідації"""
        return self._validation_errors.copy()
    
    def get_schema_info(self) -> Dict[str, Any]:
        """Get schema information for UI / Получить информацию о схеме для UI / Отримати інформацію про схему для UI"""
        info = {}
        for key, schema in CONFIG_SCHEMA.items():
            info[key] = {
                "type": schema["type"].__name__,
                "default": schema["default"],
                "current": self._data.get(key, schema["default"]),
                "encrypted": schema.get("encrypted", False)
            }
            if "allowed" in schema:
                info[key]["allowed"] = schema["allowed"]
            if "min" in schema:
                info[key]["min"] = schema["min"]
            if "max" in schema:
                info[key]["max"] = schema["max"]
        return info
    
    def get_version(self) -> int:
        """Get current config schema version / Получить текущую версию схемы конфигурации / Отримати поточну версію схеми конфігурації"""
        return self._data.get("_schema_version", 1)
    
    def has_key(self, key: str) -> bool:
        """Check if key exists in config / Проверить существование ключа в конфиге / Перевірити існування ключа в конфізі"""
        return key in self._data
    
    def get_all(self) -> Dict[str, Any]:
        """Get a copy of all config data (sensitive values remain encrypted)
        Получить копию всех данных конфигурации (чувствительные значения остаются зашифрованными)
        Отримати копію всіх даних конфігурації (чутливі значення залишаються зашифрованими)"""
        return self._data.copy()
    
    # ==================== 2FA METHODS / МЕТОДЫ 2FA / МЕТОДИ 2FA ====================
    
    def is_2fa_enabled(self) -> bool:
        """Check if 2FA is enabled / Проверяет, включена ли 2FA / Перевіряє, чи увімкнено 2FA"""
        return self.get("2fa_enabled", False)
    
    def get_2fa_secret(self) -> str:
        """Return 2FA secret (automatically decrypted) / Возвращает секрет 2FA (автоматически дешифруется) / Повертає секрет 2FA (автоматично дешифрується)"""
        return self.get("2fa_secret", "")
    
    def get_2fa_backup_hashes(self) -> List[str]:
        """Return backup code hashes / Возвращает хеши резервных кодов / Повертає хеші резервних кодів"""
        return self.get("2fa_backup_hashes", [])
    
    def get_2fa_account_name(self) -> str:
        """Return account name for 2FA / Возвращает имя аккаунта для 2FA / Повертає ім'я акаунта для 2FA"""
        return self.get("2fa_account_name", "")
    
    def is_2fa_setup_completed(self) -> bool:
        """Check if 2FA setup is completed / Проверяет, завершена ли настройка 2FA / Перевіряє, чи завершено налаштування 2FA"""
        return self.get("2fa_setup_completed", False)
    
    def set_2fa_enabled(self, enabled: bool) -> bool:
        """Enable/disable 2FA / Включает/выключает 2FA / Увімкнює/вимикає 2FA"""
        return self.set("2fa_enabled", enabled)
    
    def set_2fa_secret(self, secret: str) -> bool:
        """Set 2FA secret (will be encrypted automatically) / Устанавливает секрет 2FA (будет зашифрован автоматически) / Встановлює секрет 2FA (буде зашифровано автоматично)"""
        return self.set("2fa_secret", secret)
    
    def set_2fa_backup_hashes(self, hashes: List[str]) -> bool:
        """Set backup code hashes / Устанавливает хеши резервных кодов / Встановлює хеші резервних кодів"""
        return self.set("2fa_backup_hashes", hashes)
    
    def set_2fa_account_name(self, name: str) -> bool:
        """Set account name for 2FA / Устанавливает имя аккаунта для 2FA / Встановлює ім'я акаунта для 2FA"""
        return self.set("2fa_account_name", name)
    
    def set_2fa_setup_completed(self, completed: bool) -> bool:
        """Mark 2FA setup as completed / Отмечает завершение настройки 2FA / Позначає завершення налаштування 2FA"""
        return self.set("2fa_setup_completed", completed)
    
    def set_2fa_last_verified(self, timestamp: str = None) -> bool:
        """Set last 2FA verification time / Устанавливает время последней верификации 2FA / Встановлює час останньої верифікації 2FA"""
        if timestamp is None:
            timestamp = datetime.now().isoformat()
        return self.set("2fa_last_verified", timestamp)
    
    def clear_2fa(self) -> bool:
        """Clear all 2FA settings / Очищает все 2FA настройки / Очищує всі 2FA налаштування"""
        success = True
        success &= self.set("2fa_enabled", False)
        success &= self.set("2fa_secret", "")
        success &= self.set("2fa_backup_hashes", [])
        success &= self.set("2fa_setup_completed", False)
        success &= self.set("2fa_last_verified", "")
        return success

    # ==================== ADDITIONAL METHOD FOR FORCED SAVE / ДОПОЛНИТЕЛЬНЫЙ МЕТОД ДЛЯ ПРИНУДИТЕЛЬНОГО СОХРАНЕНИЯ / ДОДАТКОВИЙ МЕТОД ДЛЯ ПРИМУСОВОГО ЗБЕРЕЖЕННЯ ====================
    
    def force_save(self) -> bool:
        """Force save settings (without cooldown check)
        Принудительное сохранение настроек (без проверки cooldown)
        Примусове збереження налаштувань (без перевірки cooldown)"""
        config_file = self._config_file
        
        try:
            os.makedirs(os.path.dirname(config_file), exist_ok=True)
            
            save_data = self._data.copy()
            save_data["_schema_version"] = SCHEMA_VERSION
            
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, indent=2, ensure_ascii=False)
            
            self._last_save_time = time.time()
            logger.info(f"Config force saved to: {config_file}")
            return True
        except (OSError, IOError, PermissionError, TypeError) as e:
            logger.error(f"Failed to force save config: {e}")
            return False


# ==================== AUTO SAVE ON EXIT / АВТОМАТИЧЕСКОЕ СОХРАНЕНИЕ ПРИ ЗАКРЫТИИ / АВТОМАТИЧНЕ ЗБЕРЕЖЕННЯ ПРИ ЗАКРИТТІ ====================

import atexit

def _save_config_on_exit():
    """Save settings on program exit / Сохраняет настройки при закрытии программы / Зберігає налаштування при закритті програми"""
    try:
        config = Config()
        config.force_save()
        logger.info("Config saved on exit")
    except (OSError, IOError, PermissionError, AttributeError) as e:
        logger.error(f"Failed to save config on exit: {e}")

atexit.register(_save_config_on_exit)


__all__ = [
    'Config',
    'ConfigError',
    'ConfigCorruptionError',
    'ConfigMigrationError',
    'ConfigValidationError',
]