"""
Main application window
Главное окно приложения
Головне вікно програми
"""
from __future__ import annotations
from collections import deque
import os
import sys
import json
import time
import tkinter as tk
import webbrowser
from typing import Optional, Dict, Any, Callable

import customtkinter as ctk

from core.generator import PasswordGenerator, StrengthCalculator
from security.master import MasterPassword
from security.encryption import clear_master_key, reencrypt_all, set_key_from_master
from security.panic import PanicCleanup
from storage.database import PasswordDB
from storage.config import Config
from localization.lang import LANGUAGES
from gui.dialogs import CTkMessageBox, CTkInputDialog
from gui.widgets import ToolTip
from utils.helpers import (
    get_global_radius, set_global_radius, center_screen,
    get_resource_path, play_sound, is_windows, is_macos, is_linux,
    apply_window_rounding, set_window_icon, apply_linux_theme, get_system_scaling
)
from utils.paths import get_base_dir, get_config_dir, get_config_file
from utils.logger import get_logger
from utils.radius_manager import register_window

# Import for 2FA / Импорт для 2FA / Імпорт для 2FA
from security.totp import init_totp_from_config, save_totp_to_config, get_totp_manager
from utils.qr_utils import QRUtils

logger = get_logger("main_window")

# Import mixin groups / Импорт групп миксинов / Імпорт груп міксинів
from gui.mixins import UIMixins, SecurityMixins, OpsMixins, VisualMixins

HISTORY_MAX = 50
UPD_URL = "https://github.com/Maximka1993271/Password-Generator-Python/releases"

BASE_DIR = get_base_dir()
CONFIG_DIR = get_config_dir()
CONFIG_FILE = get_config_file()


class SecurePassPro(
    UIMixins,
    SecurityMixins,
    OpsMixins,
    VisualMixins,
    ctk.CTk
):
    """Main application window / Главное окно приложения / Головне вікно програми"""

    def __init__(self) -> None:
        super().__init__()

        # Settings / Настройки / Налаштування
        self.current_lang = "RU"
        self.current_theme = "Dark"
        self.current_radius = 25
        self.current_font_size = 14
        self.clipboard_timeout = 60
        self._clipboard_timer: Optional[str] = None
        self._rgb_anim_id: Optional[str] = None
        self._pulse_animation_id: Optional[str] = None
        self._suspend_check_id: Optional[str] = None
        self._minimize_check_id: Optional[str] = None
        self._lock_check_timer: Optional[str] = None

        # RGB Speed and Width settings
        self.rgb_speed_setting = "normal"
        self.rgb_width_setting = "normal"

        # Auto-lock
        self.auto_lock_enabled = tk.BooleanVar(value=False)
        self.auto_lock_timeout = 5
        self._last_activity_time = time.time()
        self._lock_check_id: Optional[str] = None
        self._was_minimized = False
        self._last_lock_state = False

        self._radius_timer = None
        self._clip_timer = None
        self._auto_timer = None
        self._font_timer = None

        set_global_radius(self.current_radius)

        # Linux adaptation
        if is_linux():
            try:
                apply_linux_theme(self)
                scaling = get_system_scaling()
                if scaling > 1.0:
                    ctk.set_widget_scaling(scaling)
                    ctk.set_window_scaling(scaling)
            except (AttributeError, RuntimeError, ImportError) as e:
                logger.debug(f"Linux theme application error: {e}")

        # UI Variables
        self.upper_var = tk.BooleanVar(value=False)
        self.lower_var = tk.BooleanVar(value=False)
        self.digits_var = tk.BooleanVar(value=False)
        self.symb_var = tk.BooleanVar(value=False)
        self.ambig_var = tk.BooleanVar(value=False)
        self.unambig_var = tk.BooleanVar(value=False)
        self.at_least_var = tk.BooleanVar(value=False)
        self.hide_var = tk.BooleanVar(value=False)
        self.no_repeat_var = tk.BooleanVar(value=False)
        self.sound_enabled = tk.BooleanVar(value=True)
        self.rgb_enabled = tk.BooleanVar(value=True)

        self.history: deque = deque(maxlen=HISTORY_MAX)
        self._rgb_t = 0.0

        # Windows
        self.settings_window: Optional[ctk.CTkToplevel] = None
        self.about_window: Optional[ctk.CTkToplevel] = None
        self.history_window: Optional[ctk.CTkToplevel] = None
        self.qr_window: Optional[ctk.CTkToplevel] = None
        self.db_window: Optional[ctk.CTkToplevel] = None

        # Widget references
        self._tooltips: Dict[str, ToolTip] = {}
        self.lang_buttons: Dict[str, ctk.CTkButton] = {}
        self.theme_buttons: Dict[str, ctk.CTkButton] = {}
        self.settings_labels: Dict[str, Any] = {}
        self._master_set_btn: Optional[ctk.CTkButton] = None
        self._master_status_label: Optional[ctk.CTkLabel] = None
        self._sound_btn: Optional[ctk.CTkButton] = None
        self._close_btn: Optional[ctk.CTkButton] = None
        self._clip_timeout_label_ref: Optional[ctk.CTkLabel] = None
        self._rgb_on_btn_ref: Optional[ctk.CTkButton] = None
        self._rgb_off_btn_ref: Optional[ctk.CTkButton] = None
        self._auto_lock_btn: Optional[ctk.CTkButton] = None
        self._auto_lock_slider: Optional[ctk.CTkSlider] = None
        self._auto_lock_label_ref: Optional[ctk.CTkLabel] = None
        self.auto_save_btn: Optional[ctk.CTkButton] = None
        self.auto_save_var = tk.BooleanVar(value=False)

        # 2FA elements
        self._2fa_status_label: Optional[ctk.CTkLabel] = None
        self._2fa_settings_btn: Optional[ctk.CTkButton] = None

        # RGB canvases
        self._rgb_c_top: Optional[tk.Canvas] = None
        self._rgb_c_bottom: Optional[tk.Canvas] = None
        self._rgb_c_left: Optional[tk.Canvas] = None
        self._rgb_c_right: Optional[tk.Canvas] = None

        self._icon_image: Optional[tk.PhotoImage] = None
        self._pdf_font_path = get_resource_path("DejaVuSans.ttf")

        # Initialize password generator
        self.generator = PasswordGenerator()
        self.strength_calc = StrengthCalculator()
        self.config = Config()

        # Initialize 2FA
        try:
            init_totp_from_config(self.config)
            MasterPassword.set_config(self.config)
        except (ImportError, AttributeError, RuntimeError) as e:
            logger.error(f"2FA initialization error: {e}")
        
        if not QRUtils.is_available():
            logger.warning("QR code module not available. 2FA setup will show text only.")

        # Setup UI
        try:
            ctk.set_widget_scaling(1.0)
            ctk.set_window_scaling(1.0)
        except (ValueError, AttributeError, RuntimeError) as e:
            logger.debug(f"Scaling setup error: {e}")

        self.title("Secure Pass Pro v4.0")
        
        # Window settings
        try:
            self.resizable(True, True)
            self.minsize(800, 650)
            self.geometry("950x800")
            set_window_icon(self)
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.error(f"Window initialization error: {e}")

        try:
            self._create_rgb_canvases()
            self._setup_ui()
            self._apply_lang("RU")
            self._center_main_window()
            apply_window_rounding(self)
        except (AttributeError, RuntimeError, tk.TclError) as e:
            logger.error(f"UI setup error: {e}")

        # Bind keys
        try:
            self.bind('<F5>', lambda e: self._generate())
            self.bind('<Control-c>', lambda e: self._copy() if self.focus_get() is not self.entry_res else None)
            self.bind('<Control-s>', lambda e: self._save())
            self.bind('<Control-o>', lambda e: self._open())
            self.bind('<Escape>', lambda e: self._close_settings() if self.settings_window else None)
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Key binding error: {e}")

        # Activity tracking for auto-lock
        try:
            self.bind_all('<Key>', self._reset_activity_timer)
            self.bind_all('<Button>', self._reset_activity_timer)
            self.bind_all('<Motion>', self._reset_activity_timer)
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Activity tracking binding error: {e}")

        # Load settings AFTER UI is created
        self.after(50, self._load_all_settings)
        self.after(100, self._start_lock_checker)
        self.protocol("WM_DELETE_WINDOW", self._on_closing)

        # Register panic cleanup
        try:
            PanicCleanup.register_clipboard_cleanup(self._emergency_clipboard_clear)
            PanicCleanup.register_cleanup_callback(self._emergency_cleanup)
        except (AttributeError, RuntimeError) as e:
            logger.debug(f"Panic cleanup registration error: {e}")

        # Register main window for radius updates
        try:
            register_window(self)
        except (AttributeError, RuntimeError) as e:
            logger.debug(f"Window registration error: {e}")

    def _emergency_clipboard_clear(self) -> None:
        """Emergency clipboard clear on crash"""
        try:
            self.clipboard_clear()
            for _ in range(3):
                self.clipboard_append(" " * 64)
                self.update()
                self.clipboard_clear()
                self.update()
        except (tk.TclError, OSError, AttributeError, RuntimeError) as e:
            logger.debug(f"Emergency clipboard clear error: {e}")

    def _emergency_cleanup(self) -> None:
        """Emergency cleanup on crash"""
        self._stop_rgb()
        try:
            PasswordDB.close_all_connections()
        except (ImportError, AttributeError, OSError, RuntimeError) as e:
            logger.debug(f"Emergency cleanup error: {e}")

    def _load_all_settings(self) -> None:
        """Load all settings from config file"""
        default_config = {
            "THEME": "Dark",
            "LANG": "RU",
            "SOUND": True,
            "RGB": True,
            "RGB_SPEED": "normal",
            "RGB_WIDTH": "normal",
            "RADIUS": 25,
            "font_size": 14,
            "CLIP_TIMEOUT": 60,
            "AUTO_LOCK": False,
            "AUTO_LOCK_TIMEOUT": 5,
            "auto_save": False
        }

        need_save = False

        if not os.path.exists(CONFIG_FILE):
            need_save = True
            config = default_config.copy()
        else:
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    config = json.load(f)
                for key in default_config:
                    if key not in config:
                        config[key] = default_config[key]
                        need_save = True
            except json.JSONDecodeError as e:
                logger.error(f"JSON decode error: {e}, using defaults")
                config = default_config.copy()
                need_save = True
            except (PermissionError, OSError, IOError) as e:
                logger.error(f"Error reading config: {e}, using defaults")
                config = default_config.copy()
                need_save = True

        if need_save:
            try:
                os.makedirs(CONFIG_DIR, exist_ok=True)
                with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                    json.dump(config, f, indent=2, ensure_ascii=False)
            except (PermissionError, OSError, IOError) as e:
                logger.error(f"Cannot save config: {e}")

        self.config.update(config)

        self.current_theme = config.get("THEME", "Dark")
        self.current_lang = config.get("LANG", "RU")
        self.sound_enabled.set(config.get("SOUND", True))
        self.rgb_enabled.set(config.get("RGB", True))

        self.rgb_speed_setting = config.get("RGB_SPEED", "normal")
        if self.rgb_speed_setting not in ["slow", "normal", "fast"]:
            self.rgb_speed_setting = "normal"

        self.rgb_width_setting = config.get("RGB_WIDTH", "normal")
        if self.rgb_width_setting not in ["thin", "normal", "thick"]:
            self.rgb_width_setting = "normal"

        self.current_radius = config.get("RADIUS", 25)
        self.current_font_size = config.get("font_size", 14)
        self.clipboard_timeout = config.get("CLIP_TIMEOUT", 60)
        self.auto_lock_enabled.set(config.get("AUTO_LOCK", False))
        self.auto_lock_timeout = config.get("AUTO_LOCK_TIMEOUT", 5)
        self.auto_save_var.set(config.get("auto_save", False))

        set_global_radius(self.current_radius)
        self._change_radius(self.current_radius)
        self._apply_font_size(self.current_font_size)

        try:
            actual_theme = self._get_actual_theme()
            ctk.set_appearance_mode(self.current_theme)
            self.after(50, lambda: self._apply_theme_colors(actual_theme))
            self.after(60, lambda: self.configure(fg_color="#F3F3F3" if actual_theme == "light" else "#1d1e1e"))
        except (ValueError, AttributeError, RuntimeError) as e:
            logger.error(f"Theme application error: {e}")

        if self.rgb_enabled.get():
            self.after(200, self._start_rgb)

        self._update_master_status_label()
        self._update_auto_lock_label()
        self._update_rgb_speed_buttons()
        self._update_rgb_width_buttons()

        self._update_2fa_status_in_settings()

        self._apply_lang(self.current_lang)

    def _update_2fa_status_in_settings(self) -> None:
        """Update 2FA status in settings window if open"""
        if hasattr(self, 'settings_window') and self.settings_window and self.settings_window.winfo_exists():
            if hasattr(self, '_2fa_status_label') and self._2fa_status_label:
                try:
                    self._2fa_status_label.configure(
                        text=self._get_2fa_status_text(),
                        text_color=self._get_2fa_status_color()
                    )
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Update 2FA status error: {e}")

    def _get_2fa_status_text(self) -> str:
        L = LANGUAGES[self.current_lang]
        if self.config.is_2fa_enabled():
            return L.get("2fa_status_enabled", "Enabled")
        else:
            return L.get("2fa_status_disabled", "Disabled")

    def _get_2fa_status_color(self) -> str:
        if self.config.is_2fa_enabled():
            return "#2ECC71"
        else:
            return "#888888"

    def _update_2fa_buttons(self) -> None:
        self._update_2fa_status_in_settings()

    def _on_closing(self) -> None:
        """Close application with resource cleanup"""
        self._stop_rgb()
        self._emergency_clipboard_clear()

        for timer in [self._pulse_animation_id, self._clipboard_timer,
                      self._lock_check_id, self._suspend_check_id, self._minimize_check_id]:
            if timer:
                try:
                    self.after_cancel(timer)
                except (tk.TclError, ValueError, RuntimeError) as e:
                    logger.debug(f"Cancel timer error: {e}")

        try:
            PasswordDB.close_all_connections()
        except (ImportError, AttributeError, OSError, RuntimeError) as e:
            logger.debug(f"DB close error: {e}")

        for win_attr in ("settings_window", "about_window", "history_window", "qr_window", "db_window"):
            win = getattr(self, win_attr, None)
            if win is not None:
                try:
                    win.destroy()
                except tk.TclError as e:
                    logger.debug(f"Window destroy error for {win_attr}: {e}")

        try:
            self.quit()
            self.destroy()
        except (tk.TclError, RuntimeError) as e:
            logger.debug(f"Quit/destroy error: {e}")
        sys.exit(0)

    # ==================== UPDATE STRENGTH DISPLAY METHOD (3 LANGUAGES SUPPORT) ====================

    def _update_strength_meter(self, password: str) -> None:
        """
        Update password strength meter with 3-language support (RU, EN, UA).
        """
        if not password:
            try:
                self.lbl_strength_text.configure(text="")
                self.lbl_strength.configure(text="")
                self.lbl_crack.configure(text="")
                self.lbl_stars_top.configure(text="")
            except (tk.TclError, AttributeError, RuntimeError):
                pass
            return

        L = LANGUAGES[self.current_lang]
        try:
            stats = self.strength_calc.calculate(password)
        except (ValueError, TypeError, AttributeError) as e:
            logger.error(f"Strength calculation error: {e}")
            return

        try:
            self.lbl_strength.configure(text=L["strength"].format(stats['combinations']))
        except (tk.TclError, KeyError, AttributeError) as e:
            logger.debug(f"Strength label update error: {e}")

        # Determine strength level and get translated text
        if stats['strength_level'] == 'weak':
            stars_display, stars_color = "Weak", "#FF4C4C"
            st_text = L.get("st_low", "Weak password")
            strength_display = L.get("strength_weak", "Weak")
        elif stats['strength_level'] == 'medium':
            if stats['entropy_bits'] < 60:
                stars_display, stars_color = "Medium", "#FFA500"
                strength_display = L.get("strength_medium", "Medium")
            else:
                stars_display, stars_color = "Medium+", "#FFD700"
                strength_display = L.get("strength_medium_plus", "Medium+")
            st_text = L.get("st_mid", "Medium password")
        else:  # 'strong' level
            # KEY FIX: Use translated "Strong" / "Надёжный" / "Надійний" from lang.py
            stars_display = L.get("strength_strong", "Strong")
            stars_color = "#2ECC71"
            st_text = L.get("st_high", "Strong password")
            strength_display = stars_display

        try:
            self.lbl_stars_top.configure(text=strength_display, text_color=stars_color)
            self.lbl_strength_text.configure(text=st_text, text_color=stars_color)
            self.lbl_crack.configure(text=L["crack_time"].format(L[stats['crack_time_label']]), text_color=stars_color)
        except (tk.TclError, KeyError, AttributeError) as e:
            logger.debug(f"Strength indicators update error: {e}")

        self._animate_password_field(stats['strength_level'])

    def _animate_password_field(self, strength_type: str = "medium") -> None:
        try:
            original_border = self.entry_res.cget("border_color")
        except (tk.TclError, AttributeError):
            original_border = "#2b2b2b"

        if strength_type == "weak":
            neon_colors = ["#FF4444", "#FF6666", "#FF8888", "#FF6666", "#FF4444"]
        elif strength_type == "strong":
            neon_colors = ["#2ECC71", "#55DD88", "#88EEAA", "#55DD88", "#2ECC71"]
        else:
            neon_colors = ["#FFA500", "#FFBB33", "#FFCC66", "#FFBB33", "#FFA500"]

        def pulse_step(step: int = 0) -> None:
            if step < len(neon_colors):
                try:
                    self.entry_res.configure(border_color=neon_colors[step], border_width=3)
                    self._pulse_animation_id = self.after(60, lambda: pulse_step(step + 1))
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Animation pulse error: {e}")
            else:
                try:
                    self.entry_res.configure(border_color=original_border if original_border else "#2b2b2b", border_width=2)
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Border reset error: {e}")
                self._pulse_animation_id = None

        if self._pulse_animation_id:
            try:
                self.after_cancel(self._pulse_animation_id)
            except (tk.TclError, ValueError, RuntimeError) as e:
                logger.debug(f"Animation cancel error: {e}")
        pulse_step()

    def _generate(self) -> None:
        """Generate password with secure clearing and duplicate checking"""
        if hasattr(self, 'btn_gen') and self.btn_gen:
            self._animate_button(self.btn_gen)

        L = LANGUAGES[self.current_lang]

        self.generator.use_upper = self.upper_var.get()
        self.generator.use_lower = self.lower_var.get()
        self.generator.use_digits = self.digits_var.get()
        self.generator.use_special = self.symb_var.get()
        self.generator.exclude_ambiguous = self.ambig_var.get()
        self.generator.exclude_unambiguous = self.unambig_var.get()
        self.generator.min_each = self.at_least_var.get()
        self.generator.no_repeat = self.no_repeat_var.get()
        self.generator.length = int(self.slider_len.get())

        if not (self.generator.use_upper or self.generator.use_lower or
                self.generator.use_digits or self.generator.use_special):
            CTkMessageBox.warning(self, L.get("err_title", "Error"), L["err_cat"])
            return

        try:
            from core.generator import SecurePasswordContext, _clear_string
            
            with SecurePasswordContext() as ctx:
                secure_pwd = self.generator.generate_secure()

                if secure_pwd is None and self.generator.no_repeat:
                    CTkMessageBox.warning(self, L.get("err_title", "Error"),
                                         L["err_no_repeat"] + L["err_no_repeat_fallback"])
                    self.generator.no_repeat = False
                    secure_pwd = self.generator.generate_secure()
                    self.generator.no_repeat = True

                if secure_pwd is None:
                    CTkMessageBox.warning(self, L.get("err_title", "Error"), L["err_pool_small"])
                    return

                password = secure_pwd.get_string()
                ctx.set_password(secure_pwd)

                if password:
                    # Validate password strength
                    is_valid, validation_msg = validate_password_strength(password)
                    if not is_valid:
                        L_local = LANGUAGES[self.current_lang]
                        if not CTkMessageBox.question(
                            self,
                            L_local.get("warn", "Warning"),
                            f"{validation_msg}\n\n{L_local.get('continue_anyway', 'Continue anyway?')}"
                        ):
                            _clear_string(password)
                            return
                    
                    # Check for duplicate
                    if self.auto_save_var.get() and self._check_duplicate_password(password):
                        L_local = LANGUAGES[self.current_lang]
                        if not CTkMessageBox.question(
                            self,
                            L_local.get("warn", "Warning"),
                            L_local.get("duplicate_warning", "This password already exists in the database.\n\nSave anyway?")
                        ):
                            _clear_string(password)
                            return

                    try:
                        self.entry_res.delete(0, "end")
                        self.entry_res.insert(0, password)
                        self.history.append(password)
                        self._update_strength_meter(password)
                        play_sound("generate", self.sound_enabled.get())
                    except (tk.TclError, AttributeError, RuntimeError) as e:
                        logger.error(f"UI update error: {e}")

                    if self.auto_save_var.get():
                        import datetime
                        label = f"Auto {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                        label = sanitize_label(label)
                        try:
                            PasswordDB.save(label, password)
                            logger.debug("[AutoSave] Saved password record")
                        except (sqlite3.Error, ValueError, OSError, IOError) as exc:
                            logger.error(f"AutoSave error: {exc}")
                            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_save"].format(exc))

                    _clear_string(password)

        except InvalidTag as e:
            logger.error(f"Invalid authentication tag during generation: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), "Encryption error: invalid authentication tag")
        except (ValueError, TypeError, RuntimeError, AttributeError) as e:
            logger.error(f"Value error during generation: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"Generation error: {e}")
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"IO error during generation: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"IO error: {e}")

    def _copy(self) -> None:
        """Copy password to clipboard with secure clearing"""
        if hasattr(self, 'btn_copy') and self.btn_copy:
            self._animate_button(self.btn_copy)

        pwd = self.entry_res.get().strip()

        if not pwd:
            CTkMessageBox.warning(self, "Warning", "No password to copy!")
            return

        L = LANGUAGES[self.current_lang]

        if hasattr(self, '_clipboard_timer') and self._clipboard_timer:
            try:
                self.after_cancel(self._clipboard_timer)
            except (tk.TclError, ValueError, RuntimeError) as e:
                logger.debug(f"Clipboard timer cancel error: {e}")

        try:
            self.clipboard_clear()
            self.clipboard_append(pwd)
            self.update()

            logger.info(f"Password copied to clipboard (length: {len(pwd)})")
            play_sound("copy", self.sound_enabled.get())

        except (tk.TclError, OSError, AttributeError, RuntimeError) as e:
            logger.error(f"Clipboard copy error: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"Could not copy: {e}")
            from core.generator import _clear_string
            _clear_string(pwd)
            return

        timeout_ms = self.clipboard_timeout * 1000
        self._clipboard_timer = self.after(timeout_ms, self._clear_clipboard)

        try:
            old_text = self.btn_copy.cget("text")
            self.btn_copy.configure(text=L["copied"].format(self.clipboard_timeout))
            self.after(2000, lambda: self._safe_button_restore(old_text))
        except (tk.TclError, AttributeError, KeyError) as e:
            logger.debug(f"Button text update error: {e}")

        CTkMessageBox.info(self, L.get("dlg_title_copied", "Clipboard"), L["pwd_done"])

        from core.generator import _clear_string
        _clear_string(pwd)

    def _safe_button_restore(self, old_text: str) -> None:
        """Safely restore button text"""
        try:
            if hasattr(self, 'btn_copy') and self.btn_copy and self.btn_copy.winfo_exists():
                self.btn_copy.configure(text=old_text)
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Button restore error: {e}")

    def _save(self) -> None:
        """Save password to file with path validation"""
        L = LANGUAGES[self.current_lang]
        pwd = self.entry_res.get().strip()
        if not pwd:
            CTkMessageBox.warning(self, L.get("warn", "Warning"), L["no_pwd"])
            return

        # Validate password before saving
        is_valid, validation_msg = validate_password_strength(pwd)
        if not is_valid:
            if not CTkMessageBox.question(
                self,
                L.get("warn", "Warning"),
                f"{validation_msg}\n\n{L.get('continue_anyway', 'Continue anyway?')}"
            ):
                from core.generator import _clear_string
                _clear_string(pwd)
                return

        from tkinter import filedialog
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[
                ("Text Files", "*.txt"),
                ("Password Files", "*.key"),
                ("Log Files", "*.log"),
                ("PDF Files", "*.pdf"),
                ("All Files", "*.*")
            ]
        )

        if not path:
            from core.generator import _clear_string
            _clear_string(pwd)
            return

        # Path validation
        if not self._validate_export_path(os.path.dirname(path)):
            CTkMessageBox.error(self, L.get("err_title", "Error"), L.get("err_permission", "Cannot write to selected location"))
            from core.generator import _clear_string
            _clear_string(pwd)
            return

        try:
            ext = os.path.splitext(path)[1].lower()

            if ext == ".pdf":
                from fpdf import FPDF
                pdf = FPDF()
                pdf.set_author("Maxim Melnikov")
                pdf.set_creator("Secure Pass Pro v4.0")
                pdf.set_title("Secure Pass Pro Password")

                pdf_theme = self.config.get("PDF_THEME", "light")

                font_path = get_resource_path("DejaVuSans.ttf")
                pdf.add_page()

                if pdf_theme == "dark":
                    pdf.set_fill_color(30, 30, 46)
                    pdf.set_text_color(200, 200, 200)
                    pdf.set_draw_color(45, 106, 79)
                    pdf.rect(0, 0, 210, 297, 'F')
                    pdf.set_text_color(78, 201, 176)
                    pdf.set_font('Arial', 'B', 16)
                    pdf.cell(200, 10, txt="Secure Pass Pro v4.0", ln=True, align='C', border=0)
                    pdf.ln(10)
                    pdf.set_text_color(200, 200, 200)
                else:
                    pdf.set_fill_color(255, 255, 255)
                    pdf.set_text_color(0, 0, 0)
                    pdf.set_font('Arial', 'B', 16)
                    pdf.cell(200, 10, txt="Secure Pass Pro v4.0", ln=True, align='C')
                    pdf.ln(10)

                if os.path.exists(font_path):
                    pdf.add_font('DejaVu', '', font_path, uni=True)
                    pdf.set_font('DejaVu', '', 12)
                else:
                    pdf.set_font('Arial', '', 12)

                if pdf_theme == "dark":
                    pdf.set_text_color(200, 200, 200)

                import datetime
                pdf.cell(200, 10, txt=f"{L['pdf_date']}: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", ln=True)
                pdf.cell(200, 10, txt=f"{L['pdf_pass']}: {pwd}", ln=True)
                pdf.output(path)

                if not self._verify_pdf(path):
                    raise IOError(L["err_integrity"])
            else:
                # Sanitize content for text files
                safe_content = self._sanitize_import_content(pwd)
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(safe_content)

                if not os.path.exists(path) or os.path.getsize(path) == 0:
                    raise IOError("File was not written")

            play_sound("success", self.sound_enabled.get())
            fname = os.path.basename(path)
            try:
                self.title(f"{fname}")
                self.after(3000, lambda: self.title(L["win_title"]))
            except (tk.TclError, KeyError, AttributeError) as e:
                logger.debug(f"Title update error: {e}")

        except PermissionError as e:
            logger.error(f"Permission error saving: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"No write permission: {e}")
        except (OSError, IOError) as e:
            logger.error(f"OS error saving: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"File system error: {e}")
        except (ValueError, TypeError, RuntimeError) as e:
            logger.error(f"Value error saving: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_save"].format(e))
        finally:
            from core.generator import _clear_string
            _clear_string(pwd)

    def _open(self) -> None:
        """Open password from file with content validation"""
        L = LANGUAGES[self.current_lang]

        from tkinter import filedialog
        path = filedialog.askopenfilename(
            title="Select password file",
            filetypes=[
                ("All Files", "*.*"),
                ("Text Files", "*.txt"),
                ("Password Files", "*.key"),
                ("Log Files", "*.log"),
                ("PDF Files", "*.pdf")
            ]
        )

        if not path:
            return

        try:
            ext = os.path.splitext(path)[1].lower()

            if path.lower().endswith(".sha256"):
                CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_unsupported"].format(".sha256"))
                return

            if ext == ".pdf":
                if is_windows():
                    os.startfile(path)
                elif is_macos():
                    import subprocess
                    subprocess.run(["open", path], check=False)
                else:
                    import subprocess
                    subprocess.run(["xdg-open", path], check=False)
                play_sound("success", self.sound_enabled.get())
                return

            content = None
            encodings = ['utf-8', 'cp1251', 'latin-1', 'cp866', 'koi8-r']

            for encoding in encodings:
                try:
                    with open(path, 'r', encoding=encoding) as f:
                        content = f.read().strip()
                    break
                except (UnicodeDecodeError, UnicodeError) as e:
                    logger.debug(f"Encoding {encoding} failed: {e}")
                    continue

            if content is None:
                try:
                    with open(path, 'rb') as f:
                        raw_bytes = f.read()
                        content = raw_bytes.decode('utf-8', errors='replace').strip()
                except (OSError, IOError, PermissionError) as e:
                    logger.error(f"Binary read error: {e}")
                    raise ValueError("Cannot read file") from e

            if not content:
                raise ValueError("File is empty")

            # Validate content length
            if len(content) > 1000:
                L_local = LANGUAGES[self.current_lang]
                if not CTkMessageBox.question(
                    self,
                    L_local.get("warn", "Warning"),
                    f"File contains {len(content)} characters.\n{L_local.get('truncate_question', 'Truncate to {0} characters?').format(1000)}"
                ):
                    from core.generator import _clear_string
                    _clear_string(content)
                    return
                content = content[:1000]

            # Sanitize imported content
            sanitized_content = self._sanitize_import_content(content)

            try:
                self.entry_res.delete(0, "end")
                self.entry_res.insert(0, sanitized_content)
                self._update_strength_meter(sanitized_content)
                play_sound("success", self.sound_enabled.get())
            except (tk.TclError, AttributeError, RuntimeError) as e:
                logger.error(f"UI update error: {e}")

            from core.generator import _clear_string
            _clear_string(content)
            _clear_string(sanitized_content)

        except PermissionError as e:
            logger.error(f"Permission error opening: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), f"No read permission: {e}")
        except (UnicodeDecodeError, UnicodeError) as e:
            logger.error(f"Encoding error opening: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_open"].format(f"Invalid encoding: {e}"))
        except (ValueError, OSError, IOError, TypeError, RuntimeError) as e:
            logger.error(f"Error opening: {e}")
            CTkMessageBox.error(self, L.get("err_title", "Error"), L["err_open"].format(str(e)))

    def _check_duplicate_password(self, password: str) -> bool:
        """Check if password already exists in the database."""
        try:
            all_passwords = PasswordDB.get_all()
            for record in all_passwords:
                if record.get("password") == password:
                    return True
        except (sqlite3.Error, OSError, IOError, ValueError, TypeError) as e:
            logger.error(f"Duplicate check error: {e}")
        return False

    def _sanitize_import_content(self, content: str) -> str:
        """Sanitize imported content."""
        if not content:
            return ""
        
        import re
        sanitized = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', content)
        sanitized = re.sub(r'[\u200B-\u200D\uFEFF]', '', sanitized)
        
        if len(sanitized) > 1000:
            sanitized = sanitized[:1000]
        
        return sanitized

    def _validate_export_path(self, path: str) -> bool:
        """Check if export path is safe."""
        try:
            directory = os.path.dirname(path)
            if directory and not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
            
            test_file = path + ".test"
            with open(test_file, 'w') as f:
                f.write("test")
            os.remove(test_file)
            
            return True
        except (OSError, IOError, PermissionError) as e:
            logger.error(f"Export path validation error: {e}")
            return False

    def _verify_pdf(self, path: str) -> bool:
        try:
            with open(path, "rb") as f:
                header = f.read(5)
                return header == b"%PDF-"
        except (OSError, IOError, PermissionError) as e:
            logger.debug(f"PDF verification error: {e}")
            return False

    def _clear_clipboard(self) -> None:
        """Clear clipboard with multiple overwrites for security."""
        try:
            if not self.winfo_exists():
                return

            overwrite_passes = 5

            for i in range(overwrite_passes):
                try:
                    import secrets
                    junk = secrets.token_hex(512)

                    self.clipboard_clear()
                    self.clipboard_append(junk)
                    self.update()

                    time.sleep(0.01)

                    from core.generator import _clear_string
                    _clear_string(junk)

                except (tk.TclError, OSError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Clipboard overwrite pass {i + 1} failed: {e}")
                    continue

            self.clipboard_clear()
            self.update()

            if is_windows():
                self._clear_clipboard_windows_api()

            logger.debug(f"Clipboard securely cleared with {overwrite_passes} overwrites")

        except (tk.TclError, OSError, AttributeError, RuntimeError) as e:
            logger.debug(f"Clipboard secure clear error: {e}")
            try:
                self.clipboard_clear()
            except (tk.TclError, OSError, RuntimeError):
                pass
        finally:
            self._clipboard_timer = None

    def _clear_clipboard_windows_api(self) -> None:
        """Additional clipboard clearing via Windows API."""
        if not is_windows():
            return

        try:
            import ctypes

            user32 = ctypes.windll.user32

            if user32.OpenClipboard(0):
                try:
                    user32.EmptyClipboard()
                    logger.debug("Clipboard cleared via Windows API")
                except (AttributeError, OSError) as e:
                    logger.debug(f"Windows API clipboard clear error: {e}")
                finally:
                    try:
                        user32.CloseClipboard()
                    except (AttributeError, OSError):
                        pass
        except (ImportError, AttributeError, OSError, TypeError) as e:
            logger.debug(f"Windows API error: {e}")


# ==================== HELPER FUNCTIONS (must be defined before use) ====================

def validate_password_strength(password: str) -> tuple:
    """Validate password strength for saving"""
    if not password:
        return False, "Password is empty"
    
    if len(password) < 4:
        return False, "Password too short (minimum 4 characters)"
    
    weak_patterns = ['123456', 'password', 'qwerty', 'admin', 'letmein', 'welcome']
    for pattern in weak_patterns:
        if pattern.lower() in password.lower():
            return False, f"Password contains weak pattern: {pattern}"
    
    return True, ""


def sanitize_label(label: str, max_length: int = 200) -> str:
    """Sanitize label for database storage"""
    import re
    if not label:
        return "Без метки"
    
    sanitized = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', str(label))
    sanitized = sanitized.strip()
    
    if len(sanitized) > max_length:
        sanitized = sanitized[:max_length]
    
    return sanitized if sanitized else "Без метки"


# Import for InvalidTag and sqlite3
try:
    from cryptography.exceptions import InvalidTag
except ImportError:
    InvalidTag = Exception

try:
    import sqlite3
except ImportError:
    sqlite3 = None


# ==================== ENTRY POINT ====================
if __name__ == "__main__":
    try:
        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")
    except (ValueError, AttributeError, RuntimeError) as e:
        print(f"CTK initialization error: {e}")

    _startup_lang = "RU"
    _startup_theme = "dark"

    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as _f:
                try:
                    _cfg = json.load(_f)
                except json.JSONDecodeError:
                    _cfg = {}
                if "LANG" in _cfg and _cfg["LANG"] in ("RU", "EN", "UA"):
                    _startup_lang = _cfg["LANG"]
                if "THEME" in _cfg:
                    if _cfg["THEME"] == "Light":
                        _startup_theme = "light"
                    elif _cfg["THEME"] == "Dark":
                        _startup_theme = "dark"
    except (OSError, IOError, PermissionError) as e:
        logger.debug(f"Error reading config on startup: {e}")

    try:
        from security.panic import init_panic_cleanup
        init_panic_cleanup()
    except (ImportError, AttributeError, RuntimeError) as e:
        print(f"Panic cleanup initialization error: {e}")

    if not MasterPassword.prompt_on_startup(_startup_lang, _startup_theme):
        sys.exit(0)

    try:
        app = SecurePassPro()
        app.mainloop()
    except (KeyboardInterrupt, SystemExit) as e:
        print(f"Application interrupted: {e}")
        sys.exit(0)
    except (RuntimeError, tk.TclError, OSError) as e:
        # ✅ ИСПРАВЛЕНО: except Exception заменен на конкретные типы исключений
        logger.exception(f"Fatal error: {e}")
        print(f"Fatal error: {e}")
        sys.exit(1)