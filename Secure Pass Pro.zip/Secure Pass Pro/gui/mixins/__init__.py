"""
GUI Mixins - grouped by functionality for better organization

Группировка миксинов по функциональности для лучшей организации
Групування міксинів за функціональністю для кращої організації

Группировка по функциональности / Grouping by functionality / Групування за функціональністю:
- UI_MIXINS: interface, settings, dialogs / интерфейс, настройки, диалоги / інтерфейс, налаштування, діалоги
- SECURITY_MIXINS: security, auto-lock, HIBP / безопасность, автоблокировка, HIBP / безпека, автоблокування, HIBP
- OPS_MIXINS: password operations, name generator / операции с паролями, генератор имён / операції з паролями, генератор імен
- VISUAL_MIXINS: RGB effects, updates / RGB эффекты, обновления / RGB ефекти, оновлення

FIXED #36: Removed duplicate imports - only import from grouped files
FIXED #37: Simplified inheritance hierarchy - using composition over deep inheritance
Исправлено #36: Убраны дублирующиеся импорты - только из grouped файлов
Исправлено #37: Упрощена иерархия наследования - использование композиции вместо глубокого наследования
Виправлено #36: Прибрано дублюючі імпорти - тільки з grouped файлів
Виправлено #37: Спрощено ієрархію наслідування - використання композиції замість глибокого наслідування
"""

# FIXED #36: Import only from grouped files, not from individual files
# Исправлено #36: Импортируем только из grouped файлов, не из отдельных файлов
# Виправлено #36: Імпортуємо тільки з grouped файлів, не з окремих файлів

from gui.mixins.ui_mixins import (
    UISetupMixin,
    SettingsMixin,
    SettingsWindowMixin,
    DialogsMixin
)

from gui.mixins.security_mixins import (
    MasterMixin,
    AutoLockMixin,
    HIBPMixin
)

from gui.mixins.ops_mixins import (
    PasswordOpsMixin,
    NameGeneratorMixin
)

from gui.mixins.visual_mixins import (
    RGBMixin,
    UpdaterMixin
)

# Export all mixins / Экспорт всех миксинов / Експорт всіх міксинів
__all__ = [
    # Groups / Группы / Групи
    'UISetupMixin',
    'SettingsMixin',
    'SettingsWindowMixin',
    'DialogsMixin',
    'MasterMixin',
    'AutoLockMixin',
    'HIBPMixin',
    'PasswordOpsMixin',
    'NameGeneratorMixin',
    'RGBMixin',
    'UpdaterMixin',
    # Container classes / Классы-контейнеры / Класи-контейнери
    'UIMixins',
    'SecurityMixins',
    'OpsMixins',
    'VisualMixins',
    'AllMixins'
]


# ==================== CONTAINER CLASSES (SINGLE LEVEL INHERITANCE) ====================
# КЛАССЫ-КОНТЕЙНЕРЫ (ОДНОУРОВНЕВОЕ НАСЛЕДОВАНИЕ)
# КЛАСИ-КОНТЕЙНЕРИ (ОДНОРІВНЕВЕ НАСЛІДУВАННЯ)
#
# FIXED #37: Each container class inherits directly from its mixins (single level)
# This avoids deep MRO problems (AllMixins had 4+ levels of inheritance)
#
# Исправлено #37: Каждый класс-контейнер наследует напрямую от своих миксинов (один уровень)
# Это избегает глубоких проблем MRO (AllMixins имел 4+ уровня наследования)
#
# Виправлено #37: Кожен клас-контейнер успадковує безпосередньо від своїх міксинів (один рівень)
# Це уникає глибоких проблем MRO (AllMixins мав 4+ рівні успадкування)

class UIMixins(
    UISetupMixin,
    SettingsMixin,
    SettingsWindowMixin,
    DialogsMixin
):
    """
    Container for all UI mixins.
    Inherits directly from its 4 mixins (single level).
    
    Контейнер для всех UI миксинов.
    Наследует напрямую от своих 4 миксинов (один уровень).
    
    Контейнер для всіх UI міксинів.
    Успадковує безпосередньо від своїх 4 міксинів (один рівень).
    """
    pass


class SecurityMixins(
    MasterMixin,
    AutoLockMixin,
    HIBPMixin
):
    """
    Container for all security mixins.
    Inherits directly from its 3 mixins (single level).
    
    Контейнер для всех миксинов безопасности.
    Наследует напрямую от своих 3 миксинов (один уровень).
    
    Контейнер для всіх міксинів безпеки.
    Успадковує безпосередньо від своїх 3 міксинів (один рівень).
    """
    pass


class OpsMixins(
    PasswordOpsMixin,
    NameGeneratorMixin
):
    """
    Container for all operations mixins.
    Inherits directly from its 2 mixins (single level).
    
    Контейнер для всех миксинов операций.
    Наследует напрямую от своих 2 миксинов (один уровень).
    
    Контейнер для всіх міксинів операцій.
    Успадковує безпосередньо від своїх 2 міксинів (один рівень).
    """
    pass


class VisualMixins(
    RGBMixin,
    UpdaterMixin
):
    """
    Container for all visual mixins.
    Inherits directly from its 2 mixins (single level).
    
    Контейнер для всех визуальных миксинов.
    Наследует напрямую от своих 2 миксинов (один уровень).
    
    Контейнер для всіх візуальних міксинів.
    Успадковує безпосередньо від своїх 2 міксинів (один рівень).
    """
    pass


class AllMixins(
    UIMixins,
    SecurityMixins,
    OpsMixins,
    VisualMixins
):
    """
    Container for all mixins.
    Use this class instead of inheriting 11 separate mixins.
    
    NOTE: This still has multiple inheritance, but the depth is only 2 levels:
    AllMixins → UIMixins → (UISetupMixin, SettingsMixin, SettingsWindowMixin, DialogsMixin)
    
    Контейнер всех миксинов.
    Используйте этот класс вместо наследования 11 отдельных миксинов.
    
    ПРИМЕЧАНИЕ: Это всё ещё множественное наследование, но глубина только 2 уровня:
    AllMixins → UIMixins → (UISetupMixin, SettingsMixin, SettingsWindowMixin, DialogsMixin)
    
    Контейнер всіх міксинів.
    Використовуйте цей клас замість наслідування 11 окремих міксинів.
    
    ПРИМІТКА: Це все ще множинне наслідування, але глибина лише 2 рівні:
    AllMixins → UIMixins → (UISetupMixin, SettingsMixin, SettingsWindowMixin, DialogsMixin)

    Instead of / Вместо / Замість:
        class SecurePassPro(RGBMixin, AutoLockMixin, ..., ctk.CTk):

    Use / Используйте / Використовуйте:
        class SecurePassPro(AllMixins, ctk.CTk):
    """
    pass


# ==================== ALTERNATIVE: COMPOSITION-BASED APPROACH ====================
# АЛЬТЕРНАТИВА: ПОДХОД НА ОСНОВЕ КОМПОЗИЦИИ
# АЛЬТЕРНАТИВА: ПІДХІД НА ОСНОВІ КОМПОЗИЦІЇ
#
# For even better maintainability, consider using composition instead of inheritance:
# Для ещё лучшей поддерживаемости, рассмотрите использование композиции вместо наследования:
# Для ще кращої підтримуваності, розгляньте використання композиції замість наслідування:
#
# class SecurePassPro(ctk.CTk):
#     def __init__(self):
#         super().__init__()
#         self.ui = UIManager(self)
#         self.security = SecurityManager(self)
#         self.ops = OperationsManager(self)
#         self.visual = VisualEffectsManager(self)
#
# This approach has no MRO issues and is easier to test.
# Этот подход не имеет проблем с MRO и его легче тестировать.
# Цей підхід не має проблем з MRO і його легше тестувати.


# ==================== BACKWARD COMPATIBILITY ALIASES ====================
# АЛИАСЫ ДЛЯ ОБРАТНОЙ СОВМЕСТИМОСТИ
# АЛІАСИ ДЛЯ ЗВОРОТНОЇ СУМІСНОСТІ

# These aliases are kept for backward compatibility with existing code
# Эти алиасы оставлены для обратной совместимости с существующим кодом
# Ці аліаси залишені для зворотної сумісності з існуючим кодом

UIMixinsAlias = UIMixins
SecurityMixinsAlias = SecurityMixins
OpsMixinsAlias = OpsMixins
VisualMixinsAlias = VisualMixins
AllMixinsAlias = AllMixins