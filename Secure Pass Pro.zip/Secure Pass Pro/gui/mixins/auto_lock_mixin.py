"""
Auto-lock mixin for SecurePassPro
FIXED: Улучшено обнаружение блокировки рабочего стола, гибернации/сна, сворачивания окна
FIXED #57: Added tracking for focus events and child window interactions
FIXED: Improved detection of desktop lock, hibernation/sleep, window minimize
FIXED #57: Добавлено отслеживание событий фокуса и взаимодействия с дочерними окнами
FIXED: Покращено виявлення блокування робочого столу, гібернації/сну, згортання вікна
FIXED #57: Додано відстеження подій фокусу та взаємодії з дочірніми вікнами
"""
import time
import tkinter as tk
import platform
import threading
from typing import Optional, Callable
from security.master import MasterPassword
from utils.logger import get_logger

logger = get_logger("auto_lock")

# Platform detection / Определение платформы / Визначення платформи
_is_windows = platform.system() == "Windows"
_is_macos = platform.system() == "Darwin"
_is_linux = platform.system() == "Linux"

# Constants for Windows / Константы для Windows / Константи для Windows
if _is_windows:
    WM_POWERBROADCAST = 0x0218
    PBT_APMSUSPEND = 0x0001
    PBT_APMRESUMEAUTOMATIC = 0x0012
    PBT_APMRESUMESUSPEND = 0x0007
    WM_WTSSESSION_CHANGE = 0x02B1
    WTS_SESSION_LOCK = 0x0007
    WTS_SESSION_UNLOCK = 0x0008
    
    # Constants for activity detection / Константы для обнаружения активности / Константи для виявлення активності
    LASTINPUTINFO_STRUCT_SIZE = 8


class AutoLockMixin:
    """Mixin class for auto-lock functionality on inactivity, suspend, workstation lock, and minimize
    Класс-миксин для автоматической блокировки при бездействии, гибернации, блокировке рабочего стола и сворачивании
    Клас-міксин для автоматичного блокування при бездіяльності, гібернації, блокуванні робочого столу та згортанні"""

    # FIXED #57: Track child windows to reset timer on their activity
    # Исправлено #57: Отслеживаем дочерние окна для сброса таймера при их активности
    # Виправлено #57: Відстежуємо дочірні вікна для скидання таймера при їх активності
    def _reset_activity_timer(self, event=None) -> None:
        """Reset activity timer / Сбрасывает таймер активности / Скидає таймер активності"""
        if not self.auto_lock_enabled.get():
            return
        self._last_activity_time = time.time()
        
        # FIXED #57: Also reset for any child window that might have focus
        # Исправлено #57: Также сбрасываем для любого дочернего окна, которое может иметь фокус
        # Виправлено #57: Також скидаємо для будь-якого дочірнього вікна, яке може мати фокус
        self._propagate_reset_to_children()

    def _propagate_reset_to_children(self) -> None:
        """Propagate activity reset to all child windows
        Распространяет сброс активности на все дочерние окна
        Поширює скидання активності на всі дочірні вікна"""
        child_windows = ['settings_window', 'db_window', 'history_window', 'qr_window', 'about_window', '_name_window']
        for win_attr in child_windows:
            win = getattr(self, win_attr, None)
            if win and win.winfo_exists():
                try:
                    if hasattr(win, '_last_activity_time'):
                        win._last_activity_time = time.time()
                except (tk.TclError, AttributeError, RuntimeError) as e:
                    logger.debug(f"Propagate reset error: {e}")

    def _start_lock_checker(self) -> None:
        """Start all lock detection systems / Запускает все системы обнаружения блокировки / Запускає всі системи виявлення блокування"""
        self._check_lock()
        self._start_suspend_detection()
        self._start_workstation_lock_detection()
        self._start_minimize_detection()
        self._start_idle_detection()
        
        # FIXED #57: Bind focus events to reset timer
        # Исправлено #57: Привязываем события фокуса для сброса таймера
        # Виправлено #57: Прив'язуємо події фокусу для скидання таймера
        self._bind_focus_events()

    def _bind_focus_events(self) -> None:
        """Bind focus events to reset activity timer
        Привязывает события фокуса для сброса таймера активности
        Прив'язує події фокусу для скидання таймера активності"""
        try:
            # Bind focus in/out events for main window
            self.bind("<FocusIn>", self._reset_activity_timer)
            self.bind("<FocusOut>", self._on_focus_out)
            
            # Bind for all widgets in the window
            self.bind_all("<FocusIn>", self._reset_activity_timer)
        except (tk.TclError, AttributeError, RuntimeError) as e:
            logger.debug(f"Focus event binding error: {e}")

    def _on_focus_out(self, event=None) -> None:
        """Handle focus out - don't reset, just mark that focus changed
        Обрабатывает потерю фокуса - не сбрасываем, просто отмечаем изменение фокуса
        Обробляє втрату фокусу - не скидаємо, просто відмічаємо зміну фокусу"""
        self._last_focus_change = time.time()

    # ==================== LOCK ON INACTIVITY / БЛОКИРОВКА ПРИ БЕЗДЕЙСТВИИ / БЛОКУВАННЯ ПРИ БЕЗДІЯЛЬНОСТІ ====================
    
    def _start_idle_detection(self) -> None:
        """Start idle detection via API (Windows) / Запускает обнаружение неактивности через API (Windows) / Запускає виявлення неактивності через API (Windows)"""
        if not _is_windows:
            return
        
        try:
            import ctypes
            from ctypes import wintypes
            
            user32 = ctypes.windll.user32
            self._last_input_info = None
            
            def get_idle_time() -> int:
                """Get idle time in milliseconds (Windows) / Возвращает время бездействия в миллисекундах (Windows) / Повертає час бездіяльності в мілісекундах (Windows)"""
                try:
                    class LASTINPUTINFO(ctypes.Structure):
                        _fields_ = [
                            ("cbSize", wintypes.UINT),
                            ("dwTime", wintypes.DWORD)
                        ]
                    
                    lii = LASTINPUTINFO()
                    lii.cbSize = ctypes.sizeof(LASTINPUTINFO)
                    
                    if user32.GetLastInputInfo(ctypes.byref(lii)):
                        ticks = user32.GetTickCount()
                        return (ticks - lii.dwTime) & 0xFFFFFFFF
                    return 0
                except (AttributeError, OSError, TypeError):
                    return 0
            
            # Save function for use in _check_lock / Сохраняем функцию для использования в _check_lock / Зберігаємо функцію для використання в _check_lock
            self._get_idle_time = get_idle_time
            logger.debug("Idle detection started")
            
        except (ImportError, AttributeError, OSError, TypeError) as e:
            logger.debug(f"Idle detection not available: {e}")
            self._get_idle_time = lambda: 0

    def _check_lock(self) -> None:
        """Check inactivity and lock if needed / Проверяет неактивность и блокирует если нужно / Перевіряє неактивність та блокує якщо потрібно"""
        if not self.auto_lock_enabled.get():
            self._lock_check_id = self.after(1000, self._check_lock)
            return

        if not MasterPassword.is_set():
            self._lock_check_id = self.after(1000, self._check_lock)
            return

        # FIXED #57: Skip lock check if any child window is open AND has recent activity
        # Исправлено #57: Пропускаем блокировку если открыто дочернее окно И есть недавняя активность
        # Виправлено #57: Пропускаємо блокування якщо відкрито дочірнє вікно І є недавня активність
        child_windows = ['settings_window', 'db_window', 'history_window', 'qr_window', 'about_window', '_name_window']
        for win_attr in child_windows:
            win = getattr(self, win_attr, None)
            if win and win.winfo_exists():
                # Check if child window has recent activity
                child_activity_time = getattr(win, '_last_activity_time', None)
                if child_activity_time:
                    idle_time = time.time() - child_activity_time
                    if idle_time < self.auto_lock_timeout * 60:
                        self._last_activity_time = time.time()
                        self._lock_check_id = self.after(1000, self._check_lock)
                        return
                else:
                    # No activity tracking in child, just reset parent timer
                    self._last_activity_time = time.time()
                    self._lock_check_id = self.after(1000, self._check_lock)
                    return

        # Use system API to get idle time if available / Используем системный API для получения времени бездействия если доступен / Використовуємо системний API для отримання часу бездіяльності якщо доступний
        if hasattr(self, '_get_idle_time') and callable(self._get_idle_time):
            try:
                idle_ms = self._get_idle_time()
                idle_seconds = idle_ms / 1000
                if idle_seconds >= self.auto_lock_timeout * 60:
                    self._lock_program()
                    self._lock_check_id = self.after(1000, self._check_lock)
                    return
            except (AttributeError, TypeError, RuntimeError) as e:
                logger.debug(f"Idle time detection error: {e}")
        
        # Fallback: use our timer / Используем наш таймер / Використовуємо наш таймер
        idle_time = time.time() - self._last_activity_time
        if idle_time >= self.auto_lock_timeout * 60:
            self._lock_program()

        self._lock_check_id = self.after(1000, self._check_lock)

    # ==================== LOCK ON SUSPEND (HIBERNATION/SLEEP) / БЛОКИРОВКА ПРИ ГИБЕРНАЦИИ/СНЕ / БЛОКУВАННЯ ПРИ ГІБЕРНАЦІЇ/СНІ ====================

    def _start_suspend_detection(self) -> None:
        """Start detection for system suspend/resume / Запускает обнаружение приостановки/возобновления системы / Запускає виявлення призупинення/відновлення системи"""
        if _is_windows:
            self._check_suspend_windows()
        elif _is_macos:
            self._check_suspend_macos()
        elif _is_linux:
            self._check_suspend_linux()

    def _check_suspend_windows(self) -> None:
        """Detect Windows suspend/resume using window procedure / Обнаружение приостановки/возобновления Windows через процедуру окна / Виявлення призупинення/відновлення Windows через процедуру вікна"""
        try:
            import ctypes
            
            user32 = ctypes.windll.user32
            hwnd = self.winfo_id()
            
            # Get current window procedure / Получаем текущую процедуру окна / Отримуємо поточну процедуру вікна
            GWL_WNDPROC = -4
            old_wndproc = user32.GetWindowLongW(hwnd, GWL_WNDPROC)
            
            # Define callback type / Определяем тип колбэка / Визначаємо тип колбека
            WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int)
            
            def wndproc(hwnd_val: int, msg: int, wParam: int, lParam: int) -> int:
                if msg == WM_POWERBROADCAST:
                    if wParam == PBT_APMSUSPEND:
                        logger.debug("System suspend detected, locking program")
                        try:
                            self.after(0, self._lock_program)
                        except (tk.TclError, RuntimeError) as e:
                            logger.debug(f"Lock on suspend error: {e}")
                return user32.CallWindowProcW(old_wndproc, hwnd_val, msg, wParam, lParam)
            
            # Set new window procedure / Устанавливаем новую процедуру окна / Встановлюємо нову процедуру вікна
            new_wndproc = WNDPROC(wndproc)
            user32.SetWindowLongW(hwnd, GWL_WNDPROC, ctypes.cast(new_wndproc, ctypes.c_void_p).value)
            
            # Keep reference to prevent garbage collection / Сохраняем ссылку для предотвращения сборки мусора / Зберігаємо посилання для запобігання збиранню сміття
            self._suspend_wndproc = new_wndproc
            
        except (ImportError, AttributeError, OSError, TypeError, tk.TclError) as e:
            logger.debug(f"Windows suspend detection failed: {e}")

    def _check_suspend_macos(self) -> None:
        """Detect macOS suspend/resume using system events / Обнаружение приостановки/возобновления macOS через системные события / Виявлення призупинення/відновлення macOS через системні події"""
        try:
            import subprocess
            import threading
            
            def monitor():
                last_time = time.time()
                while True:
                    try:
                        result = subprocess.run(
                            ['sysctl', '-n', 'kern.boottime'], 
                            capture_output=True, text=True, timeout=5
                        )
                        if result.returncode == 0:
                            import re
                            match = re.search(r'sec = (\d+)', result.stdout)
                            if match:
                                uptime = time.time() - float(match.group(1))
                                if uptime < last_time - 5:
                                    logger.debug("macOS suspend detected, locking program")
                                    try:
                                        self.after(0, self._lock_program)
                                    except (tk.TclError, RuntimeError) as e:
                                        logger.debug(f"Lock on suspend error: {e}")
                                last_time = uptime
                    except (subprocess.SubprocessError, TimeoutError, ValueError, TypeError) as e:
                        logger.debug(f"macOS suspend monitor error: {e}")
                    time.sleep(10)
            
            thread = threading.Thread(target=monitor, daemon=True)
            thread.start()
        except ImportError as e:
            logger.debug(f"macOS suspend detection failed: {e}")

    def _check_suspend_linux(self) -> None:
        """Detect Linux suspend/resume using log monitoring / Обнаружение приостановки/возобновления Linux через мониторинг логов / Виявлення призупинення/відновлення Linux через моніторинг логів"""
        try:
            import subprocess
            import threading
            
            def monitor():
                last_line = None
                while True:
                    try:
                        result = subprocess.run(
                            ['journalctl', '--since=now', '-n', '5', '-o', 'cat'],
                            capture_output=True, text=True, timeout=5
                        )
                        if result.returncode == 0:
                            for line in result.stdout.split('\n'):
                                if 'Resuming' in line or 'resumed' in line or 'wakeup' in line.lower():
                                    if line != last_line:
                                        logger.debug("Linux resume detected, checking lock")
                                        # Check master password after resume / Проверяем мастер-пароль после пробуждения / Перевіряємо майстер-пароль після пробудження
                                        try:
                                            if MasterPassword.is_set() and self.auto_lock_enabled.get():
                                                self.after(0, self._lock_program)
                                        except (AttributeError, RuntimeError) as e:
                                            logger.debug(f"Lock on resume error: {e}")
                                        last_line = line
                    except (subprocess.SubprocessError, TimeoutError, ValueError, TypeError) as e:
                        logger.debug(f"Linux suspend monitor error: {e}")
                    time.sleep(10)
            
            thread = threading.Thread(target=monitor, daemon=True)
            thread.start()
        except ImportError as e:
            logger.debug(f"Linux suspend detection failed: {e}")

    # ==================== LOCK ON WORKSTATION LOCK (DESKTOP LOCK) / БЛОКИРОВКА РАБОЧЕГО СТОЛА / БЛОКУВАННЯ РОБОЧОГО СТОЛУ ====================

    def _start_workstation_lock_detection(self) -> None:
        """Start detection for workstation lock (Windows only) / Запускает обнаружение блокировки рабочего стола (только Windows) / Запускає виявлення блокування робочого столу (тільки Windows)"""
        if _is_windows:
            self._check_workstation_lock_windows()

    def _check_workstation_lock_windows(self) -> None:
        """Detect Windows workstation lock/unlock using WTS session notifications / Обнаружение блокировки/разблокировки рабочего стола Windows через уведомления сессий WTS / Виявлення блокування/розблокування робочого столу Windows через сповіщення сесій WTS"""
        try:
            import ctypes
            
            user32 = ctypes.windll.user32
            hwnd = self.winfo_id()
            
            GWL_WNDPROC = -4
            old_wndproc = user32.GetWindowLongW(hwnd, GWL_WNDPROC)
            
            WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int)
            
            def wndproc(hwnd_val: int, msg: int, wParam: int, lParam: int) -> int:
                if msg == WM_WTSSESSION_CHANGE:
                    if wParam == WTS_SESSION_LOCK:
                        logger.debug("Workstation locked, locking program")
                        try:
                            self.after(0, self._lock_program)
                        except (tk.TclError, RuntimeError) as e:
                            logger.debug(f"Lock on workstation lock error: {e}")
                    elif wParam == WTS_SESSION_UNLOCK:
                        logger.debug("Workstation unlocked")
                return user32.CallWindowProcW(old_wndproc, hwnd_val, msg, wParam, lParam)
            
            new_wndproc = WNDPROC(wndproc)
            user32.SetWindowLongW(hwnd, GWL_WNDPROC, ctypes.cast(new_wndproc, ctypes.c_void_p).value)
            
            # Register for session notifications / Регистрируемся для получения уведомлений сессий / Реєструємося для отримання сповіщень сесій
            try:
                wtsapi32 = ctypes.windll.wtsapi32
                if wtsapi32.WTSRegisterSessionNotification:
                    wtsapi32.WTSRegisterSessionNotification(hwnd, 0)
            except (AttributeError, OSError) as e:
                logger.debug(f"WTSRegisterSessionNotification failed: {e}")
            
            # Keep references / Сохраняем ссылки / Зберігаємо посилання
            self._lock_wndproc = new_wndproc
            
        except (ImportError, AttributeError, OSError, TypeError, tk.TclError) as e:
            logger.debug(f"Windows workstation lock detection failed: {e}")

    # ==================== LOCK ON MINIMIZE (WINDOW MINIMIZE) / БЛОКИРОВКА ПРИ СВОРАЧИВАНИИ ОКНА / БЛОКУВАННЯ ПРИ ЗГОРТАННІ ВІКНА ====================

    def _start_minimize_detection(self) -> None:
        """Start detection for window minimize/restore / Запускает обнаружение сворачивания/восстановления окна / Запускає виявлення згортання/відновлення вікна"""
        self._check_minimize()

    def _check_minimize(self) -> None:
        """Check if window was minimized / Проверяет, было ли окно свернуто / Перевіряє, чи було вікно згорнуто"""
        try:
            if not self.winfo_exists():
                return

            is_minimized = False

            if _is_windows:
                try:
                    import ctypes
                    is_minimized = ctypes.windll.user32.IsIconic(self.winfo_id())
                except (ImportError, AttributeError, OSError, TypeError) as e:
                    logger.debug(f"IsIconic check failed: {e}")

            if self.auto_lock_enabled.get() and MasterPassword.is_set():
                if is_minimized:
                    if not getattr(self, '_was_minimized', False):
                        logger.debug("Window minimized, locking program")
                        try:
                            self.after(0, self._lock_program)
                        except (tk.TclError, RuntimeError) as e:
                            logger.debug(f"Lock on minimize error: {e}")
                        self._was_minimized = True
                else:
                    self._was_minimized = False

        except (tk.TclError, RuntimeError) as e:
            logger.debug(f"Minimize check error: {e}")

        if hasattr(self, '_minimize_check_id') and self._minimize_check_id:
            try:
                self.after_cancel(self._minimize_check_id)
            except (tk.TclError, ValueError) as e:
                logger.debug(f"Cancel minimize check error: {e}")
        self._minimize_check_id = self.after(1000, self._check_minimize)

    # ==================== HELPER METHODS / ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ / ДОПОМІЖНІ МЕТОДИ ====================

    def _close_all_child_windows(self) -> None:
        """Close all child windows before locking / Закрывает все дочерние окна перед блокировкой / Закриває всі дочірні вікна перед блокуванням"""
        windows = [
            ('db_window', '_close_db_window'),
            ('settings_window', '_close_settings'),
            ('history_window', '_close_history'),
            ('qr_window', '_close_qr'),
            ('about_window', '_close_about'),
            ('_name_window', '_close_window'),
        ]

        for win_attr, close_method in windows:
            win = getattr(self, win_attr, None)
            if win and win.winfo_exists():
                try:
                    if hasattr(self, close_method):
                        getattr(self, close_method)()
                    else:
                        win.destroy()
                except (tk.TclError, AttributeError) as e:
                    logger.debug(f"Window close error for {win_attr}: {e}")
                setattr(self, win_attr, None)

    def _lock_program(self) -> None:
        """Lock the program / Блокирует программу / Блокує програму"""
        if not MasterPassword.is_set():
            return

        # Do not lock if already locked / Не блокируем если уже заблокировано / Не блокуємо якщо вже заблоковано
        try:
            if not self.winfo_viewable():
                return
        except (tk.TclError, AttributeError):
            return

        self._close_all_child_windows()

        rgb_was_enabled = False
        try:
            rgb_was_enabled = self.rgb_enabled.get()
            if rgb_was_enabled:
                self._stop_rgb()
        except (AttributeError, tk.TclError) as e:
            logger.debug(f"RGB stop error: {e}")

        try:
            self.withdraw()
        except tk.TclError as e:
            logger.error(f"Cannot withdraw window: {e}")
            return

        try:
            unlocked = self._show_lock_screen()
        except (tk.TclError, RuntimeError, AttributeError) as e:
            logger.error(f"Lock screen error: {e}")
            unlocked = False

        if unlocked:
            try:
                self.deiconify()
                self.lift()
                self.focus_force()
            except tk.TclError as e:
                logger.error(f"Window restore error: {e}")
                return

            if rgb_was_enabled:
                try:
                    self._start_rgb()
                except (AttributeError, tk.TclError) as e:
                    logger.debug(f"RGB start error: {e}")

            self._last_activity_time = time.time()
            self._was_minimized = False
        else:
            try:
                self._on_closing()
            except (AttributeError, tk.TclError, RuntimeError) as e:
                logger.error(f"Close on lock error: {e}")
                # Force exit / Принудительный выход / Примусовий вихід
                import sys
                sys.exit(0)

    def _get_actual_theme(self) -> str:
        """Return actual theme for lock screen / Возвращает актуальную тему для lock screen / Повертає актуальну тему для lock screen"""
        if hasattr(self, 'current_theme'):
            if self.current_theme == "Light":
                return "light"
            elif self.current_theme == "Dark":
                return "dark"
        return "dark"

    def _get_colors_for_theme(self, theme: str) -> dict:
        """Return colors for theme / Возвращает цвета для темы / Повертає кольори для теми"""
        if theme == "light":
            return {
                "bg": "#F3F3F3",
                "fg": "#000000",
                "entry_bg": "#FFFFFF",
                "label_text": "#000000",
                "button_fg": "#1f538d"
            }
        return {
            "bg": "#1d1e1e",
            "fg": "#FFFFFF",
            "entry_bg": "#2b2b2b",
            "label_text": "#FFFFFF",
            "button_fg": "#1f538d"
        }

    def _center_window_relative_to_parent(self, window, width: int, height: int) -> None:
        """Center window relative to parent / Центрирует окно относительно родителя / Центрує вікно відносно батька"""
        try:
            window.update_idletasks()
            parent_x = self.winfo_x()
            parent_y = self.winfo_y()
            parent_width = self.winfo_width()
            parent_height = self.winfo_height()
            x = parent_x + (parent_width // 2) - (width // 2)
            y = parent_y + (parent_height // 2) - (height // 2)

            screen_width = self.winfo_screenwidth()
            screen_height = self.winfo_screenheight()

            if x < 0:
                x = 10
            if y < 30:
                y = 30
            if x + width > screen_width:
                x = screen_width - width - 10
            if y + height > screen_height:
                y = screen_height - height - 10

            window.geometry(f"{width}x{height}+{x}+{y}")
        except (tk.TclError, AttributeError) as e:
            logger.debug(f"Window centering error: {e}")