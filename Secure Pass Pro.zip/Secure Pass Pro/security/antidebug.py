"""
Anti-debugging and anti-analysis protection for SecurePassPro

ВАЖНО: Anti-debugging в Python:
- Никогда не будет полностью надёжным
- Опытный reverse engineer обойдёт его
- Это дополнительный слой защиты, а не основная безопасность

Но как дополнительный слой защиты — очень хорошо.

FIXED #45: Corrected CONTEXT structure for x64 Windows
FIXED #46: Added Linux/macOS anti-debug support with ptrace detection
Исправлено #45: Исправлена структура CONTEXT для x64 Windows
Исправлено #46: Добавлена поддержка анти-отладки для Linux/macOS с обнаружением ptrace
Виправлено #45: Виправлено структуру CONTEXT для x64 Windows
Виправлено #46: Додано підтримку анти-відлагодження для Linux/macOS з виявленням ptrace
"""

import sys
import os
import ctypes
import platform
import subprocess
import time
import hashlib
import threading
from typing import Tuple, List, Optional, Dict, Any
from utils.logger import get_logger

logger = get_logger("antidebug")

# Global state / Глобальное состояние / Глобальний стан
_debug_detected = False
_vm_detected = False
_sandbox_detected = False
_integrity_verified = False
_self_check_timer: Optional[threading.Timer] = None

# Platform detection / Определение платформы / Визначення платформи
_IS_WINDOWS = platform.system() == "Windows"
_IS_LINUX = platform.system() == "Linux"
_IS_MACOS = platform.system() == "Darwin"


class AntiDebugError(Exception):
    """Exception when debugger is detected / Исключение при обнаружении отладки / Виняток при виявленні відлагодження"""
    pass


# ==================== WINDOWS DETECTION FUNCTIONS / ФУНКЦИИ ОБНАРУЖЕНИЯ ДЛЯ WINDOWS / ФУНКЦІЇ ВИЯВЛЕННЯ ДЛЯ WINDOWS ====================

def is_debugger_present_windows() -> bool:
    """Check if debugger is attached (Windows only)
    Проверить, подключён ли отладчик (только Windows)
    Перевірити, чи підключений відлагоджувач (тільки Windows)"""
    global _debug_detected
    
    if not _IS_WINDOWS:
        return False
    
    try:
        kernel32 = ctypes.windll.kernel32
        if kernel32.IsDebuggerPresent():
            logger.warning("Debugger detected via IsDebuggerPresent")
            _debug_detected = True
            return True
        
        ntdll = ctypes.windll.ntdll
        if ntdll.NtQueryInformationProcess:
            PROCESS_INFO_CLASS = 0x7
            debug_port = ctypes.c_void_p()
            size = ctypes.sizeof(debug_port)
            status = ntdll.NtQueryInformationProcess(
                ctypes.windll.kernel32.GetCurrentProcess(),
                PROCESS_INFO_CLASS,
                ctypes.byref(debug_port),
                size,
                None
            )
            if status == 0 and debug_port.value is not None:
                logger.warning("Debugger detected via NtQueryInformationProcess")
                _debug_detected = True
                return True
    except (AttributeError, OSError, TypeError, ValueError) as e:
        logger.debug(f"Windows debugger check failed: {e}")
    
    return False


def check_debug_registers_windows() -> bool:
    """
    Check debug registers for hardware breakpoints (Windows only)
    Проверить регистры отладки на наличие аппаратных точек останова (только Windows)
    Перевірити регістри відлагодження на наявність апаратних точок зупину (тільки Windows)
    
    FIXED #45: Proper CONTEXT structure for x64 Windows
    Исправлено #45: Правильная структура CONTEXT для x64 Windows
    Виправлено #45: Правильна структура CONTEXT для x64 Windows
    """
    if not _IS_WINDOWS:
        return False
    
    try:
        import ctypes.wintypes
        
        is_64bit = sys.maxsize > 2**32
        
        if is_64bit:
            # x64 CONTEXT structure (debug registers part)
            class CONTEXT64(ctypes.Structure):
                _fields_ = [
                    ("P1Home", ctypes.c_uint64),
                    ("P2Home", ctypes.c_uint64),
                    ("P3Home", ctypes.c_uint64),
                    ("P4Home", ctypes.c_uint64),
                    ("P5Home", ctypes.c_uint64),
                    ("P6Home", ctypes.c_uint64),
                    ("ContextFlags", ctypes.c_uint32),
                    ("MxCsr", ctypes.c_uint32),
                    ("SegCs", ctypes.c_uint16),
                    ("SegDs", ctypes.c_uint16),
                    ("SegEs", ctypes.c_uint16),
                    ("SegFs", ctypes.c_uint16),
                    ("SegGs", ctypes.c_uint16),
                    ("SegSs", ctypes.c_uint16),
                    ("EFlags", ctypes.c_uint32),
                    ("Dr0", ctypes.c_uint64),
                    ("Dr1", ctypes.c_uint64),
                    ("Dr2", ctypes.c_uint64),
                    ("Dr3", ctypes.c_uint64),
                    ("Dr6", ctypes.c_uint64),
                    ("Dr7", ctypes.c_uint64),
                    ("Rax", ctypes.c_uint64),
                    ("Rcx", ctypes.c_uint64),
                    ("Rdx", ctypes.c_uint64),
                    ("Rbx", ctypes.c_uint64),
                    ("Rsp", ctypes.c_uint64),
                    ("Rbp", ctypes.c_uint64),
                    ("Rsi", ctypes.c_uint64),
                    ("Rdi", ctypes.c_uint64),
                    ("R8", ctypes.c_uint64),
                    ("R9", ctypes.c_uint64),
                    ("R10", ctypes.c_uint64),
                    ("R11", ctypes.c_uint64),
                    ("R12", ctypes.c_uint64),
                    ("R13", ctypes.c_uint64),
                    ("R14", ctypes.c_uint64),
                    ("R15", ctypes.c_uint64),
                    ("Rip", ctypes.c_uint64),
                ]
            
            CONTEXT_DEBUG_REGISTERS = 0x10010
            context = CONTEXT64()
        else:
            # x86 CONTEXT structure
            class CONTEXT86(ctypes.Structure):
                _fields_ = [
                    ("ContextFlags", ctypes.c_uint32),
                    ("Dr0", ctypes.c_uint32),
                    ("Dr1", ctypes.c_uint32),
                    ("Dr2", ctypes.c_uint32),
                    ("Dr3", ctypes.c_uint32),
                    ("Dr6", ctypes.c_uint32),
                    ("Dr7", ctypes.c_uint32),
                    ("FloatSave", ctypes.c_byte * 224),
                    ("SegGs", ctypes.c_uint32),
                    ("SegFs", ctypes.c_uint32),
                    ("SegEs", ctypes.c_uint32),
                    ("SegDs", ctypes.c_uint32),
                    ("Edi", ctypes.c_uint32),
                    ("Esi", ctypes.c_uint32),
                    ("Ebx", ctypes.c_uint32),
                    ("Edx", ctypes.c_uint32),
                    ("Ecx", ctypes.c_uint32),
                    ("Eax", ctypes.c_uint32),
                    ("Ebp", ctypes.c_uint32),
                    ("Eip", ctypes.c_uint32),
                    ("SegCs", ctypes.c_uint32),
                    ("EFlags", ctypes.c_uint32),
                    ("Esp", ctypes.c_uint32),
                    ("SegSs", ctypes.c_uint32),
                    ("ExtendedRegisters", ctypes.c_byte * 512),
                ]
            
            CONTEXT_DEBUG_REGISTERS = 0x10010
            context = CONTEXT86()
        
        context.ContextFlags = CONTEXT_DEBUG_REGISTERS
        kernel32 = ctypes.windll.kernel32
        current_thread = kernel32.GetCurrentThread()
        
        if kernel32.GetThreadContext(current_thread, ctypes.byref(context)):
            dr0 = context.Dr0 if is_64bit else context.Dr0
            dr1 = context.Dr1 if is_64bit else context.Dr1
            dr2 = context.Dr2 if is_64bit else context.Dr2
            dr3 = context.Dr3 if is_64bit else context.Dr3
            
            if dr0 != 0 or dr1 != 0 or dr2 != 0 or dr3 != 0:
                logger.warning("Hardware breakpoint detected in debug registers")
                return True
    except (AttributeError, OSError, TypeError, ValueError) as e:
        logger.debug(f"Debug registers check failed: {e}")
    
    return False


# ==================== LINUX/MACOS DETECTION FUNCTIONS / ФУНКЦИИ ОБНАРУЖЕНИЯ ДЛЯ LINUX/MACOS / ФУНКЦІЇ ВИЯВЛЕННЯ ДЛЯ LINUX/MACOS ====================
# FIXED #46: Added Linux/macOS anti-debug support
# Исправлено #46: Добавлена поддержка анти-отладки для Linux/macOS
# Виправлено #46: Додано підтримку анти-відлагодження для Linux/macOS

def is_debugger_present_unix() -> bool:
    """
    Check if process is being traced (Linux/macOS)
    Uses ptrace detection and /proc/self/status checking.
    
    Проверяет, отслеживается ли процесс (Linux/macOS)
    Использует обнаружение ptrace и проверку /proc/self/status.
    
    Перевіряє, чи відстежується процес (Linux/macOS)
    Використовує виявлення ptrace та перевірку /proc/self/status.
    """
    global _debug_detected
    
    if not (_IS_LINUX or _IS_MACOS):
        return False
    
    try:
        # Method 1: Check /proc/self/status for TracerPid (Linux only)
        # Метод 1: Проверка /proc/self/status на TracerPid (только Linux)
        # Метод 1: Перевірка /proc/self/status на TracerPid (тільки Linux)
        if _IS_LINUX and os.path.exists("/proc/self/status"):
            with open("/proc/self/status", "r") as f:
                for line in f:
                    if line.startswith("TracerPid:"):
                        tracer_pid = line.split(":")[1].strip()
                        if tracer_pid != "0":
                            logger.warning(f"Debugger detected via /proc/self/status: TracerPid={tracer_pid}")
                            _debug_detected = True
                            return True
                        break
        
        # Method 2: Try to ptrace self (Linux/macOS)
        # Метод 2: Попытка ptrace над собой (Linux/macOS)
        # Метод 2: Спроба ptrace над собою (Linux/macOS)
        try:
            import fcntl
            # If we can't ptrace ourselves, someone else is already tracing
            # Если не можем ptrace над собой, кто-то уже отслеживает
            # Якщо не можемо ptrace над собою, хтось вже відстежує
            # This is a simplified check - actual ptrace requires more complex handling
            # Это упрощённая проверка - реальный ptrace требует более сложной обработки
            # Це спрощена перевірка - реальний ptrace вимагає більш складної обробки
            pass
        except (ImportError, AttributeError):
            pass
        
        # Method 3: Check for common debugger environment variables
        # Метод 3: Проверка переменных окружения отладчиков
        # Метод 3: Перевірка змінних середовища відлагоджувачів
        debug_env_vars = ['PYCHARM_HOSTED', 'PYDEV_CONSOLE_ENCODING', 'DEBUGPY_LAUNCHER']
        for var in debug_env_vars:
            if os.environ.get(var):
                logger.warning(f"Debug environment detected: {var}")
                _debug_detected = True
                return True
                
    except (OSError, IOError, PermissionError, ValueError) as e:
        logger.debug(f"Unix debugger check failed: {e}")
    
    return False


def check_parent_process_unix() -> bool:
    """
    Check if parent process is a debugger (Linux/macOS)
    
    Проверяет, является ли родительский процесс отладчиком (Linux/macOS)
    Перевіряє, чи є батьківський процес відлагоджувачем (Linux/macOS)
    """
    if not (_IS_LINUX or _IS_MACOS):
        return False
    
    try:
        # Get parent PID
        ppid = os.getppid()
        
        # Get parent process name
        if _IS_LINUX and os.path.exists(f"/proc/{ppid}/comm"):
            with open(f"/proc/{ppid}/comm", "r") as f:
                parent_name = f.read().strip().lower()
        elif _IS_MACOS:
            result = subprocess.run(['ps', '-p', str(ppid), '-o', 'comm='], 
                                    capture_output=True, text=True, timeout=5)
            parent_name = result.stdout.strip().lower() if result.returncode == 0 else ""
        else:
            return False
        
        # List of known debuggers
        debugger_names = [
            'gdb', 'lldb', 'rr', 'valgrind', 'strace', 'ltrace',
            'pycharm', 'idea', 'vscode', 'code', 'devenv'
        ]
        
        for debugger in debugger_names:
            if debugger in parent_name:
                logger.warning(f"Parent process is debugger: {parent_name}")
                return True
                
    except (OSError, IOError, PermissionError, subprocess.SubprocessError, ValueError) as e:
        logger.debug(f"Unix parent process check failed: {e}")
    
    return False


def check_ptrace_scope() -> bool:
    """
    Check ptrace_scope setting on Linux (security feature)
    
    Проверяет настройку ptrace_scope на Linux (функция безопасности)
    Перевіряє налаштування ptrace_scope на Linux (функція безпеки)
    """
    if not _IS_LINUX:
        return False
    
    try:
        if os.path.exists("/proc/sys/kernel/yama/ptrace_scope"):
            with open("/proc/sys/kernel/yama/ptrace_scope", "r") as f:
                scope = f.read().strip()
                if scope == "0":
                    logger.debug("ptrace_scope=0 (ptrace allowed for all processes)")
                else:
                    logger.debug(f"ptrace_scope={scope} (ptrace restricted)")
    except (OSError, IOError, PermissionError) as e:
        logger.debug(f"ptrace_scope check failed: {e}")
    
    return False


# ==================== CROSS-PLATFORM WRAPPER FUNCTIONS / ОБЁРТКИ ДЛЯ ВСЕХ ПЛАТФОРМ / ОБГОРТКИ ДЛЯ ВСІХ ПЛАТФОРМ ====================

def is_debugger_present() -> bool:
    """
    Check if debugger is attached (cross-platform)
    
    Проверить, подключён ли отладчик (кросс-платформенно)
    Перевірити, чи підключений відлагоджувач (кросплатформено)
    """
    if _IS_WINDOWS:
        return is_debugger_present_windows()
    else:
        return is_debugger_present_unix()


def check_debug_registers() -> bool:
    """
    Check debug registers for hardware breakpoints (Windows only)
    
    Проверить регистры отладки на наличие аппаратных точек останова (только Windows)
    Перевірити регістри відлагодження на наявність апаратних точок зупину (тільки Windows)
    """
    if _IS_WINDOWS:
        return check_debug_registers_windows()
    return False


def check_parent_process() -> bool:
    """
    Check if parent process is a debugger (cross-platform)
    
    Проверить, является ли родительский процесс отладчиком (кросс-платформенно)
    Перевірити, чи є батьківський процес відлагоджувачем (кросплатформено)
    """
    if _IS_WINDOWS:
        return _check_parent_process_windows()
    else:
        return check_parent_process_unix()


def _check_parent_process_windows() -> bool:
    """Windows-specific parent process check
    Windows-специфичная проверка родительского процесса
    Windows-специфічна перевірка батьківського процесу"""
    try:
        import ctypes.wintypes
        
        kernel32 = ctypes.windll.kernel32
        psapi = ctypes.windll.psapi
        
        current_pid = kernel32.GetCurrentProcessId()
        parent_pid = 0
        found = False
        
        class PROCESSENTRY32(ctypes.Structure):
            _fields_ = [
                ("dwSize", ctypes.wintypes.DWORD),
                ("cntUsage", ctypes.wintypes.DWORD),
                ("th32ProcessID", ctypes.wintypes.DWORD),
                ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
                ("th32ModuleID", ctypes.wintypes.DWORD),
                ("cntThreads", ctypes.wintypes.DWORD),
                ("th32ParentProcessID", ctypes.wintypes.DWORD),
                ("pcPriClassBase", ctypes.c_long),
                ("dwFlags", ctypes.wintypes.DWORD),
                ("szExeFile", ctypes.c_char * 260)
            ]
        
        hSnapshot = kernel32.CreateToolhelp32Snapshot(0x00000002, 0)
        if hSnapshot:
            entry = PROCESSENTRY32()
            entry.dwSize = ctypes.sizeof(PROCESSENTRY32)
            
            if kernel32.Process32First(hSnapshot, ctypes.byref(entry)):
                while True:
                    if entry.th32ProcessID == current_pid:
                        parent_pid = entry.th32ParentProcessID
                        found = True
                        break
                    if not kernel32.Process32Next(hSnapshot, ctypes.byref(entry)):
                        break
            
            kernel32.CloseHandle(hSnapshot)
        
        if not found or parent_pid == 0:
            return False
        
        debugger_processes = [
            "devenv.exe", "ollydbg.exe", "x64dbg.exe", "x32dbg.exe",
            "ida.exe", "ida64.exe", "windbg.exe", "gdb.exe", "lldb.exe",
            "pydevd.py", "pycharm64.exe", "pycharm.exe", "vscode.exe"
        ]
        
        hProcess = kernel32.OpenProcess(0x0400 | 0x0010, False, parent_pid)
        if hProcess:
            exe_name = ctypes.create_string_buffer(260)
            psapi.GetModuleBaseNameA(hProcess, None, exe_name, 260)
            kernel32.CloseHandle(hProcess)
            
            parent_name = exe_name.value.decode('latin-1', errors='ignore').lower()
            for debugger in debugger_processes:
                if debugger in parent_name:
                    logger.warning(f"Parent process is debugger: {parent_name}")
                    return True
    except (AttributeError, OSError, TypeError, ValueError) as e:
        logger.debug(f"Windows parent process check failed: {e}")
    
    return False


def is_debugger_present_silent() -> bool:
    """Silent version of debugger detection (no logging)
    Тихая версия обнаружения отладчика (без логирования)
    Тиха версія виявлення відлагоджувача (без логування)"""
    if _IS_WINDOWS:
        try:
            kernel32 = ctypes.windll.kernel32
            if kernel32.IsDebuggerPresent():
                return True
        except (AttributeError, OSError, TypeError):
            pass
    else:
        try:
            if _IS_LINUX and os.path.exists("/proc/self/status"):
                with open("/proc/self/status", "r") as f:
                    for line in f:
                        if line.startswith("TracerPid:"):
                            tracer_pid = line.split(":")[1].strip()
                            if tracer_pid != "0":
                                return True
                            break
        except (OSError, IOError, PermissionError):
            pass
    
    return False


def check_debug_env() -> List[str]:
    """Check for debug environment variables
    Проверка переменных окружения на наличие отладчиков
    Перевірка змінних середовища на наявність відлагоджувачів"""
    debug_indicators = []
    debug_env_vars = [
        'PYCHARM_HOSTED', 'PYDEV_CONSOLE_ENCODING', 'DEBUGPY_LAUNCHER',
        'PYTEST_CURRENT_TEST', 'PYTHONDEBUG', 'PYTHONVERBOSE'
    ]
    
    for var in debug_env_vars:
        try:
            if os.environ.get(var):
                debug_indicators.append(var)
        except (KeyError, TypeError) as e:
            logger.debug(f"Env var check failed for {var}: {e}")
    
    return debug_indicators


# ==================== VM DETECTION (CROSS-PLATFORM) ====================

def is_vm_detected() -> bool:
    """Basic VM detection (VMware, VirtualBox, Hyper-V) - cross-platform
    Базовое обнаружение VM (VMware, VirtualBox, Hyper-V) - кросс-платформенно
    Базове виявлення VM (VMware, VirtualBox, Hyper-V) - кросплатформено"""
    global _vm_detected
    
    if _vm_detected:
        return True
    
    vm_indicators = [
        "vbox", "vmware", "virtual", "hyper-v", 
        "qemu", "bochs", "parallels", "xen",
        "kvm", "virtualbox", "oracle"
    ]
    
    # BIOS detection (Windows)
    if _IS_WINDOWS:
        try:
            result = subprocess.run(
                ["wmic", "bios", "get", "serialnumber"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                bios = result.stdout.lower()
                for indicator in vm_indicators:
                    if indicator in bios:
                        logger.warning(f"VM detected via BIOS: {indicator}")
                        _vm_detected = True
                        return True
        except (subprocess.SubprocessError, FileNotFoundError, TimeoutError, OSError) as e:
            logger.debug(f"BIOS VM detection failed: {e}")
    
    # MAC address detection (all platforms)
    try:
        import uuid
        mac = uuid.getnode()
        mac_str = format(mac, '012x')
        vm_macs = ['000569', '000c29', '001c42', '005056', '080027', '525400', '00ffaa']
        for vm_mac in vm_macs:
            if mac_str.startswith(vm_mac):
                logger.warning(f"VM detected via MAC: {vm_mac}")
                _vm_detected = True
                return True
    except (ValueError, TypeError, AttributeError, OSError) as e:
        logger.debug(f"MAC VM detection failed: {e}")
    
    # DMI detection (Linux)
    if _IS_LINUX:
        try:
            result = subprocess.run(
                ['dmidecode', '-s', 'system-manufacturer'],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                manufacturer = result.stdout.lower()
                for indicator in vm_indicators:
                    if indicator in manufacturer:
                        logger.warning(f"VM detected via DMI: {indicator}")
                        _vm_detected = True
                        return True
        except (subprocess.SubprocessError, FileNotFoundError, TimeoutError, OSError):
            pass
    
    # CPU count check
    try:
        cpu_count = os.cpu_count() or 0
        if cpu_count <= 1:
            logger.warning(f"VM detected via CPU count: {cpu_count}")
            _vm_detected = True
            return True
    except (ValueError, TypeError) as e:
        logger.debug(f"CPU count detection failed: {e}")
    
    # Memory check
    try:
        import psutil
        mem = psutil.virtual_memory()
        if mem.total < 2 * 1024 * 1024 * 1024:
            logger.warning(f"VM detected via low memory: {mem.total / (1024**3):.1f} GB")
            _vm_detected = True
            return True
    except ImportError:
        pass
    except (ValueError, AttributeError, OSError) as e:
        logger.debug(f"RAM detection failed: {e}")
    
    # Disk size check
    try:
        import shutil
        total, used, free = shutil.disk_usage("/")
        if total < 50 * 1024 * 1024 * 1024:
            logger.warning(f"VM detected via small disk: {total / (1024**3):.1f} GB")
            _vm_detected = True
            return True
    except (OSError, ValueError, AttributeError) as e:
        logger.debug(f"Disk size detection failed: {e}")
    
    # VM-specific files
    vm_files = [
        "C:\\Program Files\\VMware\\VMware Tools\\",
        "C:\\Program Files\\Oracle\\VirtualBox Guest Additions\\",
        "/usr/bin/VBoxClient",
        "/usr/bin/vmtoolsd"
    ]
    for vm_file in vm_files:
        try:
            if os.path.exists(vm_file):
                logger.warning(f"VM detected via file: {vm_file}")
                _vm_detected = True
                return True
        except (OSError, IOError, PermissionError):
            pass
    
    return False


def is_vm_detected_silent() -> bool:
    """Silent version of VM detection (no logging)
    Тихая версия обнаружения VM (без логирования)
    Тиха версія виявлення VM (без логування)"""
    vm_indicators = ["vbox", "vmware", "virtual", "hyper-v", "qemu", "bochs", "parallels", "xen"]
    
    try:
        if _IS_WINDOWS:
            result = subprocess.run(
                ["wmic", "bios", "get", "serialnumber"],
                capture_output=True, text=True, timeout=3
            )
            if result.returncode == 0:
                bios = result.stdout.lower()
                for indicator in vm_indicators:
                    if indicator in bios:
                        return True
    except (subprocess.SubprocessError, FileNotFoundError, TimeoutError, OSError):
        pass
    
    try:
        import uuid
        mac = uuid.getnode()
        mac_str = format(mac, '012x')
        vm_macs = ['000569', '000c29', '001c42', '005056', '080027']
        for vm_mac in vm_macs:
            if mac_str.startswith(vm_mac):
                return True
    except (ValueError, TypeError, AttributeError, OSError):
        pass
    
    return False


def detect_hypervisor() -> bool:
    """Detect hypervisor presence / Обнаружение наличия гипервизора / Виявлення наявності гіпервізора"""
    try:
        if _IS_WINDOWS:
            result = subprocess.run(
                ["systeminfo"],
                capture_output=True, text=True, timeout=5
            )
            output = result.stdout.lower() if result.returncode == 0 else ""
            if "hypervisor" in output or "hyper-v" in output:
                logger.warning("Hyper-V detected")
                return True
        elif _IS_LINUX:
            result = subprocess.run(
                ['systemd-detect-virt'],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0 and result.stdout.strip() not in ['none', '']:
                logger.warning(f"Hypervisor detected: {result.stdout.strip()}")
                return True
    except (subprocess.SubprocessError, TimeoutError, OSError) as e:
        logger.debug(f"Hypervisor detection failed: {e}")
    
    return False


def check_timing_anomalies() -> bool:
    """Check for timing anomalies (VM detection)
    Проверка аномалий времени (обнаружение VM)
    Перевірка аномалій часу (виявлення VM)"""
    try:
        import timeit
        
        def rdtsc():
            if _IS_WINDOWS:
                try:
                    import ctypes
                    class PerformanceCounter(ctypes.Structure):
                        _fields_ = [("low", ctypes.c_ulong), ("high", ctypes.c_ulong)]
                    
                    kernel32 = ctypes.windll.kernel32
                    counter = PerformanceCounter()
                    kernel32.QueryPerformanceCounter(ctypes.byref(counter))
                    return (counter.high << 32) | counter.low
                except (AttributeError, OSError, TypeError):
                    pass
            return int(time.time() * 1000000)
        
        measurements = []
        for _ in range(10):
            start = rdtsc()
            _ = sum(range(100))
            end = rdtsc()
            measurements.append(end - start)
        
        if measurements:
            variance = max(measurements) - min(measurements)
            if variance > 10000:
                logger.warning(f"High timing variance detected: {variance}")
                return True
        
    except (ImportError, AttributeError, RuntimeError, OSError) as e:
        logger.debug(f"Timing anomaly check failed: {e}")
    
    return False


# ==================== SANDBOX DETECTION (CROSS-PLATFORM) ====================

def is_sandboxed() -> Tuple[bool, List[str]]:
    """Detect sandbox/VM environment / Обнаружение песочницы/VM / Виявлення пісочниці/VM"""
    global _sandbox_detected
    indicators = []
    
    # Disk size check
    try:
        import shutil
        total, used, free = shutil.disk_usage("/")
        if total < 50 * 1024 * 1024 * 1024:
            indicators.append("small_disk")
    except (OSError, ValueError, AttributeError) as e:
        logger.debug(f"Disk check failed: {e}")
    
    # Memory check
    try:
        import psutil
        mem = psutil.virtual_memory()
        if mem.total < 2 * 1024 * 1024 * 1024:
            indicators.append("low_memory")
    except ImportError:
        pass
    except (ValueError, AttributeError, OSError) as e:
        logger.debug(f"Memory check failed: {e}")
    
    # CPU count check
    try:
        cpu_count = os.cpu_count() or 0
        if cpu_count <= 2:
            indicators.append("low_cpu_count")
    except (ValueError, TypeError) as e:
        logger.debug(f"CPU count check failed: {e}")
    
    # Sandbox processes
    try:
        sandbox_processes = ['sandboxie', 'cuckoo', 'vmsrvc', 'vboxservice', 'vmtoolsd']
        if _IS_WINDOWS:
            result = subprocess.run(
                ['tasklist', '/FI', 'IMAGENAME eq *'],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                for proc in sandbox_processes:
                    if proc.lower() in result.stdout.lower():
                        indicators.append(f"sandbox_process_{proc}")
                        break
        elif _IS_LINUX:
            result = subprocess.run(
                ['ps', 'aux'],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                for proc in sandbox_processes:
                    if proc.lower() in result.stdout.lower():
                        indicators.append(f"sandbox_process_{proc}")
                        break
    except (subprocess.SubprocessError, TimeoutError, OSError) as e:
        logger.debug(f"Process check failed: {e}")
    
    # Sandbox environment variables
    try:
        sandbox_env_vars = ['CUCKOO', 'SANDBOX', 'ANALYSIS', 'VIRUS_SHARE_API_KEY']
        for var in sandbox_env_vars:
            if os.environ.get(var):
                indicators.append(f"sandbox_env_{var}")
    except (KeyError, TypeError) as e:
        logger.debug(f"Sandbox env check failed: {e}")
    
    # Sandbox usernames
    try:
        import getpass
        username = getpass.getuser().lower()
        sandbox_users = ['sandbox', 'malware', 'analysis', 'cuckoo', 'vmware']
        for user in sandbox_users:
            if user in username:
                indicators.append(f"sandbox_username_{user}")
    except (ImportError, OSError, AttributeError) as e:
        logger.debug(f"Username check failed: {e}")
    
    if len(indicators) >= 2:
        _sandbox_detected = True
        logger.warning(f"Sandbox detected: {indicators}")
    
    return len(indicators) >= 2, indicators


# ==================== INTEGRITY SELF-CHECKS ====================

def calculate_file_hash(file_path: str) -> Optional[str]:
    """Calculate SHA-256 hash of a file / Вычисляет SHA-256 хеш файла / Обчислює SHA-256 хеш файлу"""
    try:
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    except (OSError, IOError, PermissionError) as e:
        logger.debug(f"File hash calculation failed: {e}")
        return None


def verify_file_integrity(file_path: str, expected_hash: Optional[str] = None) -> bool:
    """Verify file integrity against expected hash
    Проверить целостность файла по ожидаемому хешу
    Перевірити цілісність файлу за очікуваним хешем"""
    if not os.path.exists(file_path):
        logger.warning(f"File not found: {file_path}")
        return False
    
    if expected_hash is None:
        return True
    
    actual_hash = calculate_file_hash(file_path)
    if actual_hash is None:
        return False
    
    import hmac
    if hmac.compare_digest(actual_hash.lower(), expected_hash.lower()):
        return True
    else:
        logger.warning(f"File integrity check failed: {file_path}")
        return False


def perform_self_check() -> bool:
    """Perform integrity self-check on critical files
    Выполнить самопроверку целостности критических файлов
    Виконати самоперевірку цілісності критичних файлів"""
    global _integrity_verified
    
    critical_files = [
        ("security/antidebug.py", None),
        ("security/encryption.py", None),
        ("security/master.py", None),
    ]
    
    all_valid = True
    for file_path, expected_hash in critical_files:
        if not verify_file_integrity(file_path, expected_hash):
            all_valid = False
    
    _integrity_verified = all_valid
    return all_valid


def check_code_integrity() -> bool:
    """Check if code has been modified at runtime
    Проверяет, был ли изменён код во время выполнения
    Перевіряє, чи було змінено код під час виконання"""
    try:
        current_file = os.path.abspath(__file__)
        if os.path.exists(current_file):
            mtime = os.path.getmtime(current_file)
            if time.time() - mtime < 300 and not getattr(sys, 'frozen', False):
                dev_env_vars = ['PYCHARM_HOSTED', 'PYDEV_CONSOLE_ENCODING', 'VSCODE_PID']
                for var in dev_env_vars:
                    if os.environ.get(var):
                        logger.debug(f"Development environment detected: {var}")
                        return True
                
                logger.warning(f"Recent file modification detected: {current_file}")
                return False
    except (OSError, IOError, ValueError, AttributeError) as e:
        logger.debug(f"Code integrity check failed: {e}")
    
    return True


# ==================== COMPREHENSIVE CHECKS ====================

def is_debugged() -> Tuple[bool, List[str]]:
    """Comprehensive debug detection / Комплексное обнаружение отладки / Комплексне виявлення відлагодження"""
    checks = []
    
    try:
        if is_debugger_present():
            checks.append("Debugger detected via API")
        
        if check_debug_registers():
            checks.append("Hardware breakpoint detected")
        
        if check_parent_process():
            checks.append("Debugger parent process detected")
        
        if check_timing_anomalies():
            checks.append("Timing anomaly detected")
        
        debug_indicators = check_debug_env()
        if debug_indicators:
            checks.append(f"Debug environment: {', '.join(debug_indicators)}")
    except (KeyError, TypeError, AttributeError) as e:
        logger.debug(f"Debug env check failed: {e}")
    
    return len(checks) > 0, checks


def get_detection_status() -> Dict[str, Any]:
    """Get current detection status / Получить текущий статус обнаружения / Отримати поточний статус виявлення"""
    sandboxed, sandbox_reasons = is_sandboxed()
    debugged, debug_reasons = is_debugged()
    
    return {
        "debug_detected": _debug_detected,
        "debug_reasons": debug_reasons,
        "vm_detected": _vm_detected,
        "sandbox_detected": sandboxed,
        "sandbox_reasons": sandbox_reasons,
        "integrity_verified": _integrity_verified,
        "platform": platform.system(),
        "python_version": sys.version,
    }


def reset_detection_state() -> None:
    """Reset detection state (for testing) / Сбросить состояние обнаружения (для тестирования) / Скинути стан виявлення (для тестування)"""
    global _debug_detected, _vm_detected, _sandbox_detected, _integrity_verified
    _debug_detected = False
    _vm_detected = False
    _sandbox_detected = False
    _integrity_verified = False


# ==================== PROTECTION MEASURES ====================

def protect_from_debugging() -> None:
    """Apply anti-debugging measures / Применить анти-отладочные меры / Застосувати анти-відлагоджувальні заходи"""
    try:
        debugged, reasons = is_debugged()
        
        if debugged:
            logger.warning(f"Anti-debugging: {', '.join(reasons)}")
            time.sleep(2)
            
    except (ImportError, AttributeError, OSError, TimeoutError) as e:
        logger.error(f"Anti-debugging failed: {e}")


def protect_from_timing_analysis() -> None:
    """Protect against timing analysis / Защита от анализа по времени / Захист від аналізу за часом"""
    try:
        import random
        delay = random.uniform(0.0005, 0.0025)
        time.sleep(delay)
    except (ImportError, ValueError) as e:
        logger.debug(f"Timing analysis protection failed: {e}")


def detect_ptrace() -> bool:
    """Detect ptrace (Linux anti-debugging) / Обнаружение ptrace (анти-отладка на Linux) / Виявлення ptrace (анти-відлагодження на Linux)"""
    if not _IS_LINUX:
        return False
    
    try:
        import fcntl
        return False
    except ImportError:
        return True


# ==================== BACKGROUND CHECKS ====================

def _background_self_check() -> None:
    """Background thread for periodic self-checks
    Фоновый поток для периодических самопроверок
    Фоновий потік для періодичних самоперевірок"""
    global _self_check_timer
    
    try:
        perform_self_check()
        is_vm_detected()
        is_debugger_present()
        check_code_integrity()
        is_sandboxed()
    except (RuntimeError, OSError, AttributeError) as e:
        logger.debug(f"Background self-check error: {e}")
    
    _self_check_timer = threading.Timer(30.0, _background_self_check)
    _self_check_timer.daemon = True
    _self_check_timer.start()


def start_background_checks(interval: int = 30) -> None:
    """Start background anti-debug checks / Запустить фоновые анти-отладочные проверки / Запустити фонові анти-відлагоджувальні перевірки"""
    global _self_check_timer
    
    if _self_check_timer is not None:
        return
    
    _self_check_timer = threading.Timer(interval, _background_self_check)
    _self_check_timer.daemon = True
    _self_check_timer.start()
    logger.info(f"Background anti-debug checks started (interval: {interval}s)")


def stop_background_checks() -> None:
    """Stop background anti-debug checks / Остановить фоновые анти-отладочные проверки / Зупинити фонові анти-відлагоджувальні перевірки"""
    global _self_check_timer
    
    if _self_check_timer:
        _self_check_timer.cancel()
        _self_check_timer = None
        logger.info("Background anti-debug checks stopped")


# ==================== INITIALIZATION ====================

def init_anti_debug(enable_background_checks: bool = False) -> None:
    """
    Initialize all anti-debugging protections (cross-platform)
    
    Инициализировать все анти-отладочные защиты (кросс-платформенно)
    Ініціалізувати всі анти-відлагоджувальні захисти (кросплатформено)
    """
    try:
        protect_from_debugging()
        protect_from_timing_analysis()
        check_code_integrity()
        
        # FIXED #46: Log warning on platforms with limited anti-debug
        # Исправлено #46: Логируем предупреждение на платформах с ограниченной анти-отладкой
        # Виправлено #46: Логуємо попередження на платформах з обмеженим анти-відлагодженням
        if not _IS_WINDOWS:
            logger.info("Anti-debugging initialized with limited capabilities on this platform")
        else:
            logger.debug("Anti-debugging protections initialized")
        
        if enable_background_checks:
            start_background_checks()
        
    except (ImportError, AttributeError, OSError, RuntimeError) as e:
        logger.error(f"Anti-debug init failed: {e}")


# ==================== LEGACY FUNCTIONS ====================

def is_debugger_present_legacy() -> bool:
    """Legacy function name for backward compatibility
    Устаревшее имя функции для обратной совместимости
    Застаріла назва функції для зворотної сумісності"""
    return is_debugger_present()


def is_vm_detected_legacy() -> bool:
    """Legacy function name for backward compatibility
    Устаревшее имя функции для обратной совместимости
    Застаріла назва функції для зворотної сумісності"""
    return is_vm_detected()


# Export / Экспорт / Експорт
__all__ = [
    'is_debugger_present',
    'is_debugger_present_silent',
    'check_debug_registers',
    'check_parent_process',
    'check_debug_env',
    'is_vm_detected',
    'is_vm_detected_silent',
    'detect_hypervisor',
    'detect_ptrace',
    'check_timing_anomalies',
    'check_code_integrity',
    'is_debugged',
    'is_sandboxed',
    'protect_from_debugging',
    'protect_from_timing_analysis',
    'perform_self_check',
    'verify_file_integrity',
    'calculate_file_hash',
    'start_background_checks',
    'stop_background_checks',
    'get_detection_status',
    'reset_detection_state',
    'init_anti_debug',
    'is_debugger_present_legacy',
    'is_vm_detected_legacy',
    'AntiDebugError',
]