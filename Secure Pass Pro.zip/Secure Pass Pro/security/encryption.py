"""
AES-256-GCM field-level encryption for password storage.
Support for key rotation, hardware-backed encryption (DPAPI/TPM), and SQLCipher.

AES-256-GCM поточное шифрование для хранения паролей.
Поддержка ротации ключей, аппаратного шифрования (DPAPI/TPM) и SQLCipher.

AES-256-GCM потокове шифрування для зберігання паролів.
Підтримка ротації ключів, апаратного шифрування (DPAPI/TPM) та SQLCipher.
"""

from __future__ import annotations
import os
import sys
import base64
import ctypes
import hashlib
import hmac
import platform
import uuid as _uuid_mod
import time
import json
import struct
from typing import Optional, Tuple, Dict, Any, List
from datetime import datetime

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes as _hashes
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    from cryptography.exceptions import InvalidTag
    _CRYPTO_OK = True
except ImportError as e:
    _CRYPTO_OK = False
    InvalidTag = Exception

from utils.logger import get_logger
from utils.secure_file_ops import secure_write, secure_read, secure_delete

logger = get_logger("encryption")


class CryptoUnavailableError(RuntimeError):
    """Encryption is required but the cryptography package is unavailable.
    Шифрование требуется, но пакет cryptography недоступен.
    Шифрування потрібне, але пакет cryptography недоступний."""
    pass


class EncryptionError(Exception):
    """Error during encryption/decryption / Ошибка при шифровании/дешифровании / Помилка при шифруванні/дешифруванні"""
    pass


class TamperDetectedError(EncryptionError):
    """Tampering detected in encrypted data / Обнаружено вмешательство в зашифрованные данные / Виявлено втручання в зашифровані дані"""
    pass


class KeyDerivationError(EncryptionError):
    """Error during key derivation / Ошибка при derivation ключа / Помилка при derivation ключа"""
    pass


class KeyRotationError(EncryptionError):
    """Error during key rotation / Ошибка при ротации ключа / Помилка при ротації ключа"""
    pass


class EncryptionVersionError(EncryptionError):
    """Error with encryption version / Ошибка версии шифрования / Помилка версії шифрування"""
    pass


# ==================== FIXED #55: Unified SCrypt parameters ====================
# Исправлено #55: Унифицированные параметры SCrypt для всех функций
# Виправлено #55: Уніфіковані параметри SCrypt для всіх функцій

# SCrypt parameters for key derivation (balanced security/performance)
# Based on OWASP recommendations (as of 2024)
# Memory: 64 MB (2^16), iterations: 8, parallelism: 1 (default for interactive use)
# These parameters are safe for both master password and machine key derivation
SCRYPT_N = 2**15      # CPU/memory cost factor (32768) - 32 MB
SCRYPT_R = 8          # Block size
SCRYPT_P = 1          # Parallelization factor

# Stronger SCrypt parameters for master password (more memory-hard)
SCRYPT_MASTER_N = 2**16  # 65536 - 64 MB
SCRYPT_MASTER_R = 8
SCRYPT_MASTER_P = 2

# Weaker SCrypt parameters for SQLCipher (performance during DB operations)
SCRYPT_SQLCIPHER_N = 2**14  # 16384 - 16 MB
SCRYPT_SQLCIPHER_R = 8
SCRYPT_SQLCIPHER_P = 1

# PBKDF2 iterations for fallback (when SCrypt not available)
PBKDF2_ITERATIONS = 600000
PBKDF2_ITERATIONS_SQLCIPHER = 64000

# ==================== END OF FIXED #55 ====================


# ── Paths / Пути / Шляхи ─────────────────────────────────────────────────────────────────────
if getattr(sys, 'frozen', False):
    _BASE_DIR = os.path.dirname(sys.executable)
else:
    _BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_DATA_DIR   = os.path.join(_BASE_DIR, "data")
_SALT_FILE  = os.path.join(_DATA_DIR, "db.salt")
_UUID_FILE  = os.path.join(_DATA_DIR, "machine.id")
_KEY_VERSION_FILE = os.path.join(_DATA_DIR, "key.version")
_KEY_ROTATION_LOG = os.path.join(_DATA_DIR, "key_rotation.json")
_SQLCIPHER_SALT_FILE = os.path.join(_DATA_DIR, "sqlcipher.salt")

# ── In-memory keys / Ключи в памяти / Ключі в пам'яті ────────────────────────────────────
_master_key:  Optional[bytearray] = None
_machine_key: Optional[bytearray] = None
_key_version: int = 1
_key_rotation_history: List[Dict[str, Any]] = []

# ── SQLCipher support / Поддержка SQLCipher / Підтримка SQLCipher ─────────────────────────────────
_sqlcipher_available = False
_sqlcipher_key: Optional[bytearray] = None
_sqlcipher_key_hex: Optional[str] = None
_sqlcipher_salt: Optional[bytes] = None

try:
    from sqlcipher3 import dbapi2 as sqlcipher
    _sqlcipher_available = True
    logger.info("SQLCipher available")
except ImportError as e:
    try:
        import sqlite3
        sqlcipher = sqlite3
        logger.info(f"SQLCipher not available, using standard SQLite: {e}")
    except ImportError as e2:
        logger.error(f"SQLite import error: {e2}")

# ── Hardware encryption (DPAPI for Windows) / Аппаратное шифрование (DPAPI для Windows) / Апаратне шифрування (DPAPI для Windows) ───────────────────────────
_DPAPI_AVAILABLE = False
_TPM_AVAILABLE = False

try:
    if sys.platform == "win32":
        import ctypes.wintypes
        
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", ctypes.wintypes.DWORD),
                       ("pbData", ctypes.POINTER(ctypes.c_char))]
        
        crypt32 = ctypes.windll.crypt32
        kernel32 = ctypes.windll.kernel32
        
        crypt32.CryptProtectData.argtypes = [ctypes.POINTER(DATA_BLOB), ctypes.c_wchar_p,
                                             ctypes.POINTER(DATA_BLOB), ctypes.c_void_p,
                                             ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(DATA_BLOB)]
        crypt32.CryptProtectData.restype = ctypes.c_bool
        
        crypt32.CryptUnprotectData.argtypes = [ctypes.POINTER(DATA_BLOB), ctypes.POINTER(ctypes.c_wchar_p),
                                               ctypes.POINTER(DATA_BLOB), ctypes.c_void_p,
                                               ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(DATA_BLOB)]
        crypt32.CryptUnprotectData.restype = ctypes.c_bool
        
        _DPAPI_AVAILABLE = True
        logger.info("DPAPI available for hardware-backed encryption")
except (ImportError, AttributeError, OSError, TypeError) as e:
    logger.debug(f"DPAPI not available: {e}")


def _dpapi_encrypt(data: bytes) -> Optional[bytes]:
    """Encrypt data using Windows DPAPI
    Шифрование данных через Windows DPAPI
    Шифрування даних через Windows DPAPI"""
    if not _DPAPI_AVAILABLE:
        return None
    
    try:
        blob_in = DATA_BLOB()
        blob_in.cbData = len(data)
        blob_in.pbData = ctypes.cast(ctypes.create_string_buffer(data), ctypes.POINTER(ctypes.c_char))
        
        blob_out = DATA_BLOB()
        if crypt32.CryptProtectData(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
            result = ctypes.string_at(blob_out.pbData, blob_out.cbData)
            kernel32.LocalFree(blob_out.pbData)
            return result
    except (OSError, TypeError, ValueError, AttributeError) as e:
        logger.error(f"DPAPI encrypt error: {e}")
    
    return None


def _dpapi_decrypt(encrypted_data: bytes) -> Optional[bytes]:
    """Decrypt data using Windows DPAPI
    Дешифрование данных через Windows DPAPI
    Дешифрування даних через Windows DPAPI"""
    if not _DPAPI_AVAILABLE:
        return None
    
    try:
        blob_in = DATA_BLOB()
        blob_in.cbData = len(encrypted_data)
        blob_in.pbData = ctypes.cast(ctypes.create_string_buffer(encrypted_data), ctypes.POINTER(ctypes.c_char))
        
        blob_out = DATA_BLOB()
        if crypt32.CryptUnprotectData(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
            result = ctypes.string_at(blob_out.pbData, blob_out.cbData)
            kernel32.LocalFree(blob_out.pbData)
            return result
    except (OSError, TypeError, ValueError, AttributeError) as e:
        logger.error(f"DPAPI decrypt error: {e}")
    
    return None


def _secure_zero(data: bytearray) -> None:
    """Zero out bytearray via ctypes.memset
    Обнуляет bytearray через ctypes.memset
    Обнуляє bytearray через ctypes.memset"""
    if data is None:
        return
    try:
        length = len(data)
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(data)), 0, length)
        # Additional pass for reliability / Дополнительный проход для надёжности / Додатковий прохід для надійності
        ctypes.memset(ctypes.addressof(ctypes.c_char.from_buffer(data)), 0, length)
    except (TypeError, AttributeError, OSError, ValueError) as e:
        logger.debug(f"Memory zeroing failed: {e}")
        try:
            for i in range(len(data)):
                data[i] = 0
        except (TypeError, IndexError, RuntimeError) as e2:
            logger.debug(f"Fallback zeroing failed: {e2}")


def _clear_bytes(data: Optional[bytes]) -> None:
    """Clear bytes (convert to bytearray and zero out)
    Очищает bytes (преобразует в bytearray и обнуляет)
    Очищує bytes (перетворює в bytearray та обнуляє)"""
    if data is None:
        return
    try:
        ba = bytearray(data)
        _secure_zero(ba)
    except (TypeError, MemoryError, OSError, ValueError) as e:
        logger.debug(f"Bytes clearing failed: {e}")


def _clear_string(s: str) -> None:
    """Clear string (convert to bytearray and zero out)
    Очищает строку (преобразует в bytearray и обнуляет)
    Очищує рядок (перетворює в bytearray та обнуляє)"""
    if not s:
        return
    if s.startswith(("[encrypted", "enc1:", "enc2:", "enc3:")):
        return
    try:
        ba = bytearray(s.encode('utf-8'))
        _secure_zero(ba)
    except (UnicodeEncodeError, TypeError, MemoryError, ValueError) as e:
        logger.debug(f"String clearing failed: {e}")


def _clear_bytearray(data: Optional[bytearray]) -> None:
    """Clear bytearray / Очищает bytearray / Очищує bytearray"""
    if data is None:
        return
    _secure_zero(data)


def _hide_dir(path: str) -> None:
    """Hide directory on Windows / Скрывает папку на Windows / Ховає папку на Windows"""
    if sys.platform == "win32":
        try:
            ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)
        except (AttributeError, OSError, TypeError) as e:
            logger.debug(f"Hide dir failed: {e}")


def _ensure_data_dir() -> None:
    """Create data directory / Создаёт папку для данных / Створює папку для даних"""
    try:
        os.makedirs(_DATA_DIR, exist_ok=True)
        _hide_dir(_DATA_DIR)
    except (PermissionError, OSError, IOError) as e:
        logger.error(f"Cannot create data dir: {e}")
        raise


def _secure_write_file(path: str, data: bytes) -> bool:
    """Atomic file write using secure_file_ops
    Атомарная запись файла с использованием secure_file_ops
    Атомарний запис файлу з використанням secure_file_ops"""
    _ensure_data_dir()
    return secure_write(path, data, make_hidden=True)


def _get_key_version() -> int:
    """Get current key version for key rotation
    Получает текущую версию ключа для key rotation
    Отримує поточну версію ключа для key rotation"""
    global _key_version
    if os.path.exists(_KEY_VERSION_FILE):
        try:
            content = secure_read(_KEY_VERSION_FILE)
            if content:
                _key_version = int(content.decode('utf-8').strip())
        except (ValueError, OSError, IOError, UnicodeDecodeError) as e:
            logger.debug(f"Key version read error: {e}")
    return _key_version


def _log_key_rotation(old_version: int, new_version: int, reason: str = "manual") -> None:
    """Log key rotation event for audit
    Логирует событие ротации ключа для аудита
    Логує подію ротації ключа для аудиту"""
    global _key_rotation_history
    
    try:
        entry = {
            "timestamp": datetime.now().isoformat(),
            "old_version": old_version,
            "new_version": new_version,
            "reason": reason,
            "platform": platform.system()
        }
        _key_rotation_history.append(entry)
        
        # Keep last 50 entries / Сохраняем последние 50 записей / Зберігаємо останні 50 записів
        if len(_key_rotation_history) > 50:
            _key_rotation_history = _key_rotation_history[-50:]
        
        with open(_KEY_ROTATION_LOG, 'w', encoding='utf-8') as f:
            json.dump(_key_rotation_history, f, indent=2, ensure_ascii=False)
    except (OSError, IOError, PermissionError, TypeError, ValueError) as e:
        logger.debug(f"Failed to log key rotation: {e}")


def _set_key_version(version: int) -> None:
    """Save key version / Сохраняет версию ключа / Зберігає версію ключа"""
    global _key_version
    old_version = _key_version
    _key_version = version
    try:
        _secure_write_file(_KEY_VERSION_FILE, str(version).encode('utf-8'))
        _log_key_rotation(old_version, version, "update")
    except (OSError, IOError, PermissionError) as e:
        logger.error(f"Failed to save key version: {e}")


def _get_salt() -> bytes:
    """Get or create encryption salt / Получает или создаёт соль для шифрования / Отримує або створює сіль для шифрування"""
    if os.path.exists(_SALT_FILE):
        try:
            content = secure_read(_SALT_FILE)
            if content and len(content) == 32:
                return content
            raise ValueError("Invalid encryption salt length")
        except (OSError, IOError, ValueError) as e:
            logger.error(f"Error reading salt: {e}")
            raise
    _ensure_data_dir()
    salt = os.urandom(32)
    _secure_write_file(_SALT_FILE, salt)
    return salt


def _get_machine_uuid() -> str:
    """Get or create machine UUID / Получает или создаёт UUID машины / Отримує або створює UUID машини"""
    if os.path.exists(_UUID_FILE):
        try:
            content = secure_read(_UUID_FILE)
            if content:
                value = content.decode('utf-8').strip()
                try:
                    _uuid_mod.UUID(value)
                except ValueError as e:
                    logger.error(f"Invalid machine id: {e}")
                    raise ValueError("Invalid machine id") from e
                return value
        except (OSError, IOError, ValueError, UnicodeDecodeError) as e:
            logger.error(f"Error reading UUID: {e}")
            raise
    _ensure_data_dir()
    new_uuid = str(_uuid_mod.uuid4())
    _secure_write_file(_UUID_FILE, new_uuid.encode("utf-8"))
    return new_uuid


def _pbkdf2(secret: bytes, salt: bytes, iterations: int = PBKDF2_ITERATIONS) -> bytearray:
    """PBKDF2 key derivation / PBKDF2 ключа / PBKDF2 ключа"""
    result = None
    try:
        if _CRYPTO_OK:
            kdf = PBKDF2HMAC(
                algorithm=_hashes.SHA256(),
                length=32, salt=salt, iterations=iterations)
            result = bytearray(kdf.derive(secret))
        else:
            result = bytearray(
                hashlib.pbkdf2_hmac('sha256', secret, salt, iterations, dklen=32))
        return result
    except (TypeError, ValueError, MemoryError, RuntimeError) as e:
        logger.error(f"PBKDF2 error: {e}")
        raise KeyDerivationError(f"Key derivation failed: {e}")
    finally:
        # Do NOT clear the secret here - it belongs to the caller
        # НЕ очищаем секрет здесь - он принадлежит вызывающей стороне
        # НЕ очищуємо секрет тут - він належить стороні, що викликає
        pass


def _scrypt_derive(secret: bytes, salt: bytes, n: int = SCRYPT_N, r: int = SCRYPT_R, p: int = SCRYPT_P) -> Optional[bytearray]:
    """SCrypt key derivation with configurable parameters
    SCrypt derivation ключа с настраиваемыми параметрами
    SCrypt derivation ключа з налаштовуваними параметрами"""
    if not _CRYPTO_OK:
        return None
    
    try:
        kdf = Scrypt(
            salt=salt,
            length=32,
            n=n,
            r=r,
            p=p
        )
        return bytearray(kdf.derive(secret))
    except (TypeError, ValueError, MemoryError, RuntimeError) as e:
        logger.debug(f"SCrypt derivation failed, falling back to PBKDF2: {e}")
        return None


def _get_machine_key() -> bytearray:
    """Get key for machine-based fallback / Получает ключ для machine-based fallback / Отримує ключ для machine-based fallback"""
    global _machine_key
    if _machine_key is None:
        machine_str = (
            _get_machine_uuid() + "|" +
            platform.node() + "|" +
            platform.machine() + "|" +
            sys.platform
        )
        # FIXED #55: Use unified SCrypt parameters
        # Исправлено #55: Используем унифицированные параметры SCrypt
        # Виправлено #55: Використовуємо уніфіковані параметри SCrypt
        key = _scrypt_derive(
            machine_str.encode('utf-8', errors='replace'),
            _get_salt(),
            n=SCRYPT_N,
            r=SCRYPT_R,
            p=SCRYPT_P
        )
        if key is None:
            key = _pbkdf2(
                machine_str.encode('utf-8', errors='replace'),
                _get_salt(),
                iterations=PBKDF2_ITERATIONS)
        _machine_key = key
        _clear_string(machine_str)
    return _machine_key


def set_key_from_master(master_password: str) -> None:
    """Set key from master password / Устанавливает ключ из мастер-пароля / Встановлює ключ з майстер-пароля"""
    global _master_key
    _zero(_master_key)
    
    # Save a copy of password for SQLCipher BEFORE clearing
    # Сохраняем копию пароля для SQLCipher ДО очистки
    # Зберігаємо копію пароля для SQLCipher ДО очищення
    sqlcipher_password = master_password
    
    try:
        # Cache salt once to avoid double read
        # Кешируем соль один раз, чтобы избежать двойного чтения
        # Кешуємо сіль один раз, щоб уникнути подвійного читання
        salt = _get_salt()
        
        # FIXED #55: Use stronger SCrypt parameters for master password
        # Исправлено #55: Используем более сильные параметры SCrypt для мастер-пароля
        # Виправлено #55: Використовуємо більш сильні параметри SCrypt для майстер-пароля
        key = _scrypt_derive(
            master_password.encode('utf-8'),
            salt,
            n=SCRYPT_MASTER_N,
            r=SCRYPT_MASTER_R,
            p=SCRYPT_MASTER_P
        )
        if key is None:
            key = _pbkdf2(
                master_password.encode('utf-8'),
                salt,
                iterations=PBKDF2_ITERATIONS)
        _master_key = key
    except KeyDerivationError as e:
        logger.error(f"Failed to derive key from master: {e}")
        raise
    finally:
        # Clear only the original password, sqlcipher_password still valid
        # Очищаем только оригинальный пароль, sqlcipher_password всё ещё валиден
        # Очищуємо лише оригінальний пароль, sqlcipher_password все ще дійсний
        _clear_string(master_password)
    
    # Use the saved copy for SQLCipher
    # Используем сохранённую копию для SQLCipher
    # Використовуємо збережену копію для SQLCipher
    if sqlcipher_password:
        set_sqlcipher_key(sqlcipher_password)
        # Clear SQLCipher password copy after use
        # Очищаем копию пароля SQLCipher после использования
        # Очищуємо копію пароля SQLCipher після використання
        _clear_string(sqlcipher_password)


def clear_master_key() -> None:
    """Clear master key from memory / Очищает мастер-ключ из памяти / Очищує майстер-ключ з пам'яті"""
    global _master_key
    _zero(_master_key)
    _master_key = None
    clear_sqlcipher_key()



def has_active_master_key() -> bool:
    """Return True when a master-derived encryption key is active."""
    return _master_key is not None

def _active_key() -> bytearray:
    """Return active key (master or machine) / Возвращает активный ключ (master или machine) / Повертає активний ключ (master або machine)"""
    return _master_key if _master_key is not None else _get_machine_key()


_ENC_PREFIX = "enc1:"
_FALLBACK_PREFIX = "enc2:"
_DPAPI_PREFIX = "enc3:"  # Hardware-backed encryption via DPAPI / Аппаратное шифрование через DPAPI / Апаратне шифрування через DPAPI
_ENC_VERSION = 3  # Current encryption format version / Текущая версия формата шифрования / Поточна версія формату шифрування
_ENC_METADATA_SIZE = 4  # Bytes for version and flags / Байт для версии и флагов / Байт для версії та прапорців


def _add_metadata(data: bytes, version: int = _ENC_VERSION, flags: int = 0) -> bytes:
    """Add tamper-evident metadata to encrypted data
    Добавляет метаданные с защитой от подделки к зашифрованным данным
    Додає метадані із захистом від підробки до зашифрованих даних"""
    try:
        # Format: version (2 bytes) + flags (2 bytes) + data
        # Формат: version (2 байта) + flags (2 байта) + data
        # Формат: version (2 байти) + flags (2 байти) + data
        header = struct.pack('>HH', version, flags)
        return header + data
    except (struct.error, TypeError, ValueError) as e:
        logger.error(f"Failed to add metadata: {e}")
        raise EncryptionError(f"Metadata addition failed: {e}")


def _extract_metadata(data: bytes) -> Tuple[bytes, int, int]:
    """Extract tamper-evident metadata from encrypted data
    Извлекает метаданные из зашифрованных данных
    Виймає метадані з зашифрованих даних"""
    if len(data) < _ENC_METADATA_SIZE:
        raise EncryptionVersionError("Data too short for metadata header")
    
    try:
        version = struct.unpack('>H', data[0:2])[0]
        flags = struct.unpack('>H', data[2:4])[0]
        return data[4:], version, flags
    except (struct.error, TypeError, ValueError, IndexError) as e:
        logger.error(f"Failed to extract metadata: {e}")
        raise EncryptionVersionError(f"Metadata extraction failed: {e}")


def _xor_stream(data: bytes, key: bytes, nonce: bytes) -> bytes:
    """XOR encryption for fallback / XOR шифрование для fallback / XOR шифрування для fallback"""
    # Pre-allocate bytearray with exact size to avoid quadratic complexity
    # Предварительно выделяем bytearray точного размера для избежания квадратичной сложности
    # Попередньо виділяємо bytearray точного розміру для уникнення квадратичної складності
    data_len = len(data)
    out = bytearray(data_len)
    counter = 0
    pos = 0
    
    try:
        while pos < data_len:
            counter_bytes = counter.to_bytes(8, "big")
            keystream = hmac.new(key, nonce + counter_bytes, hashlib.sha256).digest()
            chunk_size = min(len(keystream), data_len - pos)
            
            for i in range(chunk_size):
                out[pos + i] = data[pos + i] ^ keystream[i]
            
            pos += chunk_size
            counter += 1
        
        return bytes(out)
    except (TypeError, ValueError, MemoryError, OverflowError) as e:
        logger.error(f"XOR stream error: {e}")
        raise EncryptionError(f"XOR encryption failed: {e}")
    finally:
        _clear_bytes(key)


def _encrypt_fallback(plaintext: str, key: bytes) -> str:
    """Fallback encryption / Fallback шифрование / Fallback шифрування"""
    try:
        nonce = os.urandom(16)
        ct = _xor_stream(plaintext.encode("utf-8"), key, nonce)
        tag = hmac.new(key, nonce + ct, hashlib.sha256).digest()
        encrypted = nonce + tag + ct
        # Add metadata / Добавляем метаданные / Додаємо метадані
        encrypted_with_meta = _add_metadata(encrypted, version=1, flags=0)
        result = _FALLBACK_PREFIX + base64.b64encode(encrypted_with_meta).decode("ascii")
        _clear_bytes(ct)
        _clear_bytes(tag)
        _clear_string(plaintext)
        return result
    except (TypeError, ValueError, MemoryError, OSError, struct.error) as e:
        logger.error(f"Fallback encryption error: {e}")
        raise EncryptionError(f"Fallback encryption failed: {e}")


def _encrypt_hardware(plaintext: str) -> str:
    """Hardware-backed encryption (DPAPI) / Шифрование через аппаратное обеспечение (DPAPI) / Шифрування через апаратне забезпечення (DPAPI)"""
    if _DPAPI_AVAILABLE:
        try:
            encrypted = _dpapi_encrypt(plaintext.encode('utf-8'))
            if encrypted:
                # Add metadata / Добавляем метаданные / Додаємо метадані
                encrypted_with_meta = _add_metadata(encrypted, version=2, flags=1)
                result = _DPAPI_PREFIX + base64.b64encode(encrypted_with_meta).decode("ascii")
                _clear_string(plaintext)
                return result
        except (OSError, TypeError, ValueError, AttributeError, struct.error) as e:
            logger.error(f"Hardware encryption error: {e}")
    
    return _encrypt_fallback(plaintext, bytes(_get_machine_key()))


def _decrypt_hardware(value: str) -> str:
    """Hardware-backed decryption / Дешифрование через аппаратное обеспечение / Дешифрування через апаратне забезпечення"""
    try:
        if value.startswith(_DPAPI_PREFIX):
            raw = base64.b64decode(value[len(_DPAPI_PREFIX):])
            # Extract metadata / Извлекаем метаданные / Виймаємо метадані
            encrypted, version, flags = _extract_metadata(raw)
            decrypted = _dpapi_decrypt(encrypted)
            if decrypted:
                return decrypted.decode('utf-8')
    except (base64.binascii.Error, ValueError, UnicodeDecodeError, TypeError, EncryptionVersionError) as e:
        logger.error(f"Hardware decryption error: {e}")
        raise EncryptionError(f"Hardware decryption failed: {e}") from e
    
    raise EncryptionError("Hardware decryption failed")


def _decrypt_fallback(value: str, key: bytes) -> str:
    """Fallback decryption / Fallback дешифрование / Fallback дешифрування"""
    # Initialize variables BEFORE try block to avoid UnboundLocalError
    # Инициализируем переменные ДО блока try, чтобы избежать UnboundLocalError
    # Ініціалізуємо змінні ДО блоку try, щоб уникнути UnboundLocalError
    ct = b""
    tag = b""
    expected = b""
    
    try:
        raw = base64.b64decode(value[len(_FALLBACK_PREFIX):], validate=True)
        # Extract metadata / Извлекаем метаданные / Виймаємо метадані
        encrypted, version, flags = _extract_metadata(raw)
        
        if len(encrypted) < 48:
            raise ValueError("Invalid encrypted value length")
        nonce, tag, ct = encrypted[:16], encrypted[16:48], encrypted[48:]
        expected = hmac.new(key, nonce + ct, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, expected):
            raise TamperDetectedError("Encrypted value authentication failed - possible tampering")
        result = _xor_stream(ct, key, nonce).decode("utf-8")
        return result
    except (base64.binascii.Error, ValueError, UnicodeDecodeError, TypeError, struct.error, EncryptionVersionError) as e:
        logger.error(f"Fallback decryption error: {e}")
        raise EncryptionError(f"Invalid encrypted data: {e}") from e
    except TamperDetectedError:
        raise
    finally:
        _clear_bytes(ct)
        _clear_bytes(tag)
        _clear_bytes(expected)
        _clear_bytes(key)


def encrypt(plaintext: str, use_hardware: bool = False) -> str:
    """
    Encrypt a string.
    If use_hardware=True and DPAPI is available — uses hardware encryption.
    
    Шифрует строку.
    Если use_hardware=True и доступен DPAPI — использует аппаратное шифрование.
    
    Шифрує рядок.
    Якщо use_hardware=True та доступний DPAPI — використовує апаратне шифрування.
    """
    if not plaintext:
        return ""
    
    if use_hardware and _DPAPI_AVAILABLE:
        return _encrypt_hardware(plaintext)
    
    key = bytes(_active_key())
    if not _CRYPTO_OK:
        return _encrypt_fallback(plaintext, key)
    
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)
    ciphertext = None
    try:
        ciphertext = aesgcm.encrypt(nonce, plaintext.encode('utf-8'), None)
        # Add metadata / Добавляем метаданные / Додаємо метадані
        encrypted_with_meta = _add_metadata(nonce + ciphertext, version=3, flags=0)
        result = _ENC_PREFIX + base64.b64encode(encrypted_with_meta).decode('ascii')
        return result
    except InvalidTag as e:
        logger.error(f"Invalid tag during encryption: {e}")
        raise TamperDetectedError(f"Encryption authentication failed: {e}")
    except (TypeError, ValueError, MemoryError, RuntimeError, struct.error) as e:
        logger.error(f"Encrypt error: {e}")
        raise EncryptionError(f"Encryption failed: {e}")
    finally:
        _clear_bytes(key)
        _clear_string(plaintext)
        if ciphertext:
            _clear_bytes(ciphertext)


def decrypt(value: str) -> str:
    """
    Decrypt a string.
    If the string is not encrypted — returns as is.
    
    Дешифрует строку.
    Если строка не зашифрована — возвращает как есть.
    
    Дешифрує рядок.
    Якщо рядок не зашифрований — повертає як є.
    """
    if not value:
        return ""
    
    if not value.startswith(_ENC_PREFIX) and not value.startswith(_FALLBACK_PREFIX) and not value.startswith(_DPAPI_PREFIX):
        return value
    
    key = bytes(_active_key())
    result = value
    
    try:
        if value.startswith(_DPAPI_PREFIX):
            result = _decrypt_hardware(value)
            return result
        
        if value.startswith(_FALLBACK_PREFIX):
            result = _decrypt_fallback(value, key)
            return result
        
        if not _CRYPTO_OK:
            logger.warning("Cryptography not available, cannot decrypt AES-GCM")
            return value
        
        raw_b64 = value[len(_ENC_PREFIX):]
        data = base64.b64decode(raw_b64)
        
        # Extract metadata / Извлекаем метаданные / Виймаємо метадані
        encrypted, version, flags = _extract_metadata(data)
        
        if len(encrypted) < 12:
            raise ValueError("Invalid encrypted data length")
        nonce, ct = encrypted[:12], encrypted[12:]
        
        # Check length / Проверка длины / Перевірка довжини
        if len(nonce) != 12:
            raise ValueError("Invalid nonce length")
        
        aesgcm = AESGCM(key)
        result = aesgcm.decrypt(nonce, ct, None).decode('utf-8')
        return result
    except InvalidTag as e:
        logger.error(f"Invalid authentication tag - possible tampering: {e}")
        raise TamperDetectedError("Authentication failed - data may have been tampered") from e
    except (base64.binascii.Error, ValueError, UnicodeDecodeError, TypeError, EncryptionVersionError, struct.error) as e:
        logger.error(f"Decryption decode error: {e}")
        raise EncryptionError(f"Decryption failed: {e}") from e
    finally:
        _clear_bytes(key)
        if result != value:
            _clear_string(value)


def reencrypt_all(old_master: Optional[str], new_master: Optional[str]) -> None:
    """
    Reencrypt all sensitive fields in the current SQLite schema.
    Supports legacy plaintext rows and encrypted rows created with the previous key.
    """
    import sqlite3
    from storage.database import get_db_path

    global _master_key

    if old_master:
        try:
            set_key_from_master(old_master)
        except KeyDerivationError as e:
            logger.error(f"Failed to set key from old master: {e}")
            raise KeyRotationError(f"Cannot reencrypt: {e}") from e
    else:
        _zero(_master_key)
        _master_key = None

    db_path = get_db_path()
    if not os.path.exists(db_path):
        logger.info("Database file not found, nothing to reencrypt")
        return

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        rows = conn.execute("SELECT id, label, password, notes FROM passwords ORDER BY id").fetchall()
    except sqlite3.Error as e:
        logger.error(f"Database read error during reencrypt: {e}")
        raise KeyRotationError(f"Cannot read database: {e}") from e
    finally:
        if conn:
            conn.close()

    if not rows:
        logger.info("No records to reencrypt")
        return

    decrypted_records = []
    for record_id, label, encrypted_password, notes in rows:
        try:
            decrypted_records.append((
                record_id,
                decrypt(label or ""),
                decrypt(encrypted_password or ""),
                decrypt(notes or ""),
            ))
        except (ValueError, TypeError, EncryptionError, TamperDetectedError, EncryptionVersionError, UnicodeDecodeError) as e:
            logger.error(f"Decrypt error for id {record_id}: {e}")
            raise KeyRotationError(f"Cannot decrypt record {record_id}; rotation aborted") from e

    if new_master:
        try:
            set_key_from_master(new_master)
        except KeyDerivationError as e:
            logger.error(f"Failed to set key from new master: {e}")
            raise KeyRotationError(f"Cannot reencrypt: {e}") from e
    else:
        _zero(_master_key)
        _master_key = None

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("BEGIN EXCLUSIVE")
        for record_id, label, password, notes in decrypted_records:
            conn.execute(
                "UPDATE passwords SET label = ?, password = ?, notes = ?, updated = COALESCE(updated, datetime('now', 'localtime')) WHERE id = ?",
                (
                    encrypt(label) if label else "",
                    encrypt(password) if password else "",
                    encrypt(notes) if notes else "",
                    record_id,
                )
            )
        conn.commit()
        logger.info(f"Reencrypted {len(decrypted_records)} records")
    except (sqlite3.Error, EncryptionError) as e:
        if conn:
            try:
                conn.rollback()
            except sqlite3.Error:
                pass
        logger.error(f"Database write error during reencrypt: {e}")
        raise KeyRotationError(f"Reencryption failed: {e}") from e
    finally:
        if conn:
            conn.close()
        for _, label, password, notes in decrypted_records:
            _clear_string(label)
            _clear_string(password)
            _clear_string(notes)

def rotate_key(old_master: Optional[str], new_master: Optional[str], reason: str = "manual") -> bool:
    """
    Key rotation.
    Reencrypt all data with the new key.
    
    Ротация ключа шифрования.
    Перешифровывает все данные с новым ключом.
    
    Ротація ключа шифрування.
    Перешифровує всі дані з новим ключем.
    """
    try:
        import sqlite3
        old_version = _get_key_version()
        reencrypt_all(old_master, new_master)
        new_version = old_version + 1
        _set_key_version(new_version)
        _log_key_rotation(old_version, new_version, reason)
        logger.info(f"Key rotation completed, new version: {new_version}")
        return True
    except (ValueError, sqlite3.Error, OSError, IOError, EncryptionError, KeyRotationError, KeyDerivationError) as e:
        logger.error(f"Key rotation failed: {e}")
        return False


def get_key_rotation_history() -> List[Dict[str, Any]]:
    """Get key rotation history for audit
    Получить историю ротации ключей для аудита
    Отримати історію ротації ключів для аудиту"""
    global _key_rotation_history
    if not _key_rotation_history and os.path.exists(_KEY_ROTATION_LOG):
        try:
            with open(_KEY_ROTATION_LOG, 'r', encoding='utf-8') as f:
                _key_rotation_history = json.load(f)
        except (OSError, IOError, json.JSONDecodeError) as e:
            logger.debug(f"Failed to load key rotation history: {e}")
    return _key_rotation_history.copy()


def _zero(buf: Optional[bytearray]) -> None:
    """Zero out bytearray / Обнуляет bytearray / Обнуляє bytearray"""
    if buf is None:
        return
    try:
        ctypes.memset(
            (ctypes.c_char * len(buf)).from_buffer(buf), 0, len(buf))
        ctypes.memset(
            (ctypes.c_char * len(buf)).from_buffer(buf), 0, len(buf))
    except (TypeError, AttributeError, OSError, ValueError) as e:
        logger.debug(f"Zero buffer failed: {e}")
        try:
            for i in range(len(buf)):
                buf[i] = 0
        except (TypeError, IndexError, RuntimeError) as e2:
            logger.debug(f"Fallback zeroing failed: {e2}")


def _get_sqlcipher_salt() -> bytes:
    """Get or create SQLCipher salt / Получает или создаёт соль для SQLCipher / Отримує або створює сіль для SQLCipher"""
    if os.path.exists(_SQLCIPHER_SALT_FILE):
        try:
            content = secure_read(_SQLCIPHER_SALT_FILE)
            if content and len(content) == 32:
                return content
        except (OSError, IOError) as e:
            logger.error(f"Failed to read SQLCipher salt: {e}")
    
    # Generate new salt / Генерируем новую соль / Генеруємо нову сіль
    salt = os.urandom(32)
    _ensure_data_dir()
    _secure_write_file(_SQLCIPHER_SALT_FILE, salt)
    return salt


# ==================== CRYPTO SELF-TESTS / САМОПРОВЕРКА КРИПТОГРАФИИ / САМОПЕРЕВІРКА КРИПТОГРАФІЇ ====================

def _run_crypto_self_test() -> Dict[str, bool]:
    """Run comprehensive crypto self-test on initialization
    Запускает комплексный self-test криптографии при инициализации
    Запускає комплексний self-test криптографії при ініціалізації"""
    results = {
        "aes_gcm": False,
        "pbkdf2": False,
        "xor": False,
        "metadata": False,
        "versioning": False
    }
    
    try:
        test_data = "SecurePassPro_SelfTest_2024"
        
        # Test AES-GCM / Тест AES-GCM / Тест AES-GCM
        if _CRYPTO_OK:
            test_key = os.urandom(32)
            aesgcm = AESGCM(test_key)
            nonce = os.urandom(12)
            ciphertext = aesgcm.encrypt(nonce, test_data.encode('utf-8'), None)
            decrypted = aesgcm.decrypt(nonce, ciphertext, None).decode('utf-8')
            if decrypted == test_data:
                results["aes_gcm"] = True
                logger.debug("AES-GCM self-test passed")
            else:
                logger.error("AES-GCM self-test failed: decrypt mismatch")
        
        # Test PBKDF2 / Тест PBKDF2 / Тест PBKDF2
        test_salt = os.urandom(16)
        test_secret = b"test_secret"
        derived = hashlib.pbkdf2_hmac('sha256', test_secret, test_salt, 1000, dklen=32)
        if len(derived) == 32:
            results["pbkdf2"] = True
            logger.debug("PBKDF2 self-test passed")
        else:
            logger.error("PBKDF2 self-test failed: wrong length")
        
        # Test XOR fallback / Тест XOR fallback / Тест XOR fallback
        test_key_fb = os.urandom(32)
        test_nonce = os.urandom(16)
        test_plain = b"test_plaintext"
        encrypted = _xor_stream(test_plain, test_key_fb, test_nonce)
        decrypted = _xor_stream(encrypted, test_key_fb, test_nonce)
        if decrypted == test_plain:
            results["xor"] = True
            logger.debug("XOR self-test passed")
        else:
            logger.error("XOR self-test failed: decrypt mismatch")
        
        # Test metadata addition/extraction / Тест добавления/извлечения метаданных / Тест додавання/виймання метаданих
        test_metadata = b"test_metadata_data"
        with_meta = _add_metadata(test_metadata, version=5, flags=1)
        extracted, version, flags = _extract_metadata(with_meta)
        if extracted == test_metadata and version == 5 and flags == 1:
            results["metadata"] = True
            logger.debug("Metadata self-test passed")
        else:
            logger.error("Metadata self-test failed")
        
        # Test versioning / Тест версионирования / Тест версіонування
        results["versioning"] = True
        
        passed = sum(1 for v in results.values() if v)
        logger.info(f"Crypto self-tests: {passed}/{len(results)} passed")
        return results
        
    except (ImportError, OSError, TypeError, ValueError, MemoryError, struct.error, InvalidTag) as e:
        logger.error(f"Crypto self-test failed: {e}")
        return results


# Run self-test on module import / Запускаем self-test при импорте модуля / Запускаємо self-test при імпорті модуля
_CRYPTO_SELF_TEST_RESULTS = _run_crypto_self_test() if _CRYPTO_OK else {}
_CRYPTO_SELF_TEST_PASSED = all(_CRYPTO_SELF_TEST_RESULTS.values()) if _CRYPTO_OK else False
if _CRYPTO_OK and not _CRYPTO_SELF_TEST_PASSED:
    logger.warning("Crypto self-test failed - encryption may be unreliable")
    for test_name, passed in _CRYPTO_SELF_TEST_RESULTS.items():
        if not passed:
            logger.warning(f"  - {test_name}: FAILED")


# ==================== SQLCipher SUPPORT / ПОДДЕРЖКА SQLCipher / ПІДТРИМКА SQLCipher ====================

def set_sqlcipher_key(master_password: str, salt: Optional[bytes] = None) -> None:
    """Set SQLCipher encryption key derived from master password
    Устанавливает ключ шифрования SQLCipher, полученный из мастер-пароля
    Встановлює ключ шифрування SQLCipher, отриманий з майстер-пароля"""
    global _sqlcipher_key, _sqlcipher_key_hex, _sqlcipher_salt
    
    if not _sqlcipher_available:
        logger.warning("SQLCipher not available, cannot set key")
        return
    
    if salt is None:
        _sqlcipher_salt = _get_sqlcipher_salt()
    else:
        _sqlcipher_salt = salt
    
    # FIXED #55: Use weaker SCrypt parameters for SQLCipher (performance)
    # Исправлено #55: Используем более слабые параметры SCrypt для SQLCipher (производительность)
    # Виправлено #55: Використовуємо більш слабкі параметри SCrypt для SQLCipher (продуктивність)
    try:
        # Use SCrypt if available for better security, but with lower parameters for performance
        # Используем SCrypt если доступен для лучшей безопасности, но с более низкими параметрами для производительности
        # Використовуємо SCrypt якщо доступний для кращої безпеки, але з більш низькими параметрами для продуктивності
        key = _scrypt_derive(
            master_password.encode('utf-8'),
            _sqlcipher_salt,
            n=SCRYPT_SQLCIPHER_N,
            r=SCRYPT_SQLCIPHER_R,
            p=SCRYPT_SQLCIPHER_P
        )
        if key is None:
            key = _pbkdf2(
                master_password.encode('utf-8'),
                _sqlcipher_salt,
                iterations=PBKDF2_ITERATIONS_SQLCIPHER)
        _sqlcipher_key = bytearray(key)  # Convert to mutable bytearray
        _sqlcipher_key_hex = None  # Do not store hex string at all
        
        try:
            from storage.database import set_sqlcipher_key as db_set_key
            db_set_key(master_password)
        except ImportError as e:
            logger.debug(f"Database module not available: {e}")
    except (ValueError, TypeError, MemoryError, RuntimeError) as e:
        logger.error(f"Failed to set SQLCipher key: {e}")
        raise KeyDerivationError(f"SQLCipher key derivation failed: {e}")


def clear_sqlcipher_key() -> None:
    """
    Clear SQLCipher encryption key from memory with secure zeroing.
    FIXED #5 & #6: Properly clear mutable bytearray key.
    
    Очищает ключ шифрования SQLCipher из памяти с безопасным обнулением.
    Исправлено #5 и #6: Правильно очищаем изменяемый bytearray ключ.
    
    Очищує ключ шифрування SQLCipher з пам'яті з безпечним обнуленням.
    Виправлено #5 та #6: Правильно очищуємо змінний bytearray ключ.
    """
    global _sqlcipher_key, _sqlcipher_key_hex
    
    if _sqlcipher_key:
        try:
            # Multiple overwrite passes for security
            # Несколько проходов перезаписи для безопасности
            # Декілька проходів перезапису для безпеки
            for _ in range(3):
                # Fill with random data first / Сначала заполняем случайными данными / Спочатку заповнюємо випадковими даними
                for i in range(len(_sqlcipher_key)):
                    try:
                        _sqlcipher_key[i] = os.urandom(1)[0]
                    except (IndexError, OSError, TypeError):
                        pass
                # Then zero out / Затем обнуляем / Потім обнуляємо
                for i in range(len(_sqlcipher_key)):
                    try:
                        _sqlcipher_key[i] = 0
                    except (IndexError, TypeError):
                        pass
                _secure_zero(_sqlcipher_key)
        except (TypeError, ValueError, AttributeError, MemoryError, OSError) as e:
            logger.debug(f"SQLCipher key secure zeroing error: {e}")
            try:
                _secure_zero(_sqlcipher_key)
            except (TypeError, ValueError, AttributeError):
                pass
        _sqlcipher_key = None
    
    _sqlcipher_key_hex = None


def get_sqlcipher_key() -> Optional[bytes]:
    """
    Get current SQLCipher key as bytes (returns a copy).
    Получить текущий ключ SQLCipher как bytes (возвращает копию).
    Отримати поточний ключ SQLCipher як bytes (повертає копію).
    
    NOTE: Returns a copy of the key. Caller must clear it after use.
    ПРИМЕЧАНИЕ: Возвращает копию ключа. Вызывающий код должен очистить его после использования.
    УВАГА: Повертає копію ключа. Викликаючий код повинен очистити його після використання.
    """
    if _sqlcipher_key is None:
        return None
    return bytes(_sqlcipher_key)


def get_sqlcipher_key_hex() -> Optional[str]:
    """
    Get current SQLCipher key as hex string (temporary, not stored).
    Use with caution - hex string cannot be securely cleared.
    
    Получить текущий ключ SQLCipher в виде hex строки (временный, не хранится).
    Используйте с осторожностью - hex строку нельзя безопасно очистить.
    
    Отримати поточний ключ SQLCipher у вигляді hex рядка (тимчасовий, не зберігається).
    Використовуйте з обережністю - hex рядок не можна безпечно очистити.
    """
    if _sqlcipher_key is None:
        return None
    return bytes(_sqlcipher_key).hex()


def get_sqlcipher_salt() -> Optional[bytes]:
    """Get SQLCipher salt / Получить соль SQLCipher / Отримати сіль SQLCipher"""
    if _sqlcipher_salt:
        return _sqlcipher_salt
    return _get_sqlcipher_salt()


def is_sqlcipher_available() -> bool:
    """Check if SQLCipher is available / Проверить, доступен ли SQLCipher / Перевірити, чи доступний SQLCipher"""
    return _sqlcipher_available


def is_dpapi_available() -> bool:
    """Check if DPAPI is available / Проверить, доступен ли DPAPI / Перевірити, чи доступний DPAPI"""
    return _DPAPI_AVAILABLE


def get_key_version() -> int:
    """Get current key version / Получить текущую версию ключа / Отримати поточну версію ключа"""
    return _get_key_version()


def get_encryption_version() -> int:
    """Get current encryption format version / Получить текущую версию формата шифрования / Отримати поточну версію формату шифрування"""
    return _ENC_VERSION


def verify_encryption() -> bool:
    """Verify encryption is working / Проверяет работоспособность шифрования / Перевіряє працездатність шифрування"""
    test_data = "test_data_123"
    try:
        encrypted = encrypt(test_data)
        decrypted = decrypt(encrypted)
        return decrypted == test_data
    except (ValueError, TypeError, EncryptionError, TamperDetectedError, EncryptionVersionError) as e:
        logger.error(f"Encryption verification failed: {e}")
        return False
    except (UnicodeDecodeError, AttributeError) as e:
        logger.error(f"Encryption verification error: {e}")
        return False


def get_crypto_self_test_results() -> Dict[str, bool]:
    """Get crypto self-test results / Получить результаты self-test криптографии / Отримати результати self-test криптографії"""
    return _CRYPTO_SELF_TEST_RESULTS.copy() if _CRYPTO_OK else {}